#include <external.h>
#include <base_module.h>
#include "http.h"
#include "router.h"

#define DEFAULT_PORT 3000
#define DEFAULT_ROOT "./pages"
#define SERVER_MEM_SIZE (10 * 1024 * 1024)  // 10 MB persistent
#define REQUEST_MEM_SIZE (1 * 1024 * 1024)  // 1 MB per request
#define TCP_LISTEN_BACKLOG 10

/**
 * Server configuration parsed from command line arguments
 */
typedef struct ServerConfig {
    i32 port;
    Str *docRoot;
} ServerConfig;

/**
 * Parse command-line arguments
 *
 * Supports:
 *   --port <number>    Server port (default: 3000)
 *   --root <path>      Document root directory (default: ./pages)
 *
 * @param m Memory chapter for allocations
 * @param argc Argument count
 * @param argv Argument vector
 * @return ServerConfig with parsed values
 */
static ServerConfig* parseArgs(MemCh *m, int argc, char **argv) {
    ServerConfig *cfg = MemCh_Alloc(m, sizeof(ServerConfig));
    cfg->port = DEFAULT_PORT;
    cfg->docRoot = S(m, DEFAULT_ROOT);

    // Simple argument parsing
    for (i32 i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--port") == 0 && i + 1 < argc) {
            cfg->port = atoi(argv[i + 1]);
            i++; // Skip next arg
        } else if (strcmp(argv[i], "--root") == 0 && i + 1 < argc) {
            cfg->docRoot = S(m, argv[i + 1]);
            i++; // Skip next arg
        } else if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            printf("Caneka Docs Server\n\n");
            printf("Usage: %s [options]\n\n", argv[0]);
            printf("Options:\n");
            printf("  --port <number>    Server port (default: 3000)\n");
            printf("  --root <path>      Document root directory (default: ./pages)\n");
            printf("  --help, -h         Show this help message\n\n");
            printf("Examples:\n");
            printf("  %s\n", argv[0]);
            printf("  %s --port 8080\n", argv[0]);
            printf("  %s --port 8080 --root /var/www/docs\n\n", argv[0]);
            exit(0);
        } else {
            fprintf(stderr, "Unknown argument: %s\n", argv[i]);
            fprintf(stderr, "Use --help for usage information\n");
            exit(1);
        }
    }

    // Validate port range
    if (cfg->port < 1 || cfg->port > 65535) {
        fprintf(stderr, "Error: Port must be between 1 and 65535\n");
        exit(1);
    }

    return cfg;
}

/**
 * Create and configure TCP server socket
 *
 * Sets up socket with:
 * - AF_INET (IPv4)
 * - SOCK_STREAM (TCP)
 * - SO_REUSEADDR (allow quick restart)
 * - Bind to INADDR_ANY on specified port
 * - Listen with backlog of 10
 *
 * @param port Port number to bind to
 * @return Socket file descriptor, or -1 on error
 */
static i32 createServerSocket(i32 port) {
    i32 sockfd;
    struct sockaddr_in servAddr;
    i32 opt = 1;

    // Create socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        fprintf(stderr, "Error creating socket: %s\n", strerror(errno));
        return -1;
    }

    // Set SO_REUSEADDR to allow quick restart (avoids TIME_WAIT)
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        fprintf(stderr, "Error setting SO_REUSEADDR: %s\n", strerror(errno));
        close(sockfd);
        return -1;
    }

    // Configure server address
    memset(&servAddr, 0, sizeof(servAddr));
    servAddr.sin_family = AF_INET;
    servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servAddr.sin_port = htons(port);

    // Bind to port
    if (bind(sockfd, (struct sockaddr*)&servAddr, sizeof(servAddr)) != 0) {
        if (errno == EADDRINUSE) {
            fprintf(stderr, "Error: Port %d is already in use\n", port);
            fprintf(stderr, "Try a different port with --port <number>\n");
        } else {
            fprintf(stderr, "Error binding to port %d: %s\n", port, strerror(errno));
        }
        close(sockfd);
        return -1;
    }

    // Start listening
    if (listen(sockfd, TCP_LISTEN_BACKLOG) != 0) {
        fprintf(stderr, "Error listening on socket: %s\n", strerror(errno));
        close(sockfd);
        return -1;
    }

    return sockfd;
}

/**
 * Handle a single HTTP request
 *
 * This is a stub for now - will be implemented in later tickets.
 * Currently just reads from socket and sends a basic response.
 *
 * @param m Request-scoped memory chapter
 * @param clientfd Client socket file descriptor
 * @param cfg Server configuration
 * @param router URL router
 */
static void handleRequest(MemCh *m, i32 clientfd, ServerConfig *cfg, Router *router) {
    char buffer[8192];
    ssize_t bytesRead;

    // Read request from socket
    bytesRead = read(clientfd, buffer, sizeof(buffer) - 1);
    if (bytesRead < 0) {
        fprintf(stderr, "Error reading from socket: %s\n", strerror(errno));
        return;
    }
    buffer[bytesRead] = '\0';

    // Split request into lines
    StrVec *lines = StrVec_Make(m);
    Str *rawRequest = Str_From(m, (byte*)buffer, bytesRead);

    i32 lineStart = 0;
    for (i32 i = 0; i < rawRequest->length; i++) {
        if (rawRequest->bytes[i] == '\r' && i + 1 < rawRequest->length && rawRequest->bytes[i + 1] == '\n') {
            // Found CRLF - extract line
            i32 lineLen = i - lineStart;
            Str *line = Str_From(m, rawRequest->bytes + lineStart, lineLen);
            StrVec_Add(lines, line);

            // Skip \r\n
            i++;
            lineStart = i + 1;
        }
    }

    // Parse HTTP request
    HttpRequest *req = Http_ParseRequest(m, lines);
    if (req == NULL) {
        const char *errorResp =
            "HTTP/1.1 400 Bad Request\r\n"
            "Content-Type: text/plain\r\n"
            "Content-Length: 15\r\n"
            "\r\n"
            "Bad Request\r\n";
        write(clientfd, errorResp, strlen(errorResp));
        return;
    }

    // Log request
    printf("[%s] %s\n",
        req->method == HTTP_GET ? "GET" : (req->method == HTTP_POST ? "POST" : "???"),
        Str_Cstr(m, req->path));

    // Route request to handler
    HttpResponse *resp = Router_Handle(router, m, req);

    // Generate response as StrVec (supports chunked writing for large bodies)
    StrVec *respVec = Http_GenerateResponseVec(m, resp);

    // Write each chunk separately to avoid MEM_SLAB_SIZE (~4KB) limitation
    Iter it;
    Iter_Init(&it, respVec->p);
    while ((Iter_Next(&it) & END) == 0) {
        Str *chunk = Iter_Get(&it);
        if (chunk != NULL && chunk->length > 0) {
            write(clientfd, chunk->bytes, chunk->length);
        }
    }
}

/**
 * Main server loop
 *
 * Accepts connections in a loop, allocates per-request memory,
 * handles the request, then cleans up.
 *
 * This is blocking and single-threaded - handles one request at a time.
 *
 * @param sockfd Server socket file descriptor
 * @param cfg Server configuration
 * @param router URL router
 */
static void runServer(i32 sockfd, ServerConfig *cfg, Router *router) {
    MemBook *memBook = MemBook_Make(NULL);
    if (memBook == NULL) {
        fprintf(stderr, "Fatal: Could not create MemBook\n");
        exit(1);
    }

    MemCh *serverMem = MemCh_Make();
    if (serverMem == NULL) {
        fprintf(stderr, "Fatal: Could not create server MemCh\n");
        exit(1);
    }

    printf("Server running on port %d\n", cfg->port);
    printf("Document root: %s\n", Str_Cstr(serverMem, cfg->docRoot));
    printf("Press Ctrl+C to stop\n\n");

    i32 requestCount = 0;

    while (1) {
        struct sockaddr_in clientAddr;
        socklen_t clientLen = sizeof(clientAddr);

        // Accept connection
        i32 clientfd = accept(sockfd, (struct sockaddr*)&clientAddr, &clientLen);
        if (clientfd < 0) {
            fprintf(stderr, "Error accepting connection: %s\n", strerror(errno));
            continue; // Try to accept next connection
        }

        requestCount++;
        printf("[Request #%d] Accepted connection from %s:%d\n",
               requestCount,
               inet_ntoa(clientAddr.sin_addr),
               ntohs(clientAddr.sin_port));

        // Allocate per-request memory
        MemCh *reqMem = MemCh_Make();
        if (reqMem == NULL) {
            fprintf(stderr, "Error: Could not allocate request memory\n");
            close(clientfd);
            continue;
        }

        // Handle the request
        handleRequest(reqMem, clientfd, cfg, router);

        // Clean up
        close(clientfd);
        MemCh_Free(reqMem);

        printf("[Request #%d] Completed and cleaned up\n\n", requestCount);
    }

    // Unreachable in normal operation, but included for completeness
    MemCh_Free(serverMem);
    MemBook_WipePages(memBook);
}

/**
 * Main entry point
 *
 * 1. Parse command-line arguments
 * 2. Initialize router
 * 3. Create and bind TCP socket
 * 4. Run server loop
 */
i32 main(int argc, char **argv) {
    MemBook *memBook = MemBook_Make(NULL);
    if (memBook == NULL) {
        fprintf(stderr, "Fatal: Could not create MemBook\n");
        return 1;
    }

    MemCh *m = MemCh_Make();
    if (m == NULL) {
        fprintf(stderr, "Fatal: Could not create MemCh\n");
        return 1;
    }

    // Parse arguments
    ServerConfig *cfg = parseArgs(m, argc, argv);

    printf("Caneka Docs Server\n");
    printf("==================\n\n");

    // Create router and register routes
    Router *router = Router_Make(m, cfg->docRoot);

    // Register route handlers (CDOCS-012)
    // Order matters: more specific routes first!
    Router_Add(router, S(m, "/test"), Handler_SmokeTest);      // CDOCS-015a smoke test
    Router_Add(router, S(m, "/docs/"), Handler_Markdown);
    Router_Add(router, S(m, "/static/"), Handler_Static);
    Router_Add(router, S(m, "/"), Handler_IndexRedirect);

    printf("Registered routes:\n");
    printf("  /test -> Smoke test (CDOCS-015a)\n");
    printf("  /docs/ -> Markdown handler\n");
    printf("  /static/ -> Static file handler\n");
    printf("  / -> Index redirect (fallback)\n\n");

    // Create and configure TCP socket
    i32 sockfd = createServerSocket(cfg->port);
    if (sockfd < 0) {
        fprintf(stderr, "Fatal: Could not create server socket\n");
        return 1;
    }

    // Run server loop (blocks until Ctrl+C)
    runServer(sockfd, cfg, router);

    // Clean up (unreachable in normal operation)
    close(sockfd);
    MemCh_Free(m);
    MemBook_WipePages(memBook);

    return 0;
}
