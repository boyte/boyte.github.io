#include <external.h>
#include <base_module.h>
#include "http.h"

/**
 * HTTP stub implementations for CDOCS-010
 * Full implementation will be in CDOCS-011 and CDOCS-013
 */

/**
 * Create HTTP 404 Not Found response
 */
HttpResponse* Http_NotFound(MemCh *m) {
    return Http_NewResponse(m, 404, S(m, "text/plain"), S(m, "404 Not Found"));
}

/**
 * Create HTTP 403 Forbidden response
 */
HttpResponse* Http_Forbidden(MemCh *m) {
    return Http_NewResponse(m, 403, S(m, "text/plain"), S(m, "403 Forbidden"));
}

/**
 * Create HTTP 500 Internal Server Error response
 */
HttpResponse* Http_InternalError(MemCh *m, Str *error) {
    Str *body = Str_Make(m, 512);
    Str_AddCstr(body, "500 Internal Server Error\n");
    Str_Add(body, error->bytes, error->length);
    return Http_NewResponse(m, 500, S(m, "text/plain"), body);
}

/**
 * Create HTTP 301 Permanent Redirect response
 */
HttpResponse* Http_Redirect(MemCh *m, Str *location) {
    HttpResponse *resp = MemCh_Alloc(m, sizeof(HttpResponse));
    resp->statusCode = 301;
    resp->statusText = S(m, "Moved Permanently");
    resp->contentType = S(m, "text/plain");
    resp->body = S(m, "Redirecting...");
    resp->headers = Table_Make(m);
    Table_Set(resp->headers, S(m, "Location"), location);
    return resp;
}

/**
 * Create a new HTTP response with common defaults
 */
HttpResponse* Http_NewResponse(MemCh *m, i32 code, Str *contentType, Str *body) {
    HttpResponse *resp = MemCh_Alloc(m, sizeof(HttpResponse));
    resp->statusCode = code;
    resp->contentType = contentType;
    resp->body = body;
    resp->bodyVec = NULL;  // Initialize to NULL (use body OR bodyVec, not both)
    resp->headers = Table_Make(m);

    // Set status text based on code
    switch (code) {
        case 200: resp->statusText = S(m, "OK"); break;
        case 301: resp->statusText = S(m, "Moved Permanently"); break;
        case 403: resp->statusText = S(m, "Forbidden"); break;
        case 404: resp->statusText = S(m, "Not Found"); break;
        case 500: resp->statusText = S(m, "Internal Server Error"); break;
        default:  resp->statusText = S(m, "Unknown"); break;
    }

    return resp;
}

HttpResponse* Http_NewResponseVec(MemCh *m, i32 code, Str *contentType, StrVec *bodyVec) {
    HttpResponse *resp = MemCh_Alloc(m, sizeof(HttpResponse));
    resp->statusCode = code;
    resp->contentType = contentType;
    resp->body = NULL;      // NULL when using bodyVec
    resp->bodyVec = bodyVec;
    resp->headers = Table_Make(m);

    // Set status text based on code
    switch (code) {
        case 200: resp->statusText = S(m, "OK"); break;
        case 301: resp->statusText = S(m, "Moved Permanently"); break;
        case 403: resp->statusText = S(m, "Forbidden"); break;
        case 404: resp->statusText = S(m, "Not Found"); break;
        case 500: resp->statusText = S(m, "Internal Server Error"); break;
        default:  resp->statusText = S(m, "Unknown"); break;
    }

    return resp;
}

/**
 * Parse HTTP method from string
 */
static HttpMethod parseMethod(Str *methodStr) {
    if (methodStr->length == 3 &&
        methodStr->bytes[0] == 'G' &&
        methodStr->bytes[1] == 'E' &&
        methodStr->bytes[2] == 'T') {
        return HTTP_GET;
    }
    if (methodStr->length == 4 &&
        methodStr->bytes[0] == 'P' &&
        methodStr->bytes[1] == 'O' &&
        methodStr->bytes[2] == 'S' &&
        methodStr->bytes[3] == 'T') {
        return HTTP_POST;
    }
    if (methodStr->length == 4 &&
        methodStr->bytes[0] == 'H' &&
        methodStr->bytes[1] == 'E' &&
        methodStr->bytes[2] == 'A' &&
        methodStr->bytes[3] == 'D') {
        return HTTP_HEAD;
    }
    return HTTP_UNKNOWN;
}

/**
 * Parse HTTP request line (GET /path HTTP/1.1)
 * Returns SUCCESS if parsed, ERROR otherwise
 */
static status parseRequestLine(MemCh *m, Str *line, HttpRequest *req) {
    // Find first space (end of method)
    i32 methodEnd = -1;
    i32 pathEnd = -1;

    for (i32 i = 0; i < line->length; i++) {
        if (line->bytes[i] == ' ') {
            if (methodEnd == -1) {
                methodEnd = i;
            } else if (pathEnd == -1) {
                pathEnd = i;
                break;
            }
        }
    }

    if (methodEnd == -1 || pathEnd == -1) {
        return ERROR;
    }

    // Extract method
    Str *methodStr = Str_From(m, line->bytes, methodEnd);
    req->method = parseMethod(methodStr);

    // Extract path
    i32 pathLen = pathEnd - methodEnd - 1;
    req->path = Str_From(m, line->bytes + methodEnd + 1, pathLen);

    // Extract version
    i32 versionLen = line->length - pathEnd - 1;
    req->version = Str_From(m, line->bytes + pathEnd + 1, versionLen);

    return SUCCESS;
}

/**
 * Parse HTTP header line (Name: Value)
 * Returns SUCCESS if parsed, ERROR otherwise
 */
static status parseHeaderLine(MemCh *m, Str *line, Table *headers) {
    // Find colon
    i32 colonPos = -1;
    for (i32 i = 0; i < line->length; i++) {
        if (line->bytes[i] == ':') {
            colonPos = i;
            break;
        }
    }

    if (colonPos == -1) {
        return ERROR;
    }

    // Extract header name
    Str *name = Str_From(m, line->bytes, colonPos);

    // Extract header value (skip colon and optional space)
    i32 valueStart = colonPos + 1;
    while (valueStart < line->length && line->bytes[valueStart] == ' ') {
        valueStart++;
    }

    i32 valueLen = line->length - valueStart;
    Str *value = Str_From(m, line->bytes + valueStart, valueLen);

    // Add to headers table
    Table_Set(headers, name, value);

    return SUCCESS;
}

/**
 * Parse HTTP request from string lines
 *
 * Expected format:
 *   Line 0: Request line (GET /path HTTP/1.1)
 *   Line 1+: Headers (Name: Value)
 *   Empty line marks end of headers
 *   Remaining lines: Body (for POST)
 */
HttpRequest* Http_ParseRequest(MemCh *m, StrVec *lines) {
    if (lines == NULL || lines->total == 0) {
        return NULL;
    }

    HttpRequest *req = MemCh_Alloc(m, sizeof(HttpRequest));
    req->method = HTTP_UNKNOWN;
    req->path = S(m, "/");
    req->version = S(m, "HTTP/1.1");
    req->headers = Table_Make(m);
    req->body = S(m, "");

    // Parse request line (first line)
    Str *requestLine = Span_Get(lines->p, 0);
    if (parseRequestLine(m, requestLine, req) != SUCCESS) {
        return NULL;
    }

    // Parse headers (subsequent lines until empty line)
    i32 bodyStart = -1;
    for (i32 i = 1; i < lines->total; i++) {
        Str *line = Span_Get(lines->p, i);

        // Empty line marks end of headers
        if (line->length == 0) {
            bodyStart = i + 1;
            break;
        }

        parseHeaderLine(m, line, req->headers);
    }

    // Parse body (if POST and body exists)
    if (req->method == HTTP_POST && bodyStart > 0 && bodyStart < lines->total) {
        Str *body = Str_Make(m, 1024);
        for (i32 i = bodyStart; i < lines->total; i++) {
            Str *line = Span_Get(lines->p, i);
            Str_Add(body, line->bytes, line->length);
            if (i < lines->total - 1) {
                Str_AddCstr(body, "\n");
            }
        }
        req->body = body;
    }

    return req;
}

/**
 * Generate HTTP response string from HttpResponse structure
 *
 * Creates a complete HTTP response with status line, headers, and body.
 * All lines are terminated with CRLF (\r\n) as per HTTP/1.1 spec.
 */
Str* Http_GenerateResponse(MemCh *m, HttpResponse *resp) {
    if (resp == NULL) {
        return S(m, "HTTP/1.1 500 Internal Server Error\r\nContent-Length: 0\r\n\r\n");
    }

    Str *result = Str_Make(m, 2048);

    // Status line: HTTP/1.1 CODE TEXT\r\n
    Str_AddCstr(result, "HTTP/1.1 ");
    
    // Add status code and text
    if (resp->statusCode == 200) {
        Str_AddCstr(result, "200 ");
        Str_Add(result, resp->statusText->bytes, resp->statusText->length);
    } else if (resp->statusCode == 301) {
        Str_AddCstr(result, "301 ");
        Str_Add(result, resp->statusText->bytes, resp->statusText->length);
    } else if (resp->statusCode == 403) {
        Str_AddCstr(result, "403 ");
        Str_Add(result, resp->statusText->bytes, resp->statusText->length);
    } else if (resp->statusCode == 404) {
        Str_AddCstr(result, "404 ");
        Str_Add(result, resp->statusText->bytes, resp->statusText->length);
    } else if (resp->statusCode == 500) {
        Str_AddCstr(result, "500 ");
        Str_Add(result, resp->statusText->bytes, resp->statusText->length);
    } else {
        // Fallback for unknown codes
        Str_AddCstr(result, "500 Internal Server Error");
    }
    Str_AddCstr(result, "\r\n");

    // Content-Type header
    Str_AddCstr(result, "Content-Type: ");
    Str_Add(result, resp->contentType->bytes, resp->contentType->length);
    Str_AddCstr(result, "\r\n");

    // Content-Length header
    Str_AddCstr(result, "Content-Length: ");
    i64 bodyLen = resp->body != NULL ? resp->body->length : 0;
    Str *lengthStr = Str_Make(m, 32);
    
    // Convert bodyLen to string manually
    char lenBuf[32];
    snprintf(lenBuf, sizeof(lenBuf), "%lld", bodyLen);
    Str_AddCstr(lengthStr, lenBuf);
    
    Str_Add(result, lengthStr->bytes, lengthStr->length);
    Str_AddCstr(result, "\r\n");

    // Additional headers (like Location for redirects)
    if (resp->headers != NULL && resp->headers->nvalues > 0) {
        Iter it;
        Iter_Init(&it, resp->headers);
        while ((Iter_Next(&it) & END) == 0) {
            Hashed *h = Iter_Get(&it);
            if (h != NULL && h->key != NULL && h->value != NULL) {
                Str *name = (Str *)h->key;
                Str *value = (Str *)h->value;
                
                Str_Add(result, name->bytes, name->length);
                Str_AddCstr(result, ": ");
                Str_Add(result, value->bytes, value->length);
                Str_AddCstr(result, "\r\n");
            }
        }
    }

    // Blank line separating headers from body
    Str_AddCstr(result, "\r\n");

    // Body
    if (resp->body != NULL && resp->body->length > 0) {
        Str_Add(result, resp->body->bytes, resp->body->length);
    }

    return result;
}

/**
 * Generate HTTP response as StrVec for chunked writing
 *
 * This avoids MEM_SLAB_SIZE (~4KB) limitation by returning response in chunks.
 * First chunk is headers, remaining chunks are body parts.
 */
StrVec* Http_GenerateResponseVec(MemCh *m, HttpResponse *resp) {
    if (resp == NULL) {
        StrVec *vec = StrVec_Make(m);
        StrVec_Add(vec, S(m, "HTTP/1.1 500 Internal Server Error\r\nContent-Length: 0\r\n\r\n"));
        return vec;
    }

    // Create StrVec for response chunks
    StrVec *result = StrVec_Make(m);

    // Build headers (status line + headers + blank line)
    Str *headers = Str_Make(m, 1024);

    // Status line: HTTP/1.1 CODE TEXT\r\n
    Str_AddCstr(headers, "HTTP/1.1 ");

    // Add status code and text
    if (resp->statusCode == 200) {
        Str_AddCstr(headers, "200 ");
        Str_Add(headers, resp->statusText->bytes, resp->statusText->length);
    } else if (resp->statusCode == 301) {
        Str_AddCstr(headers, "301 ");
        Str_Add(headers, resp->statusText->bytes, resp->statusText->length);
    } else if (resp->statusCode == 403) {
        Str_AddCstr(headers, "403 ");
        Str_Add(headers, resp->statusText->bytes, resp->statusText->length);
    } else if (resp->statusCode == 404) {
        Str_AddCstr(headers, "404 ");
        Str_Add(headers, resp->statusText->bytes, resp->statusText->length);
    } else if (resp->statusCode == 500) {
        Str_AddCstr(headers, "500 ");
        Str_Add(headers, resp->statusText->bytes, resp->statusText->length);
    } else {
        Str_AddCstr(headers, "500 Internal Server Error");
    }
    Str_AddCstr(headers, "\r\n");

    // Content-Type header
    Str_AddCstr(headers, "Content-Type: ");
    Str_Add(headers, resp->contentType->bytes, resp->contentType->length);
    Str_AddCstr(headers, "\r\n");

    // Content-Length header - calculate from body or bodyVec
    i64 bodyLen = 0;
    if (resp->body != NULL) {
        bodyLen = resp->body->length;
    } else if (resp->bodyVec != NULL) {
        bodyLen = resp->bodyVec->total;
    }

    Str_AddCstr(headers, "Content-Length: ");
    char lenBuf[32];
    snprintf(lenBuf, sizeof(lenBuf), "%lld", bodyLen);
    Str_AddCstr(headers, lenBuf);
    Str_AddCstr(headers, "\r\n");

    // Additional headers (like Location for redirects)
    if (resp->headers != NULL && resp->headers->nvalues > 0) {
        Iter it;
        Iter_Init(&it, resp->headers);
        while ((Iter_Next(&it) & END) == 0) {
            Hashed *h = Iter_Get(&it);
            if (h != NULL && h->key != NULL && h->value != NULL) {
                Str *name = (Str *)h->key;
                Str *value = (Str *)h->value;

                Str_Add(headers, name->bytes, name->length);
                Str_AddCstr(headers, ": ");
                Str_Add(headers, value->bytes, value->length);
                Str_AddCstr(headers, "\r\n");
            }
        }
    }

    // Blank line separating headers from body
    Str_AddCstr(headers, "\r\n");

    // Add headers as first chunk
    StrVec_Add(result, headers);

    // Add body chunks
    if (resp->bodyVec != NULL) {
        // Add each chunk from bodyVec
        Iter it;
        Iter_Init(&it, resp->bodyVec->p);
        while ((Iter_Next(&it) & END) == 0) {
            Str *chunk = Iter_Get(&it);
            if (chunk != NULL && chunk->length > 0) {
                StrVec_Add(result, chunk);
            }
        }
    } else if (resp->body != NULL && resp->body->length > 0) {
        // Add single body chunk
        StrVec_Add(result, resp->body);
    }

    return result;
}
