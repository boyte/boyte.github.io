#ifndef CANEKA_DOCS_HTTP_H
#define CANEKA_DOCS_HTTP_H

#include <base_module.h>

/**
 * HTTP Methods supported by the server
 */
typedef enum {
    HTTP_GET,
    HTTP_POST,
    HTTP_HEAD,
    HTTP_UNKNOWN
} HttpMethod;

/**
 * HTTP Request structure containing parsed request data
 */
typedef struct HttpRequest {
    HttpMethod method;     // HTTP method (GET, POST, etc.)
    Str *path;            // Request path (e.g., "/docs/intro")
    Str *version;         // HTTP version (e.g., "HTTP/1.1")
    Table *headers;       // Request headers (key-value pairs)
    Str *body;            // Request body (for POST requests)
} HttpRequest;

/**
 * HTTP Response structure for building responses
 */
typedef struct HttpResponse {
    i32 statusCode;       // HTTP status code (200, 404, etc.)
    Str *statusText;      // Status text ("OK", "Not Found", etc.)
    Str *contentType;     // Content-Type header value
    Str *body;            // Response body (use this OR bodyVec, not both)
    StrVec *bodyVec;      // Response body as StrVec for large content (avoids MEM_SLAB_SIZE limit)
    Table *headers;       // Additional headers
} HttpResponse;

/**
 * Parse HTTP request from string lines
 *
 * @param m Memory chapter for allocations
 * @param lines Vector of request lines (first line is request line, rest are headers)
 * @return Parsed HttpRequest or NULL on error
 */
HttpRequest* Http_ParseRequest(MemCh *m, StrVec *lines);

/**
 * Generate HTTP response string from HttpResponse structure
 *
 * @param m Memory chapter for allocations
 * @param resp Response structure
 * @return Complete HTTP response string ready to send
 */
Str* Http_GenerateResponse(MemCh *m, HttpResponse *resp);

/**
 * Generate HTTP response as StrVec for chunked writing (handles large bodies)
 *
 * Returns StrVec with headers as first chunk, body chunks following.
 * Caller should write each chunk separately to avoid MEM_SLAB_SIZE limit.
 *
 * @param m Memory chapter for allocations
 * @param resp Response structure (can have body or bodyVec)
 * @return StrVec with response chunks ready to send
 */
StrVec* Http_GenerateResponseVec(MemCh *m, HttpResponse *resp);

/**
 * Create a new HTTP response with common defaults
 *
 * @param m Memory chapter for allocations
 * @param code HTTP status code
 * @param contentType Content-Type header value
 * @param body Response body content
 * @return HttpResponse structure ready to generate
 */
HttpResponse* Http_NewResponse(MemCh *m, i32 code, Str *contentType, Str *body);

/**
 * Create a new HTTP response with StrVec body (for large content)
 *
 * @param m Memory chapter for allocations
 * @param code HTTP status code
 * @param contentType Content-Type header value
 * @param bodyVec Response body as StrVec (avoids MEM_SLAB_SIZE limit)
 * @return HttpResponse structure ready to generate
 */
HttpResponse* Http_NewResponseVec(MemCh *m, i32 code, Str *contentType, StrVec *bodyVec);

/**
 * Create HTTP 404 Not Found response
 *
 * @param m Memory chapter for allocations
 * @return 404 response
 */
HttpResponse* Http_NotFound(MemCh *m);

/**
 * Create HTTP 403 Forbidden response
 *
 * @param m Memory chapter for allocations
 * @return 403 response
 */
HttpResponse* Http_Forbidden(MemCh *m);

/**
 * Create HTTP 500 Internal Server Error response
 *
 * @param m Memory chapter for allocations
 * @param error Error message to include
 * @return 500 response
 */
HttpResponse* Http_InternalError(MemCh *m, Str *error);

/**
 * Create HTTP 301 Permanent Redirect response
 *
 * @param m Memory chapter for allocations
 * @param location URL to redirect to
 * @return 301 response
 */
HttpResponse* Http_Redirect(MemCh *m, Str *location);

#endif // CANEKA_DOCS_HTTP_H
