#ifndef CDOCS_TYPES_H
#define CDOCS_TYPES_H

/**
 * Caneka Docs Type Definitions
 *
 * Local type definitions for caneka-docs components.
 * These extend Caneka's base type system.
 */

// Sidebar types
#define TYPE_SIDEBAR        ((cls)10001)
#define TYPE_SIDEBAR_ITEM   ((cls)10002)

// Future types (reserved)
#define TYPE_SEARCH_INDEX   ((cls)10003)
#define TYPE_SEARCH_RESULT  ((cls)10004)

#endif // CDOCS_TYPES_H
