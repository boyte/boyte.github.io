#ifndef CANEKA_DOCS_ROUTER_H
#define CANEKA_DOCS_ROUTER_H

#include <base_module.h>
#include "http.h"

/**
 * Route handler function type
 *
 * @param m Memory chapter for request-scoped allocations
 * @param req Parsed HTTP request
 * @param docRoot Document root directory path
 * @return HTTP response to send to client
 */
typedef HttpResponse* (*RouteHandler)(MemCh *m, HttpRequest *req, Str *docRoot);

/**
 * URL route structure mapping patterns to handlers
 * (Named DocsRoute to avoid conflict with Caneka's Route type)
 */
typedef struct DocsRoute {
    Str *pattern;          // URL pattern (e.g., "/docs/", "/static/")
    RouteHandler handler;  // Handler function pointer
} DocsRoute;

/**
 * Router structure managing all routes
 */
typedef struct Router {
    Span *routes;          // Array of Route structures
    Str *docRoot;          // Document root directory
} Router;

/**
 * Create a new router
 *
 * @param m Memory chapter for allocations
 * @param docRoot Document root directory path
 * @return Initialized Router structure
 */
Router* Router_Make(MemCh *m, Str *docRoot);

/**
 * Add a route to the router
 *
 * Routes are matched in order added, first match wins.
 * Use prefix patterns like "/docs/" to match all paths starting with that prefix.
 *
 * @param r Router to add route to
 * @param pattern URL pattern to match (prefix-based)
 * @param handler Handler function for this route
 * @return SUCCESS or error status
 */
status Router_Add(Router *r, Str *pattern, RouteHandler handler);

/**
 * Match a URL path to a handler
 *
 * @param r Router to search
 * @param path URL path to match
 * @return Handler function or NULL if no match
 */
RouteHandler Router_Match(Router *r, Str *path);

/**
 * Handle an HTTP request by routing to appropriate handler
 *
 * This is the main entry point for request processing.
 *
 * @param r Router to use
 * @param m Memory chapter for request-scoped allocations
 * @param req HTTP request to handle
 * @return HTTP response from matched handler (or 404 if no match)
 */
HttpResponse* Router_Handle(Router *r, MemCh *m, HttpRequest *req);

/**
 * Markdown document handler
 *
 * Serves .md files from the docs directory, parses markdown,
 * and wraps result in page template.
 *
 * @param m Memory chapter for allocations
 * @param req HTTP request
 * @param docRoot Document root path
 * @return HTTP response with rendered HTML
 */
HttpResponse* Handler_Markdown(MemCh *m, HttpRequest *req, Str *docRoot);

/**
 * Static file handler
 *
 * Serves static files (CSS, JS, images) with appropriate MIME types.
 * Includes security checks to prevent path traversal attacks.
 *
 * @param m Memory chapter for allocations
 * @param req HTTP request
 * @param docRoot Document root path
 * @return HTTP response with file contents
 */
HttpResponse* Handler_Static(MemCh *m, HttpRequest *req, Str *docRoot);

/**
 * Smoke test handler
 *
 * Returns HTML page showing all HTTP server components are working.
 * Used for CDOCS-015a integration testing.
 *
 * @param m Memory chapter for allocations
 * @param req HTTP request
 * @param docRoot Document root path (unused)
 * @return HTTP 200 response with test HTML
 */
HttpResponse* Handler_SmokeTest(MemCh *m, HttpRequest *req, Str *docRoot);

/**
 * Index redirect handler
 *
 * Redirects / to /docs/intro
 *
 * @param m Memory chapter for allocations
 * @param req HTTP request
 * @param docRoot Document root path (unused)
 * @return HTTP 301 redirect response
 */
HttpResponse* Handler_IndexRedirect(MemCh *m, HttpRequest *req, Str *docRoot);

#endif // CANEKA_DOCS_ROUTER_H
