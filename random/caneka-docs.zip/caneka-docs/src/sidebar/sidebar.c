#include <external.h>
#include <base_module.h>
#include <ext_module.h>
#include "../cdocs_types.h"
#include "sidebar.h"

/**
 * Sidebar Configuration Parser
 *
 * Parses sidebar.config using Config_FromPath and builds
 * an in-memory tree structure for navigation rendering.
 */

// Forward declarations
static boolean validateItemRecursive(MemCh *m, SidebarItem *item, const char *path);

// Forward declaration of custom parser
extern Sidebar* Sidebar_ParseCustom(MemCh *m, Str *configPath);

/**
 * Parse sidebar.config file into Sidebar structure
 */
Sidebar* Sidebar_Parse(MemCh *m, Str *configPath) {
    // Use custom parser
    return Sidebar_ParseCustom(m, configPath);
}

/**
 * Validate sidebar item properties (recursive)
 */
static boolean validateItemRecursive(MemCh *m, SidebarItem *item, const char *path) {
    if (item == NULL) {
        return FALSE;
    }

    // Rule 1: title is required and non-empty
    if (item->title == NULL || item->title->length == 0) {
        fprintf(stderr, "Sidebar validation failed at %s: missing title\n", path);
        return FALSE;
    }

    // Rule 2: Must have EITHER href OR children (mutually exclusive)
    boolean hasHref = (item->href != NULL && item->href->length > 0);
    boolean hasChildren = (item->children != NULL && item->children->nvalues > 0);

    if (!hasHref && !hasChildren) {
        void *args[] = {item->title, NULL};
        Error(m, "Sidebar_ValidateItem", "sidebar.c", __LINE__,
              "Item '@' must have either 'href' or 'children'", args);
        return FALSE;
    }

    if (hasHref && hasChildren) {
        void *args[] = {item->title, NULL};
        Error(m, "Sidebar_ValidateItem", "sidebar.c", __LINE__,
              "Item '@' cannot have both 'href' and 'children'", args);
        return FALSE;
    }

    // Rule 3: href must start with '/' if present
    if (hasHref) {
        if (item->href->bytes[0] != '/') {
            void *args[] = {item->title, item->href, NULL};
            Error(m, "Sidebar_ValidateItem", "sidebar.c", __LINE__,
                  "Item '@' has invalid href '@': must start with '/'", args);
            return FALSE;
        }
    }

    // Rule 4: Validate children recursively
    if (hasChildren) {
        for (i32 i = 0; i < item->children->nvalues; i++) {
            SidebarItem *child = Span_Get(item->children, i);

            char childPath[512];
            snprintf(childPath, sizeof(childPath), "%s.children[%d]", path, i);

            if (!validateItemRecursive(m, child, childPath)) {
                return FALSE;
            }
        }
    }

    return TRUE;
}

/**
 * Public validation function
 */
boolean Sidebar_ValidateItem(MemCh *m, SidebarItem *item) {
    return validateItemRecursive(m, item, "item");
}

/**
 * Print sidebar tree for debugging
 */
static void printItemRecursive(SidebarItem *item, i32 indent) {
    if (item == NULL) {
        return;
    }

    // Print indentation
    for (i32 i = 0; i < indent; i++) {
        printf("  ");
    }

    // Print item
    if (item->href != NULL) {
        printf("- %s -> %s\n", item->title->bytes, item->href->bytes);
    } else {
        printf("+ %s\n", item->title->bytes);
    }

    // Print children
    if (item->children != NULL) {
        for (i32 i = 0; i < item->children->nvalues; i++) {
            SidebarItem *child = Span_Get(item->children, i);
            printItemRecursive(child, indent + 1);
        }
    }
}

void Sidebar_Print(Sidebar *sidebar) {
    if (sidebar == NULL) {
        printf("Sidebar is NULL\n");
        return;
    }

    printf("Sidebar (%d items):\n", sidebar->items->nvalues);
    for (i32 i = 0; i < sidebar->items->nvalues; i++) {
        SidebarItem *item = Span_Get(sidebar->items, i);
        printItemRecursive(item, 0);
    }
}

/**
 * Find sidebar item by href (recursive search)
 */
static SidebarItem* findByHrefRecursive(SidebarItem *item, Str *href) {
    if (item == NULL || href == NULL) {
        return NULL;
    }

    // Check if this item matches (compare strings)
    if (item->href != NULL && href != NULL) {
        if (item->href->length == href->length &&
            memcmp(item->href->bytes, href->bytes, href->length) == 0) {
            return item;
        }
    }

    // Search children
    if (item->children != NULL) {
        for (i32 i = 0; i < item->children->nvalues; i++) {
            SidebarItem *child = Span_Get(item->children, i);
            SidebarItem *found = findByHrefRecursive(child, href);
            if (found != NULL) {
                return found;
            }
        }
    }

    return NULL;
}

SidebarItem* Sidebar_FindByHref(Sidebar *sidebar, Str *href) {
    if (sidebar == NULL || href == NULL) {
        return NULL;
    }

    for (i32 i = 0; i < sidebar->items->nvalues; i++) {
        SidebarItem *item = Span_Get(sidebar->items, i);
        SidebarItem *found = findByHrefRecursive(item, href);
        if (found != NULL) {
            return found;
        }
    }

    return NULL;
}

/**
 * Mark item as active (used for highlighting current page)
 */
void Sidebar_MarkActive(SidebarItem *item) {
    if (item == NULL) {
        return;
    }

    item->isActive = TRUE;
}

/**
 * Render sidebar item to HTML (recursive)
 */
static void renderItemRecursive(MemCh *m, SidebarItem *item, StrVec *html) {
    if (item == NULL) {
        return;
    }

    StrVec_Add(html, S(m, "        <li class=\"p-side-navigation__item\">"));

    if (item->children != NULL && item->children->nvalues > 0) {
        // Item with children - render as category
        StrVec_Add(html, S(m, "<strong class=\"p-side-navigation__text\">"));
        StrVec_Add(html, item->title);
        StrVec_Add(html, S(m, "</strong><ul class=\"p-side-navigation__list\">"));

        // Render children
        for (i32 i = 0; i < item->children->nvalues; i++) {
            SidebarItem *child = Span_Get(item->children, i);
            renderItemRecursive(m, child, html);
        }

        StrVec_Add(html, S(m, "</ul>"));
    } else if (item->href != NULL) {
        // Leaf item with link
        StrVec_Add(html, S(m, "<a class=\"p-side-navigation__link\" href=\""));
        StrVec_Add(html, item->href);
        StrVec_Add(html, S(m, "\">"));
        StrVec_Add(html, item->title);
        StrVec_Add(html, S(m, "</a>"));
    }

    StrVec_Add(html, S(m, "</li>"));
}

/**
 * Render sidebar to HTML
 *
 * Generates HTML for the sidebar navigation using Vanilla Framework classes.
 * Returns a StrVec containing the rendered HTML.
 */
StrVec* Sidebar_ToHtml(MemCh *m, Sidebar *sidebar) {
    if (sidebar == NULL) {
        return NULL;
    }

    StrVec *html = StrVec_Make(m);

    // Opening nav tag
    StrVec_Add(html, S(m, "<nav class=\"p-side-navigation\" aria-label=\"Documentation navigation\">"));
    StrVec_Add(html, S(m, "<ul class=\"p-side-navigation__list\">"));

    // Render all top-level items
    for (i32 i = 0; i < sidebar->items->nvalues; i++) {
        SidebarItem *item = Span_Get(sidebar->items, i);
        renderItemRecursive(m, item, html);
    }

    // Closing tags
    StrVec_Add(html, S(m, "</ul></nav>"));

    return html;
}
