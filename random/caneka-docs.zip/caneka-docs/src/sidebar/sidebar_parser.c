#include <external.h>
#include <base_module.h>
#include <ext_module.h>
#include "../cdocs_types.h"
#include "sidebar.h"

/**
 * Custom parser for sidebar.config
 *
 * Format:
 *   items {
 *       section-name {
 *           title: Section Title
 *           href: /path
 *           children {
 *               ...
 *           }
 *       }
 *   }
 */

typedef struct {
    MemCh *m;
    StrVec *lines;
    i32 lineIdx;
} Parser;

static Str* trimStr(MemCh *m, Str *s) {
    if (s == NULL || s->length == 0) return s;

    // Skip leading whitespace
    i32 start = 0;
    while (start < s->length && (s->bytes[start] == ' ' || s->bytes[start] == '\t')) {
        start++;
    }

    // Skip trailing whitespace
    i32 end = s->length - 1;
    while (end >= start && (s->bytes[end] == ' ' || s->bytes[end] == '\t' ||
                            s->bytes[end] == '\r' || s->bytes[end] == '\n')) {
        end--;
    }

    if (start > end) return S(m, "");

    // Create a new string from the trimmed bytes
    i32 newLen = end - start + 1;
    char buf[1024];
    if (newLen >= sizeof(buf)) newLen = sizeof(buf) - 1;
    memcpy(buf, s->bytes + start, newLen);
    buf[newLen] = '\0';
    return S(m, buf);
}

static Str* getCurrentLine(Parser *p) {
    if (p->lineIdx >= p->lines->p->nvalues) {
        return NULL;
    }
    return trimStr(p->m, Span_Get(p->lines->p, p->lineIdx));
}

static void nextLine(Parser *p) {
    p->lineIdx++;
}

static boolean isOpenBrace(Str *line) {
    return line != NULL && line->length > 0 && line->bytes[line->length - 1] == '{';
}

static boolean isCloseBrace(Str *line) {
    return line != NULL && line->length > 0 && line->bytes[0] == '}';
}

static boolean isProperty(Str *line) {
    if (line == NULL || line->length == 0) return FALSE;

    for (i32 i = 0; i < line->length; i++) {
        if (line->bytes[i] == ':') return TRUE;
    }
    return FALSE;
}

static SidebarItem* parseItem(Parser *p, i32 depth);

static Span* parseChildren(Parser *p, i32 depth) {
    Span *children = Span_Make(p->m);
    i32 childIdx = 0;

    while (TRUE) {
        Str *line = getCurrentLine(p);
        if (line == NULL || isCloseBrace(line)) {
            break;
        }

        if (isOpenBrace(line)) {
            // This is a child item
            SidebarItem *child = parseItem(p, depth + 1);
            if (child != NULL) {
                Span_Set(children, childIdx, child);
                childIdx++;
            }
        } else {
            nextLine(p);
        }
    }

    children->nvalues = childIdx;
    return childIdx > 0 ? children : NULL;
}

static SidebarItem* parseItem(Parser *p, i32 depth) {
    Str *line = getCurrentLine(p);
    if (line == NULL || !isOpenBrace(line)) {
        return NULL;
    }

    // Skip the item name line
    nextLine(p);

    SidebarItem *item = MemCh_Alloc(p->m, sizeof(SidebarItem));
    item->type.of = TYPE_SIDEBAR_ITEM;
    item->type.state = READY;
    item->depth = depth;
    item->isActive = FALSE;
    item->title = NULL;
    item->href = NULL;
    item->children = NULL;

    // Parse properties and nested children
    while (TRUE) {
        line = getCurrentLine(p);
        if (line == NULL || isCloseBrace(line)) {
            nextLine(p);  // Skip the closing brace
            break;
        }

        if (isProperty(line)) {
            // Parse property: "name: value"
            i32 colonIdx = -1;
            for (i32 i = 0; i < line->length; i++) {
                if (line->bytes[i] == ':') {
                    colonIdx = i;
                    break;
                }
            }

            if (colonIdx > 0) {
                // Extract property name
                char nameBuf[256];
                i32 nameLen = colonIdx;
                if (nameLen >= sizeof(nameBuf)) nameLen = sizeof(nameBuf) - 1;
                memcpy(nameBuf, line->bytes, nameLen);
                nameBuf[nameLen] = '\0';
                Str *propName = trimStr(p->m, S(p->m, nameBuf));

                // Extract property value
                char valueBuf[1024];
                i32 valueLen = line->length - colonIdx - 1;
                if (valueLen >= sizeof(valueBuf)) valueLen = sizeof(valueBuf) - 1;
                memcpy(valueBuf, line->bytes + colonIdx + 1, valueLen);
                valueBuf[valueLen] = '\0';
                Str *propValue = trimStr(p->m, S(p->m, valueBuf));

                if (Str_EqualsStr(propName, S(p->m, "title"))) {
                    item->title = propValue;
                } else if (Str_EqualsStr(propName, S(p->m, "href"))) {
                    item->href = propValue;
                }
            }
            nextLine(p);
        } else if (isOpenBrace(line)) {
            // Check if this is the "children {" block
            // Extract block name (everything before the '{')
            char nameBuf[256];
            i32 nameLen = line->length - 1;
            if (nameLen >= sizeof(nameBuf)) nameLen = sizeof(nameBuf) - 1;
            memcpy(nameBuf, line->bytes, nameLen);
            nameBuf[nameLen] = '\0';
            Str *blockName = trimStr(p->m, S(p->m, nameBuf));

            if (Str_EqualsStr(blockName, S(p->m, "children"))) {
                nextLine(p);  // Skip "children {" line
                item->children = parseChildren(p, depth);
                nextLine(p);  // Skip the closing "}" of children block
            } else {
                // Some other block we don't recognize, skip it
                nextLine(p);
            }
        } else {
            nextLine(p);
        }
    }

    return item;
}

Sidebar* Sidebar_ParseCustom(MemCh *m, Str *configPath) {
    // Read file with a larger buffer (16KB should be enough for config files)
    Buff *bf = Buff_Make(m, 16384);
    if (!File_Exists(bf, configPath)) {
        fprintf(stderr, "File does not exist: %s\n", configPath->bytes);
        return NULL;
    }

    File_Open(bf, configPath, O_RDONLY);
    Buff_Read(bf);
    File_Close(bf);

    // bf->v contains chunks - process them to split into lines
    i32 numChunks = bf->v->p->nvalues;

    // Split chunks into lines
    StrVec *lines = StrVec_Make(m);
    char lineBuf[1024];
    i32 linePos = 0;
    i32 lineCount = 0;

    for (i32 chunkIdx = 0; chunkIdx < numChunks; chunkIdx++) {
        Str *chunk = Span_Get(bf->v->p, chunkIdx);

        for (i32 i = 0; i < chunk->length; i++) {
            byte ch = chunk->bytes[i];

            if (ch == '\n') {
                // End of line - add it
                lineBuf[linePos] = '\0';
                StrVec_Add(lines, S(m, lineBuf));
                lineCount++;
                linePos = 0;
            } else if (ch != '\r') {  // Skip carriage returns
                if (linePos < sizeof(lineBuf) - 1) {
                    lineBuf[linePos++] = ch;
                }
            }
        }
    }

    // Add final line if there's content without trailing newline
    if (linePos > 0) {
        lineBuf[linePos] = '\0';
        StrVec_Add(lines, S(m, lineBuf));
        lineCount++;
    }

    // Create parser
    Parser parser;
    parser.m = m;
    parser.lines = lines;
    parser.lineIdx = 0;

    // Find "items {" line
    while (TRUE) {
        Str *line = getCurrentLine(&parser);
        if (line == NULL) {
            fprintf(stderr, "Could not find 'items {' in config file (end of file)\n");
            return NULL;
        }

        if (isOpenBrace(line)) {
            // Extract block name (everything before the '{')
            char nameBuf[256];
            i32 nameLen = line->length - 1;
            if (nameLen >= sizeof(nameBuf)) nameLen = sizeof(nameBuf) - 1;
            memcpy(nameBuf, line->bytes, nameLen);
            nameBuf[nameLen] = '\0';
            Str *blockName = trimStr(m, S(m, nameBuf));

            if (Str_EqualsStr(blockName, S(m, "items"))) {
                nextLine(&parser);  // Skip "items {" line
                break;
            }
        }
        nextLine(&parser);
    }

    // Create sidebar
    Sidebar *sidebar = MemCh_Alloc(m, sizeof(Sidebar));
    sidebar->type.of = TYPE_SIDEBAR;
    sidebar->type.state = READY;
    sidebar->items = Span_Make(m);
    sidebar->configPath = configPath;

    // Parse all top-level items
    i32 itemIdx = 0;
    while (TRUE) {
        Str *line = getCurrentLine(&parser);
        if (line == NULL || isCloseBrace(line)) {
            break;
        }

        if (isOpenBrace(line)) {
            SidebarItem *item = parseItem(&parser, 0);
            if (item != NULL && item->title != NULL) {
                Span_Set(sidebar->items, itemIdx, item);
                itemIdx++;
            }
        } else {
            nextLine(&parser);
        }
    }

    sidebar->items->nvalues = itemIdx;

    return sidebar;
}
