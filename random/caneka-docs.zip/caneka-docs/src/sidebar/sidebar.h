#ifndef SIDEBAR_H
#define SIDEBAR_H

#include <base_module.h>
#include "../cdocs_types.h"

/**
 * Sidebar Navigation System
 *
 * Parses sidebar.config and builds an in-memory tree structure
 * for rendering navigation menus.
 *
 * Structure:
 * - Sidebar contains array of SidebarItems
 * - Each SidebarItem has title + (href XOR children)
 * - Children can be nested to arbitrary depth
 */

typedef struct SidebarItem SidebarItem;

/**
 * Single sidebar navigation item
 *
 * Can be either:
 * 1. Link item: has title + href
 * 2. Category item: has title + children array
 */
struct SidebarItem {
    Type type;               // Base type header
    Str *title;              // Display text (required)
    Str *href;               // URL path (for link items)
    Span *children;          // Array of SidebarItem* (for category items)
    i32 depth;               // Nesting depth (0 = top-level)
    boolean isActive;        // TRUE if matches current page
};

/**
 * Root sidebar structure
 */
typedef struct Sidebar {
    Type type;               // Base type header
    Span *items;             // Array of SidebarItem* (top-level items)
    Str *configPath;         // Path to sidebar.config file
} Sidebar;

/**
 * Parse sidebar.config file into Sidebar structure
 *
 * Returns: Sidebar* on success, NULL on error
 */
Sidebar* Sidebar_Parse(MemCh *m, Str *configPath);

/**
 * Validate sidebar item properties
 *
 * Checks:
 * - title is non-empty
 * - has href XOR children (mutually exclusive)
 * - href starts with '/' if present
 * - children is non-empty array if present
 *
 * Returns: TRUE if valid, FALSE if invalid (logs errors)
 */
boolean Sidebar_ValidateItem(MemCh *m, SidebarItem *item);

/**
 * Print sidebar tree for debugging
 */
void Sidebar_Print(Sidebar *sidebar);

/**
 * Find sidebar item by href
 *
 * Searches recursively through all items and children.
 *
 * Returns: SidebarItem* if found, NULL if not found
 */
SidebarItem* Sidebar_FindByHref(Sidebar *sidebar, Str *href);

/**
 * Mark item and its parents as active
 *
 * Sets isActive = TRUE for the item and all ancestors.
 * Used for rendering active states and expanding parent categories.
 */
void Sidebar_MarkActive(SidebarItem *item);

/**
 * Render sidebar to HTML
 *
 * Generates HTML for the sidebar navigation using Vanilla Framework classes.
 *
 * Returns: StrVec* containing rendered HTML, NULL on error
 */
StrVec* Sidebar_ToHtml(MemCh *m, Sidebar *sidebar);

#endif // SIDEBAR_H
