#include <external.h>
#include <base_module.h>
#include "router.h"
#include "markdown/markdown.h"
#include "sidebar/sidebar.h"

/**
 * Helper function to add C string to StrVec
 */
static inline void StrVec_AddCstr(MemCh *m, StrVec *v, const char *cstr) {
    StrVec_Add(v, S(m, (char*)cstr));
}

/**
 * Create a new router
 *
 * This is a stub implementation for CDOCS-010.
 * Full implementation will be in CDOCS-012.
 *
 * @param m Memory chapter for allocations
 * @param docRoot Document root directory path
 * @return Initialized Router structure
 */
Router* Router_Make(MemCh *m, Str *docRoot) {
    Router *router = MemCh_Alloc(m, sizeof(Router));
    router->routes = Span_Make(m);
    router->docRoot = docRoot;
    return router;
}

/**
 * Convert StrVec to Str in chunks to avoid MEM_SLAB_SIZE limit
 *
 * Caneka's memory system has MEM_SLAB_SIZE (~4KB) limit for single allocations.
 * For content > 4KB, we need to iterate through StrVec chunks and accumulate into
 * multiple smaller Str objects.
 *
 * @param m Memory chapter
 * @param v StrVec to convert
 * @return Str containing content, or NULL if total size > MEM_SLAB_SIZE
 */
static Str* StrVec_ToStrLarge(MemCh *m, StrVec *v) {
    if (v == NULL) {
        return NULL;
    }

    // Check if total exceeds MEM_SLAB_SIZE (PAGE_SIZE - sizeof(MemPage))
    // With PAGE_SIZE=32768, MEM_SLAB_SIZE ≈ 32KB
    // Using 32750 to leave some safety margin for MemPage header
    if (v->total > 32750) {
        return NULL;  // Caller must handle chunked content differently
    }

    // For content < 4KB, allocate a single Str
    Str *result = Str_Make(m, v->total + 1);
    if (result == NULL) {
        return NULL;
    }

    // Iterate through StrVec and append each chunk
    Iter it;
    Iter_Init(&it, v->p);
    while ((Iter_Next(&it) & END) == 0) {
        Str *chunk = Iter_Get(&it);
        if (chunk != NULL && chunk->length > 0) {
            Str_Add(result, chunk->bytes, chunk->length);
        }
    }

    return result;
}

/**
 * Add a route to the router (stub)
 */
status Router_Add(Router *r, Str *pattern, RouteHandler handler) {
    DocsRoute *route = MemCh_Alloc(r->routes->m, sizeof(DocsRoute));
    route->pattern = pattern;
    route->handler = handler;
    Span_Set(r->routes, r->routes->nvalues, route);
    return SUCCESS;
}

/**
 * Check if path starts with pattern (prefix match)
 */
static boolean pathMatchesPattern(Str *path, Str *pattern) {
    if (path->length < pattern->length) {
        return FALSE;
    }

    for (i32 i = 0; i < pattern->length; i++) {
        if (path->bytes[i] != pattern->bytes[i]) {
            return FALSE;
        }
    }

    return TRUE;
}

/**
 * Match a URL path to a handler
 *
 * Uses prefix matching - returns first route whose pattern matches
 * the start of the path. Routes are checked in order added.
 */
RouteHandler Router_Match(Router *r, Str *path) {
    if (r == NULL || r->routes == NULL || path == NULL) {
        return NULL;
    }

    // Iterate through routes and find first match
    for (i32 i = 0; i < r->routes->nvalues; i++) {
        DocsRoute *route = Span_Get(r->routes, i);
        if (route != NULL && pathMatchesPattern(path, route->pattern)) {
            return route->handler;
        }
    }

    return NULL; // No match found
}

/**
 * Handle an HTTP request by routing to appropriate handler
 *
 * Matches the request path against registered routes and invokes
 * the corresponding handler. Returns 404 if no route matches.
 */
HttpResponse* Router_Handle(Router *r, MemCh *m, HttpRequest *req) {
    if (r == NULL || req == NULL) {
        return Http_InternalError(m, S(m, "Invalid router or request"));
    }

    // Find matching handler
    RouteHandler handler = Router_Match(r, req->path);

    if (handler == NULL) {
        return Http_NotFound(m);
    }

    // Invoke handler
    return handler(m, req, r->docRoot);
}

/**
 * MIME type mapping for static files
 */
typedef struct MimeMapping {
    const char *extension;
    const char *mimeType;
} MimeMapping;

static MimeMapping mimeTypes[] = {
    {".css", "text/css"},
    {".js", "application/javascript"},
    {".json", "application/json"},
    {".svg", "image/svg+xml"},
    {".png", "image/png"},
    {".jpg", "image/jpeg"},
    {".jpeg", "image/jpeg"},
    {".gif", "image/gif"},
    {".webp", "image/webp"},
    {".ico", "image/x-icon"},
    {".html", "text/html"},
    {".txt", "text/plain"},
    {".xml", "application/xml"},
    {".pdf", "application/pdf"},
    {NULL, NULL}
};

/**
 * Get MIME type based on file extension
 */
static Str* getMimeType(MemCh *m, Str *path) {
    // Find the last dot in the path
    i32 dotPos = -1;
    for (i32 i = path->length - 1; i >= 0; i--) {
        if (path->bytes[i] == '.') {
            dotPos = i;
            break;
        }
        // Stop at path separator
        if (path->bytes[i] == '/') {
            break;
        }
    }

    if (dotPos == -1) {
        return S(m, "application/octet-stream");
    }

    // Extract extension
    i32 extLen = path->length - dotPos;

    // Compare with known MIME types
    for (i32 i = 0; mimeTypes[i].extension != NULL; i++) {
        const char *ext = mimeTypes[i].extension;
        i32 knownExtLen = 0;
        while (ext[knownExtLen] != '\0') knownExtLen++;

        if (extLen == knownExtLen) {
            boolean match = TRUE;
            for (i32 j = 0; j < extLen; j++) {
                if (path->bytes[dotPos + j] != ext[j]) {
                    match = FALSE;
                    break;
                }
            }
            if (match) {
                return S(m, mimeTypes[i].mimeType);
            }
        }
    }

    return S(m, "application/octet-stream");
}

/**
 * Markdown document handler (CDOCS-033)
 *
 * Serves .md files by:
 * 1. Converting URL path to filesystem path
 * 2. Loading and parsing markdown file
 * 3. Rendering to HTML with frontmatter
 * 4. Wrapping in page template
 *
 * Example: /docs/intro -> documentation/docs/intro.md
 */
HttpResponse* Handler_Markdown(MemCh *m, HttpRequest *req, Str *docRoot) {
    // Security: Check for path traversal attempts
    for (i32 i = 0; i < req->path->length - 1; i++) {
        if (req->path->bytes[i] == '.' && req->path->bytes[i + 1] == '.') {
            return Http_Forbidden(m);
        }
    }

    // Convert URL path to file path
    // "/docs/intro" -> "./pages/docs/intro.md"
    Str *filePath = Str_Make(m, 512);

    // Add docRoot (e.g., "./pages")
    Str_Add(filePath, docRoot->bytes, docRoot->length);

    // Add the request path (e.g., "/docs/intro")
    // This will resolve to: ./pages/docs/intro.md
    Str_Add(filePath, req->path->bytes, req->path->length);

    // Add ".md" extension
    Str_AddCstr(filePath, ".md");

    // Try to load the markdown file
    StrVec *fileContent = File_ToVec(m, filePath);
    if (fileContent == NULL) {
        return Http_NotFound(m);
    }

    // Handle empty files gracefully - render empty page
    if (fileContent->total == 0) {
        // Create empty markdown document
        Str *emptyMarkdown = Str_Make(m, 1);
        MdDocument *doc = Markdown_Parse(m, emptyMarkdown);

        // Get page title (default for empty files)
        Str *pageTitle = S(m, "Caneka Documentation");

        // Generate HTML
        StrVec *htmlContent = Markdown_ToHtml(m, doc);
        HttpResponse *response = Http_NewResponseVec(m, 200, S(m, "text/html; charset=utf-8"), htmlContent);

        // Add HTML document structure
        StrVec *fullHtml = StrVec_Make(m);
        StrVec_AddCstr(m, fullHtml, "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>");
        StrVec_Add(fullHtml, pageTitle);
        StrVec_AddCstr(m, fullHtml, "</title></head><body style=\"max-width:800px;margin:2rem auto;padding:0 1rem;\">");
        StrVec_AddVec(fullHtml, htmlContent);
        StrVec_AddCstr(m, fullHtml, "</body></html>");

        return Http_NewResponseVec(m, 200, S(m, "text/html; charset=utf-8"), fullHtml);
    }

    // Convert StrVec to Str for markdown parsing
    // Use custom function to bypass STR_MAX (2048) limit
    Str *markdown = StrVec_ToStrLarge(m, fileContent);

    // If file is too large (> 32KB), StrVec_ToStrLarge returns NULL
    // In this case, we need to handle it differently
    if (markdown == NULL) {
        // Try to build markdown string in chunks
        // Create a temporary MemCh for building the markdown string
        // This is a workaround until Markdown_Parse can accept StrVec directly
        return Http_InternalError(m, S(m, "Markdown file too large (> 32KB limit)"));
    }

    // Parse markdown (includes frontmatter, blocks, and inlines)
    MdDocument *doc = Markdown_Parse(m, markdown);

    // Get page title (use from frontmatter or default)
    Str *pageTitle;
    if (doc->frontmatter != NULL && doc->frontmatter->title != NULL) {
        pageTitle = doc->frontmatter->title;
    } else {
        pageTitle = S(m, "Caneka Documentation");
    }

    // Render markdown to HTML (returns StrVec to avoid size limits)
    StrVec *htmlContent = Markdown_ToHtml(m, doc);
    if (htmlContent == NULL) {
        return Http_InternalError(m, S(m, "Markdown rendering failed"));
    }

    // Load sidebar configuration
    Str *sidebarPath = Str_Make(m, 256);
    Str_Add(sidebarPath, docRoot->bytes, docRoot->length);
    Str_AddCstr(sidebarPath, "/sidebar.config");
    Sidebar *sidebar = Sidebar_Parse(m, sidebarPath);
    StrVec *sidebarHtml = NULL;
    if (sidebar != NULL) {
        sidebarHtml = Sidebar_ToHtml(m, sidebar);
    }

    // Build HTML page as StrVec to avoid MEM_SLAB_SIZE (~4KB) limit
    // Each part stays under 4KB, total can be unlimited
    StrVec *htmlVec = StrVec_Make(m);

    // Add HTML parts as separate chunks
    StrVec_Add(htmlVec, S(m, "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>"));
    StrVec_Add(htmlVec, pageTitle);
    StrVec_Add(htmlVec, S(m, " | Caneka Documentation</title>"));
    StrVec_Add(htmlVec, S(m, "<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\"><link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin><link href=\"https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Newsreader:ital,wght@0,400;0,600;1,400&display=swap\" rel=\"stylesheet\">"));
    StrVec_Add(htmlVec, S(m, "<style>"));
    StrVec_Add(htmlVec, S(m, ":root{--color-bg:#fdfcfb;--color-text:#1a1a1a;--color-text-muted:#666;--color-accent:#c1440e;--color-accent-soft:#d97847;--color-border:#e8e6e3;--color-sidebar-bg:#f8f7f5;--color-header-bg:#ffffff;--font-serif:'Newsreader',Georgia,serif;--font-mono:'IBM Plex Mono',Consolas,monospace;--spacing-xs:0.25rem;--spacing-sm:0.5rem;--spacing-md:1rem;--spacing-lg:1.5rem;--spacing-xl:2rem;--spacing-2xl:3rem;}"));
    StrVec_Add(htmlVec, S(m, "*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}"));
    StrVec_Add(htmlVec, S(m, "body{font-family:var(--font-serif);font-size:18px;line-height:1.7;color:var(--color-text);background:var(--color-bg);display:flex;flex-direction:column;min-height:100vh;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}"));
    StrVec_Add(htmlVec, S(m, "header{background:var(--color-header-bg);border-bottom:1px solid var(--color-border);position:sticky;top:0;z-index:100;backdrop-filter:blur(8px);background:rgba(255,255,255,0.95);}"));
    StrVec_Add(htmlVec, S(m, "header .p-navigation__row{max-width:1600px;margin:0 auto;padding:var(--spacing-md) var(--spacing-xl);}"));
    StrVec_Add(htmlVec, S(m, "header h3{font-family:var(--font-mono);font-size:15px;font-weight:600;letter-spacing:-0.02em;color:var(--color-text);text-transform:uppercase;margin:0;}"));
    StrVec_Add(htmlVec, S(m, "header a{text-decoration:none;color:inherit;transition:color 0.2s;}"));
    StrVec_Add(htmlVec, S(m, "header a:hover{color:var(--color-accent);}"));
    StrVec_Add(htmlVec, S(m, ".main-wrapper{flex:1;display:flex;max-width:1600px;margin:0 auto;width:100%;}"));
    StrVec_Add(htmlVec, S(m, ".sidebar-wrapper{width:300px;min-width:300px;background:var(--color-sidebar-bg);border-right:1px solid var(--color-border);padding:var(--spacing-xl) var(--spacing-lg);overflow-y:auto;position:sticky;top:65px;height:calc(100vh - 65px);scrollbar-width:thin;scrollbar-color:var(--color-border) transparent;}"));
    StrVec_Add(htmlVec, S(m, ".sidebar-wrapper::-webkit-scrollbar{width:6px;}"));
    StrVec_Add(htmlVec, S(m, ".sidebar-wrapper::-webkit-scrollbar-track{background:transparent;}"));
    StrVec_Add(htmlVec, S(m, ".sidebar-wrapper::-webkit-scrollbar-thumb{background:var(--color-border);border-radius:3px;}"));
    StrVec_Add(htmlVec, S(m, ".content-wrapper{flex:1;max-width:820px;padding:var(--spacing-2xl) var(--spacing-xl) var(--spacing-2xl) var(--spacing-2xl);}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__list{list-style:none;padding:0;margin:0;}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__list .p-side-navigation__list{padding-left:var(--spacing-md);margin-top:var(--spacing-xs);margin-bottom:var(--spacing-md);}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__item{margin-bottom:var(--spacing-xs);}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__text{display:flex;align-items:center;justify-content:space-between;font-family:var(--font-mono);font-size:13px;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;color:var(--color-text);padding:var(--spacing-sm) 0;margin-top:var(--spacing-lg);margin-bottom:var(--spacing-sm);cursor:pointer;user-select:none;}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__text:hover{color:var(--color-accent);}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__text::after{content:'▼';font-size:10px;transition:transform 0.2s;color:var(--color-text-muted);}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__text.collapsed::after{transform:rotate(-90deg);}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__list.collapsed{display:none;}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__link{display:block;padding:var(--spacing-sm) var(--spacing-md);font-size:15px;color:var(--color-text-muted);text-decoration:none;border-radius:4px;transition:all 0.15s ease;position:relative;}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__link:hover{color:var(--color-accent);background:rgba(193,68,14,0.04);}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__link:active{transform:translateX(2px);}"));
    StrVec_Add(htmlVec, S(m, ".p-side-navigation__link.active{color:var(--color-accent);background:rgba(193,68,14,0.08);font-weight:500;border-left:3px solid var(--color-accent);padding-left:calc(var(--spacing-md) - 3px);}"));
    StrVec_Add(htmlVec, S(m, "h1,h2,h3,h4,h5,h6{font-family:var(--font-serif);font-weight:600;line-height:1.3;color:var(--color-text);margin-top:var(--spacing-xl);margin-bottom:var(--spacing-md);}"));
    StrVec_Add(htmlVec, S(m, "h1{font-size:42px;letter-spacing:-0.02em;margin-top:0;margin-bottom:var(--spacing-lg);}"));
    StrVec_Add(htmlVec, S(m, "h2{font-size:32px;letter-spacing:-0.01em;margin-top:var(--spacing-2xl);padding-top:var(--spacing-lg);border-top:1px solid var(--color-border);}"));
    StrVec_Add(htmlVec, S(m, "h2:first-of-type{border-top:none;padding-top:0;}"));
    StrVec_Add(htmlVec, S(m, "h3{font-size:24px;}"));
    StrVec_Add(htmlVec, S(m, "h4{font-size:20px;}"));
    StrVec_Add(htmlVec, S(m, "p{margin-bottom:var(--spacing-lg);max-width:70ch;}"));
    StrVec_Add(htmlVec, S(m, "a{color:var(--color-accent);text-decoration:none;border-bottom:1px solid transparent;transition:border-color 0.2s;}"));
    StrVec_Add(htmlVec, S(m, "a:hover{border-bottom-color:var(--color-accent);}"));
    StrVec_Add(htmlVec, S(m, "code{font-family:var(--font-mono);font-size:0.9em;background:rgba(0,0,0,0.04);padding:0.15em 0.4em;border-radius:3px;color:var(--color-accent-soft);}"));
    StrVec_Add(htmlVec, S(m, "pre{font-family:var(--font-mono);font-size:14px;line-height:1.6;background:#1e1e1e;color:#d4d4d4;padding:var(--spacing-lg);border-radius:6px;overflow-x:auto;margin:var(--spacing-xl) 0;border:1px solid #333;}"));
    StrVec_Add(htmlVec, S(m, "pre code{background:none;padding:0;color:inherit;font-size:inherit;}"));
    StrVec_Add(htmlVec, S(m, "ul,ol{margin-bottom:var(--spacing-lg);padding-left:var(--spacing-xl);}"));
    StrVec_Add(htmlVec, S(m, "li{margin-bottom:var(--spacing-sm);}"));
    StrVec_Add(htmlVec, S(m, "strong{font-weight:600;color:var(--color-text);}"));
    StrVec_Add(htmlVec, S(m, "em{font-style:italic;font-family:var(--font-serif);}"));
    StrVec_Add(htmlVec, S(m, "blockquote{border-left:3px solid var(--color-accent);padding-left:var(--spacing-lg);margin:var(--spacing-xl) 0;color:var(--color-text-muted);font-style:italic;}"));
    StrVec_Add(htmlVec, S(m, "table{width:100%;border-collapse:collapse;margin:var(--spacing-xl) 0;font-size:16px;}"));
    StrVec_Add(htmlVec, S(m, "th,td{padding:var(--spacing-md);text-align:left;border-bottom:1px solid var(--color-border);}"));
    StrVec_Add(htmlVec, S(m, "th{font-family:var(--font-mono);font-size:13px;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;color:var(--color-text-muted);background:var(--color-sidebar-bg);}"));
    StrVec_Add(htmlVec, S(m, "footer{border-top:1px solid var(--color-border);background:var(--color-sidebar-bg);margin-top:auto;}"));
    StrVec_Add(htmlVec, S(m, "footer p{font-family:var(--font-mono);font-size:13px;color:var(--color-text-muted);text-align:center;padding:var(--spacing-xl) var(--spacing-md);margin:0;}"));
    StrVec_Add(htmlVec, S(m, "footer a{color:var(--color-text-muted);border-bottom:1px solid transparent;}"));
    StrVec_Add(htmlVec, S(m, "footer a:hover{color:var(--color-accent);border-bottom-color:var(--color-accent);}"));
    StrVec_Add(htmlVec, S(m, "@media(max-width:1024px){.sidebar-wrapper{position:static;width:100%;height:auto;border-right:none;border-bottom:1px solid var(--color-border);}.main-wrapper{flex-direction:column;}.content-wrapper{padding:var(--spacing-xl) var(--spacing-lg);}}"));
    StrVec_Add(htmlVec, S(m, "</style></head><body>"));

    // Header navigation
    StrVec_Add(htmlVec, S(m, "<header class=\"p-navigation\">"));
    StrVec_Add(htmlVec, S(m, "<div class=\"p-navigation__row\">"));
    StrVec_Add(htmlVec, S(m, "<div class=\"p-navigation__banner\">"));
    StrVec_Add(htmlVec, S(m, "<div class=\"p-navigation__logo\">"));
    StrVec_Add(htmlVec, S(m, "<a class=\"p-navigation__item\" href=\"/\">"));
    StrVec_Add(htmlVec, S(m, "<h3 class=\"p-heading--4\" style=\"margin:0;\">Caneka Documentation</h3>"));
    StrVec_Add(htmlVec, S(m, "</a></div></div></div></header>"));

    // Main content area with sidebar
    StrVec_Add(htmlVec, S(m, "<div class=\"main-wrapper\">"));

    // Sidebar
    if (sidebarHtml != NULL) {
        StrVec_Add(htmlVec, S(m, "<aside class=\"sidebar-wrapper\">"));
        StrVec_AddVec(htmlVec, sidebarHtml);
        StrVec_Add(htmlVec, S(m, "</aside>"));
    }

    // Page content
    StrVec_Add(htmlVec, S(m, "<main class=\"content-wrapper\">"));
    StrVec_AddVec(htmlVec, htmlContent);
    StrVec_Add(htmlVec, S(m, "</main></div>"));

    // Footer
    StrVec_Add(htmlVec, S(m, "<footer><div class=\"row\"><div class=\"col-12\" style=\"text-align:center;\">"));
    StrVec_Add(htmlVec, S(m, "<p><small>Built with <a href=\"https://caneka.org\">Caneka</a> &middot; "));
    StrVec_Add(htmlVec, S(m, "Styled with <a href=\"https://vanillaframework.io\">Vanilla Framework</a></small></p>"));
    StrVec_Add(htmlVec, S(m, "</div></div></footer>"));

    // JavaScript for collapsible sidebar
    StrVec_Add(htmlVec, S(m, "<script>"));
    StrVec_Add(htmlVec, S(m, "(function(){"));
    StrVec_Add(htmlVec, S(m, "var currentPath=window.location.pathname;"));
    StrVec_Add(htmlVec, S(m, "var activeLink=null;"));
    StrVec_Add(htmlVec, S(m, "var links=document.querySelectorAll('.p-side-navigation__link');"));
    StrVec_Add(htmlVec, S(m, "links.forEach(function(link){"));
    StrVec_Add(htmlVec, S(m, "if(link.getAttribute('href')===currentPath){"));
    StrVec_Add(htmlVec, S(m, "activeLink=link;"));
    StrVec_Add(htmlVec, S(m, "link.classList.add('active');"));
    StrVec_Add(htmlVec, S(m, "}"));
    StrVec_Add(htmlVec, S(m, "});"));
    StrVec_Add(htmlVec, S(m, "var activeLists=[];"));
    StrVec_Add(htmlVec, S(m, "if(activeLink){"));
    StrVec_Add(htmlVec, S(m, "var parent=activeLink.parentElement;"));
    StrVec_Add(htmlVec, S(m, "while(parent){"));
    StrVec_Add(htmlVec, S(m, "if(parent.classList.contains('p-side-navigation__list')){"));
    StrVec_Add(htmlVec, S(m, "activeLists.push(parent);"));
    StrVec_Add(htmlVec, S(m, "}"));
    StrVec_Add(htmlVec, S(m, "parent=parent.parentElement;"));
    StrVec_Add(htmlVec, S(m, "}"));
    StrVec_Add(htmlVec, S(m, "}"));
    StrVec_Add(htmlVec, S(m, "var headers=document.querySelectorAll('.p-side-navigation__text');"));
    StrVec_Add(htmlVec, S(m, "headers.forEach(function(h){"));
    StrVec_Add(htmlVec, S(m, "var list=h.nextElementSibling;"));
    StrVec_Add(htmlVec, S(m, "if(list&&list.classList.contains('p-side-navigation__list')){"));
    StrVec_Add(htmlVec, S(m, "var shouldStayOpen=activeLists.indexOf(list)!==-1;"));
    StrVec_Add(htmlVec, S(m, "if(!shouldStayOpen){"));
    StrVec_Add(htmlVec, S(m, "h.classList.add('collapsed');"));
    StrVec_Add(htmlVec, S(m, "list.classList.add('collapsed');"));
    StrVec_Add(htmlVec, S(m, "}"));
    StrVec_Add(htmlVec, S(m, "h.addEventListener('click',function(e){"));
    StrVec_Add(htmlVec, S(m, "e.preventDefault();"));
    StrVec_Add(htmlVec, S(m, "h.classList.toggle('collapsed');"));
    StrVec_Add(htmlVec, S(m, "list.classList.toggle('collapsed');"));
    StrVec_Add(htmlVec, S(m, "});"));
    StrVec_Add(htmlVec, S(m, "}"));
    StrVec_Add(htmlVec, S(m, "});"));
    StrVec_Add(htmlVec, S(m, "})();"));
    StrVec_Add(htmlVec, S(m, "</script>"));

    StrVec_Add(htmlVec, S(m, "</body></html>"));

    return Http_NewResponseVec(m, 200, S(m, "text/html"), htmlVec);
}

/**
 * Static file handler
 *
 * Serves files from the static directory with appropriate MIME types.
 * Returns 404 if file not found.
 *
 * SECURITY: Includes path traversal protection (CDOCS-014a)
 */
HttpResponse* Handler_Static(MemCh *m, HttpRequest *req, Str *docRoot) {
    // SECURITY CHECK 1: Reject paths containing ".." (directory traversal)
    // This prevents attacks like /static/../../../etc/passwd
    for (i32 i = 0; i < req->path->length - 1; i++) {
        if (req->path->bytes[i] == '.' && req->path->bytes[i + 1] == '.') {
            return Http_Forbidden(m);
        }
    }

    // SECURITY CHECK 2: Ensure path starts with "/static/"
    // This enforces that only files in the static directory can be served
    const char *requiredPrefix = "/static/";
    i32 prefixLen = 8; // length of "/static/"

    if (req->path->length < prefixLen) {
        return Http_Forbidden(m);
    }

    for (i32 i = 0; i < prefixLen; i++) {
        if (req->path->bytes[i] != requiredPrefix[i]) {
            return Http_Forbidden(m);
        }
    }

    // Build file path: docRoot + request path
    Str *filePath = Str_Make(m, 512);
    Str_Add(filePath, docRoot->bytes, docRoot->length);
    Str_Add(filePath, req->path->bytes, req->path->length);

    // Try to read file
    StrVec *content = File_ToVec(m, filePath);
    if (content == NULL || content->total == 0) {
        return Http_NotFound(m);
    }

    // Determine MIME type from file extension
    Str *mimeType = getMimeType(m, req->path);

    // Convert StrVec to Str for response body
    // Use custom function to bypass STR_MAX (2048) limit
    Str *body = StrVec_ToStrLarge(m, content);

    return Http_NewResponse(m, 200, mimeType, body);
}

/**
 * Smoke test handler (CDOCS-015a)
 *
 * Returns a simple HTML page to verify all HTTP server components work.
 * This validates: TCP server, HTTP parser, router, response generator.
 */
HttpResponse* Handler_SmokeTest(MemCh *m, HttpRequest *req, Str *docRoot) {
    (void)req; (void)docRoot; // Unused parameters

    Str *html = S(m,
        "<!DOCTYPE html>\n"
        "<html>\n"
        "<head><title>Caneka Docs - Server Test</title></head>\n"
        "<body style='font-family: sans-serif; padding: 40px;'>\n"
        "<h1 style='color: green;'>✓ HTTP Server Working!</h1>\n"
        "<h2>Component Checklist:</h2>\n"
        "<ul>\n"
        "  <li>✓ TCP Socket Server (accepts connections)</li>\n"
        "  <li>✓ HTTP Request Parser (parsed this request)</li>\n"
        "  <li>✓ URL Router (matched /test)</li>\n"
        "  <li>✓ Response Generator (created this response)</li>\n"
        "  <li>✓ Static File Handler (<a href='/static/test.txt'>test link</a>)</li>\n"
        "</ul>\n"
        "<p><strong>Epic 2 Complete!</strong> All HTTP server components verified.</p>\n"
        "</body>\n"
        "</html>\n");

    return Http_NewResponse(m, 200, S(m, "text/html"), html);
}

HttpResponse* Handler_IndexRedirect(MemCh *m, HttpRequest *req, Str *docRoot) {
    (void)req; (void)docRoot; // Unused parameters
    return Http_Redirect(m, S(m, "/docs/intro"));
}
