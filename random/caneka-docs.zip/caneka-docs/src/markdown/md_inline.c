#include <external.h>
#include <base_module.h>
#include "../markdown/markdown.h"

/**
 * Simple inline parser for Markdown
 *
 * Parses inline elements without using Roebling - uses manual string parsing
 * to match the approach used in md_block.c
 */

/**
 * Check if we're at the start of a specific inline marker
 */
static boolean matchMarker(Str *content, i32 pos, const char *marker, i32 markerLen) {
    if (pos + markerLen > content->length) {
        return FALSE;
    }

    for (i32 i = 0; i < markerLen; i++) {
        if (content->bytes[pos + i] != marker[i]) {
            return FALSE;
        }
    }

    return TRUE;
}

/**
 * Find the closing marker for an inline element
 * Returns the position of the closing marker, or -1 if not found
 */
static i32 findClosingMarker(Str *content, i32 startPos, const char *marker, i32 markerLen) {
    for (i32 i = startPos; i <= content->length - markerLen; i++) {
        if (matchMarker(content, i, marker, markerLen)) {
            return i;
        }
    }
    return -1;
}

/**
 * Parse inline markdown elements from block content
 *
 * This is a simplified version that handles:
 * - `code`
 * - **bold**
 * - *italic*
 * - [link](url)
 * - plain text
 *
 * @param m Memory chapter for allocations
 * @param content Raw text content (may contain inline markdown)
 * @return Span of MdInline elements
 */
Span* Markdown_ParseInlines(MemCh *m, Str *content) {
    if (content == NULL || content->length == 0) {
        Span *empty = Span_Make(m);
        return empty;
    }

    Span *inlines = Span_Make(m);
    i32 pos = 0;
    i32 lastTextStart = 0;

    while (pos < content->length) {
        MdInline *node = NULL;
        i32 markerStart = pos;
        i32 contentStart = -1;
        i32 contentEnd = -1;
        i32 nextPos = pos;

        // Check for inline code: `code`
        if (content->bytes[pos] == '`') {
            i32 closePos = findClosingMarker(content, pos + 1, "`", 1);
            if (closePos != -1) {
                // Found inline code
                // Add any plain text before this
                if (pos > lastTextStart) {
                    MdInline *textNode = MemCh_Alloc(m, sizeof(MdInline));
                    textNode->inlineType = MD_INLINE_TEXT;
                    textNode->text = Str_From(m, content->bytes + lastTextStart, pos - lastTextStart);
                    textNode->url = NULL;
                    Span_Add(inlines, textNode);
                }

                node = MemCh_Alloc(m, sizeof(MdInline));
                node->inlineType = MD_INLINE_CODE;
                node->text = Str_From(m, content->bytes + pos + 1, closePos - pos - 1);
                node->url = NULL;
                Span_Add(inlines, node);

                nextPos = closePos + 1;
                lastTextStart = nextPos;
            }
        }
        // Check for bold: **text**
        else if (pos + 1 < content->length &&
                 content->bytes[pos] == '*' && content->bytes[pos + 1] == '*') {
            i32 closePos = findClosingMarker(content, pos + 2, "**", 2);
            if (closePos != -1) {
                // Found bold
                if (pos > lastTextStart) {
                    MdInline *textNode = MemCh_Alloc(m, sizeof(MdInline));
                    textNode->inlineType = MD_INLINE_TEXT;
                    textNode->text = Str_From(m, content->bytes + lastTextStart, pos - lastTextStart);
                    textNode->url = NULL;
                    Span_Add(inlines, textNode);
                }

                node = MemCh_Alloc(m, sizeof(MdInline));
                node->inlineType = MD_INLINE_BOLD;
                node->text = Str_From(m, content->bytes + pos + 2, closePos - pos - 2);
                node->url = NULL;
                Span_Add(inlines, node);

                nextPos = closePos + 2;
                lastTextStart = nextPos;
            }
        }
        // Check for italic: *text* (but not **)
        else if (content->bytes[pos] == '*' &&
                 (pos + 1 >= content->length || content->bytes[pos + 1] != '*')) {
            i32 closePos = findClosingMarker(content, pos + 1, "*", 1);
            if (closePos != -1 && (closePos + 1 >= content->length || content->bytes[closePos + 1] != '*')) {
                // Found italic (and it's not bold)
                if (pos > lastTextStart) {
                    MdInline *textNode = MemCh_Alloc(m, sizeof(MdInline));
                    textNode->inlineType = MD_INLINE_TEXT;
                    textNode->text = Str_From(m, content->bytes + lastTextStart, pos - lastTextStart);
                    textNode->url = NULL;
                    Span_Add(inlines, textNode);
                }

                node = MemCh_Alloc(m, sizeof(MdInline));
                node->inlineType = MD_INLINE_ITALIC;
                node->text = Str_From(m, content->bytes + pos + 1, closePos - pos - 1);
                node->url = NULL;
                Span_Add(inlines, node);

                nextPos = closePos + 1;
                lastTextStart = nextPos;
            }
        }
        // Check for images: ![alt](src)
        else if (content->bytes[pos] == '!' &&
                 pos + 1 < content->length &&
                 content->bytes[pos + 1] == '[') {
            i32 textClosePos = findClosingMarker(content, pos + 2, "]", 1);
            if (textClosePos != -1 &&
                textClosePos + 1 < content->length &&
                content->bytes[textClosePos + 1] == '(') {
                i32 urlClosePos = findClosingMarker(content, textClosePos + 2, ")", 1);
                if (urlClosePos != -1) {
                    // Found image
                    if (pos > lastTextStart) {
                        MdInline *textNode = MemCh_Alloc(m, sizeof(MdInline));
                        textNode->inlineType = MD_INLINE_TEXT;
                        textNode->text = Str_From(m, content->bytes + lastTextStart, pos - lastTextStart);
                        textNode->url = NULL;
                        Span_Add(inlines, textNode);
                    }

                    node = MemCh_Alloc(m, sizeof(MdInline));
                    node->inlineType = MD_INLINE_IMAGE;
                    node->text = Str_From(m, content->bytes + pos + 2, textClosePos - pos - 2);
                    node->url = Str_From(m, content->bytes + textClosePos + 2, urlClosePos - textClosePos - 2);
                    Span_Add(inlines, node);

                    nextPos = urlClosePos + 1;
                    lastTextStart = nextPos;
                }
            }
        }
        // Check for links: [text](url)
        else if (content->bytes[pos] == '[') {
            i32 textClosePos = findClosingMarker(content, pos + 1, "]", 1);
            if (textClosePos != -1 &&
                textClosePos + 1 < content->length &&
                content->bytes[textClosePos + 1] == '(') {
                i32 urlClosePos = findClosingMarker(content, textClosePos + 2, ")", 1);
                if (urlClosePos != -1) {
                    // Found link
                    if (pos > lastTextStart) {
                        MdInline *textNode = MemCh_Alloc(m, sizeof(MdInline));
                        textNode->inlineType = MD_INLINE_TEXT;
                        textNode->text = Str_From(m, content->bytes + lastTextStart, pos - lastTextStart);
                        textNode->url = NULL;
                        Span_Add(inlines, textNode);
                    }

                    node = MemCh_Alloc(m, sizeof(MdInline));
                    node->inlineType = MD_INLINE_LINK;
                    node->text = Str_From(m, content->bytes + pos + 1, textClosePos - pos - 1);
                    node->url = Str_From(m, content->bytes + textClosePos + 2, urlClosePos - textClosePos - 2);
                    Span_Add(inlines, node);

                    nextPos = urlClosePos + 1;
                    lastTextStart = nextPos;
                }
            }
        }

        // If we didn't find any inline marker, move forward
        if (nextPos == pos) {
            nextPos = pos + 1;
        }

        pos = nextPos;
    }

    // Add any remaining plain text
    if (lastTextStart < content->length) {
        MdInline *textNode = MemCh_Alloc(m, sizeof(MdInline));
        textNode->inlineType = MD_INLINE_TEXT;
        textNode->text = Str_From(m, content->bytes + lastTextStart, content->length - lastTextStart);
        textNode->url = NULL;
        Span_Add(inlines, textNode);
    }

    // If no inline elements were found at all, return span with just plain text
    if (inlines->nvalues == 0) {
        MdInline *textNode = MemCh_Alloc(m, sizeof(MdInline));
        textNode->inlineType = MD_INLINE_TEXT;
        textNode->text = content;
        textNode->url = NULL;
        Span_Add(inlines, textNode);
    }

    return inlines;
}
