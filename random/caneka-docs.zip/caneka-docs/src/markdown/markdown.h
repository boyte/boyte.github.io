#ifndef CANEKA_DOCS_MARKDOWN_H
#define CANEKA_DOCS_MARKDOWN_H

#include <base_module.h>

/**
 * YAML Frontmatter structure
 *
 * Parsed from the --- delimited block at the start of markdown files.
 * Example:
 *   ---
 *   title: Getting Started
 *   sidebar_position: 1
 *   description: Quick start guide
 *   ---
 */
typedef struct MdFrontmatter {
    Str *title;              // Page title
    i32 sidebarPosition;     // Position in sidebar (for sorting)
    Str *description;        // Page description
} MdFrontmatter;

/**
 * Markdown block types
 */
typedef enum {
    MD_BLOCK_HEADING,        // # Heading
    MD_BLOCK_PARAGRAPH,      // Regular paragraph
    MD_BLOCK_CODE,           // ```code block```
    MD_BLOCK_LIST,           // - or 1. list
    MD_BLOCK_TABLE           // | table | row |
} MdBlockType;

/**
 * Markdown block structure
 *
 * Represents a single block-level element in the document.
 */
typedef struct MdBlock {
    MdBlockType blockType;   // Type of block
    i32 level;               // Heading level (1-6) or list nesting level
    boolean ordered;         // For lists: true for ordered (1.), false for unordered (-)
    Str *content;            // Raw content of block
    Str *language;           // Language for code blocks (e.g., "c", "bash")
    Span *children;          // Child blocks (for nested lists)
    Span *inlineNodes;       // Inline elements within this block
} MdBlock;

/**
 * Markdown inline element types
 */
typedef enum {
    MD_INLINE_TEXT,          // Plain text
    MD_INLINE_BOLD,          // **bold**
    MD_INLINE_ITALIC,        // *italic*
    MD_INLINE_CODE,          // `code`
    MD_INLINE_LINK,          // [text](url)
    MD_INLINE_IMAGE          // ![alt](src)
} MdInlineType;

/**
 * Markdown inline element structure
 */
typedef struct MdInline {
    MdInlineType inlineType; // Type of inline element
    Str *text;               // Text content
    Str *url;                // URL for links
} MdInline;

/**
 * Parsed markdown document structure
 */
typedef struct MdDocument {
    MdFrontmatter *frontmatter; // Frontmatter metadata (may be NULL)
    Span *blocks;               // Array of MdBlock structures
} MdDocument;

/**
 * Parse frontmatter from markdown content
 *
 * Extracts YAML frontmatter if present and returns content without frontmatter.
 *
 * @param m Memory chapter for allocations
 * @param markdown Full markdown content
 * @param fmOut Output parameter for frontmatter (NULL if not present)
 * @return Markdown content with frontmatter removed
 */
Str* Markdown_ParseFrontmatter(MemCh *m, Str *markdown, MdFrontmatter **fmOut);

/**
 * Parse markdown headers using Roebling pattern matcher
 *
 * This function parses ONLY headers (# through ######).
 * Other block types are handled by separate parsers.
 *
 * @param m Memory chapter for allocations
 * @param markdown Markdown content (should have frontmatter removed)
 * @return MdDocument with header blocks
 */
MdDocument* Markdown_ParseHeaders(MemCh *m, Str *markdown);

/**
 * Group consecutive list items into proper nested structures
 *
 * Takes flat array of blocks and groups consecutive MD_BLOCK_LIST items
 * into proper parent/child hierarchies.
 *
 * @param m Memory chapter for allocations
 * @param flatBlocks Flat array of blocks (may contain sequential list items)
 * @return Array with list items properly grouped
 */
Span* Markdown_GroupLists(MemCh *m, Span *flatBlocks);

/**
 * Parse markdown content into document structure
 *
 * @param m Memory chapter for allocations
 * @param markdown Markdown content (without frontmatter)
 * @return Parsed MdDocument with blocks and inline elements
 */
MdDocument* Markdown_Parse(MemCh *m, Str *markdown);

/**
 * Parse inline markdown elements from block content
 *
 * Parses inline elements within a block's content text:
 * - Links [text](url)
 * - Images ![alt](src)
 * - Bold **text**
 * - Italic *text*
 * - Inline code `code`
 * - Plain text
 *
 * @param m Memory chapter for allocations
 * @param content Raw text content that may contain inline markdown
 * @return Span of MdInline elements
 */
Span* Markdown_ParseInlines(MemCh *m, Str *content);

/**
 * Render markdown document to HTML
 *
 * Returns StrVec to avoid size limits (allows unlimited content).
 *
 * @param m Memory chapter for allocations
 * @param doc Parsed markdown document
 * @return HTML as StrVec (multiple strings, unlimited total size)
 */
StrVec* Markdown_ToHtml(MemCh *m, MdDocument *doc);

/**
 * Parse and render markdown in one step
 *
 * Convenience function that combines parsing and HTML generation.
 *
 * @param m Memory chapter for allocations
 * @param markdown Raw markdown content
 * @return HTML string
 */
StrVec* Markdown_Render(MemCh *m, Str *markdown);

/**
 * Convert text to URL-safe slug
 *
 * Used for generating heading IDs.
 * Example: "Getting Started" -> "getting-started"
 *
 * @param m Memory chapter for allocations
 * @param text Text to slugify
 * @return Lowercase hyphenated slug
 */
Str* Markdown_Slugify(MemCh *m, Str *text);

/**
 * Resolve relative link to absolute path
 *
 * Handles:
 * - Absolute URLs: "https://example.com" (unchanged)
 * - Absolute paths: "/docs/intro" (unchanged)
 * - Relative current: "./intro" from "/docs/getting-started/" -> "/docs/intro"
 * - Relative parent: "../api/base" from "/docs/guides/" -> "/docs/api/base"
 *
 * @param m Memory chapter for allocations
 * @param currentPath Current document path (e.g., "/docs/getting-started/install")
 * @param linkHref Link href attribute value
 * @return Resolved absolute path or URL
 */
Str* Markdown_ResolveLink(MemCh *m, Str *currentPath, Str *linkHref);

/**
 * Rewrite image paths for static serving
 *
 * Converts document-relative image paths to static server paths.
 * Example: "/diagrams/iter.svg" -> "/static/diagrams/iter.svg"
 *
 * @param m Memory chapter for allocations
 * @param href Image path from markdown
 * @return Rewritten path for static handler
 */
Str* Markdown_RewriteImagePath(MemCh *m, Str *href);

/**
 * Escape HTML special characters
 *
 * Prevents XSS attacks by escaping < > & " ' to HTML entities.
 *
 * @param m Memory chapter for allocations
 * @param text Text that may contain HTML special chars
 * @return HTML-safe escaped text
 */
Str* Html_Escape(MemCh *m, Str *text);

#endif // CANEKA_DOCS_MARKDOWN_H
