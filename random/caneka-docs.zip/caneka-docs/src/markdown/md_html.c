#include <external.h>
#include <base_module.h>
#include "../markdown/markdown.h"

/**
 * HTML Generator for Markdown
 *
 * Converts Markdown AST (MdDocument with MdBlock and MdInline nodes)
 * to HTML strings with proper tags, entity escaping, and structure.
 */

/**
 * Helper function to add C string to StrVec
 */
static inline void StrVec_AddCstr(MemCh *m, StrVec *v, const char *cstr) {
    StrVec_Add(v, S(m, (char*)cstr));
}

/**
 * Escape HTML special characters to prevent XSS attacks
 *
 * Replaces: < > & " ' with their HTML entity equivalents
 */
Str* Html_Escape(MemCh *m, Str *text) {
    if (text == NULL || text->length == 0) {
        return S(m, "");
    }

    Str *result = Str_Make(m, 1024);  // Start smaller, will grow as needed

    for (i32 i = 0; i < text->length; i++) {
        byte c = text->bytes[i];

        switch (c) {
            case '<':
                Str_AddCstr(result, "&lt;");
                break;
            case '>':
                Str_AddCstr(result, "&gt;");
                break;
            case '&':
                Str_AddCstr(result, "&amp;");
                break;
            case '"':
                Str_AddCstr(result, "&quot;");
                break;
            case '\'':
                Str_AddCstr(result, "&#39;");
                break;
            default:
                Str_Add(result, &c, 1);
                break;
        }
    }

    return result;
}

/**
 * Convert text to URL-safe slug for header IDs
 *
 * Example: "Getting Started" -> "getting-started"
 */
Str* Markdown_Slugify(MemCh *m, Str *text) {
    if (text == NULL || text->length == 0) {
        return S(m, "");
    }

    Str *result = Str_Make(m, text->length);
    boolean lastWasHyphen = FALSE;

    for (i32 i = 0; i < text->length; i++) {
        byte c = text->bytes[i];

        // Convert to lowercase and check if alphanumeric
        if ((c >= 'A' && c <= 'Z')) {
            c = c + ('a' - 'A');  // Convert to lowercase
            Str_Add(result, &c, 1);
            lastWasHyphen = FALSE;
        } else if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
            Str_Add(result, &c, 1);
            lastWasHyphen = FALSE;
        } else if ((c == ' ' || c == '-' || c == '_') && !lastWasHyphen) {
            // Replace spaces and separators with hyphens (but not consecutive)
            byte hyphen = '-';
            Str_Add(result, &hyphen, 1);
            lastWasHyphen = TRUE;
        }
        // Skip other special characters
    }

    // Remove trailing hyphen if present
    if (result->length > 0 && result->bytes[result->length - 1] == '-') {
        result->length--;
    }

    return result;
}

/**
 * Check if string starts with prefix
 */
static boolean startsWithPrefix(Str *str, const char *prefix, i32 prefixLen) {
    if (str->length < prefixLen) {
        return FALSE;
    }
    for (i32 i = 0; i < prefixLen; i++) {
        if (str->bytes[i] != prefix[i]) {
            return FALSE;
        }
    }
    return TRUE;
}

/**
 * Check if URL ends with .svg (ignoring query/hash).
 */
static boolean hasSvgExtension(Str *url) {
    if (url == NULL || url->length < 4) {
        return FALSE;
    }

    i32 end = url->length;
    for (i32 i = 0; i < url->length; i++) {
        byte c = url->bytes[i];
        if (c == '?' || c == '#') {
            end = i;
            break;
        }
    }

    if (end < 4) {
        return FALSE;
    }

    const char *suffix = ".svg";
    for (i32 i = 0; i < 4; i++) {
        byte c = url->bytes[end - 4 + i];
        if (c >= 'A' && c <= 'Z') {
            c = c + ('a' - 'A');
        }
        if (c != (byte)suffix[i]) {
            return FALSE;
        }
    }

    return TRUE;
}

/**
 * Process URL to handle .md extension and make it web-friendly
 *
 * Strips .md extension from relative URLs to match web server routing
 * Example: "getting-started/installation.md" -> "getting-started/installation"
 */
static Str* processUrl(MemCh *m, Str *url) {
    if (url == NULL || url->length == 0) {
        return url;
    }

    // Check if URL starts with http:// or https:// (external link)
    if (startsWithPrefix(url, "http://", 7) || startsWithPrefix(url, "https://", 8)) {
        return url;  // Don't modify external URLs
    }

    // Check if URL ends with .md
    if (url->length > 3 &&
        url->bytes[url->length - 3] == '.' &&
        url->bytes[url->length - 2] == 'm' &&
        url->bytes[url->length - 1] == 'd') {
        // Strip .md extension
        return Str_From(m, url->bytes, url->length - 3);
    }

    return url;
}

/**
 * Convert inline elements to HTML (returns StrVec to avoid size limits)
 */
static StrVec* inlinesToHtml(MemCh *m, Span *inlines) {
    StrVec *result = StrVec_Make(m);

    if (inlines == NULL || inlines->nvalues == 0) {
        return result;
    }

    for (i32 i = 0; i < inlines->nvalues; i++) {
        MdInline *node = (MdInline*)Span_Get(inlines, i);

        switch (node->inlineType) {
            case MD_INLINE_TEXT: {
                Str *escaped = Html_Escape(m, node->text);
                StrVec_Add(result, escaped);
                break;
            }

            case MD_INLINE_BOLD: {
                StrVec_AddCstr(m, result, "<strong>");
                Str *escaped = Html_Escape(m, node->text);
                StrVec_Add(result, escaped);
                StrVec_AddCstr(m, result, "</strong>");
                break;
            }

            case MD_INLINE_ITALIC: {
                StrVec_AddCstr(m, result, "<em>");
                Str *escaped = Html_Escape(m, node->text);
                StrVec_Add(result, escaped);
                StrVec_AddCstr(m, result, "</em>");
                break;
            }

            case MD_INLINE_CODE: {
                StrVec_AddCstr(m, result, "<code>");
                Str *escaped = Html_Escape(m, node->text);
                StrVec_Add(result, escaped);
                StrVec_AddCstr(m, result, "</code>");
                break;
            }

            case MD_INLINE_LINK: {
                StrVec_AddCstr(m, result, "<a href=\"");
                Str *processedUrl = processUrl(m, node->url);
                Str *escapedUrl = Html_Escape(m, processedUrl);
                StrVec_Add(result, escapedUrl);
                StrVec_AddCstr(m, result, "\">");
                Str *escapedText = Html_Escape(m, node->text);
                StrVec_Add(result, escapedText);
                StrVec_AddCstr(m, result, "</a>");
                break;
            }

            case MD_INLINE_IMAGE: {
                Str *rewrittenUrl = Markdown_RewriteImagePath(m, node->url);
                Str *escapedUrl = Html_Escape(m, rewrittenUrl);
                Str *escapedAlt = Html_Escape(m, node->text);
                if (hasSvgExtension(rewrittenUrl)) {
                    StrVec_AddCstr(m, result, "<object class=\"doc-image\" type=\"image/svg+xml\" data=\"");
                    StrVec_Add(result, escapedUrl);
                    StrVec_AddCstr(m, result, "\" aria-label=\"");
                    StrVec_Add(result, escapedAlt);
                    StrVec_AddCstr(m, result, "\">");
                    StrVec_AddCstr(m, result, "<img class=\"doc-image\" src=\"");
                    StrVec_Add(result, escapedUrl);
                    StrVec_AddCstr(m, result, "\" alt=\"");
                    StrVec_Add(result, escapedAlt);
                    StrVec_AddCstr(m, result, "\" />");
                    StrVec_AddCstr(m, result, "</object>");
                } else {
                    StrVec_AddCstr(m, result, "<img class=\"doc-image\" src=\"");
                    StrVec_Add(result, escapedUrl);
                    StrVec_AddCstr(m, result, "\" alt=\"");
                    StrVec_Add(result, escapedAlt);
                    StrVec_AddCstr(m, result, "\" />");
                }
                break;
            }
        }
    }

    return result;
}

/**
 * Convert a single block to HTML (returns StrVec to avoid size limits)
 */
static StrVec* blockToHtml(MemCh *m, MdBlock *block) {
    StrVec *result = StrVec_Make(m);

    switch (block->blockType) {
        case MD_BLOCK_HEADING: {
            // Generate header tag: <h1 id="slug">Content</h1>
            Str *slug = Markdown_Slugify(m, block->content);
            StrVec *inlineHtml = inlinesToHtml(m, block->inlineNodes);

            // Build header HTML
            char levelStr[2] = {'0' + block->level, '\0'};
            StrVec_AddCstr(m, result, "<h");
            StrVec_AddCstr(m, result, levelStr);
            StrVec_AddCstr(m, result, " id=\"");
            StrVec_Add(result, slug);
            StrVec_AddCstr(m, result, "\">");
            StrVec_AddVec(result, inlineHtml);
            StrVec_AddCstr(m, result, "</h");
            StrVec_AddCstr(m, result, levelStr);
            StrVec_AddCstr(m, result, ">\n");
            break;
        }

        case MD_BLOCK_PARAGRAPH: {
            StrVec *inlineHtml = inlinesToHtml(m, block->inlineNodes);
            StrVec_AddCstr(m, result, "<p>");
            StrVec_AddVec(result, inlineHtml);
            StrVec_AddCstr(m, result, "</p>\n");
            break;
        }

        case MD_BLOCK_CODE: {
            Str *escaped = Html_Escape(m, block->content);
            StrVec_AddCstr(m, result, "<pre><code");

            // Add language class if present
            if (block->language != NULL && block->language->length > 0) {
                StrVec_AddCstr(m, result, " class=\"language-");
                StrVec_Add(result, block->language);
                StrVec_AddCstr(m, result, "\"");
            }

            StrVec_AddCstr(m, result, ">");
            StrVec_Add(result, escaped);
            StrVec_AddCstr(m, result, "</code></pre>\n");
            break;
        }

        case MD_BLOCK_LIST: {
            // Determine list type
            const char *listTag = block->ordered ? "ol" : "ul";

            StrVec_AddCstr(m, result, "<");
            StrVec_AddCstr(m, result, listTag);
            StrVec_AddCstr(m, result, ">\n");

            // Process list items (children)
            if (block->children != NULL) {
                for (i32 i = 0; i < block->children->nvalues; i++) {
                    MdBlock *child = (MdBlock*)Span_Get(block->children, i);
                    StrVec *childHtml = inlinesToHtml(m, child->inlineNodes);

                    StrVec_AddCstr(m, result, "<li>");
                    StrVec_AddVec(result, childHtml);

                    // Handle nested lists - child->children contains nested list blocks
                    if (child->children != NULL && child->children->nvalues > 0) {
                        for (i32 j = 0; j < child->children->nvalues; j++) {
                            MdBlock *nestedList = (MdBlock*)Span_Get(child->children, j);
                            StrVec *nestedHtml = blockToHtml(m, nestedList);
                            StrVec_AddVec(result, nestedHtml);
                        }
                    }

                    StrVec_AddCstr(m, result, "</li>\n");
                }
            }

            StrVec_AddCstr(m, result, "</");
            StrVec_AddCstr(m, result, listTag);
            StrVec_AddCstr(m, result, ">\n");
            break;
        }

        case MD_BLOCK_TABLE: {
            // Simple table rendering (can be enhanced)
            Str *escaped = Html_Escape(m, block->content);
            StrVec_AddCstr(m, result, "<table>\n");
            StrVec_Add(result, escaped);
            StrVec_AddCstr(m, result, "</table>\n");
            break;
        }
    }

    return result;
}

/**
 * Render markdown document to HTML (returns StrVec to avoid size limits)
 */
StrVec* Markdown_ToHtml(MemCh *m, MdDocument *doc) {
    StrVec *result = StrVec_Make(m);

    if (doc == NULL) {
        return result;
    }

    // Process all blocks
    if (doc->blocks != NULL) {
        for (i32 i = 0; i < doc->blocks->nvalues; i++) {
            MdBlock *block = (MdBlock*)Span_Get(doc->blocks, i);
            StrVec *blockHtml = blockToHtml(m, block);
            StrVec_AddVec(result, blockHtml);
        }
    }

    return result;
}

/**
 * Parse and render markdown in one step (convenience function)
 *
 * NOTE: This function will be implemented in CDOCS-025 when Markdown_Parse is available
 */
/*
Str* Markdown_Render(MemCh *m, Str *markdown) {
    MdDocument *doc = Markdown_Parse(m, markdown);
    return Markdown_ToHtml(m, doc);
}
*/
