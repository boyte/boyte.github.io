#include <external.h>
#include <base_module.h>
#include "../markdown/markdown.h"


/**
 * Check if a line starts with three or more backticks (code fence)
 */
static boolean isCodeFence(Str *line) {
    if (line->length < 3) {
        return FALSE;
    }
    return (line->bytes[0] == '`' && line->bytes[1] == '`' && line->bytes[2] == '`');
}

/**
 * Extract language from opening code fence line
 * Example: "```c" -> "c", "```" -> ""
 */
static Str* extractLanguage(MemCh *m, Str *line) {
    // Skip the three backticks
    i32 i = 3;

    // Skip any spaces
    while (i < line->length && line->bytes[i] == ' ') {
        i++;
    }

    // Extract language (rest of line)
    if (i < line->length) {
        return Str_From(m, line->bytes + i, line->length - i);
    }

    return S(m, "");
}

/**
 * Count leading spaces/tabs in a line for determining nesting level
 */
static i32 countIndent(Str *line) {
    i32 count = 0;
    for (i32 i = 0; i < line->length; i++) {
        if (line->bytes[i] == ' ') {
            count++;
        } else if (line->bytes[i] == '\t') {
            count += 4;  // Tab counts as 4 spaces
        } else {
            break;
        }
    }
    return count;
}

/**
 * Check if line is an unordered list item (starts with - or * after optional indent)
 * Returns: index after the marker, or -1 if not a list item
 */
static i32 isUnorderedList(Str *line) {
    i32 i = 0;

    // Skip leading spaces/tabs
    while (i < line->length && (line->bytes[i] == ' ' || line->bytes[i] == '\t')) {
        i++;
    }

    // Check for - or * marker
    if (i < line->length && (line->bytes[i] == '-' || line->bytes[i] == '*')) {
        i++;

        // Must be followed by a space
        if (i < line->length && line->bytes[i] == ' ') {
            return i + 1;  // Return position after marker and space
        }
    }

    return -1;
}

/**
 * Check if line is an ordered list item (starts with digit(s). after optional indent)
 * Returns: index after the marker, or -1 if not a list item
 */
static i32 isOrderedList(Str *line) {
    i32 i = 0;

    // Skip leading spaces/tabs
    while (i < line->length && (line->bytes[i] == ' ' || line->bytes[i] == '\t')) {
        i++;
    }

    // Check for digit(s)
    if (i >= line->length || line->bytes[i] < '0' || line->bytes[i] > '9') {
        return -1;
    }

    while (i < line->length && line->bytes[i] >= '0' && line->bytes[i] <= '9') {
        i++;
    }

    // Must be followed by period and space
    if (i + 1 < line->length && line->bytes[i] == '.' && line->bytes[i + 1] == ' ') {
        return i + 2;  // Return position after period and space
    }

    return -1;
}

/**
 * Check if line is a table row (contains | characters)
 */
static boolean isTableRow(Str *line) {
    if (line == NULL || line->length == 0) {
        return FALSE;
    }

    // Table rows typically start with | or have | somewhere
    for (i32 i = 0; i < line->length; i++) {
        if (line->bytes[i] == '|') {
            return TRUE;
        }
    }

    return FALSE;
}

/**
 * Check if line is a table separator row (contains |---|)
 */
static boolean isTableSeparator(Str *line) {
    if (line == NULL || line->length < 3) {
        return FALSE;
    }

    // Must contain at least one sequence like |---|
    boolean hasPipe = FALSE;
    boolean hasDashes = FALSE;

    for (i32 i = 0; i < line->length; i++) {
        if (line->bytes[i] == '|') {
            hasPipe = TRUE;
        } else if (line->bytes[i] == '-') {
            hasDashes = TRUE;
        } else if (line->bytes[i] != ' ' && line->bytes[i] != ':') {
            // Invalid character for separator row
            return FALSE;
        }
    }

    return hasPipe && hasDashes;
}

/**
 * Group consecutive list items into proper list structures
 *
 * Takes flat list of blocks and groups consecutive MD_BLOCK_LIST items
 * into nested list structures with proper parent/child relationships.
 */
Span* Markdown_GroupLists(MemCh *m, Span *flatBlocks) {
    if (flatBlocks == NULL || flatBlocks->nvalues == 0) {
        return flatBlocks;
    }

    Span *grouped = Span_Make(m);
    i32 i = 0;

    while (i < flatBlocks->nvalues) {
        MdBlock *block = (MdBlock*)Span_Get(flatBlocks, i);

        if (block->blockType == MD_BLOCK_LIST && block->level == 0) {
            // Start of a top-level list - gather consecutive level-0 items of same type
            boolean isOrdered = block->ordered;
            Span *items = Span_Make(m);

            // Collect top-level list items and their nested children
            while (i < flatBlocks->nvalues) {
                MdBlock *item = (MdBlock*)Span_Get(flatBlocks, i);

                if (item->blockType != MD_BLOCK_LIST) {
                    break;  // Not a list item anymore
                }

                if (item->level > 0) {
                    break;  // This is a nested item, shouldn't appear at top level
                }

                if (item->level == 0 && item->ordered != isOrdered && items->nvalues > 0) {
                    break;  // Different list type (ol vs ul) at top level
                }

                // This is a top-level item - add it
                Span_Add(items, item);
                i++;

                // Check if next items are nested children (level > 0)
                if (i < flatBlocks->nvalues) {
                    MdBlock *nextItem = (MdBlock*)Span_Get(flatBlocks, i);

                    if (nextItem->blockType == MD_BLOCK_LIST && nextItem->level > 0) {
                        // Collect nested items
                        Span *nestedItems = Span_Make(m);
                        boolean nestedOrdered = nextItem->ordered;
                        i32 nestedLevel = nextItem->level;

                        while (i < flatBlocks->nvalues) {
                            MdBlock *nested = (MdBlock*)Span_Get(flatBlocks, i);

                            if (nested->blockType != MD_BLOCK_LIST) {
                                break;  // Not a list anymore
                            }

                            if (nested->level < nestedLevel) {
                                break;  // Back to parent level
                            }

                            if (nested->level == nestedLevel) {
                                Span_Add(nestedItems, nested);
                                i++;
                            } else {
                                // Different nesting level
                                break;
                            }
                        }

                        // Create nested list block and attach to parent item
                        if (nestedItems->nvalues > 0) {
                            MdBlock *nestedList = MemCh_Alloc(m, sizeof(MdBlock));
                            nestedList->blockType = MD_BLOCK_LIST;
                            nestedList->level = nestedLevel;
                            nestedList->ordered = nestedOrdered;
                            nestedList->content = NULL;
                            nestedList->language = NULL;
                            nestedList->children = nestedItems;
                            nestedList->inlineNodes = NULL;

                            // Attach nested list to the parent item
                            item->children = Span_Make(m);
                            Span_Add(item->children, nestedList);
                        }
                    }
                }
            }

            // Create parent list block
            MdBlock *listBlock = MemCh_Alloc(m, sizeof(MdBlock));
            listBlock->blockType = MD_BLOCK_LIST;
            listBlock->level = 0;
            listBlock->ordered = isOrdered;
            listBlock->content = NULL;
            listBlock->language = NULL;
            listBlock->children = items;
            listBlock->inlineNodes = NULL;

            Span_Add(grouped, listBlock);
        } else {
            // Not a list, add as-is
            Span_Add(grouped, block);
            i++;
        }
    }

    return grouped;
}

/**
 * Parse markdown headers and code blocks
 *
 * This function parses headers (# through ######) and fenced code blocks (```).
 *
 * @param m Memory chapter for allocations
 * @param markdown Markdown content (should have frontmatter removed)
 * @return MdDocument with parsed blocks
 */
MdDocument* Markdown_ParseHeaders(MemCh *m, Str *markdown) {
    if (markdown == NULL || markdown->length == 0) {
        MdDocument *doc = MemCh_Alloc(m, sizeof(MdDocument));
        doc->frontmatter = NULL;
        doc->blocks = Span_Make(m);
        return doc;
    }

    // Create blocks array
    Span *blocks = Span_Make(m);

    // Code block state
    boolean inCodeBlock = FALSE;
    MdBlock *currentCodeBlock = NULL;
    Str *codeContent = NULL;

    // Table state
    boolean inTable = FALSE;
    Str *tableContent = NULL;

    // Paragraph state
    boolean inParagraph = FALSE;
    Str *paragraphContent = NULL;

    // Split markdown into lines and parse blocks
    i32 lineStart = 0;

    for (i32 i = 0; i <= markdown->length; i++) {
        // End of line or end of string
        if (i == markdown->length || markdown->bytes[i] == '\n') {
            i32 lineEnd = i;

            // Skip \r if present (handle \r\n)
            if (lineEnd > lineStart && markdown->bytes[lineEnd - 1] == '\r') {
                lineEnd--;
            }

            // Extract line
            Str *line = NULL;
            if (lineEnd >= lineStart) {
                line = Str_From(m, markdown->bytes + lineStart, lineEnd - lineStart);
            }

            if (line != NULL && line->length > 0) {
                // Check for code fence (```)
                if (isCodeFence(line)) {
                    if (!inCodeBlock) {
                        // Opening code fence
                        inCodeBlock = TRUE;

                        // Create code block
                        currentCodeBlock = MemCh_Alloc(m, sizeof(MdBlock));
                        currentCodeBlock->blockType = MD_BLOCK_CODE;
                        currentCodeBlock->level = 0;
                        currentCodeBlock->ordered = FALSE;
                        currentCodeBlock->language = extractLanguage(m, line);
                        currentCodeBlock->children = NULL;
                        currentCodeBlock->inlineNodes = NULL;

                        // Initialize code content
                        codeContent = Str_Make(m, 256);
                    } else {
                        // Closing code fence
                        inCodeBlock = FALSE;
                        currentCodeBlock->content = codeContent;

                        // Add to blocks array
                        Span_Add(blocks, currentCodeBlock);

                        currentCodeBlock = NULL;
                        codeContent = NULL;
                    }
                } else if (inCodeBlock) {
                    // Inside code block - accumulate line
                    if (codeContent->length > 0) {
                        Str_AddCstr(codeContent, "\n");
                    }
                    Str_Add(codeContent, line->bytes, line->length);
                } else {
                    // Not in code block - check for tables, lists, headers, etc.

                    // Check for table rows
                    boolean isTable = isTableRow(line);

                    if (isTable) {
                        if (!inTable) {
                            // Finalize any paragraph before starting table
                            if (inParagraph) {
                                inParagraph = FALSE;

                                MdBlock *paraBlock = MemCh_Alloc(m, sizeof(MdBlock));
                                paraBlock->blockType = MD_BLOCK_PARAGRAPH;
                                paraBlock->level = 0;
                                paraBlock->ordered = FALSE;
                                paraBlock->content = paragraphContent;
                                paraBlock->language = NULL;
                                paraBlock->children = NULL;
                                paraBlock->inlineNodes = NULL;

                                Span_Add(blocks, paraBlock);
                                paragraphContent = NULL;
                            }

                            // Start of table
                            inTable = TRUE;
                            tableContent = Str_Make(m, 256);
                            Str_Add(tableContent, line->bytes, line->length);
                        } else {
                            // Continue table - add line
                            Str_AddCstr(tableContent, "\n");
                            Str_Add(tableContent, line->bytes, line->length);
                        }
                    } else {
                        // Not a table row
                        // If we were in a table, finalize it
                        if (inTable) {
                            inTable = FALSE;

                            // Create table block
                            MdBlock *block = MemCh_Alloc(m, sizeof(MdBlock));
                            block->blockType = MD_BLOCK_TABLE;
                            block->level = 0;
                            block->ordered = FALSE;
                            block->content = tableContent;
                            block->language = NULL;
                            block->children = NULL;
                            block->inlineNodes = NULL;

                            // Add to blocks array
                            Span_Add(blocks, block);

                            tableContent = NULL;
                        }

                        // Now check for unordered list
                        i32 unorderedPos = isUnorderedList(line);
                        i32 orderedPos = isOrderedList(line);

                        if (unorderedPos > 0 || orderedPos > 0) {
                        // Finalize any paragraph before list
                        if (inParagraph) {
                            inParagraph = FALSE;

                            MdBlock *paraBlock = MemCh_Alloc(m, sizeof(MdBlock));
                            paraBlock->blockType = MD_BLOCK_PARAGRAPH;
                            paraBlock->level = 0;
                            paraBlock->ordered = FALSE;
                            paraBlock->content = paragraphContent;
                            paraBlock->language = NULL;
                            paraBlock->children = NULL;
                            paraBlock->inlineNodes = NULL;

                            Span_Add(blocks, paraBlock);
                            paragraphContent = NULL;
                        }

                        // It's a list item
                        i32 indent = countIndent(line);
                        i32 nestLevel = indent / 2;  // 2 spaces = 1 level

                        // Extract content (text after marker)
                        i32 contentStart = (unorderedPos > 0) ? unorderedPos : orderedPos;
                        Str *itemContent = Str_From(m, line->bytes + contentStart,
                                                    line->length - contentStart);

                        // Create list item block
                        MdBlock *block = MemCh_Alloc(m, sizeof(MdBlock));
                        block->blockType = MD_BLOCK_LIST;
                        block->level = nestLevel;
                        block->ordered = (orderedPos > 0);
                        block->content = itemContent;
                        block->language = NULL;
                        block->children = NULL;
                        block->inlineNodes = NULL;

                        // Add to blocks array
                        Span_Add(blocks, block);
                    } else if (line->bytes[0] == '#') {
                        // Finalize any paragraph before header
                        if (inParagraph) {
                            inParagraph = FALSE;

                            MdBlock *paraBlock = MemCh_Alloc(m, sizeof(MdBlock));
                            paraBlock->blockType = MD_BLOCK_PARAGRAPH;
                            paraBlock->level = 0;
                            paraBlock->ordered = FALSE;
                            paraBlock->content = paragraphContent;
                            paraBlock->language = NULL;
                            paraBlock->children = NULL;
                            paraBlock->inlineNodes = NULL;

                            Span_Add(blocks, paraBlock);
                            paragraphContent = NULL;
                        }

                        // Header
                        // Count leading # characters to determine level
                        i32 level = 0;
                        i32 j = 0;
                        while (j < line->length && line->bytes[j] == '#') {
                            level++;
                            j++;
                        }

                        // Cap at level 6
                        if (level > 6) {
                            level = 6;
                        }

                        // Skip spaces after #
                        while (j < line->length && line->bytes[j] == ' ') {
                            j++;
                        }

                        // Extract heading text (rest of the line)
                        Str *headingText;
                        if (j < line->length) {
                            headingText = Str_From(m, line->bytes + j, line->length - j);
                        } else {
                            headingText = S(m, "");
                        }

                        // Create MdBlock
                        MdBlock *block = MemCh_Alloc(m, sizeof(MdBlock));
                        block->blockType = MD_BLOCK_HEADING;
                        block->level = level;
                        block->ordered = FALSE;
                        block->content = headingText;
                        block->language = NULL;
                        block->children = NULL;
                        block->inlineNodes = NULL;

                        // Add to blocks array
                        Span_Add(blocks, block);
                        } else {
                            // Not a header, list, or table - it's a paragraph
                            if (!inParagraph) {
                                // Start new paragraph
                                inParagraph = TRUE;
                                paragraphContent = Str_Make(m, 256);
                                Str_Add(paragraphContent, line->bytes, line->length);
                            } else {
                                // Continue paragraph - add space and line
                                Str_AddCstr(paragraphContent, " ");
                                Str_Add(paragraphContent, line->bytes, line->length);
                            }
                        }
                    }
                }
            } else {
                // Empty line - finalize any paragraph
                if (inParagraph) {
                    inParagraph = FALSE;

                    MdBlock *block = MemCh_Alloc(m, sizeof(MdBlock));
                    block->blockType = MD_BLOCK_PARAGRAPH;
                    block->level = 0;
                    block->ordered = FALSE;
                    block->content = paragraphContent;
                    block->language = NULL;
                    block->children = NULL;
                    block->inlineNodes = NULL;

                    Span_Add(blocks, block);
                    paragraphContent = NULL;
                }
            }

            lineStart = i + 1;
        }
    }

    // Finalize any remaining table
    if (inTable && tableContent != NULL) {
        MdBlock *block = MemCh_Alloc(m, sizeof(MdBlock));
        block->blockType = MD_BLOCK_TABLE;
        block->level = 0;
        block->ordered = FALSE;
        block->content = tableContent;
        block->language = NULL;
        block->children = NULL;
        block->inlineNodes = NULL;

        Span_Add(blocks, block);
    }

    // Finalize any remaining paragraph
    if (inParagraph && paragraphContent != NULL) {
        MdBlock *block = MemCh_Alloc(m, sizeof(MdBlock));
        block->blockType = MD_BLOCK_PARAGRAPH;
        block->level = 0;
        block->ordered = FALSE;
        block->content = paragraphContent;
        block->language = NULL;
        block->children = NULL;
        block->inlineNodes = NULL;

        Span_Add(blocks, block);
    }

    // Don't group lists here - will be done after inline parsing

    // Create document
    MdDocument *doc = MemCh_Alloc(m, sizeof(MdDocument));
    doc->frontmatter = NULL;
    doc->blocks = blocks;

    return doc;
}
