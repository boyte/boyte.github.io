#include <external.h>
#include <base_module.h>
#include "../markdown/markdown.h"

/**
 * Markdown Parser - Main Orchestration
 *
 * Wires together frontmatter parsing, block parsing, inline parsing,
 * and provides convenience functions for complete markdown processing.
 */

/**
 * Parse markdown content into document structure
 *
 * Orchestrates the complete parsing pipeline:
 * 1. Extract frontmatter (if present)
 * 2. Parse blocks (headers, code, lists, paragraphs, tables)
 * 3. Parse inline elements within each block
 *
 * @param m Memory chapter for allocations
 * @param markdown Raw markdown content (with optional frontmatter)
 * @return Parsed MdDocument with blocks and inline elements
 */
MdDocument* Markdown_Parse(MemCh *m, Str *markdown) {
    if (markdown == NULL || markdown->length == 0) {
        MdDocument *doc = MemCh_Alloc(m, sizeof(MdDocument));
        doc->frontmatter = NULL;
        doc->blocks = Span_Make(m);
        return doc;
    }

    // Step 1: Parse frontmatter (if present)
    MdFrontmatter *frontmatter = NULL;
    Str *content = Markdown_ParseFrontmatter(m, markdown, &frontmatter);

    // Step 2: Parse blocks (headers, code, lists, paragraphs, tables)
    MdDocument *doc = Markdown_ParseHeaders(m, content);
    doc->frontmatter = frontmatter;

    // Step 3: Parse inline elements within each block
    if (doc->blocks != NULL) {
        for (i32 i = 0; i < doc->blocks->nvalues; i++) {
            MdBlock *block = (MdBlock*)Span_Get(doc->blocks, i);

            // Parse inlines for blocks that contain text content
            if (block->blockType == MD_BLOCK_PARAGRAPH ||
                block->blockType == MD_BLOCK_HEADING) {
                if (block->content != NULL && block->content->length > 0) {
                    block->inlineNodes = Markdown_ParseInlines(m, block->content);
                }
            }

            // Parse inlines for list items
            if (block->blockType == MD_BLOCK_LIST) {
                if (block->content != NULL && block->content->length > 0) {
                    block->inlineNodes = Markdown_ParseInlines(m, block->content);
                }
            }
        }
    }

    // Step 4: Group consecutive list items into proper list structures
    doc->blocks = Markdown_GroupLists(m, doc->blocks);

    return doc;
}

/**
 * Parse and render markdown in one step
 *
 * Convenience function that combines parsing and HTML generation.
 * This is the simplest way to convert markdown to HTML.
 *
 * @param m Memory chapter for allocations
 * @param markdown Raw markdown content
 * @return HTML as StrVec (unlimited size)
 */
StrVec* Markdown_Render(MemCh *m, Str *markdown) {
    MdDocument *doc = Markdown_Parse(m, markdown);
    return Markdown_ToHtml(m, doc);
}
