#include <external.h>
#include <base_module.h>
#include "../markdown/markdown.h"

/**
 * Parse an integer from a string
 */
static i32 parseInt(Str *str) {
    i64 result = 0;
    boolean negative = FALSE;
    i32 start = 0;

    // Skip leading whitespace
    while (start < str->length && str->bytes[start] == ' ') {
        start++;
    }

    // Check for negative sign
    if (start < str->length && str->bytes[start] == '-') {
        negative = TRUE;
        start++;
    }

    // Parse digits
    for (i32 i = start; i < str->length; i++) {
        byte c = str->bytes[i];
        if (c >= '0' && c <= '9') {
            result = result * 10 + (c - '0');
        } else if (c == ' ') {
            break; // Stop at whitespace
        }
    }

    return negative ? -(i32)result : (i32)result;
}

/**
 * Trim leading and trailing whitespace from a string
 */
static Str* trimWhitespace(MemCh *m, Str *str) {
    if (str == NULL || str->length == 0) {
        return S(m, "");
    }

    // Find first non-whitespace
    i32 start = 0;
    while (start < str->length && (str->bytes[start] == ' ' || str->bytes[start] == '\t')) {
        start++;
    }

    // Find last non-whitespace
    i32 end = str->length - 1;
    while (end >= start && (str->bytes[end] == ' ' || str->bytes[end] == '\t' ||
                            str->bytes[end] == '\r' || str->bytes[end] == '\n')) {
        end--;
    }

    if (start > end) {
        return S(m, "");
    }

    return Str_From(m, str->bytes + start, end - start + 1);
}

/**
 * Parse a single frontmatter line (key: value)
 */
static void parseFrontmatterLine(MemCh *m, Str *line, MdFrontmatter *fm) {
    if (line == NULL || line->length == 0) {
        return;
    }

    // Find colon separator
    i32 colonPos = -1;
    for (i32 i = 0; i < line->length; i++) {
        if (line->bytes[i] == ':') {
            colonPos = i;
            break;
        }
    }

    if (colonPos == -1) {
        return; // No colon, invalid line
    }

    // Extract key and value
    Str *key = Str_From(m, line->bytes, colonPos);
    key = trimWhitespace(m, key);

    Str *value = Str_From(m, line->bytes + colonPos + 1, line->length - colonPos - 1);
    value = trimWhitespace(m, value);

    // Match known frontmatter keys
    if (key->length == 5 &&
        key->bytes[0] == 't' && key->bytes[1] == 'i' &&
        key->bytes[2] == 't' && key->bytes[3] == 'l' && key->bytes[4] == 'e') {
        fm->title = value;
    }
    else if (key->length == 16 &&
             key->bytes[0] == 's' && key->bytes[1] == 'i' && key->bytes[2] == 'd' &&
             key->bytes[3] == 'e' && key->bytes[4] == 'b' && key->bytes[5] == 'a' &&
             key->bytes[6] == 'r' && key->bytes[7] == '_' && key->bytes[8] == 'p' &&
             key->bytes[9] == 'o' && key->bytes[10] == 's' && key->bytes[11] == 'i' &&
             key->bytes[12] == 't' && key->bytes[13] == 'i' && key->bytes[14] == 'o' &&
             key->bytes[15] == 'n') {
        fm->sidebarPosition = parseInt(value);
    }
    else if (key->length == 11 &&
             key->bytes[0] == 'd' && key->bytes[1] == 'e' && key->bytes[2] == 's' &&
             key->bytes[3] == 'c' && key->bytes[4] == 'r' && key->bytes[5] == 'i' &&
             key->bytes[6] == 'p' && key->bytes[7] == 't' && key->bytes[8] == 'i' &&
             key->bytes[9] == 'o' && key->bytes[10] == 'n') {
        fm->description = value;
    }
}

/**
 * Parse frontmatter from markdown content
 *
 * Extracts YAML frontmatter if present and returns content without frontmatter.
 * Frontmatter format:
 *   ---
 *   title: Page Title
 *   sidebar_position: 1
 *   description: Page description
 *   ---
 *
 * @param m Memory chapter for allocations
 * @param markdown Full markdown content
 * @param fmOut Output parameter for frontmatter (NULL if not present)
 * @return Markdown content with frontmatter removed
 */
Str* Markdown_ParseFrontmatter(MemCh *m, Str *markdown, MdFrontmatter **fmOut) {
    if (markdown == NULL || markdown->length < 4) {
        *fmOut = NULL;
        return markdown;
    }

    // Check if starts with "---\n" or "---\r\n"
    if (!(markdown->bytes[0] == '-' && markdown->bytes[1] == '-' &&
          markdown->bytes[2] == '-' &&
          (markdown->bytes[3] == '\n' ||
           (markdown->bytes[3] == '\r' && markdown->length > 4 && markdown->bytes[4] == '\n')))) {
        *fmOut = NULL;
        return markdown; // No frontmatter
    }

    // Find the closing "---"
    i32 frontmatterStart = markdown->bytes[3] == '\r' ? 5 : 4; // After first "---\n" or "---\r\n"
    i32 frontmatterEnd = -1;

    for (i32 i = frontmatterStart; i < markdown->length - 3; i++) {
        if (markdown->bytes[i] == '-' && markdown->bytes[i + 1] == '-' &&
            markdown->bytes[i + 2] == '-' &&
            (i + 3 >= markdown->length || markdown->bytes[i + 3] == '\n' ||
             markdown->bytes[i + 3] == '\r')) {
            frontmatterEnd = i;
            break;
        }
    }

    if (frontmatterEnd == -1) {
        *fmOut = NULL;
        return markdown; // No closing delimiter found
    }

    // Initialize frontmatter structure
    MdFrontmatter *fm = MemCh_Alloc(m, sizeof(MdFrontmatter));
    fm->title = NULL;
    fm->sidebarPosition = 0;
    fm->description = NULL;

    // Parse frontmatter content line by line
    i32 lineStart = frontmatterStart;
    for (i32 i = frontmatterStart; i < frontmatterEnd; i++) {
        if (markdown->bytes[i] == '\n') {
            // Extract line (skip \r if present)
            i32 lineEnd = i;
            if (lineEnd > lineStart && markdown->bytes[lineEnd - 1] == '\r') {
                lineEnd--;
            }

            if (lineEnd > lineStart) {
                Str *line = Str_From(m, markdown->bytes + lineStart, lineEnd - lineStart);
                parseFrontmatterLine(m, line, fm);
            }

            lineStart = i + 1;
        }
    }

    *fmOut = fm;

    // Return content after frontmatter
    // Skip past closing "---" and the newline after it
    i32 contentStart = frontmatterEnd + 3;
    if (contentStart < markdown->length && markdown->bytes[contentStart] == '\r') {
        contentStart++;
    }
    if (contentStart < markdown->length && markdown->bytes[contentStart] == '\n') {
        contentStart++;
    }

    if (contentStart >= markdown->length) {
        return S(m, ""); // No content after frontmatter
    }

    return Str_From(m, markdown->bytes + contentStart, markdown->length - contentStart);
}
