#include <external.h>
#include <base_module.h>
#include "../markdown/markdown.h"

/**
 * Markdown Utility Functions
 *
 * - Link resolution (relative paths, absolute URLs)
 * - Image path rewriting for static assets
 *
 * Note: Markdown_Slugify is implemented in md_html.c
 */

/**
 * Resolve relative link to absolute path
 *
 * Handles:
 * - Absolute URLs: "https://example.com" (unchanged)
 * - Absolute paths: "/docs/intro" (unchanged)
 * - Relative current: "./intro" from "/docs/getting-started/" -> "/docs/intro"
 * - Relative parent: "../api/base" from "/docs/guides/" -> "/docs/api/base"
 *
 * @param m Memory chapter for allocations
 * @param currentPath Current document path (e.g., "/docs/getting-started/install")
 * @param linkHref Link href attribute value
 * @return Resolved absolute path or URL
 */
Str* Markdown_ResolveLink(MemCh *m, Str *currentPath, Str *linkHref) {
    if (linkHref == NULL || linkHref->length == 0) {
        return S(m, "");
    }

    // 1. Absolute URLs - return as-is
    if (linkHref->length >= 7) {
        if ((linkHref->bytes[0] == 'h' &&
             linkHref->bytes[1] == 't' &&
             linkHref->bytes[2] == 't' &&
             linkHref->bytes[3] == 'p') &&
            (linkHref->bytes[4] == ':' ||
             (linkHref->bytes[4] == 's' && linkHref->bytes[5] == ':'))) {
            return linkHref;  // http:// or https://
        }
    }

    // 2. Absolute paths - return as-is
    if (linkHref->length > 0 && linkHref->bytes[0] == '/') {
        return linkHref;
    }

    // 3. Anchor links - return as-is
    if (linkHref->length > 0 && linkHref->bytes[0] == '#') {
        return linkHref;
    }

    // 4. Relative paths - resolve against currentPath
    // currentPath: "/docs/core-concepts/memory/memch"
    // linkHref: "./cursor" -> "/docs/core-concepts/memory/cursor"
    // linkHref: "../parser/roebling" -> "/docs/core-concepts/parser/roebling"

    if (currentPath == NULL || currentPath->length == 0) {
        // No current path to resolve against, return link as-is
        return linkHref;
    }

    // Build path parts array from currentPath
    Span *pathParts = Span_Make(m);

    // Parse currentPath by splitting on '/'
    i32 partStart = 0;
    for (i32 i = 0; i <= currentPath->length; i++) {
        if (i == currentPath->length || currentPath->bytes[i] == '/') {
            if (i > partStart) {
                // Add non-empty part
                Str *part = Str_From(m, currentPath->bytes + partStart, i - partStart);
                Span_Add(pathParts, part);
            }
            partStart = i + 1;
        }
    }

    // Remove last part (filename) to get directory
    if (pathParts->nvalues > 0) {
        Span_Remove(pathParts, pathParts->nvalues - 1);
    }

    // Process linkHref parts (handle ./ and ../)
    i32 linkPartStart = 0;
    for (i32 i = 0; i <= linkHref->length; i++) {
        if (i == linkHref->length || linkHref->bytes[i] == '/') {
            if (i > linkPartStart) {
                Str *part = Str_From(m, linkHref->bytes + linkPartStart, i - linkPartStart);

                // Check for special path components
                if (part->length == 2 && part->bytes[0] == '.' && part->bytes[1] == '.') {
                    // ".." - go up one level
                    if (pathParts->nvalues > 0) {
                        Span_Remove(pathParts, pathParts->nvalues - 1);
                    }
                } else if (part->length == 1 && part->bytes[0] == '.') {
                    // "." - current directory, skip
                } else {
                    // Regular path component
                    Span_Add(pathParts, part);
                }
            }
            linkPartStart = i + 1;
        }
    }

    // Rebuild path with leading /
    Str *result = Str_Make(m, 256);
    for (i32 i = 0; i < pathParts->nvalues; i++) {
        Str *part = (Str*)Span_Get(pathParts, i);
        Str_AddCstr(result, "/");
        Str_Add(result, part->bytes, part->length);
    }

    // Handle empty result
    if (result->length == 0) {
        Str_AddCstr(result, "/");
    }

    return result;
}

/**
 * Rewrite image paths for static serving
 *
 * Converts document-relative image paths to static server paths.
 * Example: "/diagrams/iter.svg" -> "/static/diagrams/iter.svg"
 *
 * @param m Memory chapter for allocations
 * @param href Image path from markdown
 * @return Rewritten path for static handler
 */
Str* Markdown_RewriteImagePath(MemCh *m, Str *href) {
    if (href == NULL || href->length == 0) {
        return S(m, "");
    }

    // Check if path starts with "/diagrams/"
    const char *prefix = "/diagrams/";
    i32 prefixLen = 10;  // length of "/diagrams/"

    if (href->length >= prefixLen) {
        boolean matches = TRUE;
        for (i32 i = 0; i < prefixLen; i++) {
            if (href->bytes[i] != prefix[i]) {
                matches = FALSE;
                break;
            }
        }

        if (matches) {
            // Prepend "/static" to the path
            Str *result = Str_Make(m, href->length + 7);
            Str_AddCstr(result, "/static");
            Str_Add(result, href->bytes, href->length);
            return result;
        }
    }

    // Not a diagram path, return unchanged
    return href;
}
