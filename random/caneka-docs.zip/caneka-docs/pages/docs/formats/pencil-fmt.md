---
sidebar_position: 1
---

# Pencil Format (.fmt)

Pencil (`.fmt`) is Caneka's lightweight document format. It is parsed by the
Roebling formatter in `src/ext/format/fmt/` and rendered to HTML by
`Fmt_ToHtml`. The syntax is line-oriented and intentionally small.

## Spec vs Implementation

### Verified
- Parser: `src/ext/format/fmt/fmt_roebling.c`
- Tokenization: `src/ext/format/fmt/fmt_tokenize.c`
- HTML output: `src/ext/format/fmt/fmt_html.c`

### Inferred / Not Implemented
- No comment syntax
- No code block or inline-code tokens

## Syntax Overview

### Token Summary (Verified)

| Token | Example | Result |
| --- | --- | --- |
| Heading | `= Title` | `H1` (level by `=` count) |
| Paragraph | `Some text` | `P` node |
| List item | `- item` | `UL/LI` list |
| Table header | `+A,B,C` | Table headers |
| Table row | `A, 1, 2` | Table row |
| Tag | `_link=Text@url` | Inline link/image |
| Class | `.fancy` | Parsed attribute (not rendered) |

### Headings (`=`)

```pencil
= Top Level Heading
== Second Level
=== Third Level
```

The number of `=` characters controls the heading level (H1, H2, H3, ...).

### Paragraphs

Lines that do not start with a marker become paragraph content. Consecutive
lines are joined with a single space. A blank line ends the paragraph.

Example:

```pencil
This is a first paragraph
with a second line.
```

### Inline Tags (`_link`, `_image`)

```pencil
_link=Link Text@https://example.com
_image=Alt Text@/path/to/image.png
```

The tag name appears after `_` and is followed by `=label@url`.
Supported tags in `Fmt_ToHtml`:

- `_link=...@...` -> `<A href="...">...</A>`
- `_image=...@...` -> `<IMG alt="..." src="..." />`

Tags can be inline within paragraphs or on their own line.

### Classes (`.class`)

```pencil
.fancy
This paragraph uses the "fancy" class.
```

Lines starting with `.` attach a class to the **next** paragraph or heading.
The class is stored in the parsed `Mess` structure but **is not emitted**
by the current HTML renderer.

### Lists (`-`)

```pencil
- First item
- Second item
```

If the next line is not a new bullet (and not blank), it is appended to the
current bullet item. Example from `examples/example.fmt`:

```pencil
- bullet two
with two lines.
```

### Tables (`+` and `,`)

```pencil
+Column A,Column B,Column C
Apple, 1, 37
Bannana, 2, 39
Cantelope, 3, 39
```

- A line starting with `+` defines table headers.
- Subsequent comma-separated lines define rows.
- Cell values are parsed as strings; numeric conversion is left to consumers.

## Whitespace, Comments, Escapes, Errors (Verified)

| Topic | Behavior |
| --- | --- |
| Whitespace | Paragraph lines are joined with spaces |
| Comments | Not implemented |
| Escapes | Backslash is accepted in token patterns, but no explicit unescape step |
| Errors | Roebling sets `ERROR` on unmatched patterns |

## Complete Example

From `docs/about.fmt`:

```pencil
= About

This is a demo of the _link=Caneka@https://caneka.org components working together.

== What Is Caneka?

Caneka is a collection of runtime software tools.

== Components In This Demo

141 total components

- "Pencil" Document Transpiler.
- Queue, Step, and Task workflow.
- Network Server and Template Engine.
```

## HTML Rendering (Verified)

The document renderer converts Pencil to HTML:

```
= Heading -> <h1>Heading</h1>
== Subheading -> <h2>Subheading</h2>
_link=Text@url -> <a href="url">Text</a>
```

HTML rendering is implemented in `src/ext/format/fmt/fmt_html.c`.
Classes (`.fancy`) are parsed but currently ignored by `Fmt_ToHtml`.

## Use Cases

- Documentation pages
- About pages
- Schedules and roadmaps
- Human-readable content

## See Also

- Example: `docs/about.fmt`
- Example: `docs/schedule.fmt`
- Example: `examples/example.fmt`
- [Inter Layer](../architecture/inter-layer.md)
