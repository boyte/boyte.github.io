---
sidebar_position: 4
---

# Config Format (.config)

Caneka `.config` files are a small, line-based configuration format parsed by
`src/ext/format/config/`. They use braces for nesting and `:` for key-value
pairs. The parser builds a `NodeObj` tree (`Inst` with name/atts/children).

## Syntax Overview

### Sections (`name { ... }`)

```config
server {
    host: 0.0.0.0
    port: 8080
}
```

- A section starts with a token followed by `{`.
- Token character set is not formally specified; examples include `/`, `-`, `_`.
- `}` closes the current section.
- Indentation is optional and only for readability.

### Key-Value Pairs (`key: value`)

```config
title: Caneka Example - Home
id: schedule
```

- `:` is the only key separator recognized by the parser.
- Values run to the end of the line.
- Digits-only values are parsed as integers.

### Lists (`- item`)

```config
list:
    - one
    - two
    - three
```

List items are stored as a `Span` under the parent key.

## Examples (Verified)

From `examples/object.config`:

```config
doc {
    alpha: apple
    bravo: bannanna
    charlie: carrot
    start: 3

    list:
        - one
        - two
        - three

    tag {
        att-one: one
        att-two: two
    }
}
```

From `examples/web-server/pages/forms/signup.config`:

```config
binseg {
    action: add modify read
}
```

`action` is a space-separated string. Consumers use `Config_Sequence` to split
it into tokens (see `src/ext/format/config/config.c`).

## Parsed Output (Verified)

The parser builds `Inst` objects with three properties:

- `name` (index 0): section name (`StrVec`)
- `atts` (index 1): attribute table (`Table`)
- `children` (index 2): nested sections or list items (`Table` or `Span`)

Useful APIs:

- `Inst_Att(node, key)` -> attribute value
- `Inst_GetChild(node, key)` -> nested section
- `Inst_ByPath(root, path, ...)` -> lookup by path (`Path_DotAnnotate`)

## Notes and Limitations

- No `=` syntax (only `:`).
- No quoted strings or comment syntax.
- Values are stored as `StrVec` (strings) or integer wrappers (digits only).
- Use `Config_Sequence` to split a value into tokens when needed.

## See Also

- Example: `examples/object.config`
- Example: `examples/forever.config`
- Example: `examples/web-server/pages/forms/signup.config`
