---
sidebar_position: 2
---

# Templ Format (.templ)

Templ is Caneka's template format for generating dynamic HTML content. It is
implemented in `src/inter/templ/` and parsed by a Roebling state machine into
text chunks and `Fetcher` nodes, then rendered by walking that content with a
data stack.

## Parsing and Rendering (Verified)

Pipeline (from the implementation):

1. **Parse**: `Templ_RoeblingMake` tokenizes text, control lines, and variables.
2. **Prepare**: `Templ_Prepare` builds jump targets for loops/conditions.
3. **Render**: `Templ_ToS` walks content, resolving fetch targets against data.

Relevant source files:

- Parser: `src/inter/templ/templ_roebling.c`
- Prepare/jumps: `src/inter/templ/templ_prepare.c`, `src/inter/templ/templ_jump.c`
- Fetcher resolution: `src/ext/types/fetcher.c`, `src/ext/types/fetch_target.c`

## Text and Variables

Anything outside templ control lines is output as-is. Variables are inside `{}`.

```templ
<h1>{title}</h1>
<p>{stats#uptime}</p>
```

The lookup target depends on the prefix used inside `{}`.

### Path Segments and Targets (Verified)

Templ breaks variable paths into segments. Each segment becomes a `FetchTarget`.

- `name` or `@name` -> `FETCH_TARGET_KEY`
  - Table: `Table_Get`
  - Seel instance: `Seel_Get` (property index)
- `#name` -> `FETCH_TARGET_PROP`
  - Same resolution as `KEY` for tables/instances in current code
- `*name` -> `FETCH_TARGET_ATT`
  - Attribute/field lookup via `Map` on C struct types
  - Common for `Hashed` entries (`*key`, `*value`) and mapped structs
- `.` separates path segments (each segment becomes a target)

Example (from `examples/example.templ`):

```templ
<li><a href="{*local}">{*name}</a></li>
```

The `*local` and `*name` targets resolve against a mapped C struct
(`TranspFile` in tests).

## Control Lines

Lines starting with `;` are control statements and are **not** emitted.
They build `Fetcher` nodes for loops, `with` blocks, and conditionals.

### Loops: `...`

```templ
;   items.menu...
    <li>{*name}</li>
;
```

This yields a `FETCHER_FOR` whose targets are `items`, `menu`, then an iterator.
See `examples/example.templ` and `src/programs/test/option/inter/templ_tests.c`.

### With: `:`

```templ
;   *value:
    <li>{*name}</li>
;
```

`:` creates a `FETCHER_WITH`. The example above (from `examples/example.templ`)
sets the data context to `*value` of each loop item (useful for table entries).

### If: `?`

```templ
; stats.mem ?
<h2>Memory Heap</h2>
;
```

This creates a `FETCHER_IF`. The block renders if the fetch resolves to a
non-NULL value. (No boolean coercion is applied; only NULL is falsey.)
See `examples/web-server/pages/public/stats.templ`.

## Navigation Condition Tokens

Templ includes special condition tokens used with nested iterators such as
`NestSel` (see `src/ext/navigate/nestsel.c`). These tokens drive conditional
branches based on iterator flags (`UFLAG_ITER_*`):

- `>` -> `FORMAT_TEMPL_LEVEL` (non-leaf branch)
- `=` -> `FORMAT_TEMPL_CURRENT` (leaf, not selected)
- `_` -> `FORMAT_TEMPL_ACTIVE` (leaf, selected)
- `{^}` -> `FORMAT_TEMPL_INDENT` (indent/outdent control)

Example (`examples/doc/nav.templ`):

```templ
;  page.nav...
;  >
    <li><a href="{#url}">{#name}</a>{^}</li>
;  =
    <li><a href="{#url}">{#name}</a></li>
;  _
    <li><span class="active">{#name}</span></li>
;
```

These tokens are tightly coupled to `NestSel` iterator flags and should be
treated as **navigation-specific** controls rather than general conditionals.

## Block Termination

A line containing only `;` closes the most recent control block. Nested blocks
require nested terminators (e.g., one `;` for `with`, one for `for`).

## Known Limitations (Verified)

- No documented escape syntax for literal `;` in text (semicolon is a control
  marker in the parser).
- `else` / `|` is not currently wired in `templ_roebling.c` (only `?` is
  recognized as a conditional token).

## See Also

- [Templ Engine](../core-concepts/templ.md)
- Example: `examples/nav.templ`
