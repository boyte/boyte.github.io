---
sidebar_position: 3
---

# First Steps

Now that you've built Caneka, let's explore what it can do. This guide walks you through running your first programs and understanding the system.

## Running the Test Suite

The best way to verify your Caneka installation is to run the test suite:

```bash
./dist/bin/tests --dist
```

### Understanding Test Output

The tests output results in Pencil format (.fmt):

```
= Caneka Test Suite
== Memory Tests
✓ MemBook allocation
✓ MemChapter creation
✓ MemPage management
✓ Span operations
✓ Iter functionality

== Parser Tests
✓ Roebling pattern matching
✓ Tokenization
✓ String splitting

== Navigate Tests
✓ Task creation
✓ Step execution
✓ Queue management

...
```

All tests should pass on a successful build. If any tests fail, review the [Building](building.md) guide or check the [Troubleshooting](#troubleshooting) section.

## Starting the Web Server

Caneka includes a fully functional HTTP web server. To start it:

```bash
./dist/bin/webserver
```

You'll see output like:

```
Caneka Web Server Starting...
Listening on port 8080
Server ready at http://localhost:8080
```

### Accessing the Server

Open your browser and navigate to:

```
http://localhost:8080
```

You should see the Caneka demo page with:
- Project overview
- Component list
- Example files
- Live statistics

### Available Endpoints

The demo server provides several endpoints:

- `/` - Home page (about.fmt rendered as HTML)
- `/stats` - System statistics (using templates)
- `/tests` - Test results page
- `/schedule` - Roadmap and planned features
- `/static/*` - Static files and examples

## Exploring the Examples

Caneka comes with several example files in the `examples/` directory:

### Pencil Documents (.fmt)

```bash
cat examples/example.fmt
```

Pencil is Caneka's document format. The syntax is simple and human-readable:

```pencil
= Heading
== Subheading
Regular text with _link=Text@https://url.

; list_item:
  - Item text
;
```

### Template Files (.templ)

```bash
cat examples/nav.templ
```

Templ is Caneka's HTML template engine:

```templ
<ul>
; collection...
; *item:
  <li>{*item.name}</li>
;
</ul>
```

### Caneka Language (.cnk)

```bash
cat examples/str.cnk
cat examples/cash.cnk
```

These files show Caneka's type definition syntax:

```cnk
Type Str @ TEXT, CONST, BINARY
    word length
    word alloc
    byte bytes[]
```

### Configuration Files (.config)

```bash
cat examples/object.config
cat examples/forever.config
```

Simple configuration format for runtime settings.

## Clineka CLI

Caneka includes a CLI for practical runtime tasks:

- Converting Pencil `.fmt` files to HTML.
- Inspecting reversed BinSeg (`.rbs`) records.
- Running a small "forever" supervisor defined in a `.config` file.

The binary is built at:

```bash
./build/bin/clineka
```

Quick examples:

```bash
./build/bin/clineka --help
./build/bin/clineka --in examples/example.fmt --out /tmp/example.html
./build/bin/clineka --in examples/test/pages/forms/signup.rbs
./build/bin/clineka --config examples/forever.config
```

For a full walkthrough and config details, see [Clineka CLI](../guides/cli.md).

## Understanding the Architecture

Now is a good time to understand Caneka's three-layer architecture:

### Base Layer
The foundation - memory management, types, I/O:

```bash
# Explore base headers
ls src/base/include/
```

Key components:
- `mem/` - Memory management (MemBook, MemChapter, MemPage)
- `types/` - Type system and error handling
- `bytes/` - String and byte operations
- `sequence/` - Arrays, lookups, hash tables
- `io/` - File, socket, directory operations

### Extended Layer
Advanced features - parser, server, workflow:

```bash
# Explore ext headers
ls src/ext/include/
```

Key components:
- `parser/` - Roebling pattern matcher
- `navigate/` - Task/Step workflow system
- `types/` - Seel object system
- `serve/` - Network server

### Inter Layer
Web-facing components - HTTP, templates:

```bash
# Explore inter headers
ls src/inter/include/
```

Key components:
- `http/` - HTTP protocol handling
- `templ/` - Template engine
- `www/` - Web server utilities
- `doc/` - Document rendering

See the [Architecture Overview](../architecture/overview.md) for detailed information.

## Experimenting with the Parser

The Roebling parser is one of Caneka's most powerful features. It lets you
define pattern-driven grammars directly in C. Start with the parser overview
and follow the "Creating DSLs" guide to build your first pattern set.

Learn more in [Roebling Parser Overview](../core-concepts/parser/overview.md).

## Viewing Memory Statistics

Caneka's custom memory manager provides detailed statistics:

Access the stats endpoint:

```
http://localhost:8080/stats
```

This shows:
- Active memory books
- Page allocations
- Memory usage
- Recycled pages

Learn more in [Memory Management](../core-concepts/memory/overview.md).

## Next Steps

### Learn Core Concepts

Dive deeper into Caneka's fundamental components:

1. [Memory Management](../core-concepts/memory/overview.md) - Understand the custom memory system
2. [Roebling Parser](../core-concepts/parser/overview.md) - Learn pattern matching and DSL creation
3. [Navigate System](../core-concepts/navigate/overview.md) - Explore Task/Step workflows
4. [Template Engine](../core-concepts/templ.md) - Master the Templ syntax

### Explore Custom Formats

Learn Caneka's domain-specific formats:

1. [Pencil (.fmt)](../formats/pencil-fmt.md) - Document format
2. [Templ (.templ)](../formats/templ.md) - Template syntax
3. [Caneka (.cnk)](../formats/caneka-cnk.md) - Type definitions
4. [Config (.config)](../formats/config.md) - Configuration files

### Build Something

Try creating your own:

1. **Web page** using the template engine
2. **Parser** for a custom format
3. **Task workflow** using Navigate
4. **API endpoint** in the web server

See the [Developer Guides](../guides/writing-parsers.md) for tutorials.

### Read the API Reference

Explore the C API documentation:

1. [Base Module API](../api-reference/base.md)
2. [Ext Module API](../api-reference/ext.md)
3. [Inter Module API](../api-reference/inter.md)

## Troubleshooting

### Web server won't start

**Issue**: Port 8080 already in use

**Solution**: Either stop the other process or modify the server configuration to use a different port.

### Tests fail

**Issue**: Some tests don't pass

**Solution**:
1. Clean and rebuild: `./dist/bin/bootstrap --clean`
2. Build all: `./build.sh` → select "Build All Programs"
3. Run tests again: `./dist/bin/tests --dist`

### Can't access examples

**Issue**: Example files not found

**Solution**: Ensure you're in the root caneka directory when running commands.

### Memory errors

**Issue**: Segmentation faults or memory errors

**Solution**: This may indicate a bug. Please report it on the [GitHub issues page](https://github.com/comparebasic/caneka/issues) with:
- Your OS and version
- Compiler and version
- Steps to reproduce
- Error output

## Getting Help

If you encounter issues:

1. **Check Documentation**: Review the relevant sections in this documentation
2. **GitHub Issues**: Search or create an issue at [github.com/comparebasic/caneka/issues](https://github.com/comparebasic/caneka/issues)
3. **Review Code**: Caneka is designed to be transparent - read the source!

## Contributing

Interested in contributing? See the [Contributing Guide](../contributing.md) for information on:
- Code style
- Testing requirements
- Pull request process
- Development workflow

---

Congratulations! You've successfully built Caneka and explored its basic functionality. You're now ready to dive deeper into its powerful components.
