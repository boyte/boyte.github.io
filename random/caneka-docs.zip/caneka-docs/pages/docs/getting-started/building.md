---
sidebar_position: 2
---

# Building Caneka

Caneka uses a custom build system that provides a simple, interactive menu for compilation. This guide walks you through building Caneka from source.

## Quick Build

The fastest way to build Caneka is using the provided build script:

```bash
./build.sh
```

This script will:
1. Detect your C compiler (clang or gcc)
2. Compile the bootstrap program
3. Launch an interactive build menu

## The Build Process Explained

### Step 1: Run build.sh

When you run `./build.sh`, you'll see output like:

```
= Caneka build script - see README.md for details
clang found using that for compilation
making dir mkdir -p ./dist/bin
building bootstrap: clang -o ./dist/bin/bootstrap -I src/programs/buildeka/include/ src/programs/buildeka/bootstrap.c
running bootstrap: ./dist/bin/bootstrap --menu
```

### Step 2: Bootstrap Program

The bootstrap program (`bootstrap.c`) is a minimal C program that compiles the full Caneka build system. It provides an interactive menu with options:

```
Caneka Build Menu
=================
1. Build All Programs
2. Build Base Module
3. Build Ext Module
4. Build Inter Module
5. Build Web Server
6. Build Tests
7. Run Tests
8. Clean Build
9. Exit
```

### Step 3: Build Options

**Option 1: Build All Programs** (recommended for first build)
- Compiles all modules (Base, Ext, Inter)
- Builds all programs (webserver, tests, CLI tools)
- Creates executables in `./dist/bin/`

**Option 2-4: Build Individual Modules**
- Build only specific modules if you're working on a particular component
- Faster compilation for targeted development

**Option 5: Build Web Server**
- Compiles just the web server program
- Requires Base, Ext, and Inter modules to be built first

**Option 6: Build Tests**
- Compiles the test suite
- Useful for development and verification

**Option 7: Run Tests**
- Builds and executes the test suite
- Displays test results in Pencil format

**Option 8: Clean Build**
- Removes all build artifacts
- Forces a complete rebuild on next compile

## Build System Architecture

Caneka uses a custom build system called **CnkBuild** (Caneka Build):

### bootstrap.c
Located at the root, this minimal program:
- Contains no dependencies beyond the C standard library
- Compiles the buildeka library
- Provides the interactive menu

### buildeka
The build configuration system (`src/programs/buildeka/`):
- Manages module dependencies
- Handles compilation flags
- Resolves include paths
- Links modules correctly

### Module Build Files

Each module has build configuration files:

**Base Module**: `src/base/inc.c`
- Single include file that pulls in all base components
- Simplest build configuration

**Other Modules**: `*/build.c`
- More elaborate build configuration
- Defines dependencies via `dependencies.txt` files

## Understanding dependencies.txt

Each module can specify dependencies in a `dependencies.txt` file:

```
# Example dependencies.txt
base
ext/parser
ext/types
```

This tells the build system which modules must be compiled before the current module.

## Build Output

After a successful build, you'll find executables in `./build/bin/`:

```
build/
└── bin/
    ├── clineka          # CLI tools
    ├── webserver        # HTTP web server
    ├── test             # Test suite
    └── content-fetch    # Test helper
```

The bootstrap and build tools live in `./dist/bin/`:

```
dist/
└── bin/
    ├── bootstrap        # Bootstrap program
    └── buildeka         # Build system
```

## Compiler Selection

### Using clang (default)

If clang is installed, it will be used automatically:

```bash
./build.sh
```

### Using gcc

To force gcc usage, you can modify the script or set CC:

```bash
export CC=gcc
./build.sh
```

Note: There is a known issue with gcc related to the order of static libraries. Clang is recommended.

## Common Build Issues

### Issue: Compiler not found

**Error**: `clang: command not found` or `gcc: command not found`

**Solution**: Install a C compiler (see [Installation](installation.md))

### Issue: Permission denied

**Error**: `permission denied: ./build.sh`

**Solution**: Make the script executable:
```bash
chmod +x build.sh
./build.sh
```

### Issue: Build fails with linking errors

**Error**: `undefined reference to...`

**Solution**: Clean and rebuild:
1. Run `./dist/bin/bootstrap --clean`
2. Run `./build.sh` again
3. Select "Build All Programs"

### Issue: gcc static library order error

**Error**: Issues when compiling with gcc

**Solution**: Use clang instead, or wait for the gcc compatibility fix

## Incremental Builds

For development, you can rebuild specific modules:

```bash
./dist/bin/bootstrap --menu
# Then select the specific module to rebuild
```

This is much faster than rebuilding everything.

## Build Customization

The build system is designed for extensibility. You can:

1. **Add new modules**: Create a `build.c` and `dependencies.txt`
2. **Modify compiler flags**: Edit the buildeka configuration
3. **Add external libraries**: Link them in the build.c files (e.g., NaCL for crypto, SSL for network)

## Debugging Build Issues

If you encounter build problems:

1. **Check compiler version**:
   ```bash
   clang --version
   gcc --version
   ```

2. **Review build output**: The build system shows all commands it runs

3. **Clean build**: Remove all artifacts and start fresh

4. **Check dependencies**: Ensure all required modules are built first

## Next Steps

Once you've successfully built Caneka, proceed to [First Steps](first-steps.md) to run the programs and explore the system.

## Advanced: Manual Compilation

If you want to compile manually without the build system:

```bash
# Compile bootstrap directly
clang -o ./dist/bin/bootstrap -I src/programs/buildeka/include/ src/programs/buildeka/bootstrap.c

# Or compile a specific program
clang -I src/base/include -I src/ext/include -o myprogram myprogram.c src/base/inc.c
```

However, using the build system is recommended as it handles all dependencies correctly.
