---
sidebar_position: 1
---

# Installation

Getting started with Caneka is straightforward - the project has minimal dependencies and works on any POSIX-compliant system.

## System Requirements

Caneka only requires two things:

1. **POSIX-compliant Operating System**
   - Linux (any distribution)
   - macOS
   - BSD systems
   - WSL (Windows Subsystem for Linux)

2. **C Compiler**
   - `clang` (recommended)
   - `gcc` (also supported)

That's it! No package managers, no complex dependency trees, no version conflicts.

## Clone the Repository

First, clone the Caneka repository from GitHub:

```bash
git clone https://github.com/comparebasic/caneka.git
cd caneka
```

## Verify Prerequisites

Check that you have a C compiler installed:

```bash
# Check for clang
which clang

# OR check for gcc
which gcc
```

If you don't have a compiler installed:

**On macOS:**
```bash
xcode-select --install
```

**On Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install build-essential
```

**On Fedora/RHEL:**
```bash
sudo dnf groupinstall "Development Tools"
```

## Project Structure

Once cloned, you'll see the following structure:

```
caneka/
├── src/                  # Source code
│   ├── base/            # Base layer (memory, types, I/O)
│   ├── ext/             # Extended layer (parser, server)
│   ├── inter/           # Inter layer (HTTP, templates)
│   └── programs/        # Executable programs
├── docs/                # Documentation (.fmt files)
├── examples/            # Example files
├── lists/               # Feature and todo lists
├── build.sh             # Build helper script
├── bootstrap.c          # Bootstrap program
├── README.md
└── LICENCE
```

## No Dependencies to Install

Unlike most modern projects, Caneka has **zero external dependencies** beyond your system's C compiler and POSIX libraries. This means:

- No `npm install`
- No `pip install`
- No `cargo build`
- No package.json, requirements.txt, or similar

Everything you need is already in the repository or provided by your operating system.

## Next Steps

Now that you have Caneka cloned and your system ready, proceed to [Building Caneka](building.md) to compile and run the project.

## Alternative: Docker (Optional)

If you prefer using Docker, you can build Caneka in a container:

```bash
# Coming soon - Docker support planned
```

## Troubleshooting

### Issue: No C compiler found

**Solution**: Install a C compiler as shown in the "Verify Prerequisites" section above.

### Issue: Git not installed

**Solution**: Install git:
- macOS: `brew install git` or `xcode-select --install`
- Ubuntu/Debian: `sudo apt-get install git`
- Fedora/RHEL: `sudo dnf install git`

### Issue: POSIX compatibility on Windows

**Solution**: Use WSL (Windows Subsystem for Linux) for the best compatibility. Alternatively, use Cygwin or MinGW, though these are not officially supported.

## License

Caneka is primarily licensed under the 3-Clause BSD License from Compare Basic, with some components in the public domain. See the [LICENCE](https://github.com/comparebasic/caneka/blob/main/LICENCE) file for details.
