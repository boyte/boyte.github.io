---
sidebar_position: 9
---

# Contributing to Caneka

Thank you for your interest in contributing to Caneka!

## Getting Started

1. Fork the repository
2. Clone your fork
3. Build the project
4. Run tests

## Code Style

Caneka follows specific C coding conventions:

- Explicit over implicit
- Verbose naming (designed for transpiler generation)
- Type-safe operations
- Consistent memory management

## Testing

All changes must include tests:

```bash
./dist/bin/tests --dist
```

Ensure all tests pass before submitting.

## Documentation

Update documentation for:
- New features
- API changes
- Usage examples

## Pull Request Process

1. Create a feature branch
2. Make your changes
3. Add tests
4. Update documentation
5. Submit pull request

## Code Review

All submissions go through code review. Be prepared to:
- Explain your approach
- Make requested changes
- Discuss design decisions

## Roadmap

See `docs/schedule.fmt` for planned features and priorities.

## Community

- **GitHub**: [github.com/comparebasic/caneka](https://github.com/comparebasic/caneka)
- **Website**: [caneka.org](https://caneka.org)
- **License**: 3-Clause BSD

## Questions?

Open an issue on GitHub for questions or discussions.

---

Thank you for contributing to Caneka!
