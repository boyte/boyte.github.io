# Base Module API Reference - Part 3

[← Part 2](base-part2) | **Part 3 of 4** | [Part 4 →](base-part4)

---

## Collections & Data Structures

Caneka provides a rich set of collection types, all built on the foundation of Span. Understanding Span is the key to understanding all collection types.

### Table - Hash Table / Sparse Array

**Header**: [src/base/include/sequence/table.h](../../../src/base/include/sequence/table.h)

Table is Caneka's primary associative array type. It's implemented as a sparse array (Span) with multi-bit linear probing for collision resolution. Remarkably, `Table` is just a typedef for `Span`—the same structure serves both purposes.

**Type definition**:
```c
typedef Span Table;
```

This means every Table operation works on a Span, and you can use Span operations on Tables.

**See also**: [Table/Lookup Complete Guide](../core-concepts/table-lookup-complete.md)

#### Core Functions

```c
Table *Table_Make(MemCh *m);
```

Creates a new empty hash table. (Actually just calls `Span_Make()`.)

**Example**:
```c
Table *tbl = Table_Make(m);
```

---

```c
i32 Table_Set(Span *tbl, void *a, void *value);
```

Sets `value` for key `a` in the table. Uses `Get_Hash(a)` to compute the hash.

**Returns**: Index where the value was stored.

**Example**:
```c
Str *key = Str_FromCstr(m, "name", 0);
Str *val = Str_FromCstr(m, "Alice", 0);
Table_Set(tbl, key, val);
```

**How keys work**: Any Caneka type that implements `Get_Hash()` can be a key. Str, I32, I64, etc. all work automatically.

---

```c
i32 Table_SetByIter(Iter *it, void *a, void *value);
```

Sets a value using an iterator (useful when you're already iterating).

**Example**:
```c
Iter *it = Iter_Make(m, tbl);
Table_SetByIter(it, key, value);
```

---

```c
void *Table_Get(Span *tbl, void *a);
```

Retrieves the value for key `a`. Returns NULL if key not found.

**Example**:
```c
Str *key = Str_FromCstr(m, "name", 0);
void *value = Table_Get(tbl, key);
if (value) {
    // Key found
    Str *name = (Str*)value;
} else {
    // Key not in table
}
```

---

```c
void *Table_GetKey(Span *tbl, i32 idx);
```

Retrieves the key at a specific table index (not the hash—the actual stored index).

**When to use**: Iterating over table entries when you need both keys and values.

**Example**:
```c
Iter *it = Iter_Make(m, tbl);
Iter_First(it);
while (Iter_Next(it) == READY) {
    void *key = Table_GetKey(tbl, it->idx);
    void *val = Iter_Get(it);
    // Process key-value pair
}
```

---

```c
i32 Table_GetIdx(Span *tbl, void *a);
```

Returns the index where key `a` is stored, or -1 if not found.

**Example**:
```c
i32 idx = Table_GetIdx(tbl, key);
if (idx >= 0) {
    void *value = Span_Get(tbl, idx);
}
```

---

```c
i32 Table_UnSet(Table *tbl, void *a);
```

Removes the entry for key `a`. Returns the index where it was stored, or -1 if not found.

**Example**:
```c
Table_Set(tbl, key, value);
Table_UnSet(tbl, key);  // Removed
```

---

```c
Hashed *Table_GetHashed(Span *tbl, void *a);
Hashed *Table_SetHashed(Span *tbl, void *a, void *value);
```

Gets/sets a `Hashed` entry (which contains both key and value). Use these when you need direct access to the hash entry structure.

**Example**:
```c
Hashed *entry = Table_GetHashed(tbl, key);
if (entry) {
    void *stored_key = entry->a;
    void *stored_val = entry->value;
}
```

---

```c
Hashed *Table_SetValue(Iter *it, void *a);
status Table_SetKey(Iter *it, void *a);
i32 Table_SetIdxEntry(Iter *it, void *a);
```

Advanced functions for setting entries via iterators. Used internally and in performance-critical code.

---

```c
void *Table_FromIdx(Span *tbl, i32 idx);
```

Retrieves the value at a specific index. Equivalent to `Span_Get(tbl, idx)`.

---

#### Hash Key Functions

```c
status Table_HKeyVal(HKey *hk);
status Table_HKeyMiss(HKey *hk);
status Table_HKeyInit(HKey *hk, i8 dims, util id);
```

Low-level hash key manipulation. `HKey` is an internal structure used for multi-dimensional hashing.

**When to use**: Implementing custom hash table variants or multi-dimensional lookups.

---

#### Table Merging

```c
status Table_Underlay(Table *a, Table *b);
```

Merges table `b` into `a`, keeping `a`'s values when keys conflict (b goes "under" a).

**Example**:
```c
Table *defaults = /* ... */;
Table *overrides = /* ... */;
Table_Underlay(overrides, defaults);
// overrides now has all keys from both, preferring overrides
```

---

```c
status Table_Overlay(Table *a, Table *b);
```

Merges table `b` into `a`, replacing `a`'s values when keys conflict (b goes "over" a).

**Example**:
```c
Table *config = /* ... */;
Table *updates = /* ... */;
Table_Overlay(config, updates);
// config now has values from updates for overlapping keys
```

---

```c
status Table_Lay(Span *dest, Span *src, boolean overlay);
```

Generic merge function. `overlay == TRUE` means overlay, `FALSE` means underlay.

---

```c
status Table_Merge(Table *dest, Table *src);
```

Merges `src` into `dest` (currently an alias for overlay).

---

#### Advanced Table Functions

```c
Table *Table_GetOrMake(Table *tbl, void *key, word op);
```

Gets the value for `key`, or creates a new entry if it doesn't exist. `op` specifies what to create:
- `CLS(Table)`: Create nested table
- `CLS(Span)`: Create span
- etc.

**Example**:
```c
// Get or create nested table
Table *nested = Table_GetOrMake(tbl, key, CLS(Table));
Table_Set(nested, inner_key, inner_value);
```

---

```c
Span *Table_Ordered(MemCh *m, Table *tbl);
Span *Table_OrdValues(MemCh *m, Table *tbl);
```

Returns a Span containing table keys (or values) in sorted order.

**Example**:
```c
Span *keys = Table_Ordered(m, tbl);
Iter *it = Iter_Make(m, keys);
Iter_First(it);
while (Iter_Next(it) == READY) {
    void *key = Iter_Get(it);
    // Process keys in sorted order
}
```

---

```c
void *Table_ByPath(Table *tbl, StrVec *path, void *value, word op);
```

Accesses nested tables via a path (like "user.settings.theme").

**Parameters**:
- `path`: StrVec of path segments
- `value`: Value to set (if op == SET)
- `op`: Operation (GET, SET, etc.)

**Example**:
```c
// Get nested value
StrVec *path = /* parse "user.settings.theme" */;
void *theme = Table_ByPath(tbl, path, NULL, GET);

// Set nested value (creates intermediate tables if needed)
Table_ByPath(tbl, path, new_theme, SET);
```

---

```c
i32 Table_SetByCstr(Table *tbl, char *cstr, void *value);
```

Sets a value using a C string as the key (convenience function).

**Example**:
```c
Table_SetByCstr(tbl, "name", Str_FromCstr(m, "Alice", 0));
```

---

```c
status Table_SetInTable(Table *orig, void *tblKey, void *key, void *value);
```

Sets a value in a nested table.

**Example**:
```c
// Set value in tbl["user"]["name"]
Table_SetInTable(tbl,
                 Str_FromCstr(m, "user", 0),
                 Str_FromCstr(m, "name", 0),
                 Str_FromCstr(m, "Alice", 0));
```

---

```c
Table *Table_FromSpan(MemCh *m, Span *p);
```

Converts a Span to a Table (they're the same type, so this is mostly for type clarity).

---

### Lookup - Type Registry

**Header**: [src/base/include/sequence/lookup.h](../../../src/base/include/sequence/lookup.h)

Lookup provides O(1) type-indexed retrieval. It's a specialized table optimized for mapping type IDs (integers) to values, used extensively for registering handlers, formatters, and type-specific behavior.

**See also**: [Table/Lookup Complete Guide](../core-concepts/table-lookup-complete.md)

#### Core Functions

```c
Lookup *Lookup_Make(MemCh *m, word offset);
```

Creates a new lookup with the specified offset. The offset determines the base index for storing values.

**Example**:
```c
Lookup *lk = Lookup_Make(m, 0);
```

---

```c
Lookup *LookupInt_Make(MemCh *m, word offset);
```

Creates an integer-keyed lookup (uses integer values as keys instead of type IDs).

---

```c
Lookup *Lookup_FromConfig(MemCh *m, LookupConfig *config);
```

Creates a lookup from a configuration structure (specifies type mappings declaratively).

---

```c
void *Lookup_Get(Lookup *lk, word type);
```

Retrieves the value associated with `type`.

**Example**:
```c
// Register handler for Str type
Lookup_Add(m, handlers, CLS(Str), str_handler);

// Retrieve handler
StrHandler *handler = Lookup_Get(handlers, CLS(Str));
```

---

```c
i64 Lookup_GetRaw(Lookup *lk, word type);
```

Retrieves a raw 64-bit value (for storing integers or bitfields directly instead of pointers).

**Example**:
```c
Lookup_AddRaw(m, flags, CLS(MyType), 0x1234);
i64 flag = Lookup_GetRaw(flags, CLS(MyType));
```

---

```c
int Lookup_GetKey(Lookup *lk, int idx);
```

Retrieves the type ID (key) at a specific index.

---

```c
word Lookup_AbsFromIdx(Lookup *lk, word idx);
```

Converts a relative index to an absolute index (accounting for offset).

---

```c
status Lookup_Add(MemCh *m, Lookup *lk, word type, void *value);
```

Adds a type-value mapping to the lookup.

**Example**:
```c
Lookup_Add(m, lk, CLS(Str), str_processor);
Lookup_Add(m, lk, CLS(I32), i32_processor);
```

---

```c
status Lookup_AddRaw(MemCh *m, Lookup *lk, word type, i64 n);
```

Adds a raw integer value for a type.

---

```c
status Lookup_Concat(MemCh *m, Lookup *lk, Lookup *add);
```

Concatenates two lookups (adds all entries from `add` to `lk`).

**Example**:
```c
Lookup_Concat(m, main_lookup, extension_lookup);
```

---

### Hashed - Hash Entry Structure

**Header**: [src/base/include/sequence/hashed.h](../../../src/base/include/sequence/hashed.h)

Hashed represents a key-value pair with cached hash. It's the internal structure used by Table for storing entries.

**Structure**:
```c
typedef struct hashed {
    void *a;        // Key
    void *value;    // Value
    util hash;      // Cached hash of key
} Hashed;
```

#### Core Functions

```c
Hashed *Hashed_Make(MemCh *m, void *a);
```

Creates a hashed entry for key `a` (computes and caches hash).

**Example**:
```c
Hashed *entry = Hashed_Make(m, key);
entry->value = my_value;
```

---

```c
Hashed *Hashed_Clone(MemCh *m, Hashed *oh);
```

Clones a hashed entry.

---

```c
util Hash_Bytes(byte *bt, size_t length);
```

Computes a hash for a byte sequence. This is the fundamental hash function used throughout Caneka.

**Example**:
```c
byte data[] = "hello";
util hash = Hash_Bytes(data, 5);
```

**Implementation note**: Uses FNV-1a hash algorithm for speed and good distribution.

---

```c
util Get_Hash(void *a);
```

Generic hash function—dispatches to type-specific hash implementations.

**Example**:
```c
Str *s = Str_FromCstr(m, "hello", 0);
util hash = Get_Hash(s);
```

---

```c
boolean Hashed_Equals(Hashed *a, Hashed *b);
```

Compares two hashed entries for equality (compares both hash and key).

**Example**:
```c
if (Hashed_Equals(entry1, entry2)) {
    // Keys are equal
}
```

---

```c
status Hash_Init(MemCh *m);
```

Initializes the hash system. Called during startup.

---

### Shelf - LIFO Stack Container

**Header**: [src/base/include/sequence/shelf.h](../../../src/base/include/sequence/shelf.h)

Shelf implements stack (LIFO) semantics using an iterator. It's used for object pooling, free lists, and temporary storage.

**See also**: [Shelf Complete Guide](../core-concepts/sequences/shelf-complete.md)

#### Core Functions

```c
boolean Shelf_Available(Iter *shelf);
```

Checks if the shelf has items available.

**Example**:
```c
if (Shelf_Available(shelf)) {
    void *item = Shelf_Get(shelf);
}
```

---

```c
status Shelf_Add(Iter *shelf, void *a);
```

Pushes an item onto the shelf.

**Example**:
```c
Shelf_Add(shelf, item);
```

---

```c
void *Shelf_Get(Iter *shelf);
```

Pops an item from the shelf (LIFO). Returns NULL if empty.

**Example**:
```c
void *item = Shelf_Get(shelf);
if (item) {
    // Use item
}
```

**Pattern**: Shelf is commonly used for recycling:
```c
// Instead of allocating
void *obj;
if (Shelf_Available(pool)) {
    obj = Shelf_Get(pool);  // Reuse
} else {
    obj = Allocate();       // Allocate new
}

// When done
Shelf_Add(pool, obj);  // Return to pool
```

---

### Array - Span to C Array Conversion

**Header**: [src/base/include/sequence/arr.h](../../../src/base/include/sequence/arr.h)

Utilities for converting Span structures to traditional C arrays (NULL-terminated pointer arrays).

#### Core Functions

```c
void **Span_ToArr(MemCh *m, Span *p);
```

Converts a Span to a NULL-terminated C array.

**Example**:
```c
Span *span = /* ... */;
void **arr = Span_ToArr(m, span);

// Use as C array
for (i32 i = 0; arr[i] != NULL; i++) {
    process(arr[i]);
}
```

---

```c
void **Arr_Make(MemCh *m, i32 nvalues);
```

Allocates a NULL-terminated array of pointers.

**Example**:
```c
void **arr = Arr_Make(m, 3);
arr[0] = first;
arr[1] = second;
arr[2] = third;
arr[3] = NULL;  // Already set
```

---

### Path - File Path Manipulation

**Header**: [src/base/include/sequence/path.h](../../../src/base/include/sequence/path.h)

Path provides sophisticated file path parsing and manipulation. Paths are represented as StrVec (vector of path segments) with annotations for separators and dots.

#### Core Functions

```c
status Path_Init(MemCh *m);
```

Initializes the path system.

---

```c
StrVec *Path_Make(MemCh *m, Str *s, Span *sep);
```

Parses a path string into segments using the provided separators.

**Example**:
```c
Str *path_str = Str_FromCstr(m, "/usr/local/bin", 0);
Span *sep = /* '/' separator */;
StrVec *path = Path_Make(m, path_str, sep);
// path = ["", "usr", "local", "bin"]
```

---

```c
status Path_Annotate(MemCh *m, StrVec *v, Span *sep);
```

Annotates a path StrVec with separator information.

---

```c
status Path_DotAnnotate(MemCh *m, StrVec *v);
status Path_SpaceAnnotate(MemCh *m, StrVec *v);
```

Annotates paths using dots or spaces as separators.

**Example**:
```c
// Parse "user.settings.theme"
Str *s = Str_FromCstr(m, "user.settings.theme", 0);
StrVec *path = StrVec_Make(m);
/* split by '.' */
Path_DotAnnotate(m, path);
```

---

```c
StrVec *Path_Base(MemCh *m, StrVec *path);
```

Extracts the directory portion of a path (everything except the last segment).

**Example**:
```c
// "/usr/local/bin/prog" -> "/usr/local/bin"
StrVec *base = Path_Base(m, path);
```

---

```c
StrVec *Path_Name(MemCh *m, StrVec *path);
```

Extracts the filename (last segment).

**Example**:
```c
// "/usr/local/bin/prog" -> "prog"
StrVec *name = Path_Name(m, path);
```

---

```c
StrVec *Path_Ext(MemCh *m, StrVec *path);
```

Extracts the file extension.

**Example**:
```c
// "file.txt" -> "txt"
StrVec *ext = Path_Ext(m, path);
```

---

```c
StrVec *Path_WithoutExt(MemCh *m, StrVec *path);
```

Returns the path without the extension.

**Example**:
```c
// "file.txt" -> "file"
StrVec *without = Path_WithoutExt(m, path);
```

---

```c
StrVec *Path_ReJoinExt(MemCh *m, StrVec *v);
```

Rejoins a filename with its extension (reverses splitting).

---

```c
boolean Path_ExtEquals(StrVec *path, Str *ext);
```

Checks if path has the specified extension.

**Example**:
```c
if (Path_ExtEquals(path, Str_FromCstr(m, "txt", 0))) {
    // It's a text file
}
```

---

```c
status Path_Add(MemCh *m, StrVec *path, StrVec *add);
```

Appends path segments.

**Example**:
```c
Path_Add(m, base_path, Str_FromCstr(m, "subdir", 0));
```

---

```c
status Path_AddStr(StrVec *path, Str *add);
```

Appends a string segment to the path.

---

```c
Str *Path_StrAdd(MemCh *m, StrVec *path, Str *seg);
```

Adds a segment and converts the entire path to a Str.

**Example**:
```c
Str *full_path = Path_StrAdd(m, base, Str_FromCstr(m, "file.txt", 0));
// full_path = "/base/path/file.txt"
```

---

```c
status PathStr_StrAdd(Str *s, Str *seg);
```

Appends a path segment to a Str path.

---

```c
status Path_AddSlash(MemCh *m, StrVec *path);
```

Adds a trailing path separator.

---

```c
StrVec *Path_SubClone(MemCh *m, StrVec *path, i32 count);
```

Creates a clone of the first `count` segments.

**Example**:
```c
// Get first 2 segments of path
StrVec *prefix = Path_SubClone(m, path, 2);
```

---

```c
status Path_RangeOf(MemCh *m, StrVec *path, word sep, Coord *cr);
status Path_Around(MemCh *m, StrVec *path, word sep, Coord *cr);
```

Finds ranges around separators (used internally for parsing).

---

```c
status Path_JoinBase(MemCh *m, StrVec *path);
```

Joins base path components.

---


## I/O Operations

Caneka's I/O system provides a unified abstraction over files, sockets, and memory buffers. The core abstraction is `Buff`, which handles buffering, seeking, and format-agnostic I/O.

### Buff - Buffered I/O Abstraction

**Header**: [src/base/include/io/buff.h](../../../src/base/include/io/buff.h)

Buff is Caneka's universal I/O interface. It buffers reads and writes, supports both files and sockets, handles seeking, and integrates tightly with StrVec for efficient large data handling.

**See also**: [Buff I/O Complete Guide](../core-concepts/buff-io-complete.md)

**Key fields**:
```c
typedef struct buff {
    StrVec *v;       // Buffered data
    i32 fd;          // File descriptor (-1 if not set)
    word flags;      // BUFF_READ, BUFF_WRITE, BUFF_SOCKET, etc.
    i64 pos;         // Current position in file
    i64 size;        // File size (for files)
} Buff;
```

#### Creation Functions

```c
Buff *Buff_Make(MemCh *m, word flags);
```

Creates a new buffer with the specified flags:
- `BUFF_READ`: Enable reading
- `BUFF_WRITE`: Enable writing
- `BUFF_SOCKET`: Treat as socket (no seeking)
- `0`: Memory-only buffer (no file descriptor)

**Example**:
```c
Buff *bf = Buff_Make(m, BUFF_READ | BUFF_WRITE);
```

---

```c
Buff *Buff_From(MemCh *m, StrVec *v);
```

Creates a buffer backed by an existing StrVec (for in-memory I/O).

**Example**:
```c
StrVec *data = /* ... */;
Buff *bf = Buff_From(m, data);
// Read from or write to data
```

---

#### File Descriptor Management

```c
status Buff_SetFd(Buff *bf, i32 fd);
```

Attaches a file descriptor to the buffer.

**Example**:
```c
int fd = open("file.txt", O_RDONLY);
Buff_SetFd(bf, fd);
```

---

```c
status Buff_SetSocket(Buff *bf, i32 fd);
```

Attaches a socket descriptor (disables seeking).

**Example**:
```c
int sock = socket(AF_INET, SOCK_STREAM, 0);
// ... connect ...
Buff_SetSocket(bf, sock);
```

---

```c
status Buff_UnsetFd(Buff *bf);
status Buff_UnsetSocket(Buff *bf);
```

Detaches the file or socket descriptor.

**Example**:
```c
Buff_UnsetFd(bf);  // Detach, but don't close
close(fd);         // Close separately
```

---

#### Status Functions

```c
boolean Buff_IsEmpty(Buff *bf);
```

Checks if buffer has any data.

**Example**:
```c
if (Buff_IsEmpty(bf)) {
    printf("Buffer is empty\n");
}
```

---

```c
status Buff_Stat(Buff *bf);
```

Updates buffer's size information from the underlying file.

**Example**:
```c
Buff_Stat(bf);
printf("File size: %lld\n", bf->size);
```

---

#### Output Functions

```c
status Buff_Add(Buff *bf, Str *s);
```

Adds a Str to the buffer (writes if file attached, otherwise buffers in memory).

**Example**:
```c
Buff_Add(bf, Str_FromCstr(m, "Hello\n", 0));
```

---

```c
status Buff_AddVec(Buff *bf, StrVec *v);
```

Adds a StrVec to the buffer.

**Example**:
```c
Buff_AddVec(bf, data_vec);
```

---

```c
status Buff_AddBytes(Buff *bf, byte *bytes, i64 length);
```

Adds raw bytes to the buffer.

**Example**:
```c
byte data[] = {0x00, 0x01, 0x02};
Buff_AddBytes(bf, data, 3);
```

---

```c
status Buff_Flush(Buff *bf);
```

Flushes buffered writes to the underlying file or socket.

**Example**:
```c
Buff_Add(bf, str1);
Buff_Add(bf, str2);
Buff_Flush(bf);  // Write to file/socket now
```

**Performance note**: Writes are automatically flushed when the buffer reaches a threshold, but you should call `Flush()` before closing or when you need data persisted immediately.

---

#### Input Functions

```c
status Buff_Read(Buff *bf);
```

Reads data from the file/socket into the buffer. Reads up to the buffer's capacity.

**Example**:
```c
Buff_Read(bf);
// bf->v now contains read data
```

---

```c
status Buff_ReadAmount(Buff *bf, i64 amount);
```

Reads exactly `amount` bytes.

**Example**:
```c
Buff_ReadAmount(bf, 1024);  // Read 1KB
```

---

```c
status Buff_ReadToStr(Buff *bf, Str *s);
```

Reads from buffer into a Str.

**Example**:
```c
Str *s = Str_Make(m, 1024);
Buff_ReadToStr(bf, s);
```

---

```c
status Buff_GetStr(Buff *bf, Str *s);
```

Gets buffered data into a Str (doesn't read from file—uses already-buffered data).

**Example**:
```c
Buff_Read(bf);           // Read from file
Str *s = Str_Make(m, 1024);
Buff_GetStr(bf, s);      // Copy buffered data to s
```

---

```c
status Buff_RevGetStr(Buff *bf, Str *s);
```

Gets buffered data in reverse order.

---

```c
status Buff_GetToVec(Buff *bf, StrVec *v);
```

Gets buffered data into a StrVec.

**Example**:
```c
StrVec *v = StrVec_Make(m);
Buff_GetToVec(bf, v);
```

---

```c
status Buff_CompareToVec(Buff *bf, StrVec *v);
```

Compares buffered data to a StrVec.

**Example**:
```c
if (Buff_CompareToVec(bf, expected) == READY) {
    // Buffer matches expected
}
```

---

```c
status Buff_Pipe(Buff *to, Buff *from);
```

Pipes data from one buffer to another (efficient copy).

**Example**:
```c
Buff_Pipe(output, input);
// All data from input copied to output
```

---

#### Seeking Functions

```c
status Buff_PosAbs(Buff *bf, i64 position);
```

Seeks to absolute position in file.

**Example**:
```c
Buff_PosAbs(bf, 1024);  // Seek to byte 1024
```

**Note**: Only works for files, not sockets.

---

```c
status Buff_Pos(Buff *bf, i64 position);
```

Seeks relative to current position.

**Example**:
```c
Buff_Pos(bf, 100);   // Advance 100 bytes
Buff_Pos(bf, -50);   // Go back 50 bytes
```

---

```c
status Buff_PosEnd(Buff *bf);
```

Seeks to end of file.

**Example**:
```c
Buff_PosEnd(bf);
// Now positioned at end
```

---

### File - File Operations

**Header**: [src/base/include/io/file.h](../../../src/base/include/io/file.h)

File operations built on top of Buff. These provide convenient wrappers for common file tasks.

**See also**: [File Operations Complete Guide](../core-concepts/io/file-operations-complete.md)

#### Core Functions

```c
status File_Open(Buff *bf, void *_fpath, word ioFlags);
```

Opens a file and attaches it to a buffer.

**Parameters**:
- `bf`: Buffer to attach file to
- `_fpath`: File path (Str* or StrVec*)
- `ioFlags`: `BUFF_READ`, `BUFF_WRITE`, or both

**Example**:
```c
Buff *bf = Buff_Make(m, BUFF_READ);
File_Open(bf, Str_FromCstr(m, "data.txt", 0), BUFF_READ);
Buff_Read(bf);  // Read file contents
```

---

```c
status File_Close(Buff *bf);
```

Closes the file attached to the buffer.

**Example**:
```c
File_Close(bf);
```

**Note**: Also flushes any pending writes.

---

```c
StrVec *File_ToVec(MemCh *m, Str *path);
```

Reads an entire file into a StrVec. Convenience function for small-to-medium files.

**Example**:
```c
StrVec *contents = File_ToVec(m, Str_FromCstr(m, "config.txt", 0));
```

---

```c
status File_Unlink(MemCh *m, Str *path);
```

Deletes a file.

**Example**:
```c
File_Unlink(m, Str_FromCstr(m, "temp.txt", 0));
```

---

```c
status File_Rename(MemCh *m, Str *to, Str *from);
```

Renames a file.

**Example**:
```c
File_Rename(m,
            Str_FromCstr(m, "new.txt", 0),
            Str_FromCstr(m, "old.txt", 0));
```

---

```c
boolean File_Exists(Buff *bf, Str *path);
boolean File_PathExists(MemCh *m, Str *path);
```

Checks if a file exists.

**Example**:
```c
if (File_PathExists(m, Str_FromCstr(m, "config.txt", 0))) {
    // File exists
}
```

---

```c
status File_Stat(MemCh *m, Str *path, struct stat *st);
```

Gets file statistics.

**Example**:
```c
struct stat st;
File_Stat(m, path, &st);
printf("Size: %lld\n", (i64)st.st_size);
```

---

```c
void File_ModTime(MemCh *m, Str *path, struct timespec *tm);
```

Gets file modification time.

**Example**:
```c
struct timespec modtime;
File_ModTime(m, path, &modtime);
```

---

### Dir - Directory Operations

**Header**: [src/base/include/io/dir.h](../../../src/base/include/io/dir.h)

Directory manipulation and traversal functions.

**See also**: [File Operations Complete Guide](../core-concepts/io/file-operations-complete.md)

#### Core Functions

```c
status Dir_Mk(MemCh *m, Str *path);
```

Creates a directory.

**Example**:
```c
Dir_Mk(m, Str_FromCstr(m, "output", 0));
```

---

```c
status Dir_CheckCreate(MemCh *m, Str *path);
```

Creates a directory if it doesn't exist.

**Example**:
```c
Dir_CheckCreate(m, Str_FromCstr(m, "cache", 0));
```

---

```c
status Dir_Rm(MemCh *m, Str *path);
```

Removes an empty directory.

**Example**:
```c
Dir_Rm(m, Str_FromCstr(m, "temp", 0));
```

---

```c
status Dir_Destroy(MemCh *m, Str *path);
```

Recursively deletes a directory and all its contents.

**Example**:
```c
Dir_Destroy(m, Str_FromCstr(m, "old_build", 0));
```

**Warning**: This is destructive and cannot be undone.

---

```c
status Dir_Exists(MemCh *m, Str *path);
```

Checks if a directory exists.

**Example**:
```c
if (Dir_Exists(m, Str_FromCstr(m, "src", 0)) == READY) {
    // Directory exists
}
```

---

#### Directory Traversal

```c
status Dir_Gather(MemCh *m, Str *path, Span *sp);
```

Gathers all entries in a directory into a Span.

**Example**:
```c
Span *entries = Span_Make(m);
Dir_Gather(m, Str_FromCstr(m, ".", 0), entries);

Iter *it = Iter_Make(m, entries);
Iter_First(it);
while (Iter_Next(it) == READY) {
    Str *filename = Iter_Get(it);
    // Process filename
}
```

---

```c
DirSelector *Dir_GatherByExt(MemCh *m, Str *path, Span *sp, Span *exts);
```

Gathers files with specific extensions.

**Example**:
```c
Span *exts = Span_Make(m);
Span_Set(exts, 0, Str_FromCstr(m, "c", 0));
Span_Set(exts, 1, Str_FromCstr(m, "h", 0));

Span *files = Span_Make(m);
Dir_GatherByExt(m, Str_FromCstr(m, "src", 0), files, exts);
// files contains all .c and .h files
```

---

```c
status Dir_GatherSel(MemCh *m, Str *path, DirSelector *sel);
```

Gathers files using a selector (provides more control than GatherByExt).

**Example**:
```c
DirSelector *sel = DirSelector_Make(m, ext, dest, flags);
Dir_GatherSel(m, path, sel);
```

---

```c
status Dir_GatherFilterDir(MemCh *m, Str *path, DirSelector *sel);
```

Gathers files while filtering out directories.

---

```c
status Dir_Climb(MemCh *m, Str *path, DirFunc dir, FileFunc file, void *source);
```

Recursively traverses a directory tree, calling callbacks for directories and files.

**Parameters**:
- `path`: Starting directory
- `dir`: Callback for directories
- `file`: Callback for files
- `source`: User data passed to callbacks

**Example**:
```c
status HandleFile(MemCh *m, Str *path, void *source) {
    printf("File: %s\n", Str_Cstr(m, path));
    return READY;
}

status HandleDir(MemCh *m, Str *path, void *source) {
    printf("Dir: %s\n", Str_Cstr(m, path));
    return READY;
}

Dir_Climb(m, Str_FromCstr(m, ".", 0), HandleDir, HandleFile, NULL);
```

---

```c
DirSelector *DirSelector_Make(MemCh *m, Str *ext, Span *dest, word flags);
```

Creates a directory selector for filtering directory contents.

**Parameters**:
- `ext`: File extension to match
- `dest`: Span to store results
- `flags`: Filter flags

**Example**:
```c
Span *results = Span_Make(m);
DirSelector *sel = DirSelector_Make(m,
                                     Str_FromCstr(m, "txt", 0),
                                     results,
                                     0);
Dir_GatherSel(m, path, sel);
```

---

### Subprocess/Process - Process Execution

**Header**: [src/base/include/io/subprocess.h](../../../src/base/include/io/subprocess.h)

Functions for spawning and managing child processes.

**See also**: [File Operations Complete Guide](../core-concepts/io/file-operations-complete.md)

#### Core Functions

```c
status SubProcess(MemCh *m, Span *cmd_p, ProcDets *pd);
```

Spawns a subprocess asynchronously.

**Parameters**:
- `cmd_p`: Span of command arguments (argv)
- `pd`: Process details structure (output)

**Example**:
```c
Span *cmd = Span_Make(m);
Span_Set(cmd, 0, Str_FromCstr(m, "/bin/ls", 0));
Span_Set(cmd, 1, Str_FromCstr(m, "-l", 0));

ProcDets pd;
ProcDets_Init(&pd);
SubProcess(m, cmd, &pd);
// Process running, pd contains PID and pipes
```

---

```c
status SubCall(MemCh *m, Span *cmd_p, ProcDets *pd);
```

Spawns a subprocess and waits for it to complete (synchronous).

**Example**:
```c
SubCall(m, cmd, &pd);
printf("Exit code: %d\n", pd.exit_code);
```

---

```c
status SubStatus(ProcDets *pd);
```

Checks the status of a running subprocess.

**Example**:
```c
SubProcess(m, cmd, &pd);
while (SubStatus(&pd) == RUNNING) {
    // Process still running
    sleep(1);
}
```

---

```c
status SubProcToBuff(MemCh *m, Span *cmd, struct buff *out, struct buff *err);
```

Runs a subprocess and captures stdout and stderr into buffers.

**Example**:
```c
Buff *out = Buff_Make(m, 0);
Buff *err = Buff_Make(m, 0);
SubProcToBuff(m, cmd, out, err);

// out contains stdout
// err contains stderr
```

---

```c
status ProcDets_Init(ProcDets *pd);
```

Initializes a process details structure.

**Example**:
```c
ProcDets pd;
ProcDets_Init(&pd);
```

---


## Utilities

### Integer Wrapping

For use with format functions that need type information:

```c
void *I32_Wrapped(MemCh *m, i32 i);
void *I64_Wrapped(MemCh *m, i64 i);
void *CLS_Wrapped(cls c);
```

These wrap primitive values so they can be passed to format functions.

**Example**:
```c
void *args[] = {
    I32_Wrapped(m, 42),
    I64_Wrapped(m, 1000000),
    CLS_Wrapped(CLS(Str)),
    NULL
};
Fmt(bf, "i32: @, i64: @, type: &", args);
```

---



---

[← Part 2](base-part2) | **Part 3 of 4** | [Part 4 →](base-part4)
