# Ext Module API Reference - Part 1

**Part 1 of 2** | [Part 2 →](ext-part2)

---

## Architecture Overview

The Ext layer comprises six major modules, each addressing a distinct architectural concern:

**1. Parser (Roebling)** - Pattern matching engine for creating DSLs
**2. Navigate** - Task/Step execution with hierarchical data structures
**3. Types (Seel/Inst)** - Runtime type system with dynamic property access
**4. Format** - Multi-format support (Config, JSON, HTML, XML)
**5. Serve** - Event-driven TCP server infrastructure
**6. Persist** - Binary serialization format

### Module Dependencies

```
Base Layer (mem, bytes, sequence, io, types)
    ↓
Ext Layer Modules:
    Parser (Roebling) ← Format ← Persist
         ↓                ↓         ↓
    Navigate ← Types (Seel/Inst) ← Serve
```

**Dependency patterns**:
- **Parser** is foundational—Format module uses Roebling for Config, JSON, XML, HTML
- **Types (Seel/Inst)** builds on Navigate structures (Node, Mess)
- **Serve** uses Navigate (Task/Step), Types (Inst), and Format (Config)
- **Persist** uses Types for serialization metadata

### Key Design Principles

1. **Parsers as building blocks**: Roebling parsers create structured data from text
2. **Task-based concurrency**: Tasks contain Steps, Steps perform incremental work
3. **Type-safe flexibility**: Seel provides runtime types; Inst provides typed property access
4. **Format agnosticism**: Config, JSON, all parse into Inst structures
5. **Event-driven I/O**: TCP server uses poll-based non-blocking I/O with Task/Step


## Common Patterns

Before diving into specific modules, understand these patterns that appear throughout Ext:

### Capture Functions

Many Ext systems use **capture callbacks** to handle parsed or processed data:

```c
typedef status (*RblCaptureFunc)(MemCh *m, Match *mt, void *source);
typedef status (*StepFunc)(Step *st, Task *tsk);
typedef gobits (*QueueFunc)(QueueCrit *crit, util *values);
```

**Pattern**: System processes data incrementally, calls your function when significant events occur.

**Example**:
```c
status HandleMatch(MemCh *m, Match *mt, void *source) {
    StrVec *captured = mt->captured;
    // Process matched text
    return READY;
}

Roebling *rbl = Roebling_Make(m, cursor, HandleMatch, my_data);
```

### State Machines

Ext modules use explicit state machines for complex processing:

```c
rbl->state = STATE_INITIAL;
Roebling_AddStep(rbl, state_parse_header);
Roebling_AddStep(rbl, state_parse_body);
Roebling_AddStep(rbl, state_finalize);

Roebling_Run(rbl);  // Executes state machine
```

**Pattern**: Add state handlers, run the machine, state transitions happen automatically.

### Source Tracking

Most Ext functions accept `void *source` for tracking data origin:

```c
Task *tsk = Task_Make(chain, request_context);
Step *step = Step_Make(m, handle_request, arg, request_context, flags);
```

**Why**: Enables error context, debugging, and associating operations with originating requests.

---


## Parser Module (Roebling)

**Headers**: [src/ext/include/parser/](../../../src/ext/include/parser/)

The Roebling parser is a **pattern matching engine that generates data structures**. Unlike traditional regex engines that just match text, Roebling captures structured data, manages state transitions, and builds hierarchical outputs.

It's the foundation for all text parsing in Caneka: Config files, JSON, HTTP headers, template syntax—all implemented as Roebling parsers.

**See also**:
- [Pattern Matching Complete Guide](../core-concepts/parser/pattern-matching.md)
- [Creating DSLs](../core-concepts/parser/creating-dsls.md)
- [Writing Parsers Guide](../guides/writing-parsers.md)

### Pattern Definition System

#### PatCharDef - Pattern Character Definition

**Header**: [src/ext/include/parser/patchar.h](../../../src/ext/include/parser/patchar.h)

`PatCharDef` defines a pattern element—a single matching rule. Patterns are combined into sequences to match complex structures.

**Structure**:
```c
typedef struct patchardef {
    word flags;      // Pattern flags (PAT_TERM, PAT_MANY, etc.)
    byte from;       // Character range start
    byte to;         // Character range end
} PatCharDef;
```

**Pattern Flags**:
```c
PAT_END            // Pattern sequence terminator (must be last)
PAT_TERM      (X)  // Match terminates pattern (success)
PAT_OPTIONAL  (P)  // Optional match
PAT_MANY      (M)  // Match multiple times
PAT_ANY       (N)  // Match any character
PAT_INVERT    (I)  // Invert match (match anything except)
PAT_COUNT     (C)  // Count matches without capturing
PAT_INVERT_CAPTURE (G)  // Invert capture behavior
PAT_KO        (K)  // Knockout—fail if matched
PAT_CONSUME   (V)  // Consume matched characters
```

**Creating Patterns**:

```c
PatCharDef *PatChar_FromStr(MemCh *m, Str *s);
```

Creates a pattern from a Str. The string defines character ranges and flags.

**Example**:
```c
// Match lowercase letters a-z
PatCharDef *def = PatChar_FromStr(m, Str_FromCstr(m, "a-z", 0));

// Match digits 0-9, multiple times
PatCharDef def_digits = {PAT_MANY, '0', '9'};

// Match anything except newline (knockout pattern)
PatCharDef def_not_nl = {PAT_KO, '\n', '\n'};
```

---

```c
PatCharDef *PatChar_KoFromStr(MemCh *m, Str *s);
```

Creates a knockout pattern (fails if matched).

**Example**:
```c
PatCharDef *ko_newline = PatChar_KoFromStr(m, Str_FromCstr(m, "\n", 0));
// Fails if newline encountered
```

---

```c
PatCharDef *PatChar_FromStrVec(MemCh *m, StrVec *v);
```

Creates a pattern from a StrVec (for large or multi-part patterns).

---

#### Predefined Patterns

**Header**: [src/ext/include/parser/match_predefs.h](../../../src/ext/include/parser/match_predefs.h)

Common patterns are predefined as macros for convenience:

```c
#define TEXT_DEF        /* Text with optional whitespace */
#define NL_DEF          /* Newline (\n or \r\n) */
#define WS_REQUIRED     /* Required whitespace */
#define WS_OPTIONAL     /* Optional whitespace */
#define UPPER_DEF       /* Uppercase A-Z */
#define LOWER_DEF       /* Lowercase a-z */
#define DIGIT_DEF       /* Digits 0-9 */
#define ALNUM_DEF       /* Alphanumeric */
```

**Example**:
```c
// Match: optional whitespace, then text, then newline
PatCharDef pattern[] = {
    WS_OPTIONAL,
    TEXT_DEF,
    NL_DEF,
    {PAT_END}  // Terminator
};
```

---

### Match Object - Pattern Match State

**Header**: [src/ext/include/parser/match.h](../../../src/ext/include/parser/match.h)

`Match` represents the state of matching a single pattern. It tracks what's been matched, captures text, and manages backtracking.

**Key fields**:
```c
typedef struct match {
    Type type;
    PatCharDef *def;     // Pattern being matched
    StrVec *captured;    // Captured text
    i32 count;           // Match count
    status state;        // Current match state
    Span *backlog;       // Backtracking stack
} Match;
```

#### Match Functions

```c
Match *Match_Make(MemCh *m, PatCharDef *def, Span *backlog);
```

Creates a match object for the given pattern definition.

**Example**:
```c
PatCharDef def[] = { {PAT_MANY, 'a', 'z'}, {PAT_END} };
Match *mt = Match_Make(m, def, NULL);
```

---

```c
status Match_StartOver(Match *m);
```

Resets match to initial state (for reusing Match objects).

---

```c
status Match_Feed(MemCh *m, Match *mt, byte c);
```

Feeds a single byte to the match. Returns:
- `READY`: Match continuing (needs more input)
- `MATCH_TERM`: Pattern matched successfully
- `MATCH_KO`: Pattern failed (knockout or mismatch)

**Example**:
```c
Match *mt = /* ... */;
byte text[] = "hello";
for (i32 i = 0; i < 5; i++) {
    status r = Match_Feed(m, mt, text[i]);
    if (r == MATCH_TERM) {
        // Matched!
        break;
    } else if (r == MATCH_KO) {
        // Failed
        break;
    }
}
```

---

```c
status Match_FeedStrVec(MemCh *m, Match *mt, StrVec *v, i32 offset);
```

Feeds an entire StrVec to the match, starting from `offset`.

**Example**:
```c
Match_FeedStrVec(m, mt, input_vec, 0);
```

---

```c
status Match_FeedEnd(MemCh *m, Match *mt);
```

Signals end of input. For patterns with `PAT_OPTIONAL` or `PAT_MANY`, this finalizes the match.

**Example**:
```c
Match_Feed(m, mt, 'a');
Match_Feed(m, mt, 'b');
Match_FeedEnd(m, mt);  // Finalize
```

---

```c
status Match_SetCount(Match *mt, i32 count);
```

Sets the match count (for counted patterns).

---

```c
status Match_ResolveOverlay(Match *mt, i32 length);
```

Resolves overlapping matches (advanced usage).

---

```c
status Match_AddBoundrySnip(MemCh *m, Match *mt);
```

Adds a boundary snippet (marks position for capture).

---

### Roebling Engine - Pattern Matching Orchestration

**Header**: [src/ext/include/parser/roebling.h](../../../src/ext/include/parser/roebling.h)

`Roebling` orchestrates pattern matching across multiple patterns, managing state transitions, captures, and callbacks.

**Key fields**:
```c
typedef struct roebling {
    Type type;
    MemCh *m;
    Cursor *curs;             // Input cursor
    RblCaptureFunc capture;   // Capture callback
    void *source;             // User data
    Span *steps;              // State machine steps
    i32 state;                // Current state
    Span *matches;            // Active match objects
    StrVec *buffer;           // Input buffer
} Roebling;
```

#### Core Functions

```c
Roebling *Roebling_Make(MemCh *m, Cursor *curs, RblCaptureFunc capture, void *source);
```

Creates a Roebling parser.

**Parameters**:
- `m`: Memory chapter
- `curs`: Input cursor (positioned at start of data to parse)
- `capture`: Callback function for handling captures
- `source`: User data passed to capture function

**Example**:
```c
status HandleCapture(MemCh *m, Match *mt, void *source) {
    printf("Captured: %s\n", Str_Cstr(m, StrVec_Str(m, mt->captured)));
    return READY;
}

StrVec *input = File_ToVec(m, Str_FromCstr(m, "input.txt", 0));
Cursor *curs = Cursor_Make(m, input);
Roebling *rbl = Roebling_Make(m, curs, HandleCapture, NULL);
```

---

```c
status Roebling_Start(Roebling *rbl);
```

Initializes the parser (prepares for execution).

**Example**:
```c
Roebling_AddStep(rbl, state_initial);
Roebling_Start(rbl);
```

---

```c
status Roebling_Reset(MemCh *m, Roebling *rbl, StrVec *v);
```

Resets the parser with new input (reuses Roebling object).

**Example**:
```c
Roebling_Reset(m, rbl, new_input);
Roebling_Run(rbl);
```

---

#### Pattern Configuration

```c
status Roebling_SetPattern(Roebling *rbl, PatCharDef *def, word captureKey, i16 jump);
```

Sets the pattern for the current state.

**Parameters**:
- `rbl`: Roebling parser
- `def`: Pattern definition array (terminated with `{PAT_END}`)
- `captureKey`: Key for captured text (passed to capture callback)
- `jump`: State to jump to after match (-1 for default next state)

**Example**:
```c
// State 0: Match "hello" followed by space
PatCharDef hello_pattern[] = {
    {'h', 'h'}, {'e', 'e'}, {'l', 'l'}, {'l', 'l'}, {'o', 'o'},
    {PAT_TERM | PAT_CONSUME, ' ', ' '},
    {PAT_END}
};
rbl->state = 0;
Roebling_SetPattern(rbl, hello_pattern, CAPTURE_GREETING, -1);
```

---

```c
status Roebling_ResetPatterns(Roebling *rbl);
```

Clears all patterns (for reconfiguration).

---

#### Execution

```c
status Roebling_RunCycle(Roebling *rbl);
```

Executes one parsing cycle (processes input until state change or completion).

**Returns**:
- `READY`: Cycle complete, continue
- `ROEBLING_DONE`: Parsing complete
- `ERR`: Error occurred

**Example**:
```c
while (Roebling_RunCycle(rbl) == READY) {
    // Processing...
}
```

---

```c
status Roebling_Run(Roebling *rbl);
```

Executes the parser to completion (runs cycles until done).

**Example**:
```c
Roebling_AddStep(rbl, state_parse);
Roebling_Start(rbl);
Roebling_Run(rbl);  // Parses entire input
```

**Common pattern**:
```c
// Setup
Roebling *rbl = Roebling_Make(m, curs, capture, source);
Roebling_AddStep(rbl, state_handler);
rbl->state = 0;

// Run
Roebling_Start(rbl);
status result = Roebling_Run(rbl);

// Check result
if (result != READY) {
    // Parse error
}
```

---

#### Mark and Jump System

```c
status Roebling_JumpTo(Roebling *rbl, i32 mark);
```

Jumps to a specific mark (saved cursor position). Used for backtracking or conditional parsing.

**Example**:
```c
// Save position
i32 start_mark = rbl->mark;

// Try parsing as JSON
if (try_parse_json(rbl) != READY) {
    // Failed, backtrack
    Roebling_JumpTo(rbl, start_mark);
    // Try parsing as XML
    try_parse_xml(rbl);
}
```

---

```c
i64 Roebling_GetMarkIdx(Roebling *rbl, i32 mark);
```

Gets the cursor index for a mark.

---

#### Result Retrieval

```c
Match *Roebling_GetMatch(Roebling *rbl);
```

Gets the current Match object.

**Example**:
```c
Match *mt = Roebling_GetMatch(rbl);
if (mt && mt->captured) {
    StrVec *captured = mt->captured;
    // Process captured text
}
```

---

```c
i32 Roebling_GetMatchIdx(Roebling *rbl);
```

Gets the index of the current match.

---

#### State Management

```c
status Roebling_AddStep(Roebling *rbl, void *step);
```

Adds a state handler function to the parser.

**Example**:
```c
status state_parse_header(Roebling *rbl) {
    if (rbl->state == 0) {
        // Define pattern for this state
        PatCharDef header_pattern[] = { /* ... */, {PAT_END} };
        Roebling_SetPattern(rbl, header_pattern, CAPTURE_HEADER, 1);
        return READY;
    }
    return READY;
}

Roebling_AddStep(rbl, state_parse_header);
```

---

```c
status Roebling_Finalize(Roebling *rbl, Match *mt, i64 total);
```

Finalizes a match (called internally when pattern completes).

---

```c
status Roebling_Dispatch(Roebling *rbl, Match *mt);
```

Dispatches a completed match to the capture callback.

---

### Tokenization and String Utilities

**Headers**:
- [src/ext/include/parser/tokenize.h](../../../src/ext/include/parser/tokenize.h)
- [src/ext/include/parser/split.h](../../../src/ext/include/parser/split.h)
- [src/ext/include/parser/match_replace.h](../../../src/ext/include/parser/match_replace.h)

#### Tokenize

```c
Tokenize *Tokenize_Make(MemCh *m, StrVec *separators);
```

Creates a tokenizer that splits text by separators.

**Example**:
```c
StrVec *seps = StrVec_Make(m);
StrVec_Add(seps, Str_FromCstr(m, ".", 0));
Tokenize *tk = Tokenize_Make(m, seps);
```

---

#### Split

String splitting utilities using Roebling patterns.

---

#### Match Replace

Pattern-based string replacement.

---

### Snippet Tracking

**Header**: [src/ext/include/parser/snip.h](../../../src/ext/include/parser/snip.h)

Snippets track positions in the input for capturing ranges of text. They're used internally by Match but can be manipulated directly for advanced parsing.

---


## Navigate Module - Task Execution

**Headers**: [src/ext/include/navigate/](../../../src/ext/include/navigate/)

Navigate provides **asynchronous task execution** with a step-based execution model. It's the foundation for Caneka's event loop: web servers, parsers, and I/O operations all use Tasks and Steps.

**See also**:
- [Task Execution Complete Guide](../core-concepts/navigate/task-execution-complete.md)
- [Queue Complete Guide](../core-concepts/navigate/queue-complete.md)

### Task - Execution Unit

**Header**: [src/ext/include/navigate/task.h](../../../src/ext/include/navigate/task.h)

A `Task` represents an asynchronous operation broken into discrete `Steps`. Tasks can have parent-child relationships, timeouts, and metrics tracking.

**Structure**:
```c
typedef struct task {
    Type type;
    i32 idx;                  // Current step index
    i16 stepGuardMax;         // Max steps before guard triggers
    i16 g;                    // Guard counter
    util u;                   // User data (32-bit)
    MemCh *m;                 // Memory chapter
    Abstract *data;           // Task-specific data
    Abstract *source;         // Source context
    struct task *parent;      // Parent task
    Iter chainIt;             // Step chain iterator
    struct {
        struct timespec start;    // Start time
        struct timespec consumed; // Execution time
        struct timespec end;      // End time
    } metrics;
    struct timespec timeout;  // Timeout duration
} Task;
```

#### Core Functions

```c
Task *Task_Make(Span *chain, void *source);
```

Creates a task with a chain of steps.

**Parameters**:
- `chain`: Span containing Step objects (NULL for empty task)
- `source`: Source context (request, connection, etc.)

**Example**:
```c
Span *steps = Span_Make(m);
Task *tsk = Task_Make(steps, request_context);
```

---

```c
status Task_Cycle(Task *tsk);
```

Executes one task cycle (runs current step, advances to next).

**Returns**:
- `READY`: Cycle complete, continue
- `TASK_DELAY`: Step requested delay
- `TASK_DONE`: Task complete
- `ERR`: Error

**Example**:
```c
while (Task_Cycle(tsk) == READY) {
    // Task progressing...
}
```

---

```c
status Task_Tumble(Task *tsk);
```

**Executes the task to completion**, tumbling through all steps. This is the main task execution function.

**How it works**:
1. Executes steps backward (from end to start)
2. Each step can add more steps
3. Continues until no steps remain

**Example**:
```c
Task *server = WebServer_Make(3000, 0, NULL);
Task_Tumble(server);  // Runs web server (infinite loop)
```

**Performance note**: Uses backward iteration to allow steps to add new steps without interfering with iteration.

---

```c
status Task_AddStep(Task *tsk, StepFunc func, void *arg, void *source, word flags);
```

Adds a step to the task.

**Parameters**:
- `func`: Step function to execute
- `arg`: Argument passed to step function
- `source`: Source context
- `flags`: Step flags (STEP_ONCE, etc.)

**Example**:
```c
status ProcessRequest(Step *st, Task *tsk) {
    HttpCtx *ctx = st->source;
    // Process HTTP request...
    return READY;
}

Task_AddStep(tsk, ProcessRequest, NULL, http_ctx, 0);
```

---

```c
status Task_AddDataStep(Task *tsk, StepFunc func, void *arg, void *data, void *source, word flags);
```

Adds a step with both `arg` and `data` (for complex scenarios).

---

```c
status Task_Free(Step *st, Task *tsk);
```

Frees the task (called from a step to terminate execution).

**Example**:
```c
status FinalizeStep(Step *st, Task *tsk) {
    // Cleanup...
    return Task_Free(st, tsk);  // End task
}
```

---

```c
status Task_ResetChain(Task *tsk);
```

Resets the task's step chain (clears all steps).

---

```c
status Task_Init(MemCh *m);
```

Initializes the task system (called during startup).

---

### Step - Task Execution Unit

**Header**: [src/ext/include/navigate/step.h](../../../src/ext/include/navigate/step.h)

A `Step` is a single unit of work within a Task. Steps are functions that perform incremental operations.

**Structure**:
```c
typedef struct step {
    Type type;
    StepFunc func;      // Function to execute
    void *arg;          // Argument to function
    void *source;       // Source context
    word flags;         // Step flags
} Step;

typedef status (*StepFunc)(Step *st, Task *tsk);
```

#### Core Functions

```c
Step *Step_Make(MemCh *m, StepFunc func, void *arg, void *source, word flags);
```

Creates a step.

**Example**:
```c
Step *step = Step_Make(m, my_step_func, my_arg, source, 0);
```

---

```c
status Step_Add(MemCh *m, struct task *tsk, StepFunc func, void *arg, void *source);
```

Creates and adds a step to a task.

**Example**:
```c
Step_Add(m, tsk, handle_accept, NULL, server_ctx);
```

---

```c
status Step_Delay(Step *st, struct task *tsk);
```

Requests a delay (pauses task execution for this cycle).

**Example**:
```c
status WaitForData(Step *st, Task *tsk) {
    if (!data_ready()) {
        return Step_Delay(st, tsk);  // Come back later
    }
    // Process data...
    return READY;
}
```

---

### Queue - Priority Queue with Criteria

**Header**: [src/ext/include/navigate/queue.h](../../../src/ext/include/navigate/queue.h)

`Queue` manages a collection of items with filtering criteria and priority. Used for scheduling tasks based on time, file descriptor readiness, or custom conditions.

**See also**: [Queue Complete Guide](../core-concepts/navigate/queue-complete.md)

**Structure**:
```c
typedef struct queue {
    Type type;
    Span *items;          // Queue items
    Span *criteria;       // Filtering criteria
    i32 idx;              // Current item index
    i64 tick;             // Current tick count
} Queue;
```

#### Core Functions

```c
Queue *Queue_Make(MemCh *m);
```

Creates a queue.

**Example**:
```c
Queue *q = Queue_Make(m);
```

---

```c
status Queue_Reset(Queue *q);
```

Resets queue to start.

---

```c
i32 Queue_GetIdx(Queue *q);
```

Gets the current item index.

---

```c
void *Queue_Get(Queue *q);
```

Gets the current item.

**Example**:
```c
void *item = Queue_Get(q);
```

---

```c
status Queue_Set(Queue *q, i32 idx, void *a);
```

Sets an item at the specified index.

---

```c
i32 Queue_Add(Queue *q, void *a);
```

Adds an item to the queue.

**Example**:
```c
Queue_Add(q, task1);
Queue_Add(q, task2);
```

---

```c
status Queue_Remove(Queue *q, i32 idx);
```

Removes an item.

**Example**:
```c
Queue_Remove(q, 0);  // Remove first item
```

---

```c
status Queue_Next(Queue *q);
```

Advances to the next item that satisfies all criteria.

**Example**:
```c
while (Queue_Next(q) == READY) {
    void *item = Queue_Get(q);
    // Process item
}
```

---

#### Queue Criteria System

```c
i32 Queue_AddHandler(Queue *q, struct queue_crit *crit);
```

Adds a filtering criterion to the queue.

**Example**:
```c
QueueCrit *time_crit = QueueCrit_Make(m, time_filter_func, 0);
Queue_AddHandler(q, time_crit);
```

---

```c
status Queue_SetCriteria(Queue *q, i32 critIdx, i32 idx, util *value);
util Queue_GetCriteria(Queue *q, i32 critIdx, i32 idx);
```

Sets/gets criterion values for an item.

**Example**:
```c
// Set timeout for item 0
util timeout = {.i64 = 5000};  // 5 seconds
Queue_SetCriteria(q, crit_idx, 0, &timeout);
```

---

### Queue Criteria - Filtering Functions

**Header**: [src/ext/include/navigate/queue_crit.h](../../../src/ext/include/navigate/queue_crit.h)

```c
QueueCrit *QueueCrit_Make(MemCh *m, QueueFunc func, word flags);
```

Creates a queue criterion.

**Example**:
```c
gobits TimeoutFilter(QueueCrit *crit, util *values) {
    i64 now = current_time();
    i64 timeout = values[0].i64;
    return (now >= timeout) ? 1 : 0;
}

QueueCrit *crit = QueueCrit_Make(m, TimeoutFilter, 0);
```

---

```c
status QueueCrit_SetTick(QueueCrit *crit, Queue *q);
```

Sets the criterion's tick (for time-based filtering).

---

#### Time-Based Criteria

**Header**: [src/ext/include/navigate/queue_crit_time.h](../../../src/ext/include/navigate/queue_crit_time.h)

Criteria for time-based scheduling.

---

#### File Descriptor Criteria

**Header**: [src/ext/include/navigate/queue_crit_fds.h](../../../src/ext/include/navigate/queue_crit_fds.h)

Criteria for I/O readiness (polls file descriptors).

---

### Hierarchical Data Structures

Navigate includes sophisticated data structures for organizing hierarchical and relational data.

### Node - Tree Node

**Header**: [src/ext/include/navigate/node.h](../../../src/ext/include/navigate/node.h)

```c
Node *Node_Make(MemCh *m, word flags, Node *parent);
```

Creates a tree node with optional parent.

**Example**:
```c
Node *root = Node_Make(m, 0, NULL);
Node *child = Node_Make(m, 0, root);
```

---

### Mess - Hierarchical Message Structure

**Header**: [src/ext/include/navigate/mess.h](../../../src/ext/include/navigate/mess.h)

`Mess` (Message Tree) represents hierarchical structured data, typically created by parsers. It's a tree of Nodes with attributes.

**See also**: [Mess Complete Guide](../core-concepts/navigate/mess-complete.md)

#### Core Functions

```c
Mess *Mess_Make(MemCh *m);
```

Creates a message tree.

**Example**:
```c
Mess *mess = Mess_Make(m);
```

---

```c
status Mess_Tokenize(Mess *mess, Tokenize *tk, StrVec *v);
```

Tokenizes a StrVec into the message tree structure.

**Example**:
```c
Tokenize *tk = Tokenize_Make(m, separators);
Mess_Tokenize(mess, tk, input);
```

---

```c
status Mess_Append(Mess *set, Node *node, void *a);
```

Appends a value to a node.

**Example**:
```c
Node *node = /* ... */;
Mess_Append(mess, node, value);
```

---

```c
status Mess_AddAtt(Mess *set, Node *node, void *key, void *value);
```

Adds an attribute to a node.

**Example**:
```c
Mess_AddAtt(mess, node,
            Str_FromCstr(m, "type", 0),
            Str_FromCstr(m, "header", 0));
```

---

```c
status Mess_GetOrSet(Mess *mess, Node *node, void *a, Tokenize *tk);
```

Gets or creates a node at the specified path.

---

```c
status Mess_Compare(MemCh *m, Mess *a, Mess *b);
```

Compares two message trees.

**Example**:
```c
if (Mess_Compare(m, mess1, mess2) == READY) {
    // Trees are identical
}
```

---

### Relation - Relational Data

**Header**: [src/ext/include/navigate/relation.h](../../../src/ext/include/navigate/relation.h)

`Relation` represents tabular data with rows and columns, stored flat for excellent cache performance.

**See also**: [Relation Complete Guide](../core-concepts/navigate/relation-complete.md)

**Structure**:
```c
typedef struct relation {
    Type type;
    i16 stride;       // Number of columns
    Span *data;       // Flat data array
    void **headers;   // Column headers
    i16 row;          // Current row
    i16 col;          // Current column
} Relation;
```

#### Core Functions

```c
Relation *Relation_Make(MemCh *m, i16 stride, void **headers);
```

Creates a relation with the specified number of columns.

**Example**:
```c
void *headers[] = {
    Str_FromCstr(m, "name", 0),
    Str_FromCstr(m, "age", 0),
    NULL
};
Relation *rel = Relation_Make(m, 2, headers);
```

---

```c
status Relation_HeadFromValues(Relation *rel);
```

Sets headers from the first row of values.

---

```c
status Relation_Start(Relation *rel);
```

Resets to the first row.

---

```c
status Relation_Next(Relation *rel);
```

Advances to the next row.

**Example**:
```c
Relation_Start(rel);
while (Relation_Next(rel) == READY) {
    // Process row
}
```

---

```c
status Relation_SetValue(Relation *rel, i16 row, i16 col, void *value);
```

Sets a specific cell value.

**Example**:
```c
Relation_SetValue(rel, 0, 0, Str_FromCstr(m, "Alice", 0));
Relation_SetValue(rel, 0, 1, I32_Wrapped(m, 30));
```

---

```c
status Relation_AddValue(Relation *rel, void *value);
```

Adds a value at the current position (auto-advances column/row).

**Example**:
```c
Relation_AddValue(rel, Str_FromCstr(m, "Alice", 0));
Relation_AddValue(rel, I32_Wrapped(m, 30));
// Automatically moves to next row
```

---

### Frame - Nested Context Frame

**Header**: [src/ext/include/navigate/frame.h](../../../src/ext/include/navigate/frame.h)

`Frame` represents a snapshot of iteration context for nested iteration (e.g., iterating templates within templates).

**See also**: [Frame Complete Guide](../core-concepts/navigate/frame-complete.md)

```c
Frame *Frame_Make(MemCh *m, i32 originIdx, void *originKey, void *value, Span *p);
```

Creates a frame capturing current iteration state.

**Example**:
```c
Frame *frame = Frame_Make(m, iter->idx, key, value, data_span);
// frame preserves current position
```

---

### Comparison Utilities

**Header**: [src/ext/include/navigate/compare.h](../../../src/ext/include/navigate/compare.h)

```c
Comp *Comp_Make(MemCh *m, void *a, void *b);
CompResult *CompResult_Make(MemCh *m, void *a, void *b);
status Compare(Comp *comp);
```

Generic comparison utilities for structured data.

---

### Nested Selection Iterator

**Header**: [src/ext/include/navigate/nestsel.h](../../../src/ext/include/navigate/nestsel.h)

```c
status NestSel_Init(Iter *it, Inst *inst, Span *coords);
status NestSel_Next(Iter *it);
void *NestSel_Get(Iter *it);
```

Iterates through nested instance structures using coordinate paths.

---



---

**Part 1 of 2** | [Part 2 →](ext-part2)
