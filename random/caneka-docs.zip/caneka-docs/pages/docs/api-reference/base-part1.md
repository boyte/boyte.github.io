# Base Module API Reference - Part 1

**Part 1 of 4** | [Part 2 →](base-part2)

---

## Architecture Overview

The Base layer implements a three-tier memory model that fundamentally shapes how all other systems work:

**MemBook → MemChapter → MemPage**

- **MemBook**: Top-level memory pool (virtual memory segments)
- **MemChapter (MemCh)**: Allocation context with automatic cleanup
- **MemPage**: Physical slab allocator (4KB-256KB pages)

This hierarchy means you almost never call `malloc()` or `free()` directly. Instead, you create a `MemCh` context, allocate within it, and free the entire context at once. This pattern eliminates most memory leaks, simplifies error handling, and provides excellent cache locality.

**Key Design Principles**:

1. **Context-based allocation**: MemCh ties memory lifetime to logical operations
2. **Sparse arrays everywhere**: Span is the fundamental collection type
3. **String vectors over char***: StrVec handles large strings efficiently
4. **Type-aware collections**: Table and Lookup use runtime type information
5. **Buffered I/O abstraction**: Buff unifies files, sockets, and memory


## Memory Management

The memory system is the heart of Caneka. Understanding it is essential to using any other part of the system effectively.

### MemBook - Top-Level Memory Pool

**Header**: [src/base/include/mem/mem_book.h](../../../src/base/include/mem/mem_book.h)

MemBook represents the highest level of memory organization. Each book manages up to 256 virtual memory pages (64MB total at maximum page size). Books are chained together to support arbitrarily large allocations, and they track global statistics about memory usage.

You rarely interact with MemBook directly—it's managed automatically when you create MemCh contexts. However, understanding books helps you reason about memory isolation and debug memory issues.

#### Core Functions

```c
MemBook *MemBook_Make(MemBook *prev);
```

Creates a new MemBook. If `prev` is NULL, creates a standalone book. If `prev` is provided, chains the new book to it, allowing allocation to span multiple books.

**When to use**: Automatically called by the system. You only call this directly if implementing custom memory pools.

**Example**:
```c
MemBook *book = MemBook_Make(NULL);  // Create standalone book
```

---

```c
MemBook *MemBook_Get(void *addr);
```

Returns the MemBook that contains the given address. This is how Caneka implements efficient ownership tracking—every allocated pointer can be traced back to its book.

**Implementation note**: Uses bit manipulation on the address to index into the global book array. O(1) operation.

**Example**:
```c
void *ptr = MemCh_Alloc(m, 1024);
MemBook *book = MemBook_Get(ptr);  // Get book containing ptr
```

---

```c
MemBook *MemBook_Check(void *addr);
```

Like `MemBook_Get()`, but returns NULL if the address doesn't belong to any book instead of failing. Useful for defensive checks.

**Example**:
```c
if (MemBook_Check(ptr)) {
    // ptr is valid Caneka memory
} else {
    // ptr might be stack memory, static data, or invalid
}
```

---

```c
i32 MemBook_GetBookIdx(void *addr);
i32 MemBook_GetPageIdx(void *addr);
```

Extract book index and page index from any pointer. These are used internally for debugging and statistics but can be useful for logging.

**Example**:
```c
i32 book_idx = MemBook_GetBookIdx(ptr);
i32 page_idx = MemBook_GetPageIdx(ptr);
printf("Allocated in book %d, page %d\n", book_idx, page_idx);
```

---

```c
status MemBook_FreePage(MemCh *m, MemPage *pg);
```

Frees a specific page back to the book. Normally you don't call this—`MemCh_Free()` handles it. But if you're manually managing pages (advanced usage), this releases the page.

**Returns**: `READY` on success, `ERR` if page is invalid or still in use.

---

```c
status MemBook_WipePages(void *addr);
```

Frees ALL pages associated with the book containing `addr`. This is a nuclear option—it releases everything allocated from that book, regardless of MemCh contexts.

**When to use**: Application shutdown, catastrophic error recovery, or when you've carefully ensured no references remain.

**Warning**: Does not call destructors or cleanup handlers. Any file descriptors, sockets, or external resources must be freed first.

**Example**:
```c
// At application shutdown
MemBook_WipePages(main_book);  // Release all memory at once
```

---

```c
void *MemBook_GetPage(void *addr);
```

Returns the MemPage containing the given address. Useful for introspection and debugging.

**Example**:
```c
MemPage *page = MemBook_GetPage(ptr);
printf("Page has %ld bytes available\n", MemPage_Available(page));
```

---

```c
status MemBook_GetStats(void *addr, MemBookStats *st);
```

Retrieves detailed statistics about the book containing `addr`:
- Total pages allocated
- Bytes in use vs available
- Number of active chapters
- Fragmentation metrics

**Example**:
```c
MemBookStats stats;
MemBook_GetStats(some_ptr, &stats);
printf("Memory usage: %ld / %ld bytes\n", stats.used, stats.total);
```

---

### MemChapter (MemCh) - Allocation Context

**Header**: [src/base/include/mem/mem_chapter.h](../../../src/base/include/mem/mem_chapter.h)

MemChapter is where you actually allocate memory. A chapter represents a logical allocation scope—often corresponding to handling a single HTTP request, parsing a single file, or executing a single task. When you free a chapter, all allocations made within it are freed automatically.

This is the most important memory type in Caneka. Almost every function takes `MemCh *m` as its first parameter.

**See also**: [MemChapter Complete Guide](../core-concepts/memory/memchapter.md) for architectural details and usage patterns.

#### Core Functions

```c
MemCh *MemCh_Make();
```

Creates a new memory chapter with its own dedicated MemPage. This is how you start any significant operation in Caneka.

**Example**:
```c
MemCh *m = MemCh_Make();
// ... do work, allocate memory ...
MemCh_Free(m);  // Frees everything at once
```

**Pattern**: Create chapter, do work, free chapter. This pattern appears everywhere in Caneka code.

---

```c
MemCh *MemCh_OnPage();
```

Creates a chapter on an existing page from the global page pool. This is more efficient than `MemCh_Make()` when you need many short-lived chapters, because it reuses pages.

**When to use**: Parsing individual HTTP headers, processing queue items, temporary calculations.

**Example**:
```c
MemCh *m = MemCh_OnPage();  // Reuse pooled page
Str *result = ParseHeader(m, input);
MemCh_Free(m);  // Page returns to pool
```

---

```c
status MemCh_Setup(MemCh *m, MemPage *pg);
```

Manually initializes a chapter with a specific page. Advanced usage—normally you use `MemCh_Make()` or `MemCh_OnPage()`.

**When to use**: Custom memory pools, testing, or when you need precise control over page allocation.

---

```c
void *MemCh_Alloc(MemCh *m, size_t sz);
```

**This is the workhorse allocation function.** Allocates `sz` bytes from the chapter's current page. If the page is full, automatically allocates a new page and continues.

**Returns**: Pointer to allocated memory, or NULL if allocation fails.

**Memory is always zeroed**: Unlike `malloc()`, returned memory is guaranteed to be zero-initialized.

**Example**:
```c
MyStruct *s = MemCh_Alloc(m, sizeof(MyStruct));
// s->field is guaranteed to be 0/NULL
```

**Performance**: Typically just bumps a pointer (O(1)). Page allocation is O(1) too—just pops from the free list.

---

```c
void *MemCh_AllocOf(MemCh *m, size_t sz, cls typeOf);
```

Type-aware allocation. Like `MemCh_Alloc()`, but also records the type of the allocated object. This enables runtime type checking, generic serialization, and introspection.

**Parameters**:
- `m`: Memory chapter
- `sz`: Size in bytes (usually `sizeof(T)`)
- `typeOf`: Type class (e.g., `CLS(MyStruct)`)

**Returns**: Pointer cast to the correct type.

**Example**:
```c
MyStruct *s = MemCh_AllocOf(m, sizeof(MyStruct), CLS(MyStruct));
// Now s can be introspected: Get_Type(s) returns CLS(MyStruct)
```

**When to use**: When you need runtime type information (serialization, reflection, generic containers).

---

```c
void *MemCh_Realloc(MemCh *m, size_t s, void *orig, size_t origsize);
```

Reallocates memory, expanding or shrinking the allocation. Tries to resize in-place if possible; otherwise allocates new memory and copies.

**Parameters**:
- `m`: Memory chapter
- `s`: New size in bytes
- `orig`: Original pointer
- `origsize`: Original size in bytes

**Returns**: Pointer to resized memory (may be same as `orig` or new allocation).

**Example**:
```c
byte *buffer = MemCh_Alloc(m, 1024);
// ... need more space ...
buffer = MemCh_Realloc(m, 2048, buffer, 1024);
```

**Note**: Unlike standard `realloc()`, you must provide the original size. This enables more efficient reallocation.

---

```c
status MemCh_Free(MemCh *m);
```

**Frees the entire chapter and all memory allocated from it.** This is the primary way you release memory in Caneka. All strings, structures, collections—everything allocated from `m` becomes invalid.

**Returns**: `READY` on success.

**Example**:
```c
MemCh *m = MemCh_Make();
Str *s1 = Str_Make(m, 1024);
Str *s2 = Str_Make(m, 1024);
Table *tbl = Table_Make(m);
MemCh_Free(m);  // s1, s2, tbl all freed at once
```

**Performance**: O(1) if only one page allocated. O(pages) if multiple pages, but still very fast—just updates free lists.

---

```c
status MemCh_FreeTemp(MemCh *m);
```

Frees temporary allocations from the chapter while keeping the chapter itself alive. This is useful for operations that allocate intermediate results but want to keep the chapter for the final result.

**Implementation**: Maintains a watermark and frees everything allocated after that watermark.

**Example**:
```c
MemCh *m = MemCh_Make();
Str *result = Str_Make(m, 1024);  // Keep this

// Mark watermark here
Str *temp1 = Str_Make(m, 256);    // Temporary
Str *temp2 = Str_Make(m, 256);    // Temporary

MemCh_FreeTemp(m);  // temp1, temp2 freed; result kept
```

---

#### Memory Metrics

```c
i64 MemCount(i16 level);
```

Returns the number of allocations at a specific page level. Page levels range from 0 (4KB) to 6 (256KB).

**Example**:
```c
i64 small_pages = MemCount(0);  // 4KB pages
i64 large_pages = MemCount(6);  // 256KB pages
```

---

```c
i64 MemChapterCount();
i64 MemAvailableChapterCount();
```

Returns the total number of chapters allocated and the number available for reuse. Useful for monitoring memory health.

**Example**:
```c
printf("Active chapters: %ld, Available: %ld\n",
       MemChapterCount(), MemAvailableChapterCount());
```

---

### MemPage - Page-Level Slab Allocator

**Header**: [src/base/include/mem/mem_page.h](../../../src/base/include/mem/mem_page.h)

MemPage is the physical memory allocator. Each page is a fixed-size slab (4KB to 256KB) that serves allocations via bump-pointer allocation. You rarely manipulate pages directly—MemCh handles them—but understanding pages helps you reason about performance.

#### Core Functions

```c
MemPage *MemPage_Make(struct mem_ctx *m, i16 level);
```

Allocates a new page at the specified level:
- Level 0: 4KB (default for most operations)
- Level 1: 8KB
- Level 2: 16KB
- Level 3: 32KB
- Level 4: 64KB
- Level 5: 128KB
- Level 6: 256KB

**When to use**: Automatically called by MemCh when more space is needed. You call this directly only when implementing custom allocators.

---

```c
MemPage *MemPage_Attach(struct mem_ctx *m, i16 level);
```

Attaches an existing page from the free list to a memory context, or creates a new one if none available.

---

```c
void *MemPage_Alloc(MemPage *pg, word sz);
```

Allocates `sz` bytes from the page via bump-pointer allocation. Returns NULL if insufficient space.

**Example**:
```c
MemPage *pg = MemPage_Make(m, 0);  // 4KB page
void *p1 = MemPage_Alloc(pg, 100);  // Allocate 100 bytes
void *p2 = MemPage_Alloc(pg, 200);  // Allocate 200 more
```

---

#### Page Macros

```c
MemPage_Available(pg)
MemPage_Taken(pg)
```

Return bytes available and bytes used in the page, respectively.

**Example**:
```c
printf("Page: %ld used, %ld available\n",
       MemPage_Taken(pg), MemPage_Available(pg));
```

---

### Span - Sparse Multi-Dimensional Array

**Header**: [src/base/include/mem/span.h](../../../src/base/include/mem/span.h)

Span is Caneka's fundamental collection type—a sparse, dynamically-sized array that can have up to 13 dimensions. It's used everywhere: as the backing store for hash tables, as dynamic arrays, as multi-dimensional matrices, and as the foundation for iterators.

Unlike traditional arrays, Span doesn't allocate space for unused indices. If you set index 0 and index 1000000, it only allocates space for those two values—not the million in between.

**See also**:
- [Span Overview](../core-concepts/memory/span.md)
- [Span Complete Guide](../core-concepts/memory/span-complete.md)

#### Core Functions

```c
Span *Span_Make(struct mem_ctx *m);
```

Creates a new empty Span.

**Example**:
```c
MemCh *m = MemCh_Make();
Span *arr = Span_Make(m);
```

---

```c
status Span_Setup(Span *p);
```

Initializes a stack-allocated Span. Use this when you want a Span on the stack instead of heap-allocated.

**Example**:
```c
Span stack_span;
Span_Setup(&stack_span);
Span_Set(&stack_span, 0, value);
```

---

```c
status Span_Set(Span *p, i32 idx, void *t);
```

Sets the value at index `idx` to `t`. Automatically expands the span if needed. If a value already exists at that index, it's replaced.

**Example**:
```c
Span_Set(arr, 0, first_item);
Span_Set(arr, 100, second_item);  // Sparse—no wasted space
```

---

```c
void *Span_Get(Span *p, i32 idx);
```

Retrieves the value at index `idx`. Returns NULL if no value has been set at that index.

**Example**:
```c
void *item = Span_Get(arr, 5);
if (item) {
    // Index 5 has a value
} else {
    // Index 5 is unset
}
```

---

```c
status Span_Remove(Span *p, i32 idx);
```

Removes the value at index `idx`, creating a gap. The span remains the same size—this just marks the index as empty.

**Example**:
```c
Span_Set(arr, 10, value);
Span_Remove(arr, 10);  // Now index 10 is empty again
```

---

```c
boolean Span_IsBlank(Span *p);
```

Returns `TRUE` if the span is empty (no values set), `FALSE` otherwise.

**Example**:
```c
if (Span_IsBlank(arr)) {
    printf("Array is empty\n");
}
```

---

### Iter - Span Iterator

**Header**: [src/base/include/mem/iter.h](../../../src/base/include/mem/iter.h)

Iter provides cursor-based iteration over Span structures, with sophisticated gap-handling and stack semantics. It's much more than a simple iterator—it supports pushing/popping, inserting, removing, and even multi-dimensional navigation.

**See also**:
- [Iter Overview](../core-concepts/memory/iter.md)
- [Iter Complete Guide](../core-concepts/memory/iter-complete.md)

#### Core Functions

```c
Iter *Iter_Make(struct mem_ctx *m, Span *p);
```

Creates a new iterator for the given Span.

**Example**:
```c
Span *arr = Span_Make(m);
Iter *it = Iter_Make(m, arr);
```

---

```c
void Iter_Init(Iter *it, Span *p);
```

Initializes a stack-allocated iterator.

**Example**:
```c
Iter stack_iter;
Iter_Init(&stack_iter, arr);
```

---

```c
void Iter_Setup(Iter *it, Span *p, status op, i32 idx);
```

Sets up iterator with specific operation and starting index. `op` can be:
- `ITER_SET`: Position at index
- `ITER_FIRST`: Position at first element
- `ITER_END`: Position after last element

**Example**:
```c
Iter_Setup(it, arr, ITER_FIRST, 0);  // Start at beginning
```

---

```c
status Iter_Next(Iter *it);
```

Advances to the next element, skipping gaps. Returns `READY` if successful, `ITER_STOP` if reached end.

**Example**:
```c
Iter *it = Iter_Make(m, arr);
Iter_First(it);
while (Iter_Next(it) == READY) {
    void *item = Iter_Get(it);
    // Process item
}
```

---

```c
status Iter_Prev(Iter *it);
```

Moves to the previous element, skipping gaps.

**Example**:
```c
Iter_End(it);
while (Iter_Prev(it) == READY) {
    void *item = Iter_Get(it);
    // Process in reverse
}
```

---

```c
status Iter_PrevRemove(Iter *it);
```

Moves to the previous element AND removes the current element. Efficient for backward iteration with deletion.

**Example**:
```c
// Remove all items in reverse order
Iter_End(it);
while (Iter_PrevRemove(it) == READY) {
    // Current item was removed
}
```

---

```c
status Iter_Pop(Iter *it);
```

Removes the current element and stays at the same position (which now points to the next element). Like stack pop.

**Example**:
```c
Iter_First(it);
Iter_Pop(it);  // Remove first element
void *now_first = Iter_Get(it);  // Get new first
```

---

```c
status Iter_Reset(Iter *it);
```

Resets iterator to the initial state (before first element).

---

```c
status Iter_First(Iter *it);
```

Positions at the first element. Returns `READY` if span has elements, `ITER_STOP` if empty.

**Example**:
```c
if (Iter_First(it) == READY) {
    void *first = Iter_Get(it);
}
```

---

```c
status Iter_GoToIdx(Iter *it, i32 idx);
```

Positions iterator at the specified index, even if it's a gap. Use `Iter_Get()` to check if the index contains a value.

**Example**:
```c
Iter_GoToIdx(it, 100);
void *val = Iter_Get(it);
if (val) {
    // Index 100 has a value
}
```

---

```c
status Iter_Push(Iter *it, void *value);
```

Pushes value onto the end of the span (stack semantics). Increments span size.

**Example**:
```c
Iter_Push(it, item1);
Iter_Push(it, item2);
// Span now has two items
```

---

```c
status Iter_Set(Iter *it, void *value);
```

Sets the value at the current iterator position.

**Example**:
```c
Iter_First(it);
Iter_Set(it, new_value);  // Replace first element
```

---

```c
status Iter_Add(Iter *it, void *value);
```

Adds value at the current position without overwriting. If position is occupied, shifts existing values.

---

```c
status Iter_Insert(Iter *it, i32 idx, void *value);
```

Inserts value at the specified index, shifting subsequent elements.

**Example**:
```c
Iter_Insert(it, 0, first);   // Insert at beginning
Iter_Insert(it, 10, middle); // Insert at index 10
```

---

```c
status Iter_Remove(Iter *it);
```

Removes the element at the current position.

**Example**:
```c
Iter_First(it);
while (Iter_Next(it) == READY) {
    void *item = Iter_Get(it);
    if (should_remove(item)) {
        Iter_Remove(it);
    }
}
```

---

```c
void *Iter_Get(Iter *it);
```

Gets the value at the current iterator position. Returns NULL if position is empty or iterator is not positioned.

**Example**:
```c
Iter_First(it);
void *first = Iter_Get(it);
```

---

```c
void *Iter_Current(Iter *it);
```

Alias for `Iter_Get()`.

---

```c
void *Iter_GetByIdx(Iter *it, i32 idx);
```

Gets value at the specified index without moving the iterator.

**Example**:
```c
void *item = Iter_GetByIdx(it, 42);  // Get index 42
// Iterator position unchanged
```

---

```c
status Iter_SetByIdx(Iter *it, i32 idx, void *value);
```

Sets value at the specified index without moving the iterator.

**Example**:
```c
Iter_SetByIdx(it, 10, value);  // Set index 10
// Iterator position unchanged
```

---


## Type System & Error Handling

Caneka implements a comprehensive runtime type system with reflection, error handling, and loop guards. This system enables type-safe collections, generic serialization, and robust error propagation.

### Error System

**Header**: [src/base/include/types/error.h](../../../src/base/include/types/error.h)

The error system provides structured error reporting with context propagation. Unlike `errno` or simple error codes, Caneka errors carry full context: function name, file, line number, and formatted messages with type-aware placeholders.

**See also**: [Error Handling Complete Guide](../core-concepts/error-handling-complete.md)

#### Core Functions

```c
status Error_Init(struct mem_ctx *m);
```

Initializes the error system for a memory chapter. Called automatically by most initialization functions.

---

```c
void Error(struct mem_ctx *m, char *func, char *file, int line,
           char *fmt, void *args[]);
```

Reports an error with full context. This is the primary error logging function.

**Parameters**:
- `m`: Memory chapter (errors are logged to the chapter)
- `func`: Function name (use `__func__`)
- `file`: Source file (use `__FILE__`)
- `line`: Line number (use `__LINE__`)
- `fmt`: Format string with placeholders (`$`, `@`, `&`, `^`)
- `args`: NULL-terminated array of arguments

**Format placeholders**:
- `$`: String (Str* or char*)
- `@`: Integer (I32_Wrapped() or I64_Wrapped())
- `&`: Type name (CLS_Wrapped())
- `^`: Pointer address

**Example**:
```c
if (value < 0) {
    void *args[] = {
        I32_Wrapped(m, value),
        NULL
    };
    Error(m, __func__, __FILE__, __LINE__,
          "Invalid value: @", args);
    return ERR;
}
```

**Common pattern**: Use the `ERROR` macro for convenience:
```c
#define ERROR(m, fmt, ...) \
    Error(m, __func__, __FILE__, __LINE__, fmt, ##__VA_ARGS__)
```

---

```c
void Fatal(char *func, char *file, int line, char *fmt, void *args[]);
```

Reports a fatal error and terminates the program. Use for unrecoverable errors like memory corruption or violated invariants.

**Example**:
```c
if (!critical_resource) {
    void *args[] = { NULL };
    Fatal(__func__, __FILE__, __LINE__,
          "Critical resource missing", args);
}
```

---

```c
boolean IsZeroed(struct mem_ctx *m, byte *b, size_t sz,
                 char *func, char *file, int line);
```

Verifies that a memory region is zero-initialized. Returns `TRUE` if zeroed, logs error and returns `FALSE` otherwise.

**When to use**: Validating that structures are properly initialized, especially when using stack-allocated structures.

**Example**:
```c
MyStruct s;
memset(&s, 0, sizeof(s));
if (!IsZeroed(m, (byte*)&s, sizeof(s), __func__, __FILE__, __LINE__)) {
    // Structure not zeroed—error logged
}
```

---

```c
void ErrNoError(struct buff *bf);
```

Outputs a "no error" message to the buffer. Used by error handlers to indicate successful operations.

**Example**:
```c
if (m->error) {
    Buff_Add(output, m->error->message);
} else {
    ErrNoError(output);  // "No error"
}
```

---

### Guard System - Loop Protection

**Header**: [src/base/include/types/guard.h](../../../src/base/include/types/guard.h)

The guard system prevents infinite loops by tracking iteration counts and failing after a configurable limit. This is essential for robust server applications that can't afford to hang on malformed input.

**See also**: [Guard Mechanism Complete Guide](../core-concepts/guard-mechanism-complete.md)

#### Core Functions

```c
status Guard_Reset(i16 *g);
```

Resets a guard counter to 0. Use this when starting a new operation that has its own iteration limit.

**Example**:
```c
i16 guard = 0;
Guard_Reset(&guard);
```

---

```c
status Guard_Incr(struct mem_ctx *m, i16 *g, i16 max,
                  char *func, char *file, int line);
```

Increments the guard counter and checks if it exceeds `max`. Returns `READY` if within limit, `ERR` if exceeded (and logs error).

**Parameters**:
- `m`: Memory chapter for error logging
- `g`: Guard counter variable
- `max`: Maximum allowed iterations
- `func`, `file`, `line`: Context for error reporting

**Example**:
```c
i16 guard = 0;
while (has_more_work()) {
    if (Guard_Incr(m, &guard, 1000, __func__, __FILE__, __LINE__) != READY) {
        // Exceeded 1000 iterations—error logged
        return ERR;
    }
    do_work();
}
```

**Common pattern**: Use the `GUARD` macro:
```c
#define GUARD(m, g, max) \
    Guard_Incr(m, g, max, __func__, __FILE__, __LINE__)

// Usage:
while (condition) {
    if (GUARD(m, &guard, 1000) != READY) return ERR;
    // ... work ...
}
```

---

```c
boolean Guard(i16 *g, i16 max, char *func, char *file, int line);
```

Checks if guard counter has exceeded the limit without incrementing. Returns `TRUE` if within limit, `FALSE` if exceeded.

**Example**:
```c
if (!Guard(&guard, 1000, __func__, __FILE__, __LINE__)) {
    // Exceeded limit
    return ERR;
}
```

---

### Type System Utilities

**Header**: [src/base/include/types/type.h](../../../src/base/include/types/type.h)

Runtime type system utilities for equality checking, truthiness, and type introspection.

**See also**: [Type System Complete Guide](../core-concepts/type-system-complete.md)

#### Core Functions

```c
boolean Equals(void *a, void *b);
```

Generic equality comparison. Uses runtime type information to dispatch to appropriate equality function (Str equals, Table equals, etc.).

**Example**:
```c
Str *s1 = Str_FromCstr(m, "hello");
Str *s2 = Str_FromCstr(m, "hello");
if (Equals(s1, s2)) {
    // Strings are equal
}
```

---

```c
boolean Caneka_Truthy(void *a);
```

Checks if a value is "truthy" in Caneka's type system:
- Integers: nonzero
- Strings: non-empty
- Pointers: non-NULL
- Collections: non-empty

**Example**:
```c
if (Caneka_Truthy(str)) {
    // String is non-empty
}
```

---

### Map System - Type-Indexed Property Access

**Header**: [src/base/include/types/map.h](../../../src/base/include/types/map.h)

The Map system provides structured property access to objects, mapping string keys to offsets in structures. This enables generic property access without code generation.

#### Core Functions

```c
Map *Map_Make(struct mem_ctx *m, i16 length, RangeType *atts,
              struct str **keys);
```

Creates a map from property keys to structure offsets. Used internally by the type system.

**Parameters**:
- `m`: Memory chapter
- `length`: Number of properties
- `atts`: Array of property types and offsets
- `keys`: Array of property names

---

```c
Map *Map_FromTable(struct mem_ctx *m, struct span *tbl, cls typeOf);
```

Creates a map from a Table, using type information to determine structure.

---

```c
status Maps_Init(struct mem_ctx *m);
```

Initializes the map system. Called during startup.

---

```c
struct span *Map_ToTable(struct mem_ctx *m, void *_a);
```

Converts a mapped object back to a Table representation.

**Example**:
```c
Table *tbl = Map_ToTable(m, obj);
// Access properties as table entries
```

---

```c
Map *Map_Get(cls typeOf);
```

Retrieves the registered map for a given type. Returns NULL if type has no map.

**Example**:
```c
Map *map = Map_Get(CLS(MyStruct));
if (map) {
    // Type has property map
}
```

---

```c
status Map_MakeTbl(struct mem_ctx *m, Map *map);
```

Populates the map's internal table structure.

---

```c
void *Map_FromOffset(struct mem_ctx *m, void *a, i16 offset, cls typeOf);
```

Retrieves a property value from an object at the specified offset.

**Parameters**:
- `m`: Memory chapter
- `a`: Object instance
- `offset`: Byte offset of property
- `typeOf`: Type of property

**Example**:
```c
// Get property at offset 16, expected to be a Str
Str *name = Map_FromOffset(m, obj, 16, CLS(Str));
```

---



---

**Part 1 of 4** | [Part 2 →](base-part2)
