# Ext Module API Reference - Part 2

[← Part 1](ext-part1) | **Part 2 of 2**

---

## Types Module (Seel/Inst)

**Headers**: [src/ext/include/types/](../../../src/ext/include/types/)

The Types module provides **runtime type registration** (Seel) and **typed property containers** (Inst). This enables generic property access, reflection, and schema-driven data structures.

**See also**: [Seel/Inst Complete Guide](../core-concepts/seel-inst-complete.md)

### Seel - Type Registry

**Header**: [src/ext/include/types/seel.h](../../../src/ext/include/types/seel.h)

Seel is the **property schema registry**. It maps type IDs to property definitions, enabling structured access to instance data.

**Global Lookups**:
```c
extern Lookup *SeelLookup;       // Type ID → Seel Table
extern Lookup *SeelOrdLookup;    // Type ID → Ordered Seel
extern Lookup *SeelNameLookup;   // Type ID → Type Name
extern Table *SeelByName;        // Type Name → Type ID
```

**Type Definition**:
```c
typedef cls seelType;
```

#### Core Functions

```c
status Seel_Init(MemCh *m);
```

Initializes the Seel system (called during startup).

---

```c
status Seel_Seel(MemCh *m, Table *seel, Str *name, cls typeOf);
```

Registers a property in a Seel table.

**Example**:
```c
Table *user_seel = Table_Make(m);
Seel_Seel(m, user_seel, Str_FromCstr(m, "name", 0), CLS(Str));
Seel_Seel(m, user_seel, Str_FromCstr(m, "age", 0), CLS(I32));
```

---

```c
i32 Seel_GetIdx(Table *seel, void *key);
```

Gets the index of a property in the Seel table.

**Example**:
```c
i32 name_idx = Seel_GetIdx(seel, Str_FromCstr(m, "name", 0));
```

---

```c
Span *Seel_OrdSeel(MemCh *m, seelType instOf);
```

Gets the ordered Seel for a type (properties in definition order).

---

```c
Table *Seel_GetSeel(MemCh *m, cls instType);
```

Gets the Seel table for a type.

**Example**:
```c
Table *seel = Seel_GetSeel(m, CLS(HttpCtx));
```

---

```c
i32 Seel_TypeByName(void *name);
```

Looks up a type ID by name.

**Example**:
```c
i32 type_id = Seel_TypeByName(Str_FromCstr(m, "User", 0));
```

---

### Inst - Typed Instance

**Header**: [src/ext/include/types/inst.h](../../../src/ext/include/types/inst.h)

`Inst` (Instance) is a **property container** backed by a Seel schema. It's a Span with runtime type information, allowing property access by name.

**Type Definition**:
```c
typedef Span Inst;  // Inst is a Span with type metadata
```

#### Core Functions

```c
Span *Inst_Make(MemCh *m, cls typeOf);
```

Creates an instance of the specified type.

**Example**:
```c
Inst *user = Inst_Make(m, CLS(User));
```

---

```c
Inst *asInst(MemCh *m, void *a);
```

Casts a value to Inst (validates type).

**Example**:
```c
Inst *inst = asInst(m, some_object);
```

---

#### Property Access

```c
void *Inst_Att(Inst *inst, void *key);
```

Gets an attribute (property) value by key.

**Example**:
```c
Str *name = Inst_Att(user, Str_FromCstr(m, "name", 0));
```

---

```c
Table *Inst_GetTblOfAtt(Inst *inst, void *key);
```

Gets a nested table attribute.

**Example**:
```c
Table *settings = Inst_GetTblOfAtt(user, Str_FromCstr(m, "settings", 0));
```

---

```c
status Inst_SetAtt(Inst *inst, void *key, void *value);
```

Sets an attribute value.

**Example**:
```c
Inst_SetAtt(user,
            Str_FromCstr(m, "name", 0),
            Str_FromCstr(m, "Alice", 0));
```

---

```c
void *Inst_GetChild(Inst *inst, void *key);
```

Gets a child instance.

**Example**:
```c
Inst *address = Inst_GetChild(user, Str_FromCstr(m, "address", 0));
```

---

#### Path-Based Access

```c
void *Inst_ByPath(Span *inst, StrVec *path, void *value, word op, Span *coords);
```

Generic path-based access (get, set, delete).

**Parameters**:
- `inst`: Instance
- `path`: Path segments (e.g., ["user", "settings", "theme"])
- `value`: Value to set (for SET operation)
- `op`: Operation (`SPAN_OP_GET`, `SPAN_OP_SET`, etc.)
- `coords`: Coordinate tracking (NULL if not needed)

**Example**:
```c
// Get nested value
StrVec *path = /* parse "user.settings.theme" */;
Str *theme = Inst_ByPath(inst, path, NULL, SPAN_OP_GET, NULL);

// Set nested value
Inst_ByPath(inst, path, new_theme, SPAN_OP_SET, NULL);
```

---

**Convenience Macros**:
```c
#define Inst_GetByPath(n, p) Inst_ByPath((n), (p), NULL, SPAN_OP_GET, NULL)
#define Inst_SetByPath(n, p, v) Inst_ByPath((n), (p), (v), SPAN_OP_SET, NULL)
```

**Example**:
```c
StrVec *path = Path_Make(m, Str_FromCstr(m, "user.name", 0), dot_sep);
Str *name = Inst_GetByPath(inst, path);
```

---

#### Introspection

```c
i32 Inst_Set(Span *inst, Table *seel, void *key, void *value);
```

Sets a property using a Seel table for validation.

---

```c
status Inst_ShowKeys(Buff *bf, Inst *inst, i32 indent);
```

Outputs all property keys to a buffer (debugging utility).

**Example**:
```c
Buff *bf = Buff_Make(m, 0);
Inst_ShowKeys(bf, user, 0);
// Outputs: "name\nage\nemail\n"
```

---

### Property System Functions

```c
void *Seel_Get(Span *inst, void *key);
status Seel_Set(Span *inst, void *key, void *value);
status Seel_SetKv(Span *inst, Str *prop, void *key, void *value);
```

Generic property get/set functions that work with any Seel-backed instance.

**Example**:
```c
Seel_Set(user, Str_FromCstr(m, "name", 0), Str_FromCstr(m, "Bob", 0));
Str *name = Seel_Get(user, Str_FromCstr(m, "name", 0));
```

---

### Fetcher - Dynamic Property Access

**Header**: [src/ext/include/types/fetcher.h](../../../src/ext/include/types/fetcher.h)

The Fetcher system provides **flexible, multi-mode property access**. Instead of just accessing properties by name, Fetchers support:
- Key-based access (`obj.key`)
- Attribute access (`obj.@attribute`)
- Index access (`arr[5]`)
- Method calls (`obj.method()`)
- Iteration (`for item in obj`)

**Structure**:
```c
typedef struct fetcher {
    Type type;
    union { Span *targets; } val;
    IterApi *api;
} Fetcher;
```

#### Core Functions

```c
Fetcher *Fetcher_Make(MemCh *m);
```

Creates a fetcher.

**Example**:
```c
Fetcher *fch = Fetcher_Make(m);
```

---

```c
void *Fetch(MemCh *m, Fetcher *fch, void *data, void *source);
```

Executes the fetcher to retrieve a value.

**Example**:
```c
void *result = Fetch(m, fetcher, instance, source);
```

---

```c
void *Fetch_FromPath(Fetcher *fch, void *data, void *source);
```

Fetches using a path (sequence of fetch targets).

**Example**:
```c
// Fetch user.settings.theme
void *theme = Fetch_FromPath(fetcher, root, source);
```

---

### FetchTarget - Property Lookup Definition

**Header**: [src/ext/include/types/fetch_target.h](../../../src/ext/include/types/fetch_target.h)

`FetchTarget` defines **how** to fetch a property. Multiple FetchTargets form a path.

#### Creation Functions

```c
FetchTarget *FetchTarget_Make(MemCh *m);
```

Creates an empty fetch target.

---

```c
FetchTarget *FetchTarget_MakeKey(MemCh *m, Str *key);
```

Creates a key-based fetch target (property access).

**Example**:
```c
FetchTarget *tg = FetchTarget_MakeKey(m, Str_FromCstr(m, "name", 0));
```

---

```c
FetchTarget *FetchTarget_MakeAtt(MemCh *m, Str *att);
```

Creates an attribute-based fetch target.

**Example**:
```c
FetchTarget *tg = FetchTarget_MakeAtt(m, Str_FromCstr(m, "id", 0));
```

---

```c
FetchTarget *FetchTarget_MakeFunc(MemCh *m, Str *key);
```

Creates a function call fetch target.

**Example**:
```c
FetchTarget *tg = FetchTarget_MakeFunc(m, Str_FromCstr(m, "toString", 0));
```

---

```c
FetchTarget *FetchTarget_MakeIdx(MemCh *m, i32 idx);
```

Creates an index-based fetch target (array access).

**Example**:
```c
FetchTarget *tg = FetchTarget_MakeIdx(m, 5);  // arr[5]
```

---

```c
FetchTarget *FetchTarget_MakeIter(MemCh *m);
```

Creates an iterator fetch target.

---

```c
FetchTarget *FetchTarget_MakeProp(MemCh *m, Str *method);
```

Creates a property method fetch target.

---

```c
FetchTarget *FetchTarget_MakeCommand(MemCh *m);
```

Creates a command fetch target.

---

#### Execution Functions

```c
status FetchTarget_Resolve(MemCh *m, FetchTarget *tg, cls typeOf);
```

Resolves the fetch target against a type.

---

```c
void *Fetch_Target(MemCh *m, FetchTarget *tg, void *value, void *source);
```

Executes a single fetch target.

**Example**:
```c
void *result = Fetch_Target(m, target, instance, source);
```

---

#### Convenience Functions

```c
void *Fetch_ByKey(MemCh *m, void *a, Str *key, void *source);
void *Fetch_ByAtt(MemCh *m, void *a, Str *att, void *source);
void *Fetch_Prop(MemCh *m, void *a, Str *method, void *source);
Iter *Fetch_Iter(MemCh *m, void *a, void *source);
```

Direct fetch functions for common operations.

**Example**:
```c
Str *name = Fetch_ByKey(m, user, Str_FromCstr(m, "name", 0), NULL);
```

---

### Iterator API

**Header**: [src/ext/include/types/iter_api.h](../../../src/ext/include/types/iter_api.h)

The Iterator API provides **pluggable iteration** over different data structures.

**Structure**:
```c
typedef struct inst_iter_api {
    Type type;
    IterFunc next;       // Next function
    IterFunc prev;       // Previous function
    IterGetFunc get;     // Get function
    Abstract *source;
} IterApi;

typedef status (*IterFunc)(Iter *it);
typedef void *(*IterGetFunc)(Iter *it);
```

#### Global Iterators

```c
extern IterApi *BaseIterApi;
```

Default iterator API for Span-based iteration.

---

#### Core Functions

```c
status IterApi_Init(MemCh *m);
```

Initializes the iterator API system.

---

```c
IterApi *IterApi_Make(MemCh *m, IterFunc next, IterFunc prev, IterGetFunc get);
```

Creates a custom iterator API.

**Example**:
```c
status my_next(Iter *it) {
    // Custom next logic
    return READY;
}

void *my_get(Iter *it) {
    // Custom get logic
    return value;
}

IterApi *api = IterApi_Make(m, my_next, NULL, my_get);
```

---

### Instance Iterator

**Header**: [src/ext/include/navigate/inst_iter.h](../../../src/ext/include/navigate/inst_iter.h)

```c
InstIter *InstIter_Make(MemCh *m, Inst *inst, Iter *it, IterApi *api);
InstIter *InstIter_From(MemCh *m, Inst *inst);
```

Creates iterators for instance properties.

**Example**:
```c
InstIter *iter = InstIter_From(m, user);
// Iterate over user properties
```

---

### Equality

**Header**: [src/ext/include/types/equals.h](../../../src/ext/include/types/equals.h)

```c
extern Lookup *EqualsLookup;
status Equals_Init(MemCh *m);
boolean Equals(void *a, void *b);
```

Type-aware equality comparison (dispatches to type-specific equality functions).

**Example**:
```c
if (Equals(user1, user2)) {
    // Users are equal
}
```

---


## Format Module

**Headers**: [src/ext/include/format/](../../../src/ext/include/format/)

The Format module provides parsers and formatters for multiple text formats. All formats parse into `Inst` structures, providing a uniform interface.

**See also**: [Format System Complete Guide](../core-concepts/format-system-complete.md)

### Format Initialization

```c
status Format_Init(MemCh *m);
```

Initializes all format parsers.

---

### Configuration Format

**Headers**:
- [src/ext/include/format/config/config.h](../../../src/ext/include/format/config/config.h)
- [src/ext/include/format/config/config_roebling.h](../../../src/ext/include/format/config/config_roebling.h)

Caneka's `.config` format is a hierarchical configuration syntax with space-separated values and nested blocks.

**See also**: [Config Format Complete Guide](../core-concepts/config-format-complete.md)

#### Core Functions

```c
Inst *Config_FromVec(MemCh *m, StrVec *v);
```

Parses a StrVec containing config text into an Inst.

**Example**:
```c
StrVec *config_text = File_ToVec(m, Str_FromCstr(m, "app.config", 0));
Inst *config = Config_FromVec(m, config_text);

// Access config values
Str *port = Inst_Att(config, Str_FromCstr(m, "port", 0));
```

---

```c
Inst *Config_FromPath(MemCh *m, Str *path);
```

Loads and parses a config file.

**Example**:
```c
Inst *config = Config_FromPath(m, Str_FromCstr(m, "server.config", 0));
```

---

```c
Span *Config_Sequence(MemCh *m, StrVec *v);
```

Parses a space-separated sequence into a Span.

**Example**:
```c
// "jpg png gif" → [jpg, png, gif]
StrVec *v = Str_FromCstr(m, "jpg png gif", 0);
Span *exts = Config_Sequence(m, v);
```

---

#### Config Roebling Parser

```c
Roebling *FormatConfig_Make(MemCh *m, Cursor *curs, void *source);
Inst *FormatConfig_GetRoot(Roebling *rbl);
```

Low-level config parser (usually you use `Config_FromVec` instead).

**Example**:
```c
Cursor *curs = Cursor_Make(m, config_text);
Roebling *rbl = FormatConfig_Make(m, curs, NULL);
Roebling_Run(rbl);
Inst *root = FormatConfig_GetRoot(rbl);
```

---

### JSON Support

**Header**: [src/ext/include/format/json/json_roebling.h](../../../src/ext/include/format/json/json_roebling.h)

JSON parser that converts JSON into Inst structures.

#### Core Functions

```c
Roebling *JsonParser_Make(MemCh *m, Cursor *curs, cls instTypeOf);
```

Creates a JSON parser.

**Parameters**:
- `instTypeOf`: Type to create for objects (usually `CLS(Inst)`)

**Example**:
```c
StrVec *json = Str_FromCstr(m, "{\"name\": \"Alice\", \"age\": 30}", 0);
Cursor *curs = Cursor_Make(m, StrVec_From(m, json));
Roebling *rbl = JsonParser_Make(m, curs, CLS(Inst));
Roebling_Run(rbl);
```

---

```c
void *JsonParser_GetRoot(Roebling *rbl);
Inst *Json_GetRoot(Roebling *rbl);
```

Retrieves the parsed JSON root object.

**Example**:
```c
Inst *json = Json_GetRoot(rbl);
Str *name = Inst_Att(json, Str_FromCstr(m, "name", 0));
// name = "Alice"
```

---

### HTML Formatting

**Headers**:
- [src/ext/include/format/html.h](../../../src/ext/include/format/html.h)
- [src/ext/include/format/html/html_escape_roebling.h](../../../src/ext/include/format/html/html_escape_roebling.h)

#### HTML Entity Escaping

```c
Roebling *HtmlEntRbl_Make(MemCh *m, Cursor *curs, void *source);
```

Creates an HTML entity escape parser.

**Example**:
```c
StrVec *input = Str_FromCstr(m, "<div>Hello & goodbye</div>", 0);
Cursor *curs = Cursor_Make(m, StrVec_From(m, input));
StrVec *output = StrVec_Make(m);
Roebling *rbl = HtmlEntRbl_Make(m, curs, output);
Roebling_Run(rbl);
// output = "&lt;div&gt;Hello &amp; goodbye&lt;/div&gt;"
```

---

```c
status HtmlEnt_IntoVec(MemCh *m, Roebling *rbl, StrVec *v);
```

Escapes HTML entities from parser into StrVec.

---

### XML Tag Support

**Header**: [src/ext/include/format/xml/tag.h](../../../src/ext/include/format/xml/tag.h)

```c
enum tag_atts {
    TAG_CLOSE = 1 << 8,       // </tag>
    TAG_SELFCLOSE = 1 << 8,   // <tag />
};

i64 Tag_Out(Buff *bf, void *name, word flags);
```

Outputs XML/HTML tags.

**Example**:
```c
Buff *bf = Buff_Make(m, 0);
Tag_Out(bf, Str_FromCstr(m, "div", 0), 0);  // <div>
Buff_AddCstr(bf, "content");
Tag_Out(bf, Str_FromCstr(m, "div", 0), TAG_CLOSE);  // </div>
// Result: <div>content</div>
```

---

### Pencil Formatter (Fmt)

**Headers**:
- [src/ext/include/format/fmt/fmt.h](../../../src/ext/include/format/fmt/fmt.h)
- [src/ext/include/format/fmt/fmt_html.h](../../../src/ext/include/format/fmt/fmt_html.h)

Pencil is Caneka's markdown-like document format with enhanced semantics.

**See also**: [Doc Module Complete Guide](../core-concepts/doc-module-complete.md)

#### Core Functions

```c
extern Lookup *FormatFmt_Defs;

Roebling *FormatFmt_Make(MemCh *m, Cursor *curs, void *source);
status FormatFmt_DefSpan(MemCh *m, Lookup *lk);
status FormatFmt_Init(MemCh *m);
```

Pencil parser creation and initialization.

---

```c
status Fmt_ToHtml(Buff *bf, Mess *mess);
status FmtToHtml_Init(MemCh *m);
```

Converts parsed Pencil (Mess structure) to HTML.

**Example**:
```c
// Parse Pencil file
StrVec *pencil = File_ToVec(m, Str_FromCstr(m, "doc.fmt", 0));
Cursor *curs = Cursor_Make(m, pencil);
Roebling *rbl = FormatFmt_Make(m, curs, NULL);
Roebling_Run(rbl);

// Convert to HTML
Buff *html = Buff_Make(m, 0);
Mess *mess = /* get from parser */;
Fmt_ToHtml(html, mess);
```

---


## Serve Module - TCP Server

**Headers**: [src/ext/include/serve/](../../../src/ext/include/serve/)

The Serve module provides **event-driven TCP server infrastructure** using poll-based non-blocking I/O with Task/Step execution.

**See also**: [TCP Server Complete Guide](../core-concepts/tcp-server-complete.md)

### TCP Context

**Header**: [src/ext/include/serve/tcp_ctx.h](../../../src/ext/include/serve/tcp_ctx.h)

`TcpCtx` configures a TCP server: port, address, handlers, and metrics.

**Structure**:
```c
typedef struct tcp_ctx {
    Type type;
    i32 port;                  // Port number
    Str *inet4;                // IPv4 address
    Str *inet6;                // IPv6 address
    TaskPopulate populate;     // Connection handler factory
    StepFunc finalize;         // Finalization step
    SourceFunc defaultData;    // Default data factory
    StrVec *path;              // Document root
    Inst *pages;               // Page configuration
    Inst *inc;                 // Includes
    NodeObj *nav;              // Navigation
    struct {
        struct timespec start;  // Server start time
        i64 open;               // Open connections
        i64 error;              // Error count
        i64 served;             // Requests served
    } metrics;
} TcpCtx;

typedef Task *(*TaskPopulate)(void *ctx, ProtoCtx *proto);
typedef void *(*SourceFunc)(void *ctx);
```

#### Core Functions

```c
TcpCtx *TcpCtx_Make(MemCh *m);
```

Creates a TCP server context.

**Example**:
```c
TcpCtx *ctx = TcpCtx_Make(m);
ctx->port = 3000;
ctx->populate = http_connection_handler;
```

---

### Protocol Context

**Header**: [src/ext/include/serve/proto_ctx.h](../../../src/ext/include/serve/proto_ctx.h)

`ProtoCtx` represents a single connection's protocol state.

**Structure**:
```c
typedef struct proto {
    Type type;
    util u;            // User data
    Buff *in;          // Input buffer
    Span *outSpan;     // Output span
    Buff *out;         // Output buffer
    void *ctx;         // Protocol-specific context
} ProtoCtx;
```

#### Core Functions

```c
ProtoCtx *ProtoCtx_Make(MemCh *m);
```

Creates a protocol context.

**Example**:
```c
ProtoCtx *proto = ProtoCtx_Make(m);
proto->in = Buff_Make(m, BUFF_READ);
proto->out = Buff_Make(m, BUFF_WRITE);
```

---

### Server Task Factory

**Header**: [src/ext/include/serve/serve_tcp.h](../../../src/ext/include/serve/serve_tcp.h)

```c
Task *ServeTcp_Make(TcpCtx *ctx);
```

Creates the TCP server task. This task:
1. Binds to the port
2. Listens for connections
3. Accepts connections
4. Spawns per-connection tasks via `populate`

**Constants**:
```c
#define TCP_STEP_MAX 16000           // Max steps per task
#define SERV_READ_SIZE 1024          // Read buffer size
#define SERV_SEND_SIZE 1024          // Send buffer size
#define TCP_POLL_DELAY 10            // Poll delay (ms)
#define ACCEPT_AT_ONEC_MAX 192       // Max concurrent accepts
#define TCP_TIMEOUT 6                // Timeout (seconds)
#define TCP_LISTEN_BACKLOG 128       // Listen backlog
#define TCP_ZERO_REQ_DELAY 6000      // Zero request delay (ms)
```

**Example**:
```c
TcpCtx *ctx = TcpCtx_Make(m);
ctx->port = 8080;
ctx->populate = my_connection_handler;

Task *server = ServeTcp_Make(ctx);
Task_Tumble(server);  // Run server (infinite loop)
```

---

### TCP Task Step Functions

**Header**: [src/ext/include/serve/tcp_task.h](../../../src/ext/include/serve/tcp_task.h)

Step functions for TCP I/O operations.

```c
#define TcpTask_GetPollFd(tsk) ((struct pollfd *)&(tsk)->u)
```

Gets the pollfd from a task's user data.

---

```c
status TcpTask_ReadToRbl(Step *st, Task *tsk);
```

Reads from socket and feeds to a Roebling parser.

**Example**:
```c
Task_AddStep(tsk, TcpTask_ReadToRbl, NULL, roebling, 0);
```

---

```c
status TcpTask_WriteFromOut(Step *st, Task *tsk);
```

Writes from output buffer to socket.

**Example**:
```c
Task_AddStep(tsk, TcpTask_WriteFromOut, NULL, proto, 0);
```

---

```c
status TcpTask_ExpectRecv(Step *st, Task *tsk);
status TcpTask_ExpectSend(Step *st, Task *tsk);
```

Sets poll expectations for receive/send.

**Example**:
```c
Task_AddStep(tsk, TcpTask_ExpectRecv, NULL, NULL, 0);
Task_AddStep(tsk, read_handler, NULL, proto, 0);
```

---

```c
status TcpTask_WriteStep(Step *st, Task *tsk);
```

Generic write step.

---


## Persist Module - Binary Serialization

**Headers**: [src/ext/include/persist/](../../../src/ext/include/persist/)

The Persist module provides **binary serialization** (BinSeg) for saving and loading structured data.

**See also**: [BinSeg Complete Guide](../core-concepts/binseg-complete.md)

### BinSeg Types and Structures

**Header**: [src/ext/include/persist/binseg.h](../../../src/ext/include/persist/binseg.h)

#### Data Kinds

```c
enum binseg_kinds {
    BINSEG_TYPE_BYTES = 1,            // Byte data
    BINSEG_TYPE_NUMBER = 2,           // Numeric data
    BINSEG_TYPE_COLLECTION = 3,       // Collections (Span)
    BINSEG_TYPE_BYTES_COLLECTION = 4, // Byte collections
    BINSEG_TYPE_DICTIONARY = 5,       // Dictionaries (Table)
    BINSEG_TYPE_INST = 6,             // Instances
};
```

#### Flags

```c
enum binseg_types {
    BINSEG_REVERSED = 1 << 8,   // Data is reversed
    BINSEG_READ = 1 << 9,       // Read operation
    BINSEG_ADD = 1 << 10,       // Add operation
    BINSEG_MODIFY = 1 << 11,    // Modify operation
};
```

#### BinSeg Header

```c
typedef struct binseg_hdr {
    word total;                      // Total size
    word kind;                       // Data kind
    struct { i16 idx; i16 id; } ident; // Identifier
} BinSegHeader;
```

### BinSeg Context

```c
typedef struct binseg_ctx {
    Type type;
    MemCh *m;
    Table *seel;        // Type registry
    Buff *read;         // Read buffer
    Buff *add;          // Add buffer (new data)
    Buff *modify;       // Modify buffer (updates)
    Span *shelves;      // Recycling shelves
    Span *records;      // Record index
} BinSegCtx;

typedef status (*BinSegFunc)(struct binseg_ctx *ctx, void *a, i16 id, i16 idx);
```

### Core Functions

```c
BinSegCtx *BinSegCtx_Make(MemCh *m, word flags);
```

Creates a BinSeg context.

**Example**:
```c
BinSegCtx *ctx = BinSegCtx_Make(m, BINSEG_WRITE);
```

---

```c
status BinSegCtx_Open(BinSegCtx *ctx, Str *path);
```

Opens a BinSeg file.

**Example**:
```c
BinSegCtx_Open(ctx, Str_FromCstr(m, "data.binseg", 0));
```

---

```c
status BinSegCtx_Close(BinSegCtx *ctx);
```

Closes the BinSeg file (flushes pending writes).

---

```c
status BinSegCtx_SendByIdent(BinSegCtx *ctx, void *_a, i16 id, i16 idx);
```

Serializes an object with specific identifier.

**Parameters**:
- `_a`: Object to serialize
- `id`: Type ID
- `idx`: Instance index

**Example**:
```c
BinSegCtx_SendByIdent(ctx, user, USER_TYPE_ID, 0);
```

---

```c
#define BinSegCtx_Send(ctx, a) BinSegCtx_SendByIdent((ctx), (a), 0, 0)
```

Convenience macro for serializing with auto-generated ID.

**Example**:
```c
BinSegCtx_Send(ctx, my_object);
```

---

```c
status BinSegCtx_Load(BinSegCtx *ctx);
```

Loads all data from the BinSeg file.

**Example**:
```c
BinSegCtx *ctx = BinSegCtx_Make(m, BINSEG_READ);
BinSegCtx_Open(ctx, Str_FromCstr(m, "data.binseg", 0));
BinSegCtx_Load(ctx);
// Data now accessible via ctx->records
```

---

```c
word BinSegCtx_HeaderSize(word kind, word length);
```

Calculates header size for a given kind and length.

---

```c
word BinSeg_ActionByStr(void *a);
```

Determines action (ADD/MODIFY) based on object state.

---

```c
status BinSeg_Init(MemCh *m);
```

Initializes the BinSeg system.

---

### Path Utilities

**Header**: [src/ext/include/persist/path.h](../../../src/ext/include/persist/path.h)

```c
status Path_Pair(MemCh *m, Str *path, Str *base, Str *fname);
Str *Path_File(MemCh *m, Str *path);
Str *Path_Base(MemCh *m, Str *path);
```

Path manipulation for BinSeg file naming.

**Example**:
```c
Str *file = Path_File(m, Str_FromCstr(m, "/data/users.binseg", 0));
// file = "users.binseg"
```

---

### Persist Flags

```c
enum persist_flags {
    PERSIST_TRACKED = 1 << 8    // Track changes for incremental saves
};
```

---


## See Also

- [Ext Layer Architecture](../architecture/ext-layer.md) - Architectural overview
- [Base API Reference](base.md) - Foundation layer API
- [Inter API Reference](inter.md) - Integration layer API
- [Pattern Matching Guide](../core-concepts/parser/pattern-matching.md) - Roebling patterns
- [Task Execution Guide](../core-concepts/navigate/task-execution-complete.md) - Task/Step system
- [Seel/Inst Guide](../core-concepts/seel-inst-complete.md) - Type system
- [Writing Parsers Tutorial](../guides/writing-parsers.md) - Parser tutorial
- [Creating Web Apps Tutorial](../guides/creating-web-apps.md) - Web development guide

---

*This comprehensive Ext API reference documents the extended capabilities of Caneka. For practical examples and tutorials, see the [Developer Guides](../guides/writing-parsers.md) section.*



---

[← Part 1](ext-part1) | **Part 2 of 2**
