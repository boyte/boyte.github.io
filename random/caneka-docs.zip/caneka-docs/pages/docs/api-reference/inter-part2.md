# Inter Module API Reference - Part 2

[← Part 1](inter-part1) | **Part 2 of 2**

---

## Doc Module - Documentation Generation

**Headers**: [src/inter/include/doc/](../../../src/inter/include/doc/)

The Doc module generates HTML documentation from source code components, functions, and comments.

**See also**: [Doc Module Complete Guide](../core-concepts/doc-module-complete.md)

### DocComp - Documentation Component

**Header**: [src/inter/include/doc/doc_comp.h](../../../src/inter/include/doc/doc_comp.h)

```c
typedef Inst DocComp;
```

DocComp represents a documented component (module, class, etc.).

```c
status DocComp_Init(MemCh *m);
```

Initializes the component documentation type.

---

```c
DocComp *DocComp_FromStr(MemCh *m, StrVec *src, Str *s);
```

Creates a component from source string.

**Example**:
```c
StrVec *source = File_ToVec(m, Str_FromCstr(m, "module.c", 0));
Str *component_name = Str_FromCstr(m, "MyModule", 0);
DocComp *comp = DocComp_FromStr(m, source, component_name);
```

---

### DocFunc - Function Documentation

**Header**: [src/inter/include/doc/doc_func.h](../../../src/inter/include/doc/doc_func.h)

```c
status DocFunc_Init(MemCh *m);
```

Initializes function documentation type.

**Function metadata**:
- Function name
- Declaration (signature)
- Parameters
- Return type
- Description/comment

---

### DocComment - Comment Structure

**Header**: [src/inter/include/doc/doc_comment.h](../../../src/inter/include/doc/doc_comment.h)

```c
status DocComment_Init(MemCh *m);
```

Initializes comment documentation type.

```c
enum doc_comment_props {
    DOC_COMMENT_BODY = 0,    // Comment text (StrVec)
    DOC_COMMENT_REFS = 1,    // References/links (Table)
};
```

**Example**:
```c
Inst *comment = Inst_Make(m, CLS(DocComment));
Inst_SetAtt(comment,
            Str_FromCstr(m, "body", 0),
            Str_FromCstr(m, "Allocates memory...", 0));
```

---

### HTML Generation

**Header**: [src/inter/include/doc/doc_to.h](../../../src/inter/include/doc/doc_to.h)

```c
status Doc_To(Buff *bf, DocComp *comp, ToSFunc func);
```

Renders a component to HTML using a custom formatter.

**Parameters**:
- `bf`: Output buffer
- `comp`: Component to render
- `func`: Formatter function

**Example**:
```c
Buff *html = Buff_Make(m, 0);
Doc_To(html, component, Doc_ToHtmlToS);
// html contains formatted HTML documentation
```

---

```c
status Doc_ToHtmlToS(Buff *bf, void *a, word tagIdx, word flags);
```

HTML formatter for documentation components.

**Tag indices**:
```c
enum doc_html_tag_idx {
    DOC_HTML_OPEN = 1,           // <section class="doc-html">
    DOC_HTML_HEADER,             // Document header
    DOC_HTML_FOOTER,             // Document footer
    DOC_HTML_TITLE,              // <hgroup> with title
    DOC_HTML_MOD_COMMENT,        // Module comment
    DOC_HTML_DESC,               // Description section
    DOC_HTML_FUNC_SECTION,       // <h2>Functions</h2>
    DOC_HTML_FUNC_START,         // <article> function start
    DOC_HTML_FUNC_NAME,          // <h4> function name
    DOC_HTML_FUNC_DECL,          // Function declaration
    DOC_HTML_FUNC_COMMENT,       // Function comment
    DOC_HTML_FUNC_END,           // </article> function end
    DOC_HTML_CLOSE,              // </section> close
};
```

**Example**:
```c
// Render component header
Doc_ToHtmlToS(bf, component, DOC_HTML_HEADER, 0);

// Render functions section
Doc_ToHtmlToS(bf, component, DOC_HTML_FUNC_SECTION, 0);

// For each function
Doc_ToHtmlToS(bf, function, DOC_HTML_FUNC_START, 0);
Doc_ToHtmlToS(bf, function, DOC_HTML_FUNC_NAME, 0);
Doc_ToHtmlToS(bf, function, DOC_HTML_FUNC_DECL, 0);
Doc_ToHtmlToS(bf, function, DOC_HTML_FUNC_COMMENT, 0);
Doc_ToHtmlToS(bf, function, DOC_HTML_FUNC_END, 0);
```

---

### Documentation Parsing

**Header**: [src/inter/include/doc/cdoc_roebling.h](../../../src/inter/include/doc/cdoc_roebling.h)

```c
Roebling *Doc_MakeRoebling(MemCh *m, Cursor *curs, void *source);
```

Creates a documentation parser.

**Parses**:
- C-style comments (`/* ... */`, `// ...`)
- Function declarations
- Parameter lists
- Documentation annotations

**Example**:
```c
StrVec *source_code = File_ToVec(m, Str_FromCstr(m, "module.c", 0));
Cursor *curs = Cursor_Make(m, source_code);
Roebling *rbl = Doc_MakeRoebling(m, curs, NULL);
Roebling_Run(rbl);
// Parsed documentation available
```

---

### License Management

**Header**: [src/inter/include/doc/licence.h](../../../src/inter/include/doc/licence.h)

```c
status Caneka_LicenceInit(MemCh *m);
```

Initializes license information.

---

```c
status Show_Licences(Buff *bf);
```

Displays all licenses to a buffer.

**Example**:
```c
Buff *bf = Buff_Make(m, 0);
Show_Licences(bf);
// bf contains license text
```

---

```c
extern struct lookup *LicenceLookup;
```

Global license lookup table.

---


## Inter Module Initialization

**Header**: [src/inter/include/init.h](../../../src/inter/include/init.h)

```c
status Inter_Init(MemCh *m);
```

Initializes all Inter module type systems. Must be called before using any Inter types.

**Example**:
```c
Caneka_Init();  // Initialize Base
Ext_Init();     // Initialize Ext
Inter_Init();   // Initialize Inter

// Now ready to use HTTP, Templ, WWW, Doc
```

---


## Complete Web Server Example

Putting it all together, here's how to create a complete web server:

```c
int main(int argc, char **argv) {
    // Initialize Caneka
    Caneka_Init();
    Ext_Init();
    Inter_Init();

    // Create memory chapter for configuration
    MemCh *m = MemCh_Make();

    // Load configuration
    Inst *config = Config_FromPath(m, Str_FromCstr(m, "server.config", 0));

    // Build route tree from filesystem
    StrVec *doc_root = Str_FromCstr(m, "www/pages", 0);
    Route *pages = Route_From(m, doc_root);
    Route_Prepare(pages);  // Load templates

    // Create server
    Task *server = WebServer_Make(3000, 0, NULL);
    WebServer_SetConfig(server, doc_root, config, NULL);

    // Store pages in server context
    TcpCtx *tcp_ctx = server->data;
    tcp_ctx->pages = pages;

    // Run server
    printf("Server listening on http://localhost:3000\n");
    Task_Tumble(server);  // Infinite loop

    return 0;
}
```

**Request flow**:
1. Client connects → `ServeTcp_Make()` accepts
2. Request received → `HttpRbl_Make()` parses headers
3. Route matched → `Route_Get(pages, ctx->path)`
4. Handler dispatched → `Route_Handle(route, output, data, ctx)`
   - Static file: read and serve
   - Template: `Templ_ToS(template, output, data, ctx)`
   - Format: convert Pencil to HTML
5. Response prepared → `HttpProto_PrepareResponse(proto, tsk)`
6. Response sent → `TcpTask_WriteFromOut()`
7. Cleanup → `MemCh_Free(m)` releases all memory

---


## Common Patterns

### Pattern 1: Serve Static File

```c
status ServeStaticFile(HttpCtx *ctx, Str *path) {
    // Check ETag
    StrVec *client_etag = /* from If-None-Match */;
    if (Route_CheckEtag(route, client_etag) == READY) {
        ctx->code = HTTP_STATUS_NOT_MODIFIED;
        return READY;
    }

    // Read file
    StrVec *content = File_ToVec(ctx->m, path);
    if (!content) {
        ctx->code = HTTP_STATUS_NOT_FOUND;
        return ERR;
    }

    // Set headers
    ctx->code = HTTP_STATUS_OK;
    ctx->mime = Route_MimeFunc(path);
    ctx->contentLength = content->length;

    // Generate ETag
    struct timespec mod;
    File_ModTime(ctx->m, path, &mod);
    StrVec *etag = HttpCtx_MakeEtag(ctx->m, path, &mod);
    Table_Set(ctx->headersOut, Str_FromCstr(ctx->m, "ETag", 0), etag);

    return READY;
}
```

---

### Pattern 2: Render Template

```c
status RenderTemplate(HttpCtx *ctx, Templ *templ, Inst *data) {
    // Prepare template (if not already prepared)
    if (templ->content.state != ITER_READY) {
        Templ_Prepare(templ);
    }

    // Create output buffer
    Buff *output = Buff_Make(ctx->m, 0);

    // Render
    Templ_SetData(templ, data);
    i64 written = Templ_ToS(templ, output, data, ctx);

    if (written < 0) {
        ctx->code = HTTP_STATUS_ERROR;
        return ERR;
    }

    // Set response headers
    ctx->code = HTTP_STATUS_OK;
    ctx->mime = Str_FromCstr(ctx->m, "text/html", 0);
    ctx->contentLength = written;

    return READY;
}
```

---

### Pattern 3: Parse JSON Request Body

```c
status HandleJSONPost(HttpCtx *ctx) {
    // Parse body
    Cursor *curs = Cursor_Make(ctx->m, ctx->proto->in->v);
    HttpCtx_ParseBody(ctx, config, curs);

    if (!ctx->body) {
        ctx->code = HTTP_STATUS_ERROR;
        return ERR;
    }

    // Extract data
    Inst *data = ctx->body;
    Str *name = Inst_Att(data, Str_FromCstr(ctx->m, "name", 0));
    Str *email = Inst_Att(data, Str_FromCstr(ctx->m, "email", 0));

    // Process...

    // Send JSON response
    Buff *response = Buff_Make(ctx->m, 0);
    Buff_AddCstr(response, "{\"status\":\"ok\"}");

    ctx->code = HTTP_STATUS_OK;
    ctx->mime = Str_FromCstr(ctx->m, "application/json", 0);
    ctx->contentLength = response->v->length;

    return READY;
}
```

---

### Pattern 4: Custom Route Handler

```c
status MyCustomHandler(Buff *bf, Route *rt, Inst *data, HttpCtx *ctx) {
    // Check authentication
    if (!ctx->authenticated) {
        ctx->code = HTTP_STATUS_FORBIDDON;
        return ERR;
    }

    // Generate content
    Buff_AddCstr(bf, "<html><body>");
    Buff_AddCstr(bf, "<h1>Custom Handler</h1>");
    Buff_AddCstr(bf, "</body></html>");

    // Set headers
    ctx->code = HTTP_STATUS_OK;
    ctx->mime = Str_FromCstr(ctx->m, "text/html", 0);
    ctx->contentLength = bf->v->length;

    return READY;
}

// Register handler
Table_Set(handlers,
          Str_FromCstr(m, "/custom", 0),
          MyCustomHandler);
```

---


## See Also

- [Inter Layer Architecture](../architecture/inter-layer.md) - Architectural overview
- [Base API Reference](base.md) - Foundation layer API
- [Ext API Reference](ext.md) - Extended layer API
- [HTTP Lifecycle Guide](../core-concepts/http-lifecycle-complete.md) - HTTP request flow
- [Templ Complete Guide](../core-concepts/templ-complete.md) - Template engine
- [WWW Routing Guide](../core-concepts/www-routing-complete.md) - Web server routing
- [Doc Module Guide](../core-concepts/doc-module-complete.md) - Documentation generation
- [Creating Web Apps Tutorial](../guides/creating-web-apps.md) - Web development guide

---

*This comprehensive Inter API reference documents the integration layer of Caneka. For practical examples and complete applications, see the [Creating Web Apps Tutorial](../guides/creating-web-apps.md).*



---

[← Part 1](inter-part1) | **Part 2 of 2**
