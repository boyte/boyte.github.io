# Base Module API Reference - Part 2

[← Part 1](base-part1) | **Part 2 of 4** | [Part 3 →](base-part3)

---

## Bytes & Strings

Caneka's string system is dramatically different from C's null-terminated strings. Strings are **length-tracked byte sequences** that can contain null bytes, support efficient composition, and integrate tightly with the memory system.

The three core types are:
- **Str**: Single contiguous string (up to ~4KB)
- **StrVec**: Vector of Str chunks (for arbitrarily large strings)
- **Cursor**: Position tracker for navigating StrVec

**See also**: [Strings Complete Guide](../core-concepts/strings-complete.md)

### Str - Core String Type

**Header**: [src/base/include/bytes/str.h](../../../src/base/include/bytes/str.h)

Str represents a mutable byte sequence with explicit length tracking. It supports both owned and referenced memory, allowing zero-copy operations when possible.

**Key fields**:
```c
typedef struct str {
    byte *bytes;    // Byte data (not necessarily null-terminated)
    word length;    // Current length in bytes
    word alloc;     // Allocated capacity
    word flags;     // STR_BUFFER, STR_REF, etc.
} Str;
```

#### Creation Functions

```c
Str *Str_Make(MemCh *m, word alloc);
```

Creates a new empty string with the specified allocation size.

**Example**:
```c
Str *s = Str_Make(m, 1024);  // 1KB capacity
```

---

```c
Str *Str_MakeBlank(MemCh *m);
```

Creates an empty string with minimal allocation (typically 64 bytes).

**Example**:
```c
Str *s = Str_MakeBlank(m);  // Small default allocation
```

---

```c
Str *Str_From(MemCh *m, byte *bytes, word length);
```

Creates a string by **copying** the provided bytes.

**Example**:
```c
byte data[] = {0x00, 0x01, 0x02};
Str *s = Str_From(m, data, 3);  // Copies 3 bytes
```

---

```c
Str *Str_FromCstr(MemCh *m, char *cstr, word flags);
```

Creates a string from a null-terminated C string. Behavior depends on flags:
- `0`: Copy the string
- `STR_REF`: Create a reference (zero-copy)

**Example**:
```c
// Copy
Str *s1 = Str_FromCstr(m, "hello", 0);

// Reference (zero-copy)
Str *s2 = Str_FromCstr(m, "world", STR_REF);
```

**Warning**: With `STR_REF`, the original C string must remain valid for the string's lifetime.

---

```c
Str *Str_CstrRef(MemCh *m, char *cstr);
```

Convenience function for creating a reference to a C string. Equivalent to `Str_FromCstr(m, cstr, STR_REF)`.

**Example**:
```c
Str *s = Str_CstrRef(m, "static constant");
```

---

```c
Str *Str_Ref(MemCh *m, byte *bytes, word length, word alloc, word flags);
```

Creates a reference to an existing byte buffer with full control over all fields.

**Parameters**:
- `bytes`: Pointer to data
- `length`: Current data length
- `alloc`: Buffer capacity
- `flags`: `STR_REF`, `STR_BUFFER`, etc.

**Example**:
```c
byte buffer[1024];
Str *s = Str_Ref(m, buffer, 0, 1024, STR_BUFFER);
// s references buffer, can grow up to 1024 bytes
```

---

```c
Str *Str_Clone(MemCh *m, Str *s);
```

Creates a shallow copy of the string (shares the same byte buffer if possible).

**Example**:
```c
Str *copy = Str_Clone(m, original);
```

---

```c
Str *Str_Copy(MemCh *m, Str *_s);
```

Creates a deep copy of the string (allocates new buffer and copies data).

**Example**:
```c
Str *copy = Str_Copy(m, original);
// copy has its own independent byte buffer
```

---

```c
Str *Str_CloneAlloc(MemCh *m, Str *s, word alloc);
```

Clones a string with a specific allocation size (useful for pre-allocating space for growth).

**Example**:
```c
Str *s = Str_FromCstr(m, "hello", 0);  // 5 bytes
Str *big = Str_CloneAlloc(m, s, 1024);  // Clone with 1KB capacity
```

---

```c
char *Str_Cstr(MemCh *m, Str *s);
```

Converts a Str to a null-terminated C string. **Allocates new memory** to add the null terminator if necessary.

**Example**:
```c
Str *s = Str_FromCstr(m, "hello", 0);
char *cstr = Str_Cstr(m, s);
printf("%s\n", cstr);
```

**Note**: The returned C string is allocated from `m` and will be freed when `m` is freed.

---

#### Mutation Functions

```c
status Str_Reset(Str *s);
```

Resets the string to empty (sets length to 0, keeps allocation).

**Example**:
```c
Str_Add(s, "hello", 5);
Str_Reset(s);
// s is now empty but still has allocated capacity
```

---

```c
status Str_Wipe(Str *s);
```

Zeroes the string's byte buffer and resets length to 0.

**Example**:
```c
Str_Wipe(s);  // All bytes set to 0, length = 0
```

---

```c
status Str_Incr(Str *s, word length);
```

Increases the string's length by `length` bytes. **Does not allocate**—assumes space is available.

**When to use**: After manually writing bytes into `s->bytes`, update the length.

**Example**:
```c
Str *s = Str_Make(m, 1024);
memcpy(s->bytes, data, 100);
Str_Incr(s, 100);  // Update length to 100
```

---

```c
status Str_Decr(Str *s, word length);
```

Decreases the string's length by `length` bytes (truncates from the end).

**Example**:
```c
Str_Add(s, "hello world", 11);
Str_Decr(s, 6);  // Now contains "hello"
```

---

```c
i64 Str_Add(Str *s, byte *b, i64 length);
```

Appends `length` bytes from `b` to the string. Automatically reallocates if necessary.

**Returns**: Number of bytes added, or negative on error.

**Example**:
```c
Str_Add(s, "hello", 5);
Str_Add(s, " ", 1);
Str_Add(s, "world", 5);
// s now contains "hello world"
```

---

```c
i64 Str_AddCstr(Str *s, char *cstr);
```

Appends a null-terminated C string.

**Example**:
```c
Str_AddCstr(s, "hello");
Str_AddCstr(s, " ");
Str_AddCstr(s, "world");
```

---

```c
i64 Str_AddVec(Str *s, StrVec *v);
```

Appends the contents of a StrVec to the string.

**Example**:
```c
StrVec *vec = StrVec_Make(m);
StrVec_Add(vec, chunk1);
StrVec_Add(vec, chunk2);
Str_AddVec(s, vec);  // Appends both chunks
```

---

```c
Str *Str_Rec(MemCh *m, Str *s);
```

Records/persists the string by ensuring it has its own allocated buffer (converts references to owned copies).

**Example**:
```c
Str *ref = Str_CstrRef(m, "temporary");
Str *owned = Str_Rec(m, ref);  // Now owned, safe to outlive original
```

---

#### String Makers - Utility Functions

```c
Str *Str_Prefixed(MemCh *m, Str *s, Str *prefix);
```

Creates a new string with `prefix` prepended to `s`.

**Example**:
```c
Str *name = Str_FromCstr(m, "world", 0);
Str *greeting = Str_Prefixed(m, name, Str_FromCstr(m, "hello ", 0));
// greeting = "hello world"
```

---

```c
Str *Str_BuffFromCstr(MemCh *m, char *cstr);
```

Creates a buffer-backed string from a C string (optimized for subsequent appends).

---

```c
Str *Str_MemCount(MemCh *m, i64 mem);
```

Formats a memory count as a human-readable string (e.g., "1.5 MB").

**Example**:
```c
Str *size = Str_MemCount(m, 1536000);
// size = "1.5 MB"
```

---

```c
Str *Str_FromI64(MemCh *m, i64 i);
```

Converts a 64-bit integer to a string.

**Example**:
```c
Str *num = Str_FromI64(m, 12345);
// num = "12345"
```

---

```c
Str *Str_FromI64Pad(MemCh *m, i64 i, i32 pad);
```

Converts an integer to a string with zero-padding.

**Example**:
```c
Str *num = Str_FromI64Pad(m, 42, 5);
// num = "00042"
```

---

```c
Str *Str_ToUpper(MemCh *m, Str *s);
Str *Str_ToLower(MemCh *m, Str *s);
Str *Str_ToTitle(MemCh *m, Str *s);
```

Case conversion functions.

**Example**:
```c
Str *upper = Str_ToUpper(m, Str_FromCstr(m, "hello", 0));
// upper = "HELLO"
```

---

```c
Str *Str_ToLowerFiltered(MemCh *m, Str *s, Str *filter, byte replace);
```

Converts to lowercase while replacing characters in `filter` with `replace`.

**Example**:
```c
Str *slug = Str_ToLowerFiltered(m, title,
                                Str_FromCstr(m, " /?", 0), '-');
// "Hello World?" -> "hello-world-"
```

---

```c
Str *Str_UniRandom(MemCh *m, i64 n, word digits);
```

Generates a random string of length `n` using the specified character set.

**Parameters**:
- `digits`: Character set flags (alphanumeric, hex, etc.)

**Example**:
```c
Str *session_id = Str_UniRandom(m, 32, DIGIT_HEX);
// 32-character hex string
```

---

```c
status Str_AddChain(MemCh *m, Str *s, void *args[]);
```

Appends multiple strings/values in sequence. `args` is a NULL-terminated array.

**Example**:
```c
void *parts[] = {
    Str_FromCstr(m, "hello", 0),
    Str_FromCstr(m, " ", 0),
    Str_FromCstr(m, "world", 0),
    NULL
};
Str_AddChain(m, s, parts);
// s = "hello world"
```

---

```c
i64 Str_Trunc(Str *s, i64 amount);
```

Truncates the string by `amount` bytes from the end.

**Example**:
```c
Str_Add(s, "hello world", 11);
Str_Trunc(s, 6);
// s = "hello"
```

---

```c
i64 Str_AddMemCount(Str *s, i64 mem);
```

Appends a formatted memory count.

**Example**:
```c
Str_AddMemCount(s, 2048000);
// s += "2.0 MB"
```

---

```c
i64 Str_AddI64(Str *s, i64 i);
```

Appends an integer as a string.

**Example**:
```c
Str_AddI64(s, 42);
// s += "42"
```

---

```c
Str *Str_FuncName(m);
```

Macro that returns the current function name as a Str.

**Example**:
```c
Str *fname = Str_FuncName(m);
// fname = name of current function
```

---

### StrVec - String Vector

**Header**: [src/base/include/bytes/str_vec.h](../../../src/base/include/bytes/str_vec.h)

StrVec represents a sequence of Str chunks, allowing strings larger than a single page. It's the foundation for handling large files, HTTP bodies, and streaming data.

**Key fields**:
```c
typedef struct str_vec {
    Span *p;          // Span of Str pointers
    word length;      // Total length in bytes (across all chunks)
    i32 anchor;       // Saved position for temporary allocations
} StrVec;
```

#### Core Functions

```c
StrVec *StrVec_Make(MemCh *m);
```

Creates a new empty StrVec.

**Example**:
```c
StrVec *vec = StrVec_Make(m);
```

---

```c
StrVec *StrVec_From(MemCh *m, Str *s);
```

Creates a StrVec containing a single Str.

**Example**:
```c
Str *s = Str_FromCstr(m, "hello", 0);
StrVec *vec = StrVec_From(m, s);
```

---

```c
StrVec *StrVec_Copy(MemCh *m, StrVec *v);
```

Creates a shallow copy of the StrVec (shares Str chunks).

---

```c
StrVec *StrVec_CopyTo(MemCh *m, StrVec *_v, i32 anchor);
```

Copies the StrVec up to the specified anchor position.

**Example**:
```c
StrVec_Anchor(vec);       // Mark current position
StrVec_Add(vec, chunk1);
StrVec_Add(vec, chunk2);
StrVec *first_part = StrVec_CopyTo(m, vec, vec->anchor);
// first_part contains only chunks before anchor
```

---

```c
StrVec *StrVec_ReAlign(MemCh *m, StrVec *orig);
```

Realigns the StrVec by merging small chunks and optimizing layout.

---

```c
StrVec *StrVec_FromLongBytes(MemCh *m, byte *bytes, i32 length);
```

Creates a StrVec from a large byte buffer, automatically chunking it.

**Example**:
```c
byte large_buffer[100000];
StrVec *vec = StrVec_FromLongBytes(m, large_buffer, 100000);
// Automatically split into appropriate chunks
```

---

```c
StrVec *StrVec_FromB64(MemCh *m, StrVec *v);
```

Decodes base64-encoded StrVec into raw bytes.

**Example**:
```c
StrVec *encoded = /* base64 data */;
StrVec *decoded = StrVec_FromB64(m, encoded);
```

---

#### Vector Operations

```c
i32 StrVec_Add(StrVec *v, Str *s);
```

Appends a Str to the vector.

**Example**:
```c
StrVec_Add(vec, chunk1);
StrVec_Add(vec, chunk2);
```

---

```c
i32 StrVec_AddVec(StrVec *v, StrVec *v2);
```

Appends all chunks from `v2` to `v`.

**Example**:
```c
StrVec_AddVec(dest, source);
// dest now contains all chunks from source
```

---

```c
i32 StrVec_AddVecAfter(StrVec *v, StrVec *v2, i32 idx);
```

Inserts all chunks from `v2` into `v` after position `idx`.

**Example**:
```c
StrVec_AddVecAfter(vec, middle_part, 5);
// Inserts middle_part after 5th chunk
```

---

```c
i32 StrVec_AddChain(StrVec *v, void *args[]);
```

Appends multiple strings in sequence.

**Example**:
```c
void *parts[] = {
    chunk1,
    chunk2,
    chunk3,
    NULL
};
StrVec_AddChain(vec, parts);
```

---

```c
i32 StrVec_GetIdx(StrVec *v, Str *s);
```

Returns the index of the first occurrence of `s` in the vector, or -1 if not found.

**Example**:
```c
i32 idx = StrVec_GetIdx(vec, search_str);
if (idx >= 0) {
    // Found at index idx
}
```

---

```c
status StrVec_AddBytes(MemCh *m, StrVec *v, byte *ptr, i64 length);
```

Appends raw bytes to the vector, creating a new chunk if necessary.

**Example**:
```c
byte data[] = {0x00, 0x01, 0x02};
StrVec_AddBytes(m, vec, data, 3);
```

---

```c
status StrVec_Incr(StrVec *v, i64 amount);
status StrVec_Decr(StrVec *v, i64 amount);
```

Increases or decreases the vector's total length.

**Example**:
```c
StrVec_Incr(vec, 100);  // Add 100 to length
StrVec_Decr(vec, 50);   // Subtract 50 from length
```

---

```c
status StrVec_Pop(StrVec *v);
```

Removes the last chunk from the vector.

**Example**:
```c
StrVec_Add(vec, chunk1);
StrVec_Add(vec, chunk2);
StrVec_Pop(vec);  // chunk2 removed
```

---

```c
status StrVec_PopTo(StrVec *v, i32 idx);
```

Removes all chunks after index `idx`.

**Example**:
```c
StrVec_PopTo(vec, 2);  // Keep only first 3 chunks (0, 1, 2)
```

---

```c
status StrVec_Anchor(StrVec *v);
status StrVec_Return(StrVec *v);
```

`Anchor` saves the current position; `Return` restores to that position (removing everything added after the anchor).

**Example**:
```c
StrVec_Add(vec, keep_this);
StrVec_Anchor(vec);       // Mark position
StrVec_Add(vec, temp1);
StrVec_Add(vec, temp2);
StrVec_Return(vec);       // Remove temp1, temp2
// Vector back to just keep_this
```

---

```c
status StrVec_NextSlot(StrVec *v, struct cursor *curs);
```

Advances cursor to the next available slot in the vector.

---

#### Conversion Functions

```c
Str *StrVec_Str(MemCh *m, void *a);
```

Converts the entire StrVec to a single Str (concatenates all chunks).

**Example**:
```c
Str *combined = StrVec_Str(m, vec);
// All chunks merged into one string
```

**Note**: For large vectors, this allocates a large contiguous buffer.

---

```c
Str *StrVec_StrTo(MemCh *m, StrVec *v, i32 anchor);
```

Converts the StrVec up to the anchor position to a Str.

**Example**:
```c
StrVec_Anchor(vec);
StrVec_Add(vec, more_data);
Str *first_part = StrVec_StrTo(m, vec, vec->anchor);
```

---

```c
Str *StrVec_ToStr(MemCh *m, StrVec *v, word length);
```

Converts up to `length` bytes of the vector to a Str.

**Example**:
```c
Str *first_1k = StrVec_ToStr(m, vec, 1024);
```

---

```c
Str *StrVec_StrPrefixed(MemCh *m, void *prefix, StrVec *v);
```

Converts StrVec to Str with a prefix.

**Example**:
```c
Str *result = StrVec_StrPrefixed(m,
                                  Str_FromCstr(m, "Prefix: ", 0),
                                  vec);
```

---

```c
Str *StrVec_StrCombo(MemCh *m, void *a, void *b);
```

Combines two StrVecs or Strs into a single Str.

**Example**:
```c
Str *combined = StrVec_StrCombo(m, vec1, vec2);
```

---

```c
i64 StrVec_FfIter(Iter *it, i64 offset);
```

Feeds StrVec chunks into an iterator starting from `offset`.

---

```c
void *StrVec_Nth(MemCh *m, StrVec *v, i32 n);
```

Returns the nth chunk from the vector.

**Example**:
```c
Str *third = StrVec_Nth(m, vec, 2);  // Get chunk at index 2
```

---

### Cursor - Position Tracking

**Header**: [src/base/include/bytes/cursor.h](../../../src/base/include/bytes/cursor.h)

Cursor tracks a position within a StrVec, enabling efficient forward/backward navigation without copying data. It's essential for parsers and stream processors.

**Key fields**:
```c
typedef struct cursor {
    StrVec *v;        // StrVec being traversed
    i32 str_idx;      // Current chunk index
    i32 byte_idx;     // Byte offset within chunk
    i64 abs;          // Absolute byte position in vector
} Cursor;
```

#### Core Functions

```c
Cursor *Cursor_Make(MemCh *m, StrVec *v);
```

Creates a cursor for the given StrVec, positioned at the start.

**Example**:
```c
Cursor *curs = Cursor_Make(m, vec);
```

---

```c
Cursor *Cursor_Copy(MemCh *m, Cursor *_curs);
```

Creates a copy of the cursor (useful for lookahead without modifying the original).

**Example**:
```c
Cursor *saved = Cursor_Copy(m, curs);
// Try parsing...
if (failed) {
    curs = saved;  // Restore position
}
```

---

```c
status Cursor_Setup(Cursor *curs, StrVec *v);
```

Initializes a stack-allocated cursor.

**Example**:
```c
Cursor stack_cursor;
Cursor_Setup(&stack_cursor, vec);
```

---

```c
status Cursor_Incr(Cursor *curs, i32 length);
```

Moves the cursor forward by `length` bytes, automatically crossing chunk boundaries.

**Example**:
```c
Cursor_Incr(curs, 10);  // Advance 10 bytes
```

---

```c
status Cursor_Decr(Cursor *curs, i32 length);
```

Moves the cursor backward by `length` bytes.

**Example**:
```c
Cursor_Decr(curs, 5);  // Move back 5 bytes
```

---

```c
status Cursor_NextByte(Cursor *curs);
```

Advances to the next byte (equivalent to `Cursor_Incr(curs, 1)`).

**Example**:
```c
while (Cursor_NextByte(curs) == READY) {
    byte b = curs->v->p->arr[curs->str_idx]->bytes[curs->byte_idx];
    // Process byte
}
```

---

```c
status Cursor_Add(Cursor *curs, Str *s);
status Cursor_AddVec(Cursor *curs, StrVec *v);
```

Inserts a Str or StrVec at the current cursor position.

**Example**:
```c
Cursor_Add(curs, Str_FromCstr(m, "INSERT", 0));
```

---

```c
StrVec *Cursor_Get(MemCh *m, Cursor *curs, i32 length, i32 offset);
```

Extracts a StrVec of `length` bytes starting from `offset` relative to cursor position.

**Example**:
```c
StrVec *chunk = Cursor_Get(m, curs, 100, 0);  // Get next 100 bytes
```

---

```c
status Cursor_SetStrBytes(Cursor *curs, Str *s, i32 max);
```

Fills Str `s` with up to `max` bytes from the cursor position.

**Example**:
```c
Str *s = Str_Make(m, 1024);
Cursor_SetStrBytes(curs, s, 100);  // Read 100 bytes into s
```

---

```c
status Cursor_FillStr(Cursor *curs, Str *s);
```

Fills Str `s` with bytes from cursor, advancing the cursor.

**Example**:
```c
Str *s = Str_Make(m, 256);
Cursor_FillStr(curs, s);
// s filled, cursor advanced
```

---

```c
status Cursor_RFillStr(Cursor *curs, Str *s);
```

Fills Str `s` in reverse (backward from cursor position).

---

```c
status Cursor_End(Cursor *curs);
```

Moves cursor to the end of the StrVec.

**Example**:
```c
Cursor_End(curs);
i64 total_length = Cursor_Pos(curs);
```

---

```c
i64 Cursor_Pos(Cursor *curs);
```

Returns the absolute byte position in the StrVec.

**Example**:
```c
Cursor_Incr(curs, 100);
printf("Position: %lld\n", Cursor_Pos(curs));  // 100
```

---

### Histogram - Character Analysis

**Header**: [src/base/include/bytes/histo.h](../../../src/base/include/bytes/histo.h)

Histogram analyzes character distribution in strings, useful for content type detection, security analysis, and encoding detection.

**See also**: [Histogram Complete Guide](../core-concepts/strings/histogram-complete.md)

#### Core Functions

```c
Histo *Histo_Make(MemCh *m);
```

Creates a new histogram.

**Example**:
```c
Histo *hst = Histo_Make(m);
```

---

```c
status Histo_Feed(Histo *hst, Str *s);
```

Analyzes the character distribution in `s` and updates the histogram.

**Example**:
```c
Histo_Feed(hst, text);
if (hst->ratio_punct > 0.5) {
    // Text is more than 50% punctuation—might be binary data
}
```

---

```c
status Histo_ToRatio(Histo *hst);
```

Converts raw counts to ratios (0.0 to 1.0).

**Example**:
```c
Histo_Feed(hst, text);
Histo_ToRatio(hst);
printf("Alphanumeric: %.2f%%\n", hst->ratio_alnum * 100);
```

---

### Formatting - Fmt System

**Header**: [src/base/include/bytes/fmt.h](../../../src/base/include/bytes/fmt.h)

The Fmt system provides printf-style formatting with Caneka-specific placeholders and type-aware output.

**See also**: [Format System Complete Guide](../core-concepts/format-system-complete.md)

#### Core Functions

```c
status Fmt(struct buff *bf, char *fmt, void *args[]);
```

Formats output to a buffer using the format string and NULL-terminated argument array.

**Format placeholders**:
- `$`: String (Str* or char*)
- `@`: Integer (I32_Wrapped() or I64_Wrapped())
- `&`: Type name (CLS_Wrapped())
- `^`: Pointer address
- `%s`, `%d`, etc.: Standard printf specifiers

**Example**:
```c
Buff *bf = Buff_Make(m, 0);
void *args[] = {
    Str_FromCstr(m, "Alice", 0),
    I32_Wrapped(m, 42),
    NULL
};
Fmt(bf, "Name: $, Age: @\n", args);
// Output: "Name: Alice, Age: 42\n"
```

---

```c
FmtLine *FmtLine_Make(MemCh *m, char *fmt, void **args);
```

Creates a FmtLine object representing a formatted line (useful for deferred formatting).

**Example**:
```c
void *args[] = {
    Str_FromCstr(m, "value", 0),
    NULL
};
FmtLine *line = FmtLine_Make(m, "Result: $", args);
```

---

```c
FmtLine *FmtLine_FromSpan(MemCh *m, char *fmt, Span *p);
```

Creates a FmtLine from a Span of arguments.

---

```c
StrVec *Fmt_ToStrVec(MemCh *m, char *fmt, void **args);
```

Formats directly to a StrVec instead of a buffer.

**Example**:
```c
void *args[] = {
    Str_FromCstr(m, "test", 0),
    NULL
};
StrVec *result = Fmt_ToStrVec(m, "Output: $", args);
```

---

```c
void *FmtVar_Get(MemCh *m, Str *key, void *arg);
```

Retrieves a format variable by name from an argument.

---

### Integer Utilities

**Header**: [src/base/include/bytes/str.h](../../../src/base/include/bytes/str.h)

Utilities for parsing and formatting integers.

#### Core Functions

```c
i32 Int_FromStr(Str *s);
i64 I64_FromStr(Str *s);
```

Parses an integer from a Str.

**Example**:
```c
Str *s = Str_FromCstr(m, "12345", 0);
i64 num = I64_FromStr(s);  // num = 12345
```

---

```c
i64 Str_I64OnBytes(byte **_b, byte *end, i64 i);
```

Parses an integer from a byte buffer, advancing the pointer.

**Example**:
```c
byte *ptr = buffer;
i64 num = Str_I64OnBytes(&ptr, buffer + length, 0);
// ptr advanced past the integer
```

---

```c
Str *Str_FromI64(MemCh *m, i64 i);
```

Formats an integer as a Str.

**Example**:
```c
Str *num = Str_FromI64(m, 42);
// num = "42"
```

---

### Character Analysis

```c
boolean TextCharFilter(byte *b, i64 length);
```

Checks if a byte sequence contains only text characters (no control characters except whitespace).

**Example**:
```c
if (TextCharFilter(data, len)) {
    // Data is plain text
} else {
    // Contains binary or control characters
}
```

---



---

[← Part 1](base-part1) | **Part 2 of 4** | [Part 3 →](base-part3)
