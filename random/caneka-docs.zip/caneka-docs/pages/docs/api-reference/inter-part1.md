# Inter Module API Reference - Part 1

**Part 1 of 2** | [Part 2 →](inter-part2)

---

## Architecture Overview

The Inter layer comprises four tightly integrated modules:

**1. HTTP** - Request/response handling, protocol parsing, ETag caching
**2. Templ** - Template engine with data binding and control flow
**3. WWW** - Web server, filesystem-driven routing, content serving
**4. Doc** - Documentation generation from code to HTML

### Request Lifecycle

A complete HTTP request flows through Inter like this:

```
1. [TCP Accept] → ServeTcp (Ext/Serve module)
2. [HTTP Parse] → HttpRbl_Make() parses headers
3. [Route Match] → Route_Get() finds handler
4. [Content Gen] → Route_Handle() dispatches:
   - Static files: direct file serve
   - Templates: Templ_ToS() renders with data
   - Binary DB: BinSeg database operations
5. [Response] → HttpProto_PrepareResponse()
6. [Send] → TcpTask_WriteFromOut()
7. [Cleanup] → MemCh_Free(m) releases all memory
```

### Module Dependencies

```
Base (memory, I/O, strings) ← Ext (parser, navigate, types) ← Inter
                                                                   ↓
                                            HTTP ← Templ
                                              ↓       ↓
                                            WWW → Doc
```

**Integration Points**:
- **HTTP** uses Roebling (Ext/Parser) for request parsing
- **Templ** uses Fetcher (Ext/Types) for variable binding
- **WWW** uses Task/Step (Ext/Navigate) for request handling
- **Doc** uses Mess (Ext/Navigate) for document structure

### Key Design Principles

1. **Filesystem-driven routing**: Routes mirror directory structure
2. **Template compilation**: Parse once, render many
3. **Memory isolation**: Each request gets its own MemCh
4. **ETag caching**: Automatic HTTP caching for static assets
5. **Task-based concurrency**: Non-blocking I/O via Task/Step

---


## HTTP Module

**Headers**: [src/inter/include/http/](../../../src/inter/include/http/)

The HTTP module handles the HTTP protocol: parsing requests, building responses, managing headers, and supporting ETag-based caching.

**See also**: [HTTP Lifecycle Complete Guide](../core-concepts/http-lifecycle-complete.md)

### HttpCtx - Request/Response Context

**Header**: [src/inter/include/http/http_ctx.h](../../../src/inter/include/http/http_ctx.h)

`HttpCtx` is the central structure for HTTP requests and responses. It contains everything about a request: method, path, headers, body, query parameters, and the matched route.

**Structure**:
```c
typedef struct {
    Type type;
    MemCh *m;                  // Memory chapter for this request
    i32 method;                // HTTP method (GET, POST, etc.)
    i32 code;                  // Response status code
    i64 contentLength;         // Content-Length for response
    Str *mime;                 // MIME type (text/html, etc.)
    StrVec *httpVersion;       // HTTP version (1.1, 2.0)
    StrVec *path;              // Request path (/users/123)
    Abstract *body;            // Parsed body (JSON/form data)
    Inst *route;               // Matched route
    Table *data;               // Request/response data
    Span *errors;              // Error collection
    Table *headersOut;         // Response headers
    Iter queryIt;              // Query string iterator
    Iter headersIt;            // Request headers iterator
} HttpCtx;
```

#### HTTP Methods

```c
enum http_method {
    HTTP_METHOD_GET,
    HTTP_METHOD_POST,
    HTTP_METHOD_PUT,
    HTTP_METHOD_DELETE,
    HTTP_METHOD_PATCH,
    HTTP_METHOD_HEAD,
    HTTP_METHOD_OPTIONS,
};
```

#### HTTP Status Codes

```c
enum http_status {
    HTTP_STATUS_OK = 200,
    HTTP_STATUS_REDIRECT = 301,
    HTTP_STATUS_TEMP_REDIRECT = 302,
    HTTP_STATUS_NOT_MODIFIED = 304,
    HTTP_STATUS_FORBIDDON = 403,
    HTTP_STATUS_NOT_FOUND = 404,
    HTTP_STATUS_ERROR = 500,
};
```

#### Core Functions

```c
HttpCtx *HttpCtx_Make(MemCh *m);
```

Creates an HTTP context for a request.

**Example**:
```c
MemCh *m = MemCh_OnPage();
HttpCtx *ctx = HttpCtx_Make(m);
ctx->method = HTTP_METHOD_GET;
ctx->code = HTTP_STATUS_OK;
```

---

```c
status HttpCtx_Init(MemCh *m);
```

Initializes the HTTP type system (called during startup).

---

#### Header Management

```c
status HttpCtx_WriteHeaders(Buff *bf, HttpCtx *ctx);
```

Writes HTTP response headers to a buffer.

**Example**:
```c
ctx->code = HTTP_STATUS_OK;
ctx->mime = Str_FromCstr(m, "text/html", 0);
ctx->contentLength = 1024;

Buff *bf = Buff_Make(m, BUFF_WRITE);
HttpCtx_WriteHeaders(bf, ctx);
// Outputs: "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n..."
```

**Standard headers written**:
- Status line (e.g., `HTTP/1.1 200 OK`)
- `Content-Type` (from `ctx->mime`)
- `Content-Length` (from `ctx->contentLength`)
- Custom headers (from `ctx->headersOut`)
- `Server: Caneka`

---

#### Body Parsing

```c
status HttpCtx_ParseBody(HttpCtx *ctx, NodeObj *config, Cursor *curs);
```

Parses request body based on Content-Type.

**Supported types**:
- `application/json` - Parses into Inst structures
- `application/x-www-form-urlencoded` - Parses into Table
- Multipart form data (future)

**Parameters**:
- `ctx`: HTTP context
- `config`: Configuration for parsing
- `curs`: Cursor positioned at body start

**Example**:
```c
// POST with JSON body: {"name": "Alice", "age": 30}
Cursor *curs = Cursor_Make(m, request_body);
HttpCtx_ParseBody(ctx, config, curs);

Inst *body = ctx->body;
Str *name = Inst_Att(body, Str_FromCstr(m, "name", 0));
// name = "Alice"
```

---

#### ETag Generation

```c
StrVec *HttpCtx_MakeEtag(MemCh *m, Str *path, struct timespec *mod);
```

Generates an ETag for caching based on file path and modification time.

**Parameters**:
- `path`: File path
- `mod`: File modification time

**Returns**: ETag string (e.g., `"abc123-1234567890"`)

**Example**:
```c
struct timespec modtime;
File_ModTime(m, path, &modtime);
StrVec *etag = HttpCtx_MakeEtag(m, path, &modtime);

Table_Set(ctx->headersOut,
          Str_FromCstr(m, "ETag", 0),
          etag);
```

**ETag format**: `{hash}-{timestamp}` where:
- `hash` is based on file path
- `timestamp` is modification time in seconds

---

### ProtoCtx - Protocol Context

**Header**: [src/inter/include/http/http_proto.h](../../../src/inter/include/http/http_proto.h)

`ProtoCtx` manages the protocol state for a connection, bridging TCP I/O with HTTP semantics.

**Structure**:
```c
typedef struct proto {
    Type type;
    util u;                // User data (pollfd for TCP)
    Buff *in;              // Input buffer (request)
    Span *outSpan;         // Output span (multiple buffers)
    Buff *out;             // Output buffer (response)
    void *ctx;             // Protocol-specific context (HttpCtx)
} ProtoCtx;
```

#### Core Functions

```c
ProtoCtx *HttpProto_Make(MemCh *m);
```

Creates a protocol context for HTTP.

**Example**:
```c
ProtoCtx *proto = HttpProto_Make(m);
proto->in = Buff_Make(m, BUFF_READ);
proto->out = Buff_Make(m, BUFF_WRITE);
proto->ctx = HttpCtx_Make(m);
```

---

```c
status HttpProto_AddBuff(ProtoCtx *proto, Buff *bf);
```

Adds a buffer to the output span (for multi-part responses).

**Example**:
```c
Buff *header = Buff_Make(m, 0);
HttpCtx_WriteHeaders(header, ctx);
HttpProto_AddBuff(proto, header);

Buff *body = Buff_Make(m, 0);
// ... generate body ...
HttpProto_AddBuff(proto, body);
```

---

```c
status HttpProto_PrepareResponse(ProtoCtx *proto, Task *tsk);
```

Finalizes the response for sending. Combines all buffers from `outSpan` into `out`.

**Example**:
```c
// Add headers and body
HttpProto_AddBuff(proto, header_buf);
HttpProto_AddBuff(proto, body_buf);

// Finalize for sending
HttpProto_PrepareResponse(proto, tsk);

// Response now ready in proto->out
Task_AddStep(tsk, TcpTask_WriteFromOut, NULL, proto, 0);
```

---

### HTTP Task Operations

**Header**: [src/inter/include/http/http_task.h](../../../src/inter/include/http/http_task.h)

Task-based HTTP operations integrate HTTP with Caneka's async execution model.

```c
status HttpTask_InitResponse(Task *tsk, void *arg, void *source);
```

Initializes response handling for a task.

**Example**:
```c
Task_AddStep(tsk, HttpTask_InitResponse, NULL, ctx, 0);
```

---

```c
status HttpTask_AddRecieve(Task *tsk, void *arg, void *source);
```

Sets up request receiving (polling for data).

**Example**:
```c
Task_AddStep(tsk, HttpTask_AddRecieve, NULL, proto, 0);
```

---

### HTTP Request Parsing

**Header**: [src/inter/include/http/http_roebling.h](../../../src/inter/include/http/http_roebling.h)

HTTP request parsing using Roebling pattern matching.

```c
Roebling *HttpRbl_Make(MemCh *m, Cursor *curs, void *source);
```

Creates an HTTP request parser.

**Parses**:
- Request line (e.g., `GET /path HTTP/1.1`)
- Headers (e.g., `Content-Type: application/json`)
- Body (delegates to `HttpCtx_ParseBody()`)

**Example**:
```c
StrVec *request = /* TCP receive */;
Cursor *curs = Cursor_Make(m, request);
HttpCtx *ctx = HttpCtx_Make(m);

Roebling *rbl = HttpRbl_Make(m, curs, ctx);
Roebling_Run(rbl);

// ctx now populated with method, path, headers
```

**State machine**:
1. Parse request line → extract method, path, version
2. Parse headers → populate headersIt
3. Parse body (if present) → populate body

---


## Templ Module - Template Engine

**Headers**: [src/inter/include/templ/](../../../src/inter/include/templ/)

The Templ module provides a powerful template engine with variable binding, iteration, and control flow. Templates are **compiled** (parsed once) and **rendered** (many times) for efficiency.

**See also**: [Templ Complete Guide](../core-concepts/templ-complete.md)

### Templ - Template Structure

**Header**: [src/inter/include/templ/templ.h](../../../src/inter/include/templ/templ.h)

`Templ` represents a compiled template ready for rendering.

**Structure**:
```c
typedef struct templ {
    Type type;
    Type objType;          // Template object type
    MemCh *m;              // Memory chapter
    i32 indent;            // Current indentation level
    i16 level;             // Nesting level (for debugging)
    Iter content;          // Template content iterator
    Iter data;             // Data stack (for WITH/FOR contexts)
} Templ;
```

**Template Phases**:
1. **Parse**: Roebling parses `.templ` file → Span of content items
2. **Prepare**: `Templ_Prepare()` analyzes jumps and bindings
3. **Render**: `Templ_ToS()` renders with data to output buffer

#### Core Functions

```c
Templ *Templ_Make(MemCh *m, Span *content);
```

Creates a template from parsed content.

**Parameters**:
- `m`: Memory chapter
- `content`: Span of template items (from Roebling parser)

**Example**:
```c
// Parse template file
StrVec *tmpl_src = File_ToVec(m, Str_FromCstr(m, "page.templ", 0));
Cursor *curs = Cursor_Make(m, tmpl_src);
Roebling *rbl = Templ_RoeblingMake(m, curs, NULL);
Roebling_Run(rbl);

Span *content = /* get from parser */;
Templ *templ = Templ_Make(m, content);
```

---

#### Preparation

```c
status Templ_Prepare(Templ *templ);
```

Prepares the template for rendering (analyzes control flow, validates jumps).

**What it does**:
1. Scans content for jump markers (FOR, WITH, IF, END)
2. Creates TemplJump objects for control flow
3. Validates jump targets (ensures every FOR/IF has matching END)
4. Optimizes jump indices

**Example**:
```c
Templ *templ = Templ_Make(m, content);
status r = Templ_Prepare(templ);
if (r != READY) {
    // Template has syntax errors (mismatched FOR/END, etc.)
}
```

---

```c
status Templ_PrepareCycle(Templ *templ);
```

Executes one preparation cycle (for incremental preparation).

**Example**:
```c
while (Templ_PrepareCycle(templ) == READY) {
    // Preparing...
}
```

---

```c
status Templ_Reset(Templ *templ);
```

Resets template state for reuse (clears data stack, resets iterators).

**Example**:
```c
// Render with first dataset
Templ_SetData(templ, user1);
Templ_ToS(templ, bf, user1, NULL);

// Reset and render with second dataset
Templ_Reset(templ);
Templ_SetData(templ, user2);
Templ_ToS(templ, bf, user2, NULL);
```

---

#### Rendering

```c
i64 Templ_ToS(Templ *templ, Buff *bf, void *data, void *source);
```

Renders the template with data to a buffer.

**Parameters**:
- `templ`: Prepared template
- `bf`: Output buffer
- `data`: Data to render (usually Inst or Table)
- `source`: Source context (HttpCtx, etc.)

**Returns**: Number of bytes written, or negative on error.

**Example**:
```c
// Template: <h1>{title}</h1><p>{description}</p>
Inst *page = Inst_Make(m, CLS(WwwPage));
Inst_SetAtt(page, Str_FromCstr(m, "title", 0), Str_FromCstr(m, "Home", 0));
Inst_SetAtt(page, Str_FromCstr(m, "description", 0), Str_FromCstr(m, "Welcome", 0));

Buff *output = Buff_Make(m, 0);
Templ_ToS(templ, output, page, NULL);
// output: <h1>Home</h1><p>Welcome</p>
```

---

```c
i64 Templ_ToSCycle(Templ *templ, Buff *bf, i64 total, void *source);
```

Renders one cycle (for incremental rendering).

**Example**:
```c
i64 total = 0;
status r;
while ((r = Templ_ToSCycle(templ, bf, total, NULL)) == READY) {
    total = r;
}
```

---

```c
status Templ_SetData(Templ *templ, void *data);
```

Binds data to the template (sets the root data context).

**Example**:
```c
Inst *user = /* ... */;
Templ_SetData(templ, user);
Templ_ToS(templ, bf, user, NULL);
```

---

### TemplJump - Control Flow

**Header**: [src/inter/include/templ/templ_jump.h](../../../src/inter/include/templ/templ_jump.h)

`TemplJump` represents control flow structures: FOR loops, WITH blocks, IF/IFNOT conditionals.

**Structure**:
```c
typedef struct templ_jump {
    Type type;
    Type sourceType;       // Jump type (FOR, WITH, IF, etc.)
    Fetcher *fch;          // Condition/iteration fetcher
    i32 idx;               // Jump location in content
    struct {
        JumpCrit dest;     // Loop back destination (FOR)
        JumpCrit skip;     // Skip on false (IF)
        JumpCrit ret;      // Return point (END)
    } crit;
} TemplJump;
```

#### Jump Types

Controlled by `sourceType` flags:
- `FETCHER_FOR` - FOR loop (iterate over collection)
- `FETCHER_WITH` - WITH block (context switch)
- `FETCHER_IF` - IF conditional (skip if false)
- `FETCHER_IFNOT` - IFNOT conditional (skip if true)
- `FETCHER_END` - END marker (close block)

#### Core Functions

```c
TemplJump *TemplJump_Make(MemCh *m, i32 idx, Fetcher *fch);
```

Creates a jump for control flow.

**Example**:
```c
// FOR jump: iterate over users
Fetcher *users_fch = FetchTarget_MakeKey(m, Str_FromCstr(m, "users", 0));
TemplJump *for_jump = TemplJump_Make(m, content_idx, users_fch);
for_jump->sourceType = FETCHER_FOR;
```

---

```c
status Templ_HandleJump(Templ *templ);
```

Processes a jump during rendering.

**What it does**:
1. Evaluates jump condition/iteration via fetcher
2. Updates data stack (pushes context for FOR/WITH)
3. Adjusts content iterator (loops back, skips forward, or returns)

**Example** (internal use during rendering):
```c
// Encountered FOR jump
Templ_HandleJump(templ);
// Data stack updated, iterator positioned at loop body
```

---

#### Template Syntax Examples

**Variable binding**:
```html
<h1>{title}</h1>
<p>{user.name}</p>
```

**FOR loop**:
```html
<ul>
{for item in items}
    <li>{item.name}</li>
{end}
</ul>
```

**WITH context**:
```html
{with user}
    <p>Name: {name}</p>
    <p>Email: {email}</p>
{end}
```

**IF conditional**:
```html
{if authenticated}
    <a href="/logout">Logout</a>
{end}
{ifnot authenticated}
    <a href="/login">Login</a>
{end}
```

---

### TemplCtx - Template Context

**Header**: [src/inter/include/templ/templ_ctx.h](../../../src/inter/include/templ/templ_ctx.h)

`TemplCtx` manages parsing and preparation state.

```c
TemplCtx *TemplCtx_Make(MemCh *m, Cursor *curs, Abstract *source);
```

Creates a template context for parsing.

---

```c
TemplCtx *TemplCtx_FromCurs(MemCh *m, Cursor *curs, Abstract *source);
```

Creates context from cursor.

**Example**:
```c
Cursor *curs = Cursor_Make(m, template_source);
TemplCtx *ctx = TemplCtx_FromCurs(m, curs, NULL);
```

---

### Template Parsing

**Header**: [src/inter/include/templ/templ_roebling.h](../../../src/inter/include/templ/templ_roebling.h)

```c
Roebling *Templ_RoeblingMake(MemCh *m, Cursor *curs, void *source);
```

Creates a template parser.

**Parses**:
- Plain text → output as-is
- Variables `{name}` → Fetcher for property access
- Control structures `{for...}`, `{if...}`, `{end}` → TemplJump

**Example**:
```c
StrVec *tmpl = File_ToVec(m, Str_FromCstr(m, "page.templ", 0));
Cursor *curs = Cursor_Make(m, tmpl);
Roebling *rbl = Templ_RoeblingMake(m, curs, NULL);
Roebling_Run(rbl);
// Parsed content now available
```

---

### Template Initialization

```c
status Templ_ClsInit(MemCh *m);
```

Initializes the template type system.

---


## WWW Module - Web Server

**Headers**: [src/inter/include/www/](../../../src/inter/include/www/)

The WWW module implements a complete web server with filesystem-driven routing, static file serving, template rendering, and HTTP caching.

**See also**: [WWW Routing Complete Guide](../core-concepts/www-routing-complete.md)

### WebServer - Server Management

**Header**: [src/inter/include/www/webserver.h](../../../src/inter/include/www/webserver.h)

```c
Task *WebServer_Make(i32 port, quad ip4, util *ip6);
```

Creates a web server task.

**Parameters**:
- `port`: Port to listen on (e.g., 3000, 8080)
- `ip4`: IPv4 address (0 for any)
- `ip6`: IPv6 address (NULL for none)

**Returns**: Task that runs the server (use with `Task_Tumble()`)

**Example**:
```c
Task *server = WebServer_Make(3000, 0, NULL);
printf("Server listening on http://localhost:3000\n");
Task_Tumble(server);  // Run (infinite loop)
```

---

```c
status WebServer_SetConfig(Task *tsk, StrVec *path, NodeObj *config, Table *handlers);
```

Configures the server with document root and handlers.

**Parameters**:
- `tsk`: Server task
- `path`: Document root directory
- `config`: Configuration (routes, extensions, etc.)
- `handlers`: Route handler table

**Example**:
```c
Task *tsk = WebServer_Make(3000, 0, NULL);

StrVec *doc_root = /* path to www/ */;
NodeObj *config = /* parsed from .config file */;
Table *handlers = /* route handlers */;

WebServer_SetConfig(tsk, doc_root, config, handlers);
Task_Tumble(tsk);
```

---

```c
status WebServer_AddRoute(MemCh *m, Route *pages, StrVec *dir, StrVec *path);
```

Adds a route directory to the route tree.

**Example**:
```c
Route *root = Route_Make(m);
WebServer_AddRoute(m, root,
                   Str_FromCstr(m, "www/pages", 0),
                   Str_FromCstr(m, "/", 0));
```

---

#### Server Task Steps

```c
status WebServer_ServePage(Step *st, Task *tsk);
```

Task step that serves a page (handler dispatch).

**Example**:
```c
Task_AddStep(tsk, WebServer_ServePage, NULL, ctx, 0);
```

---

```c
status WebServer_GatherPage(Step *st, Task *tsk);
```

Task step that gathers page content (preparation).

**Example**:
```c
Task_AddStep(tsk, WebServer_GatherPage, NULL, ctx, 0);
```

---

### Route - Routing System

**Header**: [src/inter/include/www/route.h](../../../src/inter/include/www/route.h)

`Route` represents a node in the routing tree. Routes are Inst objects with special properties.

**Type Definition**:
```c
typedef Inst Route;
```

#### Route Flags

```c
enum route_flags {
    ROUTE_STATIC = 1 << 8,      // Static file (CSS, JS, images)
    ROUTE_DYNAMIC = 1 << 9,     // Dynamic content (templates)
    ROUTE_FMT = 1 << 10,        // Format message (Pencil → HTML)
    ROUTE_INDEX = 1 << 13,      // Index page (directory → index.html)
    ROUTE_BINSEG = 1 << 11,     // Binary segment database
    ROUTE_ASSET = 1 << 12,      // Asset (cacheable)
    ROUTE_ACTION = 1 << 14,     // Action handler (POST/PUT/DELETE)
    ROUTE_FORBIDDEN = 1 << 15,  // Forbidden (403)
};
```

#### Route Properties

Routes are Inst objects with these properties:

```c
enum route_prop_idx {
    ROUTE_PROPIDX_PATH = 0,        // Request path (StrVec)
    ROUTE_PROPIDX_DATA = 1,        // Associated data (Table)
    ROUTE_PROPIDX_CHILDREN = 2,    // Child routes (Table)
    ROUTE_ROUTE_GENS = 3,          // Route generators (Span)
};
```

#### Core Functions

```c
Route *Route_Make(MemCh *m);
```

Creates an empty route.

**Example**:
```c
Route *root = Route_Make(m);
```

---

```c
Route *Route_From(MemCh *m, StrVec *dir);
```

Builds a route tree from a directory structure.

**How it works**:
1. Scans directory recursively
2. Creates route for each file/directory
3. Maps extensions to handlers (.templ → template, .html → static, etc.)
4. Loads .config files for configuration

**Example**:
```c
// Directory structure:
// www/
//   pages/
//     index.templ
//     about.html
//     users/
//       list.templ
//       profile.templ

Route *pages = Route_From(m, Str_FromCstr(m, "www/pages", 0));
// Creates route tree:
// / → index.templ
// /about → about.html
// /users → list.templ
// /users/profile → profile.templ
```

---

```c
status Route_SetTargetFile(Route *rt, Str *ext, Str *absPath);
```

Associates a file with a route for a specific extension.

**Example**:
```c
Route_SetTargetFile(route,
                    Str_FromCstr(m, "templ", 0),
                    Str_FromCstr(m, "/var/www/page.templ", 0));
```

---

```c
Route *Route_Get(Route *rt, StrVec *path);
```

Finds a route matching the request path.

**Example**:
```c
// Request: GET /users/profile
StrVec *path = /* parse "/users/profile" */;
Route *matched = Route_Get(root, path);
// matched → users/profile.templ route
```

**Matching rules**:
1. Exact match (e.g., `/users/profile` → `users/profile.templ`)
2. Index fallback (e.g., `/users/` → `users/index.templ`)
3. Extension mapping (e.g., `/users/list` → `users/list.templ`)

---

```c
status Route_Handle(Route *rt, Span *dest, Inst *data, HttpCtx *ctx);
```

Handles a request by dispatching to the appropriate route handler.

**Parameters**:
- `rt`: Matched route
- `dest`: Output buffer span
- `data`: Page data (WwwPage instance)
- `ctx`: HTTP context

**Example**:
```c
Route *route = Route_Get(pages, ctx->path);
Span *output = Span_Make(m);
Inst *page_data = /* ... */;

Route_Handle(route, output, page_data, ctx);
// output contains rendered response
```

**Dispatch logic**:
1. Checks route flags (STATIC, DYNAMIC, FMT, BINSEG)
2. Calls appropriate handler:
   - STATIC → `routeFuncStatic()` (file serve)
   - DYNAMIC → `routeFuncTempl()` (template render)
   - FMT → `routeFuncFmt()` (Pencil to HTML)
   - BINSEG → `routeFuncFileDb()` (database ops)

---

```c
status Route_Prepare(Route *rt);
```

Prepares a route for use (loads templates, validates configuration).

**Example**:
```c
Route *route = Route_From(m, doc_root);
Route_Prepare(route);  // Load and compile templates
```

---

#### Configuration

```c
status Route_CollectConfig(Route *root, StrVec *name, StrVec *path, Table *configAtts);
```

Collects configuration from .config files in the route tree.

**How it works**:
1. Scans route tree for .config files
2. Parses config files (using Config_FromPath)
3. Merges configuration hierarchically (children inherit from parents)

**Example**:
```c
// www/pages/.config:
// ext: templ html
// header: inc/header.templ
//
// www/pages/blog/.config:
// ext: templ
// sidebar: inc/sidebar.templ

Route_CollectConfig(root, name, path, config_table);
// blog routes inherit header, add sidebar
```

---

#### ETag Support

```c
status Route_CheckEtag(Route *rt, StrVec *etag);
```

Checks if the provided ETag matches the route's ETag.

**Example**:
```c
StrVec *client_etag = /* from If-None-Match header */;
if (Route_CheckEtag(route, client_etag) == READY) {
    // ETag matches—return 304 Not Modified
    ctx->code = HTTP_STATUS_NOT_MODIFIED;
    return READY;
}
```

---

```c
status Route_SetEtag(Route *rt, Str *path, struct timespec *mod);
```

Sets the ETag for a route based on file path and modification time.

**Example**:
```c
struct timespec modtime;
File_ModTime(m, file_path, &modtime);
Route_SetEtag(route, file_path, &modtime);
```

---

#### MIME Type System

```c
Single *Route_MimeFunc(StrVec *path);
```

Gets the MIME type function for a file path based on extension.

**Example**:
```c
StrVec *path = Str_FromCstr(m, "image.png", 0);
Single *mime = Route_MimeFunc(path);
// mime contains "image/png"
```

**Supported types**:
- `.html` → `text/html`
- `.css` → `text/css`
- `.js` → `application/javascript`
- `.json` → `application/json`
- `.png` → `image/png`
- `.jpg`, `.jpeg` → `image/jpeg`
- `.gif` → `image/gif`
- `.svg` → `image/svg+xml`
- `.txt` → `text/plain`
- etc.

---

```c
extern Span *RouteFuncTable;
extern Span *RouteMimeTable;
```

Global tables for route handlers and MIME types.

---

#### Route Initialization

```c
status Route_Init(MemCh *m);
```

Initializes the route type system.

---

### RouteGen - Route Generator

**Structure**:
```c
typedef struct route_gen {
    Type type;
    StrVec *path;        // Route path
    Table *headers;      // Response headers
    Templ *templ;        // Template (if dynamic)
    Str *mime;           // MIME type
    Str *ext;            // File extension
    Abstract *action;    // Action handler
    TaskFunc taskFunc;   // Task function
    RouteGenType *gen;   // Generator type
} RouteGen;
```

```c
RouteGen *RouteGen_Make(MemCh *m);
```

Creates a route generator.

**Example**:
```c
RouteGen *gen = RouteGen_Make(m);
gen->path = Str_FromCstr(m, "/users", 0);
gen->templ = user_list_template;
gen->mime = Str_FromCstr(m, "text/html", 0);
```

---

### Route Handler Type

```c
typedef status (*RouteFunc)(Buff *bf, Route *rt, Inst *data, HttpCtx *ctx);
```

Route handler function signature.

**Parameters**:
- `bf`: Output buffer
- `rt`: Matched route
- `data`: Page data
- `ctx`: HTTP context

**Built-in handlers**:
```c
routeFuncStatic()     // Serve static files
routeFuncTempl()      // Render templates
routeFuncFmt()        // Pencil to HTML
routeFuncFileDb()     // BinSeg database CRUD
```

---

### Page & Navigation Types

#### WwwPage

**Header**: [src/inter/include/www/page.h](../../../src/inter/include/www/page.h)

```c
typedef Inst WwwPage;

status WwwPage_Init(MemCh *m);
```

WwwPage represents page data (title, content, metadata).

**Example**:
```c
Inst *page = Inst_Make(m, CLS(WwwPage));
Inst_SetAtt(page, Str_FromCstr(m, "title", 0), Str_FromCstr(m, "Home", 0));
Inst_SetAtt(page, Str_FromCstr(m, "content", 0), Str_FromCstr(m, "Welcome!", 0));
```

---

#### WwwNav

**Header**: [src/inter/include/www/nav.h](../../../src/inter/include/www/nav.h)

```c
typedef Inst WwwNav;

status WwwNav_Init(MemCh *m);
```

WwwNav represents navigation structures (menus, breadcrumbs).

**Example**:
```c
Inst *nav = Inst_Make(m, CLS(WwwNav));
// Add navigation items...
```

---

### URL Utilities

**Header**: [src/inter/include/www/utils.h](../../../src/inter/include/www/utils.h)

```c
StrVec *WwwUtils_UrlSeg(MemCh *m, StrVec *v);
```

Converts a path to URL segments.

**Example**:
```c
StrVec *path = Str_FromCstr(m, "/users/123/profile", 0);
StrVec *segments = WwwUtils_UrlSeg(m, path);
// segments = ["users", "123", "profile"]
```

---



---

**Part 1 of 2** | [Part 2 →](inter-part2)
