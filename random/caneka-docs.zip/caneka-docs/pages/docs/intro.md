---
sidebar_position: 1
---

# Introduction to Caneka

Welcome to Caneka - **The Glass-Bottom-Boat of Programming Language Runtimes**.

## What is Caneka?

What could you do if you knew what happened between your programming language and the hardware?

Caneka is a full-stack + web-server + database replacement for a web development runtime. Based entirely on simplistic components written from scratch in C, it provides transparency and reliability while maintaining minimal dependencies.

## Documentation Focus

This documentation exists to build a shared, precise understanding of Caneka's
language surface, runtime behavior, and architecture before any DSL changes are
attempted. Treat these pages as the canonical reference and verify details
against the implementation in `src/` and the examples in `examples/`.

When behavior is inferred or not yet fully specified, it is labeled clearly.
Spec intent and implementation details are separated so readers can see what is
guaranteed today versus what is still evolving.

See [Documentation Goals](documentation-goals.md) for the full intent and scope.

## Docs Status

Coverage snapshot (update as sections evolve):

- Architecture: baseline coverage in place, refine with code-level details.
- Core Concepts: baseline coverage, expand deeper references and invariants.
- Formats (`.cnk`, `.templ`, `.fmt`, `.config`): baseline docs, add precise syntax and edge cases.
- API Reference: initial coverage, fill gaps and verify against headers.
- Guides: initial coverage, expand with verified workflows and examples.

### Key Features

- **Full Transparency**: See exactly what happens between your code and the hardware
- **Minimal Dependencies**: Only requires POSIX OS and C compiler
- **From-Scratch Design**: Built on fundamental components for maximum control
- **Syntax-Agnostic**: Create custom Domain Specific Languages (DSLs) with the Roebling parser
- **Complete Stack**: Memory management, web server, templates, database, and more

## Why Caneka?

Caneka was born from the idea that productivity in software engineering needed new tooling. Programming languages seemed to stall after Object-Oriented Programming (OOP):

- **Level 1**: Assembly
- **Level 2**: Types (C)
- **Level 3**: Objects (C++, Java, JavaScript, Python, etc.)
- **Level 4**: Composition/Implicit Handling (?)

We never fully reached Level 4 - a place where developers spend more time on composition than repetitive details. Caneka aims to enable that next evolution through transparent, composable components.

## Core Philosophy

### Built from Simplistic Components

Every component in Caneka is written from scratch in C, allowing you to understand and verify exactly what your runtime is doing. No black boxes, no hidden abstractions - just transparent, reliable code.

### Minimal Dependencies

Caneka only requires:
- A POSIX-compliant operating system
- A C compiler (clang or gcc)

That's it. No package manager, no complex dependency tree, no version conflicts.

### Syntax Agnostic

The Roebling parser acts like "a regular expression engine that can generate and run data structures," enabling teams to create custom Domain Specific Languages that map directly to their problem space.

## What's Included

Caneka provides a complete runtime stack:

- **Base Layer**: Memory management, types, strings, sequences, I/O
- **Extended Layer**: Roebling parser, Task/Step workflow, network server, Seel type system
- **Inter Layer**: HTTP handling, template engine, web server
- **Programs**: Build system, web server, CLI tools, test suite

See the [Architecture Overview](architecture/overview.md) for detailed information about each layer.

## Quick Start

Ready to dive in? Check out the [Getting Started](getting-started/installation.md) guide to build and run Caneka.

## Custom Formats

Caneka includes several custom formats for different purposes:

- **Pencil (.fmt)**: Document format for human-readable content
- **Templ (.templ)**: Template engine for HTML generation
- **Caneka (.cnk)**: Language format for type definitions
- **Config (.config)**: Configuration files

Learn more in the [Custom Formats](formats/pencil-fmt.md) section.

## Community

Caneka is developed by [Compare Basic](https://comparebasic.com) and released under the 3-Clause BSD License.

- **Website**: [caneka.org](https://caneka.org)
- **GitHub**: [github.com/comparebasic/caneka](https://github.com/comparebasic/caneka)
- **License**: 3-Clause BSD (with some public domain components)

## Next Steps

- [Install and Build Caneka](getting-started/installation.md)
- [Understand the Architecture](architecture/overview.md)
- [Explore Core Concepts](core-concepts/memory/overview.md)
- [View API Reference](api-reference/base.md)
