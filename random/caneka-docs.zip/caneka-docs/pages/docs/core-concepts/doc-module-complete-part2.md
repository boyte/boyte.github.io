# Doc Module: Complete Guide - Part 2

[← Part 1](doc-module-complete-part1) | **Part 2 of 3** | [Part 3 →](doc-module-complete-part3)

---

## Code Examples

### Example 1: Basic Document Parsing

Parse a Pencil document from a file:

```c
MemCh *m = MemCh_Make();

// Load .fmt file
Str *path = S(m, "example.fmt");
StrVec *content = File_ToVec(m, path);

if(content == NULL){
    Error(m, FUNCNAME, FILENAME, LINENUMBER, "File not found: $", (void *[]){path, NULL});
    return ERROR;
}

// Create cursor over content
Cursor *curs = Cursor_Make(m, content);

// Create Fmt parser
Roebling *rbl = FormatFmt_Make(m, curs, NULL);

// Execute parser
status r = Roebling_Run(rbl);

if(r & ERROR){
    Error(m, FUNCNAME, FILENAME, LINENUMBER, "Parse error", NULL);
    return ERROR;
}

// Extract parsed Mess tree
Mess *mess = (Mess *)rbl->dest;

// Tree is now ready for HTML generation or inspection
```

### Example 2: HTML Generation

Generate HTML from a parsed Mess tree:

```c
MemCh *m = MemCh_Make();

// Assume 'mess' is a parsed Mess tree from Example 1

// Create output buffer
Buff *bf = Buff_Make(m, ZERO);

// Generate HTML
status r = Fmt_ToHtml(bf, mess);

if(r & ERROR){
    Error(m, FUNCNAME, FILENAME, LINENUMBER, "HTML generation failed", NULL);
    return ERROR;
}

// Convert buffer to string
Str *html = StrVec_Str(m, bf->v);

// Output can now be sent to HTTP client, written to file, etc.
printf("Generated HTML:\n%s\n", Str_Chars(html));
```

### Example 3: Complete Pipeline with File Output

Parse a .fmt file and write HTML to disk:

```c
status ConvertFmtToHtml(MemCh *m, Str *inputPath, Str *outputPath){
    // Load input file
    StrVec *content = File_ToVec(m, inputPath);
    if(content == NULL){
        return ERROR;
    }

    // Parse
    Cursor *curs = Cursor_Make(m, content);
    Roebling *rbl = FormatFmt_Make(m, curs, NULL);
    status r = Roebling_Run(rbl);

    if(r & ERROR){
        return ERROR;
    }

    Mess *mess = (Mess *)rbl->dest;

    // Generate HTML
    Buff *bf = Buff_Make(m, ZERO);
    r = Fmt_ToHtml(bf, mess);

    if(r & ERROR){
        return ERROR;
    }

    // Write to file
    File *outFile = File_Make(m, outputPath, FILE_WRITE);
    if(outFile == NULL){
        return ERROR;
    }

    r = Buff_WriteTo(bf, outFile->bf);
    File_Close(outFile);

    return r;
}

// Usage
MemCh *m = MemCh_Make();
ConvertFmtToHtml(m, S(m, "docs/about.fmt"), S(m, "/tmp/about.html"));
```

### Example 4: CLI Tool Implementation

Complete CLI tool for document conversion (simplified from `src/programs/clineka/main.c`):

```c
int main(int argc, char **argv){
    MemCh *m = MemCh_Make();

    // Parse command-line arguments
    Str *inputPath = NULL;
    Str *outputPath = NULL;
    Str *configPath = NULL;

    for(i32 i = 1; i < argc; i++){
        if(strcmp(argv[i], "--in") == 0 && i + 1 < argc){
            inputPath = S(m, argv[++i]);
        }else if(strcmp(argv[i], "--out") == 0 && i + 1 < argc){
            outputPath = S(m, argv[++i]);
        }else if(strcmp(argv[i], "--config") == 0 && i + 1 < argc){
            configPath = S(m, argv[++i]);
        }
    }

    if(inputPath == NULL || outputPath == NULL){
        printf("Usage: %s --in input.fmt --out output.html [--config wrapper.config]\n", argv[0]);
        return 1;
    }

    // Optional: Load wrapper config (header/footer HTML)
    Str *header = NULL;
    Str *footer = NULL;

    if(configPath != NULL){
        // Load config file with header/footer templates
        // (Config parser details omitted for brevity)
    }

    // Load and parse input file
    StrVec *content = File_ToVec(m, inputPath);
    if(content == NULL){
        fprintf(stderr, "Error: Could not read %s\n", Str_Chars(inputPath));
        return 1;
    }

    Cursor *curs = Cursor_Make(m, content);
    Roebling *rbl = FormatFmt_Make(m, curs, NULL);
    status r = Roebling_Run(rbl);

    if(r & ERROR){
        fprintf(stderr, "Error: Parse failed for %s\n", Str_Chars(inputPath));
        return 1;
    }

    Mess *mess = (Mess *)rbl->dest;

    // Generate HTML
    Buff *bf = Buff_Make(m, ZERO);

    // Add header if configured
    if(header != NULL){
        ToS(bf, header, 0, ZERO);
    }

    r = Fmt_ToHtml(bf, mess);

    if(r & ERROR){
        fprintf(stderr, "Error: HTML generation failed\n");
        return 1;
    }

    // Add footer if configured
    if(footer != NULL){
        ToS(bf, footer, 0, ZERO);
    }

    // Write output file
    File *outFile = File_Make(m, outputPath, FILE_WRITE);
    if(outFile == NULL){
        fprintf(stderr, "Error: Could not create %s\n", Str_Chars(outputPath));
        return 1;
    }

    r = Buff_WriteTo(bf, outFile->bf);
    File_Close(outFile);

    if(r & ERROR){
        fprintf(stderr, "Error: Write failed\n");
        return 1;
    }

    printf("Successfully converted %s → %s\n",
           Str_Chars(inputPath), Str_Chars(outputPath));

    return 0;
}
```

**Usage**:
```bash
./dist/bin/clineka --in examples/example.fmt --out /tmp/output.html
./dist/bin/clineka --in docs/about.fmt --out /tmp/about.html --config wrapper.config
```

### Example 5: Web Server Route Handler

HTTP server integration (from `src/inter/www/route.c`):

```c
static status routeFuncFmt(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get cached Mess from route (parsed at startup)
    Mess *mess = (Mess *)as(Seel_Get(rt, K(m, "action")), TYPE_MESS);

    if(mess == NULL){
        Error(m, FUNCNAME, FILENAME, LINENUMBER, "No Mess in route", NULL);
        return ERROR;
    }

    // Generate HTML (fast - no parsing!)
    status r = Fmt_ToHtml(bf, mess);

    if(r & ERROR){
        Error(m, FUNCNAME, FILENAME, LINENUMBER, "HTML generation failed", NULL);
        return ERROR;
    }

    // Set HTTP headers
    HttpCtx_SetHeader(ctx, S(m, "Content-Type"), S(m, "text/html"));

    return SUCCESS;
}
```

When registered in the WWW routing system:
```
GET /documentation → documentation.fmt → routeFuncFmt → HTML response
GET /about → about.fmt → routeFuncFmt → HTML response
```

### Example 6: Inspecting Parsed Tree

Navigate and inspect a parsed Mess tree:

```c
void InspectMessTree(Mess *mess){
    MemCh *m = mess->m;

    printf("Mess Tree Inspection:\n");
    printf("Root node: %p\n", (void *)mess->root);

    // Walk tree with iterator
    Iter it;
    Iter_Init(&it, mess->root);

    i32 depth = 0;

    while((Iter_Next(&it) & END) == 0){
        Node *node = (Node *)Iter_Get(&it);

        // Track depth changes
        if(it.type.state & ITER_DESCENDING){
            depth++;
        }else if(it.type.state & ITER_ASCENDING){
            depth--;
        }

        // Print node info with indentation
        for(i32 i = 0; i < depth; i++){
            printf("  ");
        }

        printf("Node captureKey=%d ", node->captureKey);

        // Print node type name
        switch(node->captureKey){
        case FORMATTER_INDENT:
            printf("(HEADING level=%d)",
                   ((Single *)Table_Get(node->atts, S(m, "level")))->val.w);
            break;
        case FORMATTER_PARAGRAPH:
            printf("(PARAGRAPH)");
            break;
        case FORMATTER_BULLET:
            printf("(BULLET)");
            break;
        case FORMATTER_TABLE:
            printf("(TABLE)");
            break;
        case FORMATTER_TAG:
            printf("(TAG)");
            break;
        }

        // Print value if present
        if(node->value != NULL && node->value->type.of == TYPE_STRVEC){
            StrVec *v = (StrVec *)node->value;
            Str *s = StrVec_Str(m, v);
            printf(" value=\"%s\"", Str_Chars(s));
        }

        printf("\n");
    }
}
```

**Example Output**:
```
Mess Tree Inspection:
Root node: 0x7f8b12345678
  Node captureKey=100 (HEADING level=1) value="Introduction"
  Node captureKey=200 (PARAGRAPH) value="This is the first paragraph."
  Node captureKey=200 (PARAGRAPH) value="This is the second paragraph."
  Node captureKey=300 (BULLET) value="First item"
  Node captureKey=300 (BULLET) value="Second item"
  Node captureKey=100 (HEADING level=2) value="Details"
    Node captureKey=500 (TAG) value="Click here"
```

### Example 7: Custom HTML Generator

Add a custom generator for a new element type:

```c
// Custom generator for code blocks (hypothetical feature)
static i64 codeBlockFunc(TranspCtx *ctx, word flags){
    Node *node = (Node *)Iter_Get(&ctx->it);
    MemCh *m = ctx->m;

    if(flags & TRANSP_OPEN){
        // Get language from attributes
        Str *lang = (Str *)Table_Get(node->atts, S(m, "lang"));

        // Start <PRE><CODE> with optional language class
        Tag_Out(ctx->bf, "PRE", 0);

        if(lang != NULL){
            ToS(ctx->bf, S(m, "<CODE class=\"language-"), 0, ZERO);
            ToS(ctx->bf, lang, 0, ZERO);
            ToS(ctx->bf, S(m, "\">"), 0, ZERO);
        }else{
            Tag_Out(ctx->bf, "CODE", 0);
        }
    }

    if(flags & TRANSP_BODY){
        // Output code content (HTML-escaped)
        if(node->value != NULL){
            HtmlEnt_IntoVec(m, ctx->htmlEntRbl, (StrVec *)node->value);
            ToS(ctx->bf, ctx->htmlEntRbl->dest, 0, ZERO);
        }
    }

    if(flags & TRANSP_CLOSE){
        // Close </CODE></PRE>
        Tag_Out(ctx->bf, "CODE", TAG_CLOSE);
        Tag_Out(ctx->bf, "PRE", TAG_CLOSE);
    }

    return SUCCESS;
}

// Register custom generator
void RegisterCustomGenerators(Lookup *generatorLookup){
    Lookup_Set(generatorLookup, FORMATTER_CODE_BLOCK, (void *)codeBlockFunc);
}
```

This demonstrates the extensibility of the HTML generation system.

### Example 8: Streaming Generation

Generate HTML in streaming fashion for large documents:

```c
status StreamHtmlToSocket(MemCh *m, Mess *mess, Buff *socketBuff){
    // Create generation context
    TranspCtx *ctx = MemCh_Calloc(m, sizeof(TranspCtx));
    ctx->type.of = TYPE_TRANSP_CTX;
    ctx->m = m;

    // Use separate buffer for chunked output
    Buff *chunkBuff = Buff_Make(m, ZERO);
    ctx->bf = chunkBuff;

    ctx->htmlEntRbl = HtmlEnt_Make(m);
    ctx->lk = GetHtmlGeneratorLookup(m);

    // Walk tree
    Iter_Init(&ctx->it, mess->root);

    while((Iter_Next(&ctx->it) & END) == 0){
        Node *node = (Node *)Iter_Get(&ctx->it);
        TranspFunc func = (TranspFunc)Lookup_Get(ctx->lk, node->captureKey);

        if(func != NULL){
            func(ctx, TRANSP_OPEN | TRANSP_BODY | TRANSP_CLOSE);
        }

        // Flush chunk to socket if buffer gets large
        if(StrVec_ByteCount(chunkBuff->v) > 8192){
            Buff_WriteTo(chunkBuff, socketBuff);

            // Send to client
            status r = Buff_Flush(socketBuff);
            if(r & ERROR){
                return ERROR;
            }

            // Clear chunk buffer
            StrVec_Clear(chunkBuff->v);
        }
    }

    // Flush final chunk
    Buff_WriteTo(chunkBuff, socketBuff);
    return Buff_Flush(socketBuff);
}
```

This approach is useful for very large documents to reduce memory usage and improve time-to-first-byte.

### Example 9: Programmatic Mess Construction

Build a Mess tree programmatically without parsing:

```c
Mess *CreateProgrammaticMess(MemCh *m){
    // Create Mess structure
    Mess *mess = MemCh_Calloc(m, sizeof(Mess));
    mess->type.of = TYPE_MESS;
    mess->m = m;

    // Create root node
    Node *root = Node_Make(m, mess, FORMATTER_INDENT);
    mess->root = root;

    // Create heading
    Node *heading = Node_Make(m, mess, FORMATTER_INDENT);
    heading->parent = root;

    StrVec *headingText = StrVec_Make(m);
    StrVec_AppendS(headingText, "Generated Document");
    heading->value = (Abstract *)headingText;

    Single levelSingle = {.type = {TYPE_WRAPPED_I32, 0}, .val.w = 1};
    Table_Set(heading->atts, S(m, "level"), &levelSingle);

    // Create paragraph
    Node *para = Node_Make(m, mess, FORMATTER_PARAGRAPH);
    para->parent = root;

    StrVec *paraText = StrVec_Make(m);
    StrVec_AppendS(paraText, "This document was created programmatically.");
    para->value = (Abstract *)paraText;

    // Add nodes to root's children
    Span *children = Span_Make(m, TYPE_NODE);
    Span_Push(children, heading);
    Span_Push(children, para);
    root->child = (Abstract *)children;

    return mess;
}

// Usage
MemCh *m = MemCh_Make();
Mess *mess = CreateProgrammaticMess(m);
Buff *bf = Buff_Make(m, ZERO);
Fmt_ToHtml(bf, mess);

// Output: <H1>Generated Document</H1><P>This document was created programmatically.</P>
```

This demonstrates that Mess trees are just data structures and can be constructed without parsing.

### Example 10: Error Handling in Parsing

Robust error handling for malformed documents:

```c
status ParseFmtWithErrorHandling(MemCh *m, Str *path, Mess **outMess){
    *outMess = NULL;

    // Load file
    StrVec *content = File_ToVec(m, path);
    if(content == NULL){
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
              "File not found: $", (void *[]){path, NULL});
        return ERROR;
    }

    // Check for empty file
    if(StrVec_Count(content) == 0){
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
              "Empty file: $", (void *[]){path, NULL});
        return ERROR;
    }

    // Create cursor
    Cursor *curs = Cursor_Make(m, content);

    // Create parser
    Roebling *rbl = FormatFmt_Make(m, curs, NULL);
    if(rbl == NULL){
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
              "Parser creation failed", NULL);
        return ERROR;
    }

    // Execute parser
    status r = Roebling_Run(rbl);

    // Check for parse errors
    if(r & ERROR){
        // Try to extract error position
        i32 line = Cursor_Line(curs);
        i32 col = Cursor_Col(curs);

        Single lineSingle = {.type = {TYPE_WRAPPED_I32, 0}, .val.w = line};
        Single colSingle = {.type = {TYPE_WRAPPED_I32, 0}, .val.w = col};

        Error(m, FUNCNAME, FILENAME, LINENUMBER,
              "Parse error in $ at line $, column $",
              (void *[]){path, &lineSingle, &colSingle, NULL});

        return ERROR;
    }

    // Check for guard violations
    if(rbl->type.state & GUARD_ERROR){
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
              "Guard violation - possible infinite loop in parser", NULL);
        return ERROR;
    }

    // Extract Mess
    Mess *mess = (Mess *)rbl->dest;
    if(mess == NULL){
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
              "No Mess produced by parser", NULL);
        return ERROR;
    }

    // Validate Mess structure
    if(mess->root == NULL){
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
              "Mess has no root node", NULL);
        return ERROR;
    }

    *outMess = mess;
    return SUCCESS;
}
```

This demonstrates comprehensive error checking at every stage.

### Example 11: Performance Benchmarking

Measure parsing and generation performance:

```c
void BenchmarkFmtProcessing(MemCh *m, Str *path){
    struct timespec start, end;

    // Benchmark parsing
    clock_gettime(CLOCK_MONOTONIC, &start);

    StrVec *content = File_ToVec(m, path);
    Cursor *curs = Cursor_Make(m, content);
    Roebling *rbl = FormatFmt_Make(m, curs, NULL);
    Roebling_Run(rbl);

    clock_gettime(CLOCK_MONOTONIC, &end);

    i64 parseNanos = (end.tv_sec - start.tv_sec) * 1000000000 +
                     (end.tv_nsec - start.tv_nsec);

    Mess *mess = (Mess *)rbl->dest;

    // Benchmark HTML generation (multiple iterations for accuracy)
    i32 iterations = 1000;

    clock_gettime(CLOCK_MONOTONIC, &start);

    for(i32 i = 0; i < iterations; i++){
        Buff *bf = Buff_Make(m, ZERO);
        Fmt_ToHtml(bf, mess);
    }

    clock_gettime(CLOCK_MONOTONIC, &end);

    i64 genNanos = (end.tv_sec - start.tv_sec) * 1000000000 +
                   (end.tv_nsec - start.tv_nsec);
    i64 avgGenNanos = genNanos / iterations;

    // Report results
    printf("Fmt Processing Benchmark for %s:\n", Str_Chars(path));
    printf("  Parsing:    %ld μs\n", parseNanos / 1000);
    printf("  Generation: %ld μs (avg of %d iterations)\n",
           avgGenNanos / 1000, iterations);
    printf("  Speedup:    %.1fx (cached approach)\n",
           (double)parseNanos / (double)avgGenNanos);

    // File size
    i32 bytes = StrVec_ByteCount(content);
    printf("  File size:  %d bytes\n", bytes);
    printf("  Parse rate: %.1f MB/s\n",
           (double)bytes / (double)parseNanos * 1000.0);
}
```

**Example Output**:
```
Fmt Processing Benchmark for docs/about.fmt:
  Parsing:    523 μs
  Generation: 87 μs (avg of 1000 iterations)
  Speedup:    6.0x (cached approach)
  File size:  4237 bytes
  Parse rate: 7.7 MB/s
```

### Example 12: Integration with Template System

Use Fmt-generated HTML in Templ templates:

```c
// Generate HTML fragment from Fmt
status GenerateFmtFragment(MemCh *m, Str *fmtPath, Str **outHtml){
    StrVec *content = File_ToVec(m, fmtPath);
    Cursor *curs = Cursor_Make(m, content);
    Roebling *rbl = FormatFmt_Make(m, curs, NULL);

    status r = Roebling_Run(rbl);
    if(r & ERROR){
        return ERROR;
    }

    Mess *mess = (Mess *)rbl->dest;
    Buff *bf = Buff_Make(m, ZERO);

    r = Fmt_ToHtml(bf, mess);
    if(r & ERROR){
        return ERROR;
    }

    *outHtml = StrVec_Str(m, bf->v);
    return SUCCESS;
}

// Use in Templ data
status PrepareTemplData(MemCh *m, Table *data){
    // Generate content fragment
    Str *content = NULL;
    status r = GenerateFmtFragment(m, S(m, "docs/section.fmt"), &content);

    if(r & ERROR){
        return ERROR;
    }

    // Add to template data
    Table_Set(data, S(m, "content"), content);
    Table_Set(data, S(m, "title"), S(m, "Documentation"));

    return SUCCESS;
}
```

**Template file (page.templ)**:
```templ
<html>
<head>
  <title>{title}</title>
</head>
<body>
  {content}
</body>
</html>
```

**Result**: Fmt-generated HTML embedded in Templ-generated page.


## Performance Characteristics

### Parsing Performance

**Typical Rates**:
- **Small documents** (< 10KB): 200-500 μs, ~20-50 MB/s
- **Medium documents** (10-100KB): 0.5-5 ms, ~10-20 MB/s
- **Large documents** (> 100KB): 5-50 ms, ~5-10 MB/s

**Factors Affecting Parse Speed**:
1. **Document complexity** - More inline tags and tables slow parsing
2. **Line length** - Very long lines (> 1000 chars) degrade performance
3. **Nesting depth** - Deeply nested structures increase overhead
4. **Roebling pattern complexity** - More patterns = more backtracking

**Memory Usage During Parsing**:
- **StrVec content**: ~1x file size (stored as gap buffer)
- **Cursor state**: ~256 bytes
- **Roebling state**: ~1-2KB
- **Mess tree**: ~10-50x file size (depends on structure)
  - Each Node: ~128 bytes
  - Attributes: ~32 bytes per attribute
  - Text content: ~1x original size (separate StrVec per node)

**Example**: A 10KB document might produce a 200-500KB Mess tree.

### HTML Generation Performance

**Typical Rates**:
- **Simple documents**: 50-100 μs, ~50-200 MB/s
- **Complex documents**: 100-300 μs, ~20-50 MB/s
- **Very large documents**: 300-1000 μs, ~5-20 MB/s

**Bottlenecks**:
1. **HTML entity escaping** - Most expensive operation (~40% of time)
2. **String concatenation** - ToS() calls accumulate overhead (~30%)
3. **Tree traversal** - Iter operations (~20%)
4. **Lookup operations** - Function dispatch (~10%)

**Optimization Techniques**:

1. **Pre-escape content at parse time** (if content is static):
```c
// During parsing, escape immediately
HtmlEnt_IntoVec(m, escaper, textContent);
node->value = (Abstract *)escaper->dest;
```

2. **Buffer pre-allocation**:
```c
// Pre-allocate buffer to avoid reallocation
Buff *bf = Buff_Make(m, ZERO);
StrVec_Reserve(bf->v, estimatedSize);
```

3. **Batch string operations**:
```c
// Instead of multiple ToS() calls
ToS(bf, S(m, "<"), 0, ZERO);
ToS(bf, tagName, 0, ZERO);
ToS(bf, S(m, ">"), 0, ZERO);

// Use single StrVec_Appendf
StrVec_Appendf(bf->v, "<%s>", tagName);
```

### Memory Usage

**Startup Memory (per .fmt file)**:
- Mess tree: 10-50x file size
- Cached for entire server lifetime
- Example: 100 files × 10KB each × 30x = ~30MB

**Per-Request Memory**:
- Output buffer: ~1-2x file size
- TranspCtx: ~512 bytes
- Temporary escaping buffer: ~1x content size
- Total: ~2-3x file size, freed after response

**Trade-offs**:
- **High memory, fast requests** (current): Parse once, cache Mess, fast generation
- **Low memory, slow requests** (alternative): Parse on every request, no caching

The current approach prioritizes request latency over memory usage, which is appropriate for a web server with limited document count.

### Concurrency Characteristics

**Thread-Safety**:
- **Parsing**: NOT thread-safe (Roebling modifies state)
- **Mess tree**: Thread-safe read-only after creation
- **HTML generation**: Thread-safe if each thread has separate TranspCtx and Buff

**Recommended Pattern for Multi-Threaded Server**:
```c
// Startup: Parse once (single-threaded)
Mess *cachedMess = ParseFmt(m, path);

// Request handling: Generate HTML (multi-threaded)
void HandleRequest(HttpCtx *ctx, Mess *mess){
    MemCh *m = MemCh_Make();  // Thread-local memory
    Buff *bf = Buff_Make(m, ZERO);

    Fmt_ToHtml(bf, mess);  // Safe: mess is read-only, bf is thread-local

    HttpCtx_SendResponse(ctx, bf);
    MemCh_Free(m);
}
```

No locking required because:
- Mess tree is immutable after parsing
- Each request creates its own TranspCtx and Buff
- No shared mutable state during generation


## Best Practices

### 1. Parse Once, Generate Many

Always cache parsed Mess trees for documents that will be requested multiple times:

```c
// GOOD: Parse once at startup
Mess *aboutPageMess = ParseFmtFile(m, "docs/about.fmt");
Route_SetAction(aboutRoute, aboutPageMess);

// Per request: Fast generation only
Fmt_ToHtml(bf, aboutPageMess);
```

```c
// BAD: Re-parse on every request
StrVec *content = File_ToVec(m, "docs/about.fmt");
Cursor *curs = Cursor_Make(m, content);
Roebling *rbl = FormatFmt_Make(m, curs, NULL);
Roebling_Run(rbl);  // Wasteful!
Mess *mess = (Mess *)rbl->dest;
Fmt_ToHtml(bf, mess);
```

**Speedup**: 4-17x faster per request.

### 2. Use Appropriate Memory Contexts

Allocate parsing structures in long-lived memory, generation structures in request memory:

```c
// Startup: Use application-level MemCh
MemCh *appMemory = MemCh_Make();
Mess *cachedMess = ParseFmt(appMemory, path);

// Request: Use request-scoped MemCh
void HandleRequest(HttpCtx *ctx){
    MemCh *reqMemory = MemCh_Make();
    Buff *bf = Buff_Make(reqMemory, ZERO);

    Fmt_ToHtml(bf, cachedMess);

    SendResponse(ctx, bf);
    MemCh_Free(reqMemory);  // Clean up request allocations
}
```

### 3. Validate Input Files at Startup

Fail fast if documents are malformed:

```c
status InitializeRoutes(MemCh *m){
    Mess *mess = ParseFmt(m, "critical.fmt");

    if(mess == NULL){
        // Server won't start with broken documents
        Error(m, FUNCNAME, FILENAME, LINENUMBER, "Critical document failed to parse", NULL);
        return ERROR;
    }

    // Continue with valid tree
}
```

This prevents serving broken pages and makes errors visible during deployment.

### 4. Use HTML Entity Escaping

Always escape user-provided content to prevent XSS:

```c
// GOOD: Automatic escaping via Fmt_ToHtml
Fmt_ToHtml(bf, mess);  // All text content is escaped

// ALSO GOOD: Manual escaping for custom generators
HtmlEnt_IntoVec(m, escaper, userContent);
ToS(bf, escaper->dest, 0, ZERO);
```

```c
// BAD: Direct output of unescaped content
ToS(bf, userContent, 0, ZERO);  // Vulnerable to XSS!
```

### 5. Optimize for Common Case

Structure documents to minimize parser state changes:

```c
// GOOD: Simple linear structure
= Heading
Paragraph text.

Another paragraph.

- List item 1
- List item 2
```

```c
// LESS OPTIMAL: Frequent state changes
= Heading
_link=Link@url
More text
_image=Alt@src
- Item
More text
_link=Another@url
```

Frequent inline tags cause more state transitions and tokenization changes.

### 6. Pre-allocate Buffers for Known Sizes

If you know approximate output size:

```c
// Estimate: HTML is typically 2-3x source size
i32 estimatedSize = StrVec_ByteCount(sourceContent) * 3;

Buff *bf = Buff_Make(m, ZERO);
StrVec_Reserve(bf->v, estimatedSize);

Fmt_ToHtml(bf, mess);
```

Avoids multiple StrVec reallocations during generation.

### 7. Use Streaming for Very Large Documents

For documents > 100KB, consider streaming:

```c
// Instead of accumulating entire HTML in memory
TranspCtx *ctx = CreateTranspCtx(m, mess);

while(!TreeWalkComplete(ctx)){
    GenerateChunk(ctx);

    if(ChunkSizeExceeds(ctx, 8192)){
        FlushToSocket(ctx);
        ClearChunkBuffer(ctx);
    }
}
```

Reduces memory footprint and improves time-to-first-byte.

### 8. Leverage Mess Tree Inspection

For debugging, inspect the Mess tree structure:

```c
void DebugParsedDocument(Mess *mess){
    Iter it;
    Iter_Init(&it, mess->root);

    while((Iter_Next(&it) & END) == 0){
        Node *node = (Node *)Iter_Get(&it);
        PrintNodeInfo(node);  // Custom debug output
    }
}
```

This helps understand how the parser interpreted the document.

### 9. Handle Parse Errors Gracefully

Provide helpful error messages:

```c
status r = Roebling_Run(rbl);

if(r & ERROR){
    i32 line = Cursor_Line(curs);
    i32 col = Cursor_Col(curs);

    fprintf(stderr, "Parse error at line %d, column %d\n", line, col);

    // Optionally: Show context
    ShowLineContext(curs, line);
}
```

### 10. Document Custom Extensions

If you add custom generators or patterns:

```c
/**
 * Custom code block generator
 *
 * Syntax: ```language
 *         code content
 *         ```
 *
 * Generates: <PRE><CODE class="language-X">...</CODE></PRE>
 */
static i64 codeBlockFunc(TranspCtx *ctx, word flags){
    // Implementation
}
```

Clear documentation helps maintainers understand extensions.



---

[← Part 1](doc-module-complete-part1) | **Part 2 of 3** | [Part 3 →](doc-module-complete-part3)
