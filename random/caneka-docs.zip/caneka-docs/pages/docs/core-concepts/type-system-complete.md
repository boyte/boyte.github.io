---
sidebar_position: 6
---

# Type System - Complete Guide

Caneka's type system provides **runtime type identification**, **interface matching**, and **property schemas** from scratch, without relying on language-level features. Every object in Caneka carries its type with it, enabling polymorphism, type-safe casting, and dynamic property access.

## Core Philosophy

Traditional C has no runtime types—you cast blindly and hope for the best. Caneka builds a complete type system where:

1. **Every object knows its type** at runtime
2. **Interfaces** enable polymorphism (one interface, multiple implementations)
3. **Type-safe casting** prevents undefined behavior
4. **Property schemas** provide structured object access
5. **Wrapped primitives** make integers, booleans, and pointers first-class objects

## Type Header Structure

Every object in Caneka starts with a `Type` header:

```c
typedef struct typehdr {
    cls of;        // Type ID (word/uint16_t)
    status state;  // State flags (16-bit status flags)
} Type;

// All abstract objects embed Type
typedef struct virt {
    Type type;
} Abstract;
```

**Key Fields:**
- **type.of**: Runtime type identifier (1-65535)
- **type.state**: Bit flags for state and type-specific behaviors

### Example: String Structure

```c
typedef struct str {
    Type type;          // type.of = TYPE_STR
    word length;
    word alloc;
    byte *bytes;
} Str;

// Creating a string
Str *s = Str_From(m, "hello");
// s->type.of = TYPE_STR
// s->type.state = STRING_TEXT | STRING_UTF8
```

**Insight:** Because every object starts with `Type`, you can cast any pointer to `Abstract*` and read its `type.of` to identify what it is.

## Type ID System

Caneka defines 100+ type IDs organized by category.

### Type Categories

```c
// Raw Types (primitives)
_TYPE_ZERO          = 0
TYPE_UTIL           = 1
TYPE_I64            = 2
TYPE_U32            = 3
TYPE_I32            = 4
TYPE_WORD           = 5
TYPE_I16            = 6
TYPE_BYTE           = 7
TYPE_I8             = 8

// Wrapped Primitive Types
_TYPE_WRAPPED_START = 100
TYPE_WRAPPED_PTR    = 101
TYPE_WRAPPED_FUNC   = 102
TYPE_WRAPPED_DO     = 103
TYPE_WRAPPED_UTIL   = 104
TYPE_WRAPPED_I64    = 105
TYPE_WRAPPED_I32    = 106
TYPE_WRAPPED_I16    = 107
TYPE_WRAPPED_I8     = 108
TYPE_WRAPPED_BOOL   = 109
TYPE_WRAPPED_CSTR   = 110
_TYPE_WRAPPED_END   = 199

// Core Collections
TYPE_SPAN           = 200
TYPE_TABLE          = 201  // Alias: SPAN with TABLE_SEALED flag
TYPE_LOOKUP         = 202
TYPE_HASHED         = 203
TYPE_ITER           = 204

// Strings
TYPE_STR            = 300
TYPE_STRVEC         = 301

// Memory Management
TYPE_MEMCTX         = 400
TYPE_BOOK           = 401
TYPE_MAP            = 402

// Extended Types
_TYPE_EXT_START     = 500
TYPE_NODEOBJ        = 501
TYPE_TASK           = 502
TYPE_FRAME          = 503
TYPE_FETCHER        = 504
TYPE_ROEBLING       = 505

// Instance Marker
TYPE_INSTANCE       = 1 << 14  // 16384 - Flags for user-defined instances
```

### Type-to-String Conversion

```c
// Get type name at runtime
char *Type_ToChars(cls type);
Str *Type_ToStr(MemCh *m, cls type);

// Example
printf("Type: %s\n", Type_ToChars(TYPE_WRAPPED_I32));
// Output: "Type: TYPE_WRAPPED_I32"
```

## Interface Matching

**Problem:** You want `Span` and `Table` to both work with the same API (since `Table` is just a specialized `Span`).

**Solution:** Interface matching allows multiple types to implement the same interface.

### Interface Matching Function

```c
boolean Ifc_Match(cls inst, cls ifc) {
    if(inst == ifc)
        return TRUE;  // Exact match

    if(ifc == TYPE_WRAPPED) {
        // All wrapped types match TYPE_WRAPPED interface
        return (inst >= _TYPE_WRAPPED_START && inst <= _TYPE_WRAPPED_END);
    }
    else if(ifc == TYPE_SPAN) {
        // Both SPAN and TABLE implement TYPE_SPAN interface
        return (inst == TYPE_SPAN || inst == TYPE_TABLE);
    }

    return FALSE;
}
```

### Getting Interface Type

```c
cls Ifc_Get(cls inst) {
    if(inst == TYPE_SPAN || inst == TYPE_TABLE)
        return TYPE_SPAN;      // Both implement SPAN interface
    else if(inst >= TYPE_WRAPPED && inst <= _TYPE_WRAPPED_END)
        return TYPE_WRAPPED;   // All wrapped types share interface
    return inst;              // Otherwise, type is its own interface
}
```

### Type-Safe Casting

Caneka provides two casting macros:

#### Exact Type Casting: `as()`

Requires exact type match:

```c
Task *tsk = (Task *)as(obj, TYPE_TASK);
// ERROR if obj->type.of != TYPE_TASK

Single *sg = (Single *)as(value, TYPE_WRAPPED_I32);
// ERROR if value->type.of != TYPE_WRAPPED_I32
```

#### Interface Casting: `asIfc()`

Allows matching types:

```c
Span *p = (Span *)asIfc(source, TYPE_SPAN);
// SUCCESS if source is SPAN or TABLE

Single *sg = (Single *)asIfc(value, TYPE_WRAPPED);
// SUCCESS if value is any wrapped type
```

### Implementation

```c
void *_as(char *func, char *file, i32 line, void *_x, cls type) {
    Abstract *x = (Abstract *)_x;
    if(x == NULL || x->type.of != type) {
        Error(m, func, file, line,
              "Cast from Abstract mismatched type expecting '$', have '$'",
              Type_ToStr(m, type), Type_ToStr(m, x->type.of));
        return NULL;
    }
    return x;
}

void *_asIfc(char *func, char *file, i32 line, void *_x, cls type) {
    Abstract *x = (Abstract *)_x;
    if(x == NULL || !Ifc_Match(x->type.of, type)) {
        Error(m, func, file, line,
              "Cast from Abstract mismatched interface, expecting '$', have '$'",
              Type_ToStr(m, type), Type_ToStr(m, x->type.of));
        return NULL;
    }
    return x;
}
```

## Wrapped Primitives

C primitives (int, bool, pointers) are not objects—they have no type header. Caneka **wraps** them in `Single` objects to make them first-class.

### Single Structure

```c
typedef struct single {
    Type type;      // Type header (type.of = TYPE_WRAPPED_*)
    Type objType;   // For wrapped pointers, the type of pointed object
    union {
        byte b;
        word w;
        quad i;
        util value;
        void *a;
        void *ptr;
        DoFunc dof;
    } val;          // Value storage (8 bytes)
} Single;

// sizeof(Single) = 16 bytes on 64-bit systems
```

**Fields:**
- **type**: The Single's type (TYPE_WRAPPED_I32, TYPE_WRAPPED_PTR, etc.)
- **objType**: For wrapped pointers, tracks what type the pointer points to
- **val**: Union holding the actual value (int, pointer, function pointer, etc.)

### Creating Wrapped Values

#### Integer Wrappers

```c
// Wrap 32-bit integer
Single *num = I32_Wrapped(m, 42);
// num->type.of = TYPE_WRAPPED_I32
// num->val.i = 42

// Wrap 64-bit integer
Single *bigNum = I64_Wrapped(m, 123456789);
// bigNum->type.of = TYPE_WRAPPED_I64
// bigNum->val.value = 123456789
```

#### Boolean Wrapper

```c
Single *flag = Bool_Wrapped(m, true);
// flag->type.of = TYPE_WRAPPED_I64  // Booleans wrapped as i64
// flag->val.value = 1
```

#### Pointer Wrapper

```c
Str *str = Str_From(m, "hello");
Single *ptr = Ptr_Wrapped(m, str, TYPE_STR);
// ptr->type.of = TYPE_WRAPPED_PTR
// ptr->objType.of = TYPE_STR  // Tracks pointer target type
// ptr->val.ptr = str
```

#### Function Pointer Wrapper

```c
void MyFunction(void *arg) { /* ... */ }

Single *fn = Func_Wrapped(m, MyFunction);
// fn->type.of = TYPE_WRAPPED_FUNC
// fn->val.ptr = MyFunction
```

#### String Wrapper

```c
char *cstr = "hello";
Single *s = Cstr_Wrapped(m, cstr);
// s->type.of = TYPE_WRAPPED_CSTR
// s->val.ptr = cstr
```

### Unwrapping Values

```c
// Get value from wrapped integer
Single *num = I32_Wrapped(m, 42);
i32 value = (i32)num->val.i;  // value = 42

// Get pointer from wrapped pointer
Single *ptr = Ptr_Wrapped(m, str, TYPE_STR);
Str *original = (Str *)ptr->val.ptr;
```

### Why Wrap Primitives?

1. **Uniform object interface**: Everything is an `Abstract*` with a type
2. **Storage in collections**: Spans, Tables, Iterators expect objects with Type headers
3. **Type safety**: Know that a table entry is an integer vs. a pointer
4. **Memory management**: Wrapped values allocated in MemBook, freed with context

**Example: Storing integers in a Table**

```c
Table *config = Table_Make(m);

// Store wrapped integer
Table_Set(config, S(m, "port"), I32_Wrapped(m, 8080));

// Retrieve and unwrap
Single *wrapped = Table_Get(config, S(m, "port"));
i32 port = Single_GetI32(wrapped);  // port = 8080
```

## Type Flags and State Management

The `type.state` field holds 16 bits of flags, split into two regions:

```c
// Lower 8 bits: Normal/outcome flags (bits 0-7)
word NORMAL_FLAGS = 0b0000000011111111;

// Upper 8 bits: Class-specific flags (bits 8-15)
word UPPER_FLAGS = 0b1111111100000000;
```

### Common State Flags (Lower 8 Bits)

```c
enum status_types {
    READY      = 0,        // 0x00 - Initial/ready state
    SUCCESS    = 1 << 0,   // 0x01 - Operation succeeded
    ERROR      = 1 << 1,   // 0x02 - Error occurred
    NOOP       = 1 << 2,   // 0x04 - No operation
    DEBUG      = 1 << 3,   // 0x08 - Debug mode
    MORE       = 1 << 4,   // 0x10 - More data available
    LAST       = 1 << 5,   // 0x20 - Last item in sequence
    END        = 1 << 6,   // 0x40 - End of sequence
    PROCESSING = 1 << 7,   // 0x80 - Still processing
};
```

**Usage: Task execution**

```c
Task *tsk = Task_Make(m);
tsk->type.state = READY;

status result = Task_Execute(tsk);
if(result & SUCCESS) {
    tsk->type.state |= SUCCESS;
}
if(result & MORE) {
    tsk->type.state |= PROCESSING;
}
```

### Class-Specific Flags (Upper 8 Bits)

Each type defines its own flags in the upper 8 bits.

#### Table Flags

```c
enum table_flags {
    TABLE_SEALED = 1 << 8,  // Table is sealed (locked from modification)
};

// Example
Table *tbl = Table_Make(m);
tbl->type.state |= TABLE_SEALED;  // Lock the table
```

#### Span Flags

```c
enum span_flags {
    FLAG_SPAN_INLINE_SLOTS = 1 << 8,   // Slots stored inline
    FLAG_SPAN_HAS_GAPS     = 1 << 9,   // Contains removed elements
    FLAG_SPAN_ORDERED      = 1 << 10,  // Maintains insertion order
    FLAG_SPAN_RAW          = 1 << 11,  // Contains raw pointers
    FLAG_SPAN_TABLE        = 1 << 12,  // Operating as hash table
};

// Example
Span *sp = Span_Make(m);
sp->type.state |= FLAG_SPAN_ORDERED;  // Maintain order
```

#### String Flags

```c
enum string_flags {
    STRING_TEXT    = 1 << 8,   // Printable text
    STRING_CONST   = 1 << 9,   // Immutable
    STRING_BINARY  = 1 << 10,  // Binary data
    STRING_ENCODED = 1 << 11,  // Encoded (UTF-8, hex, etc.)
    STRING_COPY    = 1 << 12,  // Copied from external source
    STRING_UTF8    = 1 << 13,  // UTF-8 encoded
};

// Example
Str *str = Str_From(m, "hello");
Type_SetFlag(&str->type, STRING_TEXT | STRING_UTF8);
```

### Flag Operations

```c
// Set flags (preserves lower, replaces upper)
void Type_SetFlag(void *a, word flags) {
    Abstract *abs = (Abstract *)a;
    abs->type.state = (abs->type.state & NORMAL_FLAGS) | flags;
}

// Add flag
obj->type.state |= FLAG;

// Remove flag
obj->type.state &= ~FLAG;

// Check flag
if(obj->type.state & FLAG) {
    // Flag is set
}
```

## Seel Property System

**Seel** (pronounced "seal") is Caneka's type-to-property-schema mapping system. It provides:

1. **Property schemas** for types (defining what properties a type has)
2. **Type-safe property access** by name
3. **Ordered properties** for consistent iteration
4. **Type instantiation** tracking

### Core Concept

Each type can register a **property table** that defines:
- Property names (keys)
- Property types (expected type for each property)
- Property order (for iteration)

### Global Seel Lookups

```c
Lookup *SeelLookup;        // Type ID → Property Table
Lookup *SeelOrdLookup;     // Type ID → Ordered properties
Lookup *SeelNameLookup;    // Type ID → Type name
Table *SeelByName;         // Type name → Type ID
```

### Registering a Type Schema

```c
status NodeObj_ClsInit(MemCh *m) {
    // Create property schema table
    Table *tbl = Table_Make(m);

    // Define properties: property_name → expected_type
    Table_Set(tbl, S(m, "name"), I16_Wrapped(m, TYPE_STRVEC));
    Table_Set(tbl, S(m, "atts"), I16_Wrapped(m, TYPE_TABLE));
    Table_Set(tbl, S(m, "children"), I16_Wrapped(m, TYPE_TABLE));

    // Register schema for TYPE_NODEOBJ
    Seel_Seel(m, tbl, S(m, "NodeObj"), TYPE_NODEOBJ);

    return SUCCESS;
}
```

**What this does:**
- Registers that `TYPE_NODEOBJ` has three properties: `name`, `atts`, `children`
- `name` must be a `TYPE_STRVEC`
- `atts` and `children` must be `TYPE_TABLE`
- Properties are stored at indices 0, 1, 2 in the object's span

### Property Access

```c
// Get a property (with type checking)
void *Seel_Get(Span *inst, void *key) {
    // Look up the property schema for this type
    Table *seel = Lookup_Get(SeelLookup, inst->type.of);
    if(seel == NULL) return NULL;

    // Find the property definition
    Hashed *h = Table_GetHashed(seel, key);
    if(h == NULL) return NULL;

    Single *sg = (Single *)h->value;  // Expected type

    // Get value from object at property index
    Abstract *value = Span_Get(inst, h->orderIdx);

    // Type check
    if(value != NULL && sg->val.w != TYPE_ABSTRACT) {
        as(value, sg->val.w);  // Validate type
    }

    return value;
}

// Set a property
status Seel_Set(Span *inst, void *key, void *value) {
    Table *seel = Lookup_Get(SeelLookup, inst->type.of);
    Hashed *h = Table_GetHashed(seel, key);

    return Span_Set(inst, h->orderIdx, value);
}
```

### Using Seel Properties

```c
// Create a NodeObj instance
NodeObj *node = NodeObj_Make(m);

// Set properties (type-checked)
Seel_Set(node, S(m, "name"), S(m, "My Node"));

Table *atts = Table_Make(m);
Table_Set(atts, S(m, "id"), I32_Wrapped(m, 42));
Seel_Set(node, S(m, "atts"), atts);

// Get properties
StrVec *name = Seel_Get(node, S(m, "name"));  // Returns "My Node"
Table *attributes = Seel_Get(node, S(m, "atts"));  // Returns atts table
```

### Ordered Property Iteration

```c
// Get ordered property list
Span *Seel_OrdSeel(MemCh *m, cls instOf) {
    return Lookup_Get(SeelOrdLookup, instOf);
}

// Iterate over object properties in order
Span *ordSeel = Seel_OrdSeel(m, TYPE_NODEOBJ);
Iter it = Iter_Make(ordSeel);

while(Iter_HasNext(&it)) {
    Hashed *h = Iter_Next(&it);
    Str *propName = h->key;
    Single *propType = h->value;

    printf("Property %d: %s (type %d)\n",
           h->orderIdx, StrVec_GetCStr(propName), propType->val.w);
}

// Output:
// Property 0: name (type 301)
// Property 1: atts (type 201)
// Property 2: children (type 201)
```

## Instance System (Object-Oriented Types)

**Inst** is Caneka's object-oriented type system built on Seel and Span.

### Instance Structure

An **Inst** is a **Span** with the `TYPE_INSTANCE` flag and predefined property indices:

```c
enum inst_prop_idx {
    INST_PROPIDX_NAME     = 0,   // Instance name (StrVec)
    INST_PROPIDX_ATTS     = 1,   // Attributes (Table)
    INST_PROPIDX_CHILDREN = 2,   // Child instances (Table)
};

// Creating an instance
Span *Inst_Make(MemCh *m, cls typeOf) {
    Span *inst = Span_Make(m);
    inst->type.of = typeOf | TYPE_INSTANCE;  // Mark as instance

    // Initialize properties
    Span_Set(inst, INST_PROPIDX_NAME, StrVec_Make(m));
    Span_Set(inst, INST_PROPIDX_ATTS, Table_Make(m));
    Span_Set(inst, INST_PROPIDX_CHILDREN, Table_Make(m));

    return inst;
}
```

### Type-Safe Instance Casting

```c
Inst *asInst(MemCh *m, void *a) {
    if(a == NULL) return NULL;

    Abstract *abs = (Abstract *)a;
    if((abs->type.of & TYPE_INSTANCE) == 0) {
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
              "Type is not an Inst: $", Type_ToStr(m, abs->type.of));
        return NULL;
    }

    return (Inst *)a;
}
```

### Instance Property Access

```c
// Get instance name
StrVec *Inst_Name(Inst *inst) {
    return (StrVec *)Span_Get(inst, INST_PROPIDX_NAME);
}

// Set instance name
status Inst_SetName(Inst *inst, StrVec *name) {
    return Span_Set(inst, INST_PROPIDX_NAME, name);
}

// Get an attribute
void *Inst_Att(Inst *inst, void *key) {
    Table *atts = (Table *)Span_Get(inst, INST_PROPIDX_ATTS);
    if(atts != NULL)
        return Table_Get(atts, key);
    return NULL;
}

// Set an attribute
status Inst_SetAtt(Inst *inst, void *key, void *value) {
    Table *atts = (Table *)Span_Get(inst, INST_PROPIDX_ATTS);
    if(atts != NULL)
        return Table_Set(atts, key, value);
    return ERROR;
}

// Get a child instance
Inst *Inst_Child(Inst *inst, void *key) {
    Table *children = (Table *)Span_Get(inst, INST_PROPIDX_CHILDREN);
    if(children != NULL)
        return Table_Get(children, key);
    return NULL;
}

// Add a child instance
status Inst_AddChild(Inst *inst, void *key, Inst *child) {
    Table *children = (Table *)Span_Get(inst, INST_PROPIDX_CHILDREN);
    if(children != NULL)
        return Table_Set(children, key, child);
    return ERROR;
}
```

### Path Navigation

```c
// Navigate by path (e.g., "parent/child/property")
void *Inst_GetByPath(Inst *inst, StrVec *path) {
    return Inst_ByPath(inst, path, NULL, SPAN_OP_GET, NULL);
}

// Example
// inst = {
//   atts: {
//     config: {
//       port: 8080
//     }
//   }
// }

StrVec *path = StrVec_From(m, "atts/config/port");
Single *port = Inst_GetByPath(inst, path);
// port->val.i = 8080
```

### Complete Instance Example

```c
MemCh *m = &book->m;

// Create instance
Inst *page = Inst_Make(m, TYPE_WWW_PAGE);

// Set name
Inst_SetName(page, S(m, "home"));

// Set attributes
Inst_SetAtt(page, S(m, "title"), S(m, "Home Page"));
Inst_SetAtt(page, S(m, "path"), S(m, "/index.html"));

// Create child instance
Inst *section = Inst_Make(m, TYPE_WWW_PAGE);
Inst_SetName(section, S(m, "header"));
Inst_SetAtt(section, S(m, "class"), S(m, "header"));

// Add child
Inst_AddChild(page, S(m, "sections"), section);

// Access via path
StrVec *title = Inst_GetByPath(page, S(m, "atts/title"));
// title = "Home Page"

StrVec *childClass = Inst_GetByPath(page, S(m, "sections/header/atts/class"));
// childClass = "header"
```

## Type Equality and Comparison

Caneka provides two levels of comparison:

### Equals: Value Equality

**Purpose:** Check if two objects have the same value, regardless of type details.

```c
boolean Equals(void *_a, void *_b) {
    Abstract *a = (Abstract *)_a;
    Abstract *b = (Abstract *)_b;

    if(a == b) return TRUE;          // Same object
    if(a == NULL || b == NULL) return FALSE;

    // String comparisons (works across Str and StrVec)
    if(a->type.of == TYPE_STR) {
        if(b->type.of == TYPE_STR)
            return Str_EqualsStr((Str *)a, (Str *)b);
        else if(b->type.of == TYPE_STRVEC)
            return Str_EqualsStrVec((Str *)a, (StrVec *)b);
    }

    // Wrapped type comparisons (normalized to util)
    else if(Ifc_Match(a->type.of, TYPE_WRAPPED) &&
            Ifc_Match(b->type.of, TYPE_WRAPPED)) {

        Single *sga = (Single *)a;
        Single *sgb = (Single *)b;

        // Extract value into util for normalized comparison
        util au = (a->type.of == TYPE_WRAPPED_I64) ? sga->val.value : sga->val.i;
        util bu = (b->type.of == TYPE_WRAPPED_I64) ? sgb->val.value : sgb->val.i;

        return au == bu;
    }

    // Type-specific equality
    else {
        cls aTypeOf = Ifc_Get(a->type.of);
        cls bTypeOf = Ifc_Get(b->type.of);

        if(aTypeOf != bTypeOf) return FALSE;

        EqFunc func = Lookup_Get(EqualsLookup, aTypeOf);
        if(func == NULL) return FALSE;

        return func(a, b);
    }
}
```

**Examples:**

```c
// Wrapped integers
Single *a = I32_Wrapped(m, 42);
Single *b = I64_Wrapped(m, 42);
Equals(a, b);  // TRUE - value comparison, different wrapping OK

// Strings
Str *s1 = Str_From(m, "hello");
Str *s2 = Str_From(m, "hello");
Equals(s1, s2);  // TRUE - same content

// Different types
Str *str = Str_From(m, "test");
Single *num = I32_Wrapped(m, 42);
Equals(str, num);  // FALSE - incompatible types
```

### Exact: Structural Equality

**Purpose:** Check if two objects are identical in type, state, and value.

```c
boolean Exact(void *_a, void *_b) {
    Abstract *a = (Abstract *)_a;
    Abstract *b = (Abstract *)_b;

    if(a == b) return TRUE;
    if(a == NULL || b == NULL) return FALSE;
    if(a->type.of != b->type.of) return FALSE;  // Must be exact type

    // Type-specific exact checks
    if(a->type.of == TYPE_STR)
        return Str_ExactStr((Str *)a, (Str *)b);

    if(a->type.of == TYPE_WRAPPED_PTR)
        return Single_Exact((Single *)a, (Single *)b);

    // ... more checks ...

    return FALSE;
}

// Single exact comparison (includes state)
boolean Single_Exact(Single *a, Single *b) {
    if(a->type.of != b->type.of ||
       a->type.state != b->type.state ||
       a->objType.of != b->objType.of ||
       a->objType.state != b->objType.state)
        return FALSE;

    if(a->type.of == TYPE_WRAPPED_PTR)
        return Exact(a->val.ptr, b->val.ptr);

    return a->val.value == b->val.value;
}
```

**Examples:**

```c
// Type mismatch
Single *a = I32_Wrapped(m, 42);
Single *b = I64_Wrapped(m, 42);
Exact(a, b);  // FALSE - different types

// State mismatch
Str *s1 = Str_From(m, "hello");
s1->type.state |= STRING_CONST;

Str *s2 = Str_From(m, "hello");

Exact(s1, s2);  // FALSE - different state flags
```

### Truthiness

```c
boolean Caneka_Truthy(void *_a) {
    Abstract *a = (Abstract *)_a;
    if(a == NULL) return FALSE;

    if(Ifc_Match(a->type.of, TYPE_WRAPPED_I64))
        return ((Single *)a)->val.value != 0;

    if(Ifc_Match(a->type.of, TYPE_STR))
        return ((Str *)a)->length > 1;  // Non-empty string

    return FALSE;
}

// Examples
Caneka_Truthy(I32_Wrapped(m, 42));   // TRUE
Caneka_Truthy(I32_Wrapped(m, 0));    // FALSE
Caneka_Truthy(S(m, "hello"));        // TRUE
Caneka_Truthy(S(m, ""));             // FALSE
Caneka_Truthy(NULL);                 // FALSE
```

## Clone Operation

Cloning creates deep copies with type-specific logic.

### Clone Lookup System

```c
Lookup *CloneLookup;  // Type → Clone function mapping

status Clone_Init(MemCh *m) {
    CloneLookup = Lookup_Make(m, _TYPE_ZERO);

    // Register clone functions
    Lookup_Add(m, CloneLookup, TYPE_STR, (void *)Str_Clone);
    Lookup_Add(m, CloneLookup, TYPE_WRAPPED, (void *)Single_Clone);
    Lookup_Add(m, CloneLookup, TYPE_HASHED, (void *)Hashed_Clone);
    Lookup_Add(m, CloneLookup, TYPE_SPAN, (void *)Span_Clone);
    Lookup_Add(m, CloneLookup, TYPE_STRVEC, (void *)StrVec_Clone);

    return READY;
}
```

### Universal Clone Function

```c
void *Clone(MemCh *m, void *_a) {
    Abstract *a = (Abstract *)_a;
    if(a == NULL) return NULL;

    // Look up clone function by interface type
    Maker mk = (Maker)Lookup_Get(CloneLookup, Ifc_Get(a->type.of));
    if(mk != NULL)
        return mk(m, a);

    Error(m, FUNCNAME, FILENAME, LINENUMBER,
          "Unable to clone type $", Type_ToStr(m, a->type.of));
    return NULL;
}
```

### Type-Specific Clone Examples

```c
// String clone
Str *Str_Clone(MemCh *m, Str *og) {
    Str *str = MemCh_AllocOf(m, sizeof(Str), TYPE_STR);
    str->type = og->type;  // Copy type header
    str->length = og->length;
    str->alloc = og->length + 1;
    str->bytes = MemCh_AllocOf(m, str->alloc, TYPE_BYTE);
    memcpy(str->bytes, og->bytes, og->length + 1);
    return str;
}

// Single clone (handles wrapped pointers recursively)
Single *Single_Clone(MemCh *m, Single *og) {
    Single *sg = MemCh_AllocOf(m, sizeof(Single), TYPE_WRAPPED);
    *sg = *og;  // Copy all fields

    if(sg->type.of == TYPE_WRAPPED_PTR && sg->val.ptr != NULL)
        sg->val.ptr = Clone(m, sg->val.ptr);  // Recursively clone

    return sg;
}

// Span clone (deep copy)
Span *Span_Clone(MemCh *m, Span *og) {
    Span *sp = Span_Make(m);
    sp->type = og->type;

    Iter it = Iter_Make(og);
    while(Iter_HasNext(&it)) {
        Abstract *value = Iter_Next(&it);
        if(value != NULL)
            Span_Set(sp, it.idx, Clone(m, value));  // Clone each element
    }

    return sp;
}
```

## Map System (Struct Properties)

The **Map** system provides property access for C structs using offsets.

### Map Structure

```c
typedef struct map {
    RangeType type;        // type.of = TYPE_MAP, type.range = field count
    RangeType *atts;       // Array of field type definitions
    Str **keys;            // Field names
    Span *tbl;             // Field lookup table
} Map;
```

### Creating a Map

```c
// Define struct
typedef struct my_struct {
    Type type;
    i32 id;
    Str *name;
    boolean active;
} MyStruct;

// Create map for the struct
RangeType atts[] = {
    {TYPE_I32, offsetof(MyStruct, id)},
    {TYPE_STR, offsetof(MyStruct, name)},
    {TYPE_WRAPPED_BOOL, offsetof(MyStruct, active)}
};

Str *keys[] = {
    S(m, "id"),
    S(m, "name"),
    S(m, "active")
};

Map *map = Map_Make(m, 3, atts, keys);

// Register map for type
Lookup_Add(m, MapsLookup, TYPE_MY_STRUCT, map);
```

### Accessing Struct Properties

```c
// Convert struct instance to dynamic table
Table *Map_ToTable(MemCh *m, MyStruct *obj) {
    Map *map = Lookup_Get(MapsLookup, TYPE_MY_STRUCT);
    Table *tbl = Table_Make(m);

    Iter it = Iter_Make(map->tbl);
    while(Iter_HasNext(&it)) {
        Hashed *h = Iter_Next(&it);
        RangeType *def = h->value;

        // Extract and wrap value
        if(def->of == TYPE_I32) {
            i32 *ptr = ((void *)obj) + def->range;
            Table_Set(tbl, h->key, I32_Wrapped(m, *ptr));
        }
        else if(def->of == TYPE_STR) {
            Str **ptr = ((void *)obj) + def->range;
            Table_Set(tbl, h->key, *ptr);
        }
    }

    return tbl;
}

// Use it
MyStruct *obj = MyStruct_Make(m);
obj->id = 42;
obj->name = S(m, "test");
obj->active = true;

Table *tbl = Map_ToTable(m, obj);
// tbl = {id: 42, name: "test", active: true}
```

## Performance Considerations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| Type check | O(1) | Read `type.of` field |
| Interface match | O(1) | Fixed-size switch on type ID |
| Type-safe cast | O(1) | Type check + pointer cast |
| Property get (Seel) | O(log n) | Hash table lookup |
| Property set (Seel) | O(log n) | Hash table insertion |
| Equals | O(n) | n = size of objects being compared |
| Clone | O(n) | n = total size of object graph |

### Memory Overhead

```c
// Type header: 4 bytes
sizeof(Type) = 4 bytes  // cls (2 bytes) + state (2 bytes)

// Wrapped primitive: 16 bytes
sizeof(Single) = 16 bytes  // Type + objType + val (8 bytes)

// Overhead ratio
Wrapped i32: 16 bytes / 4 bytes (raw) = 4x overhead
Wrapped pointer: 16 bytes / 8 bytes (raw) = 2x overhead
```

**Trade-off:** Memory overhead for type safety, uniform object interface, and memory management

## Best Practices

1. **Use interface casting when flexible**: `asIfc()` allows multiple implementations
2. **Wrap primitives for collections**: Tables and Spans need objects with Type headers
3. **Register Seel schemas early**: During module initialization
4. **Use Equals for value comparison**: More flexible than Exact
5. **Clone carefully**: Deep cloning can be expensive for large object graphs
6. **Check types before casting**: Use `as()` and `asIfc()` instead of blind casts

## Common Pitfalls

### Pitfall 1: Blind Pointer Casting

```c
// WRONG - No type check
void *obj = GetObject();
Task *tsk = (Task *)obj;  // May crash if not a Task
```

**Fix:** Use type-safe casting

```c
void *obj = GetObject();
Task *tsk = (Task *)as(obj, TYPE_TASK);  // ERROR if not a Task
```

### Pitfall 2: Forgetting to Wrap Primitives

```c
// WRONG - Can't store raw int in Table
Table *tbl = Table_Make(m);
i32 port = 8080;
Table_Set(tbl, S(m, "port"), &port);  // port is not an object!
```

**Fix:** Wrap primitives

```c
Table *tbl = Table_Make(m);
Table_Set(tbl, S(m, "port"), I32_Wrapped(m, 8080));
```

### Pitfall 3: Modifying Sealed Tables

```c
// WRONG - Modifying sealed table
Table *tbl = Table_Make(m);
tbl->type.state |= TABLE_SEALED;
Table_Set(tbl, S(m, "key"), value);  // May fail or be ignored
```

**Fix:** Check seal status

```c
if((tbl->type.state & TABLE_SEALED) == 0) {
    Table_Set(tbl, S(m, "key"), value);
}
```

### Pitfall 4: Comparing Wrapped Types with ==

```c
// WRONG - Comparing object pointers
Single *a = I32_Wrapped(m, 42);
Single *b = I32_Wrapped(m, 42);
if(a == b) { /* Never true - different allocations */ }
```

**Fix:** Use Equals

```c
Single *a = I32_Wrapped(m, 42);
Single *b = I32_Wrapped(m, 42);
if(Equals(a, b)) { /* TRUE - same value */ }
```

### Pitfall 5: Not Registering Clone Functions

```c
// WRONG - Forgetting to register clone
MyType *Clone_MyType(MemCh *m, MyType *og) { /* ... */ }

// Later
MyType *obj = MyType_Make(m);
MyType *copy = Clone(m, obj);  // ERROR - no clone function registered
```

**Fix:** Register during initialization

```c
status MyType_Init(MemCh *m) {
    Lookup_Add(m, CloneLookup, TYPE_MYTYPE, (void *)Clone_MyType);
    return SUCCESS;
}
```

## Advanced Patterns

### Pattern 1: Type-Generic Functions

```c
void ProcessObject(MemCh *m, void *obj) {
    Abstract *a = (Abstract *)obj;

    if(a->type.of == TYPE_STR) {
        Str *s = (Str *)a;
        printf("String: %s\n", StrVec_GetCStr(s));
    }
    else if(Ifc_Match(a->type.of, TYPE_WRAPPED)) {
        Single *sg = (Single *)a;
        printf("Wrapped value: %lld\n", sg->val.value);
    }
    else if(Ifc_Match(a->type.of, TYPE_SPAN)) {
        Span *sp = (Span *)a;
        printf("Span with %d elements\n", sp->count);
    }
}
```

### Pattern 2: Dynamic Property Access

```c
// Get property by name string
void *GetDynamicProperty(MemCh *m, Inst *inst, const char *propName) {
    Str *key = S(m, propName);

    // Try attributes first
    void *value = Inst_Att(inst, key);
    if(value != NULL) return value;

    // Try Seel properties
    value = Seel_Get(inst, key);
    if(value != NULL) return value;

    // Try children
    return Inst_Child(inst, key);
}
```

### Pattern 3: Type Validation

```c
// Validate that a table contains expected types
status ValidateConfig(Table *config) {
    // Check port is integer
    Single *port = Table_Get(config, S(m, "port"));
    if(port == NULL || !Ifc_Match(port->type.of, TYPE_WRAPPED_I32))
        return ERROR;

    // Check host is string
    Str *host = Table_Get(config, S(m, "host"));
    if(host == NULL || host->type.of != TYPE_STR)
        return ERROR;

    return SUCCESS;
}
```

## See Also

- [Seel Property System](seel.md) - Property caching details
- [Memory Management](memory/overview.md) - Allocation context
- [Span](memory/span-complete.md) - Collection implementation using types
- [Table/Lookup](table-complete.md) - Hash tables and type-keyed lookups
