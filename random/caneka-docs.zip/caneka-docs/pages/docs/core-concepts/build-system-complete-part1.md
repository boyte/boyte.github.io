# Build System (Buildeka) - Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](build-system-complete-part2)

---

## Why Buildeka?

Traditional build systems (Make, CMake, Meson) are external dependencies. **Caneka builds itself**:

- **Self-Hosted**: Build system written in C, compiled by bootstrap
- **Zero Dependencies**: No Python, Ruby, or Node.js required
- **Modular**: Selective compilation of features (crypto backends, optional modules)
- **Dependency Tracking**: Automatic topological sort of module dependencies
- **Incremental**: Only recompiles changed files
- **Interactive**: Visual progress bar or quiet listing mode
- **Cross-Platform**: Supports clang, gcc, icc, msvc


## Architecture Overview

```
┌──────────────────────────────────────────────────────────────┐
│                    BUILD SYSTEM FLOW                         │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  1. ./build.sh (shell script)                                │
│     ├─ Detect compiler (clang/gcc)                          │
│     ├─ Compile bootstrap.c → dist/bin/bootstrap             │
│     └─ Launch bootstrap --menu                              │
│                                                               │
│  2. Bootstrap Menu (interactive)                             │
│     ├─ Options: buildeka, tests, CLI, webserver, all        │
│     ├─ Vi-key navigation (j/k) or arrow keys                │
│     └─ Triggers buildeka compilation                        │
│                                                               │
│  3. Buildeka (dist/bin/buildeka)                            │
│     ├─ Parse CLI args (--src, --option, --dir)              │
│     ├─ Scan modules and dependencies.txt files              │
│     ├─ Resolve dependency DAG (topological sort)            │
│     ├─ Generate include flags and caneka.h                  │
│     └─ Compile modules in correct order                     │
│        ├─ Compile .c → .o (object files)                    │
│        ├─ Archive .o → .a (static libraries)                │
│        └─ Link executables                                   │
│                                                               │
│  Output: dist/bin/[executables], build/lib*/lib*.a          │
└──────────────────────────────────────────────────────────────┘
```

**Build Process**:
```
build.sh → bootstrap → buildeka → [modules]
   ↓          ↓           ↓           ↓
compiler   menu       deps scan   compilation
detect     select     resolve     + linking
```


## Getting Started

### First Build

```bash
# Clone repository
git clone https://github.com/caneka/caneka.git
cd caneka

# Run bootstrap
./build.sh

# Interactive menu appears:
# ┌─────────────────────────────────┐
# │  Caneka Build System            │
# ├─────────────────────────────────┤
# │  1. buildeka-only               │
# │  2. run-tests                   │
# │  3. build-only                  │
# │  4. clean                       │
# │  5. build-cli                   │
# │  6. build-webserver             │
# │  7. build-run-webserver         │
# │  8. read-documentation          │
# │  9. all                         │
# └─────────────────────────────────┘

# Select option (1-9) or navigate with j/k/arrows
```

**What Happens**:
1. `build.sh` detects your compiler (prefers clang, falls back to gcc)
2. Compiles `bootstrap.c` → `dist/bin/bootstrap`
3. Launches interactive menu
4. Menu option compiles buildeka itself
5. Buildeka then compiles selected targets

### Subsequent Builds

After initial setup, use buildeka directly:

```bash
# Build specific module
./dist/bin/buildeka --src src/programs/test --option base ext inter

# Build with crypto support (NaCl backend)
./dist/bin/buildeka --src src/programs/test \
    --option base ext inter crypto@third/nacl

# Build webserver
./dist/bin/buildeka --src src/programs/webserver --option base ext inter

# Quiet mode (list instead of progress bar)
./dist/bin/buildeka --src src/programs/test --quiet --option base ext inter
```


## build.sh - Bootstrap Script

**Location**: Root directory

**Purpose**: Minimal shell script that kickstarts the build process

**Source**:
```bash
#!/bin/sh

# Compiler detection
if [ $(which clang) ]; then
    CC="clang"
elif [ $(which gcc) ]; then
    CC="gcc"
else
    echo "Error: No C compiler found (need clang or gcc)"
    exit 1
fi

# Create distribution directories
mkdir -p ./dist/bin

# Compile bootstrap program
$CC -o ./dist/bin/bootstrap \
    -I src/programs/buildeka/include/ \
    src/programs/buildeka/bootstrap.c

# Launch interactive menu
./dist/bin/bootstrap --menu
```

**Compiler Priority**:
1. **clang** (preferred)
2. **gcc** (fallback)
3. Error if neither found

**Why Prefer Clang?**
- Better error messages
- Faster compilation
- Stricter warnings (catches more bugs)


## Bootstrap Menu

**File**: `src/programs/buildeka/bootstrap.c`

The bootstrap menu is a **standalone C program** with no dependencies (not even Caneka's base library). It provides an interactive interface for common build tasks.

### Menu Options

| Option | Command | Description |
|--------|---------|-------------|
| 1 | buildeka-only | Build only buildeka tool |
| 2 | run-tests | Build and run test suite |
| 3 | build-only | Build core Caneka modules |
| 4 | clean | Remove ./build directory |
| 5 | build-cli | Build clineka command-line tool |
| 6 | build-webserver | Build webserver |
| 7 | build-run-webserver | Build and run webserver |
| 8 | read-documentation | Open documentation |
| 9 | all | Build tests, CLI, webserver |

### Navigation

**Keyboard Controls**:
- **j** / **↓**: Move down
- **k** / **↑**: Move up
- **1-9**: Select option directly
- **Enter**: Confirm selection
- **Ctrl+C**: Exit

**Example Interaction**:
```
Use arrow/vi-keys(j/k) to navigate, Enter to select:
> 1. buildeka-only
  2. run-tests
  3. build-only
  ...
```

### Implementation Highlights

**Raw Terminal Mode**:
```c
struct termios orig_termios;

void enableRawMode() {
    tcgetattr(STDIN_FILENO, &orig_termios);  // Save original

    struct termios raw = orig_termios;
    raw.c_lflag &= ~(ECHO | ICANON);         // Disable echo, canonical
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);
}

void disableRawMode() {
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &orig_termios);  // Restore
}
```

**Signal Handling**:
```c
void sigint_handler(int sig) {
    disableRawMode();          // Restore terminal
    printf("\nExiting...\n");
    exit(0);
}

signal(SIGINT, sigint_handler);   // Handle Ctrl+C
signal(SIGSEGV, sigint_handler);  // Handle crashes
```

**Menu Rendering**:
```c
void printMenu(int selected) {
    printf("\033[2J\033[H");  // Clear screen, move cursor to top

    printf("Caneka Build System\n");
    printf("─────────────────────\n\n");

    for(int i = 0; i < 9; i++){
        if(i == selected){
            printf("> %d. %s\n", i+1, options[i]);  // Highlight
        }else{
            printf("  %d. %s\n", i+1, options[i]);
        }
    }
}
```

**Build Command Execution**:
```c
// Example: Option 2 (run-tests)
char *buildTests[] = {
    "./dist/bin/buildeka",
    "--src", "src/programs/test",
    "--option", "base", "ext", "inter",
    NULL
};

// Fork and execute
pid_t pid = fork();
if(pid == 0){
    execvp(buildTests[0], buildTests);  // Child: run buildeka
    exit(1);
}else{
    wait(NULL);  // Parent: wait for completion
}
```


## Buildeka Architecture

**File**: `src/programs/buildeka/`

Buildeka is the core build tool, implemented using Caneka's base library.

### BuildCtx Structure

The central build context tracks all compilation state:

```c
typedef struct buildctx {
    Type type;                          // TYPE_BUILDCTX
    MemCh *m;                          // Memory allocator
    struct timespec start;             // Build start time
    struct timespec modified;          // Latest file modification
    StrVec *dir;                       // Build output directory
    StrVec *src;                       // Source modules to build

    struct {                           // Current build state
        StrVec *name;                  // Current module name
        StrVec *target;                // Library target (lib*.a)
        StrVec *targetName;            // Library name
        StrVec *source;                // Current source file
        StrVec *dest;                  // Compiled object destination
        StrVec *binDest;               // Executable destination
        Hashed *depKv;                 // Dependency metadata
        Span *staticlibs;              // Static libs to link
        Span *liblist;                 // Dynamic libs (-l flags)
        Span *inc;                     // Include paths (-I flags)
        Span *flags;                   // Feature flags (-DCNKOPT_*)
    } current;

    struct {                           // Build configuration
        StrVec *buildDir;              // Output directory
        Span *inc;                     // Global includes
        Span *cflags;                  // Compiler flags
        Span *libs;                    // Link libraries
        Span *staticLibs;              // Static libraries
        Span *sources;                 // Source files
        Table *options;                // Optional modules
        Span *objects;                 // Compiled objects
        Table *dependencies;           // Module dependency graph
        Single *totalSources;          // Total source count
        Single *countSources;          // Compiled source count
        Single *totalModules;          // Total modules
        Single *countModules;          // Compiled modules
    } input;

    struct {                           // Build tools
        Str *cc;                       // C compiler
        Str *ccVersion;                // Compiler version
        Str *ar;                       // Archiver (ar)
    } tools;

    struct {                           // Progress display
        CliStatus *cli;                // Status bar
        BuildCliFields fields;         // Display fields
    } cli;
} BuildCtx;
```

### Build Flow

**Main Entry** (`main.c`):
```c
int main(int argc, char **argv){
    Caneka_Init();
    MemCh *m = MemCh_Make();

    // 1. Parse arguments
    CliArgs *args = CliArgs_Make(m);
    Args_Add(args, "src", "Source modules", ARG_MULTIPLE, NULL);
    Args_Add(args, "option", "Optional modules", ARG_MULTIPLE, NULL);
    Args_Add(args, "dir", "Build directory", ZERO, NULL);
    Args_Add(args, "type", "exec or static", ZERO, NULL);
    Args_Add(args, "quiet", "Suppress progress", ARG_OPTIONAL, NULL);
    Args_Add(args, "run", "Execute after build", ARG_OPTIONAL, NULL);

    CliArgs_Parse(args, argc, argv);

    // 2. Create build context
    BuildCtx *ctx = BuildCtx_Make(m);
    ctx->src = CliArgs_Get(args, "src");
    ctx->dir = CliArgs_Get(args, "dir") ?: S(m, "build");

    // Parse options: crypto@third/nacl → {crypto: third/nacl}
    Span *optSpan = CliArgs_Get(args, "option");
    ctx->input.options = BuildCtx_GenOptionsTable(ctx, optSpan);

    // 3. Execute build
    status result = BuildCtx_Build(ctx);

    // 4. Run if requested
    if(CliArgs_Get(args, "run") && result & SUCCESS){
        // Execute compiled binary
    }

    MemCh_Free(m);
    return (result & SUCCESS) ? 0 : 1;
}
```


## Compiler Detection

**File**: `src/programs/buildeka/include/detect.h`

Buildeka detects the compiler at **compile-time** using preprocessor macros:

```c
#if defined(__clang__)
    #define _gen_CC "clang"
    #define _gen_CC_VERSION __clang_major__
#elif defined(__INTEL_COMPILER)
    #define _gen_CC "icc"
    #define _gen_CC_VERSION __INTEL_COMPILER
#elif __GNUC__
    #define _gen_CC "gcc"
    #define _gen_CC_VERSION __GNUC__
#elif defined(_MS_VER)
    #define _gen_CC "msvc"
    #define _gen_CC_VERSION _MS_VER
#endif

#define _gen_AR "ar"
```

**Detection Priority**:
1. **Clang** (`__clang__`)
2. **Intel ICC** (`__INTEL_COMPILER`)
3. **GCC** (`__GNUC__`)
4. **MSVC** (`_MS_VER`)

**Runtime Usage**:
```c
BuildCtx *ctx = BuildCtx_Make(m);
ctx->tools.cc = S(m, _gen_CC);                    // "clang"
ctx->tools.ccVersion = Str_FromI64(m, _gen_CC_VERSION);  // "19"
ctx->tools.ar = S(m, _gen_AR);                    // "ar"
```

**Compiler Command**:
```c
Span *cmd = Span_Make(m);
Span_Add(cmd, ctx->tools.cc);          // clang
Span_Add(cmd, "-g");                   // Debug symbols
Span_Add(cmd, "-c");                   // Compile only
Span_AddSpan(cmd, ctx->current.inc);   // -I flags
Span_Add(cmd, "-o");
Span_Add(cmd, dest);                   // Output
Span_Add(cmd, source);                 // Input

// Execute: clang -g -c -I... -o file.o file.c
SubProcess(m, cmd, &pd);
```


## Module System

Caneka uses a **modular architecture** where each module is a directory with source files and a `dependencies.txt` file.

### Module Structure

```
src/[module_name]/
├─ include/
│  ├─ [module_name]_module.h    # Public API
│  └─ [internal headers]
├─ *.c                           # Implementation
├─ option/                       # Optional features
│  ├─ [feature]/
│  │  └─ *.c
│  └─ ...
├─ dependencies.txt              # Dependency specification
└─ inc.c                         # Inclusion file (optional)
```

### Core Modules

| Module | Path | Description |
|--------|------|-------------|
| **base** | `src/base` | Core data structures (MemCh, Str, Table, etc.) |
| **ext** | `src/ext` | Extended features (Roebling, Navigate, Seel) |
| **inter** | `src/inter` | Integration layer (HTTP, Templ, WWW) |
| **passport** | `src/passport` | Authentication and sessions |

### Program Modules

| Program | Path | Description |
|---------|------|-------------|
| **test** | `src/programs/test` | Test suite |
| **clineka** | `src/programs/clineka` | CLI tool |
| **webserver** | `src/programs/webserver` | Web server |
| **buildeka** | `src/programs/buildeka` | Build system itself |

### Third-Party Modules

| Module | Path | Description |
|--------|------|-------------|
| **nacl** | `src/third/nacl.experimental` | NaCl crypto (optional) |
| **openssl** | `src/third/openssl` | OpenSSL crypto (optional) |


## dependencies.txt Format

Each module's `dependencies.txt` file declares its dependencies and configuration.

### Syntax

```
[declaration]                    # Simple dependency or directive
[tag]=[label]@[path]            # Tagged dependency with path
```

### Directives

| Directive | Format | Purpose |
|-----------|--------|---------|
| Simple | `base` | Depend on module "base" |
| Option | `option=crypto@third/nacl` | Optional module selection |
| Executable | `exec=main.c` | Mark file as executable entry point |
| Skip | `skip=old.c` | Skip file from compilation |
| Include | `include=/usr/include/openssl/` | External include directory |
| Link | `link=openssl@crypto` | Link external library |
| Static | `static=libfoo.a` | Link static library |

### Example: base/dependencies.txt

```
# Base module has no dependencies
```

### Example: ext/dependencies.txt

```
base
```
**Meaning**: Ext depends on base

### Example: inter/dependencies.txt

```
ext
```
**Meaning**: Inter depends on ext (which transitively depends on base)

### Example: test/dependencies.txt

```
exec=main.c
exec=content-fetch.c
option=crypto@third/nacl
option=crypto@third/openssl
option=inter
option=ext
option=base
```

**Meaning**:
- `main.c` and `content-fetch.c` are executable entry points
- Crypto can use either nacl or openssl (selected via CLI)
- Modules inter, ext, base are optional (must be explicitly enabled)

### Example: openssl/dependencies.txt

```
include=/usr/include/openssl/
link=openssl@crypto
inter
ext
base
```

**Meaning**:
- Add `/usr/include/openssl/` to include paths
- Link against libcrypto from openssl
- Depend on inter, ext, base


## Dependency Resolution

**File**: `src/programs/buildeka/dependency.c`

Buildeka resolves dependencies using **topological sorting**.

### Algorithm

**Function**: `BuildCtx_ParseDependencies(ctx, key, path)`

**Steps**:

1. **Scan Directory**:
   ```c
   DirSelector *sel = DirSelector_Make(m,
       S(m, ".c"),               // Filter: .c files only
       NULL,                     // No exclude
       DIR_SELECTOR_MTIME_ALL|   // Track modification times
       DIR_SELECTOR_NODIRS       // No directories
   );

   Dir_GatherSel(m, pathStr, sel);
   // Result: sel->dest = list of .c files
   //         sel->time = newest modification time
   ```

2. **Read dependencies.txt**:
   ```c
   StrVec *depPath = {path, "/", "dependencies.txt"};
   Str *depFileContent = File_ToStr(m, depPath);

   // Parse line by line
   Cursor *curs = Cursor_Make(m, depFileContent);
   while(Cursor_NextLine(curs)){
       Str *line = Cursor_Line(curs);
       // Parse declaration
   }
   ```

3. **Parse Declaration**:
   ```c
   Span *BuildCtx_ToModDeclare(MemCh *m, Str *s){
       // Input: "option=crypto@third/nacl"
       // Output: Span with:
       //   BUILD_MOD_DECLARE_TAG = "option"
       //   BUILD_MOD_DECLARE_LABEL = "crypto"
       //   BUILD_MOD_DECLARE_VALUE = "third/nacl"

       Span *declare = Span_Make(m);
       // Parse '@' and '=' delimiters
       return declare;
   }
   ```

4. **Recursive Resolution**:
   ```c
   if(Equals(tag, "dep") || tag == NULL){
       // This is a dependency module
       StrVec *depPath = {src_prefix, "/", value};

       // Recursively parse dependency
       BuildCtx_ParseDependencies(ctx, label, depPath);
   }
   ```

5. **Store Metadata**:
   ```c
   // Store in DirSelector's metadata table
   Table_Set(sel->meta, "dep", dependencyList);
   Table_Set(sel->meta, "inc", includeFlags);
   Table_Set(sel->meta, "exec", executableFiles);
   Table_Set(sel->meta, "skip", skippedFiles);
   Table_Set(sel->meta, "option", optionalModules);
   Table_Set(sel->meta, "static", staticLibs);
   Table_Set(sel->meta, "link", linkedLibs);
   ```

6. **Deduplication**:
   ```c
   // Check if already processed
   if(Table_Get(ctx->input.dependencies, key) != NULL){
       return NOOP;  // Skip duplicate
   }

   // Add to dependencies table
   Table_Set(ctx->input.dependencies, key, sel);
   ```

### Topological Sort

**Build Order**:
```
Dependencies table order: {base, ext, inter, test}

Build execution order:
1. base    (no dependencies)
2. ext     (depends on base)
3. inter   (depends on ext, base)
4. test    (depends on inter, ext, base)
```

**Implementation**:
```c
Iter *it = Iter_Make(m, ctx->input.dependencies);
while(Iter_Next(it)){
    Hashed *h = (Hashed *)Iter_Value(it);
    StrVec *name = h->key;           // Module name
    DirSelector *sel = h->value;     // Module metadata

    // Build module and all sources
    BuildCtx_BuildModule(ctx, name, sel);
}
```


## Optional Modules

Optional modules allow **selective compilation** of features.

### CLI Syntax

```bash
./dist/bin/buildeka --src src/programs/test \
    --option base ext inter crypto@third/nacl
```

**Parsing**:
```c
Table *BuildCtx_GenOptionsTable(BuildCtx *ctx, Span *options){
    Table *tbl = Table_Make(ctx->m);

    // Parse each option: "crypto@third/nacl"
    Iter_Init(&it, options);
    while(Iter_Next(&it)){
        Str *s = Iter_Get(&it);
        Span *declare = BuildCtx_ToModDeclare(ctx->m, s);

        Str *label = Span_Get(declare, BUILD_MOD_DECLARE_LABEL);
        Str *value = Span_Get(declare, BUILD_MOD_DECLARE_VALUE);

        // Table: {crypto: third/nacl}
        Table_Set(tbl, label, value);
    }
    return tbl;
}
```

### Feature Flags

Selected options generate **preprocessor defines**:

```c
// For each selected option
Table *options = ctx->input.options;
Iter_Init(&it, options);
while(Iter_Next(&it)){
    Hashed *h = Iter_Get(&it);
    Str *optName = h->key;  // e.g., "crypto"

    // Generate: -DCNKOPT_CRYPTO
    StrVec *flag = Sv(m, "-DCNKOPT_");
    StrVec_Add(flag, Str_ToUpper(m, optName));
    Span_Add(ctx->current.flags, StrVec_Str(m, flag));
}
```

**Result**:
```c
#ifdef CNKOPT_CRYPTO
    // Crypto code enabled
    #include "crypto_api.h"
#endif
```

### Option Selection in dependencies.txt

```
# In dependencies.txt
option=crypto@third/nacl
option=crypto@third/openssl
```

**Resolution**:
```c
// If CLI: --option crypto@third/nacl
// Selected: third/nacl
// Compile: src/third/nacl/**/*.c
// Skip: src/third/openssl (not selected)

// If CLI: --option crypto@third/openssl
// Selected: third/openssl
// Compile: src/third/openssl/**/*.c
// Skip: src/third/nacl (not selected)
```


## Include Flag Generation

**File**: `src/programs/buildeka/gen.c`

Buildeka generates include flags for each module.

### Global Includes

```c
status BuildCtx_GenAllIncSpan(BuildCtx *ctx){
    Span *inc = Span_Make(m);

    // Build directory includes
    StrVec *buildInc = {ctx->input.buildDir, "/", "include", "/"};
    Span_Add(inc, StrVec_StrPrefixed(m, "-I", buildInc));

    // API layer
    Span_Add(inc, S(m, "-Isrc/api/include"));

    // Base module
    Span_Add(inc, S(m, "-Isrc/base/include"));

    ctx->input.inc = inc;
    return SUCCESS;
}
```

**Result**: `{"-Ibuild/include/", "-Isrc/api/include", "-Isrc/base/include"}`

### Module-Specific Includes

```c
// For module "ext"
Span *moduleInc = Span_Make(m);

// Module's own include directory
StrVec *srcInc = {"src", "/", "ext", "/", "include"};
Span_Add(moduleInc, StrVec_StrPrefixed(m, "-I", srcInc));
// Result: "-Isrc/ext/include"

// External includes from dependencies.txt
Span *extInc = Table_Get(sel->meta, "inc");
if(extInc != NULL){
    Span_AddSpan(moduleInc, extInc);
}
// Result: "-I/usr/include/openssl/" (if specified)

// Dependency includes (recursive)
Span *deps = Table_Get(sel->meta, "dep");
Iter_Init(&it, deps);
while(Iter_Next(&it)){
    StrVec *depName = Iter_Get(&it);
    DirSelector *depSel = Table_Get(ctx->input.dependencies, depName);
    Span *depInc = Table_Get(depSel->meta, "inc");
    Span_AddSpan(moduleInc, depInc);
}

// Store for this module
Table_Set(sel->meta, "inc", moduleInc);
```

### Generated caneka.h

```c
status BuildCtx_GenIncFlags(BuildCtx *ctx, Span *modlist, Span *genlist){
    // Create build/include/caneka.h
    StrVec *canekaPath = {ctx->input.buildDir, "/", "include", "/", "caneka.h"};
    Buff *bf = Buff_Make(m, BUFF_UNBUFFERED|BUFF_CLOBBER);
    File_Open(bf, StrVec_Str(m, canekaPath), O_CREAT|O_TRUNC|O_WRONLY);

    // Write header
    Buff_Print(bf, "/* This file generated by buildeka */\n\n");
    Buff_Print(bf, "#include <external.h>\n");
    Buff_Print(bf, "#include <base_module.h>\n\n");

    // Include each compiled module
    Iter_Init(&it, modlist);
    while(Iter_Next(&it)){
        StrVec *name = Iter_Get(&it);
        Buff_Print(bf, "/* module $ */\n", {name});
        Buff_Print(bf, "#include <$_module.h>\n\n", {name});
    }

    File_Close(bf);
    return SUCCESS;
}
```

**Generated** `build/include/caneka.h`:
```c
/* This file generated by buildeka */

#include <external.h>
#include <base_module.h>

/* module base */
#include <base_module.h>

/* module ext */
#include <ext_module.h>

/* module inter */
#include <inter_module.h>
```


## Compilation Process

**File**: `src/programs/buildeka/object.c`

### Object File Compilation

**Function**: `BuildCtx_BuildObject(ctx, name, sel)`

**Algorithm**:
```c
// 1. Setup paths
ctx->current.source = sourceFile;  // src/module/file.c
ctx->current.dest = destObject;    // build/module/file.o

// 2. Build compiler command
Span *cmd = Span_Make(m);
Span_Add(cmd, ctx->tools.cc);              // clang
Span_AddSpan(cmd, ctx->input.cflags);      // Global flags
Span_AddSpan(cmd, ctx->current.inc);       // -I flags
Span_AddSpan(cmd, ctx->current.flags);     // -DCNKOPT_* flags
Span_Add(cmd, "-g");                       // Debug symbols
Span_Add(cmd, "-c");                       // Compile only (no link)
Span_Add(cmd, "-o");
Span_Add(cmd, StrVec_Cstr(m, destObject)); // Output
Span_Add(cmd, StrVec_Cstr(m, sourceFile)); // Input

// 3. Execute compilation
ProcDets pd;
ProcDets_Init(&pd);
status result = SubProcess(m, cmd, &pd);

if(result & ERROR){
    Fatal(FUNCNAME, FILENAME, LINE,
        "Compilation failed for $", {sourceFile});
    return ERROR;
}

return SUCCESS;
```

**Example Command**:
```bash
clang -g -c \
    -Ibuild/include \
    -Isrc/api/include \
    -Isrc/base/include \
    -Isrc/ext/include \
    -DCNKOPT_BASE \
    -DCNKOPT_EXT \
    -o build/ext/parser.o \
    src/ext/parser.c
```

### Static Library Archival

**Function**: `BuildCtx_LinkObject(ctx, name, sel)`

```c
// 1. Add object to archive
Span *cmd = Span_Make(m);
Span_Add(cmd, ctx->tools.ar);                      // ar
Span_Add(cmd, "-rc");                              // Replace/create
Span_Add(cmd, StrVec_Cstr(m, ctx->current.target)); // libcnkext.a
Span_Add(cmd, StrVec_Cstr(m, ctx->current.dest));   // file.o

// 2. Execute archival
ProcDets pd;
ProcDets_Init(&pd);
status result = SubProcess(m, cmd, &pd);

return result;
```

**Example Command**:
```bash
ar -rc build/ext/libcnkext.a build/ext/parser.o
```

**Result**: `libcnkext.a` now contains `parser.o`

### Executable Linking

**Function**: `BuildCtx_BuildObject(ctx, name, sel)` (for executables)

```c
// 1. Build link command
Span *cmd = Span_Make(m);
Span_Add(cmd, ctx->tools.cc);                      // clang
Span_AddSpan(cmd, ctx->input.cflags);              // Global flags
Span_AddSpan(cmd, ctx->current.inc);               // -I flags
Span_Add(cmd, "-o");
Span_Add(cmd, StrVec_Cstr(m, ctx->current.binDest)); // Output: build/bin/test
Span_Add(cmd, StrVec_Cstr(m, ctx->current.source));  // Input: main.c

// 2. Link module library
if(ctx->current.target != NULL){
    Span_Add(cmd, StrVec_Cstr(m, ctx->current.target)); // libcnktest.a
}

// 3. Add dependencies (reverse order for proper linking)
Span_AddSpanRev(cmd, ctx->current.staticlibs);     // libcnkinter.a, libcnkext.a, libcnkbase.a

// 4. Add dynamic libraries
Span_AddSpan(cmd, ctx->current.liblist);           // -lcrypto -lm

// 5. Execute linking
ProcDets pd;
ProcDets_Init(&pd);
status result = SubProcess(m, cmd, &pd);

return result;
```

**Example Command**:
```bash
clang -o build/bin/test \
    src/programs/test/main.c \
    build/test/libcnktest.a \
    build/inter/libcnkinter.a \
    build/ext/libcnkext.a \
    build/base/libcnkbase.a \
    -lcrypto \
    -lm
```

**Why Reverse Order?**

Linkers resolve symbols left-to-right. Dependencies must come after dependents:
- `libcnktest.a` depends on symbols in `libcnkinter.a`
- `libcnkinter.a` depends on symbols in `libcnkext.a`
- `libcnkext.a` depends on symbols in `libcnkbase.a`


## Incremental Builds

**File**: `src/programs/buildeka/module.c`

Buildeka only recompiles changed files.

### Library Timestamp Check

```c
status skipRecent(BuildCtx *ctx, DirSelector *sel){
    // Check if library .a exists
    Str *libPath = StrVec_Str(m, ctx->current.target);

    if(!File_PathExists(m, libPath)){
        return ZERO;  // Library doesn't exist, must compile
    }

    // Get library modification time
    struct timespec libTime;
    File_ModTime(m, libPath, &libTime);

    // Compare with newest source file
    // sel->time = newest source modification time
    if(Time_Greater(&libTime, &sel->time)){
        // Library is newer than all sources, skip!
        ctx->input.countSources->val.i +=
            ctx->input.totalModuleSources->val.i;
        return SUCCESS;
    }

    return ZERO;  // Sources newer, must recompile
}
```

### Object File Reuse

```c
// For each source file
Iter_Init(&it, sel->dest);
while(Iter_Next(&it)){
    StrVec *source = Iter_Get(&it);
    StrVec *destObj = {buildDir, "/", module, "/", basename, ".o"};

    // Check if object exists and is newer than source
    if(File_PathExists(m, StrVec_Str(m, destObj))){
        struct timespec objTime;
        File_ModTime(m, StrVec_Str(m, destObj), &objTime);

        if(Time_Greater(&objTime, &sel->time)){
            // Object newer than source, skip compilation
            BuildCtx_LinkObject(ctx, name, sel);  // Just re-archive
            continue;
        }
    }

    // Object outdated or doesn't exist, recompile
    BuildCtx_BuildObject(ctx, name, sel);
    BuildCtx_LinkObject(ctx, name, sel);
}
```

**Example Scenario**:

```
First build:
  ✓ Compile src/ext/parser.c → build/ext/parser.o
  ✓ Archive ar -rc build/ext/libcnkext.a build/ext/parser.o

Modify src/ext/strings.c (not parser.c):
  ⊘ Skip parser.c (object newer than source)
  ✓ Compile strings.c → strings.o
  ✓ Re-archive: ar -rc libcnkext.a strings.o

Modify nothing:
  ⊘ Skip entire module (library newer than all sources)
```



---

**Part 1 of 2** | [Part 2 →](build-system-complete-part2)
