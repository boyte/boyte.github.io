# WWW Routing System Complete Guide - Part 1

**Part 1 of 3** | [Part 2 →](www-routing-complete-part2)

---

## Overview

The WWW Routing System in Caneka provides URL-to-handler mapping for the web server, transforming HTTP requests into appropriate content responses. Unlike traditional routing systems that define routes programmatically, Caneka's router **mirrors the filesystem structure** and automatically registers handlers based on file extensions. This creates a transparent, discoverable routing system where the URL structure directly reflects the project's file organization.

The routing system integrates deeply with Caneka's type system (Routes are Inst objects), the HTTP lifecycle (providing the handlers for requests), and various content engines (Templ templates, Fmt documents, BinSeg databases, static files).


## Core Philosophy

### Filesystem-Driven Routing

The routing system follows Caneka's **"glass-bottom-boat" transparency principle**: routes are not hidden in configuration files or scattered across code, but visible in the filesystem structure. If you have a file at `pages/public/stats.templ`, it automatically becomes accessible at `/stats`.

**Key Design Principles:**

1. **Discoverability**: Routes are visible in the file structure
2. **Convention Over Configuration**: File extensions determine content type and handling
3. **Hierarchical Organization**: URL paths mirror directory structure
4. **Centralized Handlers**: Each file type has a single, predictable handler function
5. **Preparation Phase**: Templates and formats are parsed once at startup, not per-request

### Route as Inst

Routes are implemented as **Inst objects** with the `TYPE_WWW_ROUTE` type. This means routes inherit all the capabilities of the Seel/Inst property system:

- **Hierarchical Navigation**: Routes form a tree using `Inst_ByPath` traversal
- **Typed Properties**: Each route has a schema defining its properties (path, mime, handler function, etc.)
- **Property Access**: Use `Seel_Get`/`Seel_Set` to access route data
- **Composability**: Routes can be nested and composed like any Inst tree

This design creates a **unified data model** where routes, configuration, and content all use the same underlying type system.

### Handler Functions

Each file extension maps to a **RouteFunc** handler:

```c
typedef status (*RouteFunc)(Buff *bf, Route *rt, Inst *data, HttpCtx *ctx);
```

Handlers are **pure functions** that:
- Read prepared content from the route (via `Seel_Get`)
- Generate output into a buffer
- Use data table for template variables
- Access HTTP context for headers, query params, etc.
- Return status codes (SUCCESS, ERROR, etc.)


## Structure

### Route Object Schema

Routes follow the `TYPE_WWW_ROUTE` schema defined in [route.c:412-421](../../../src/inter/www/route.c#L412-L421):

```c
status Route_Init(MemCh *m){
    Table *seel = Table_Make(m);
    Table_Set(seel, S(m, "path"), I16_Wrapped(m, TYPE_STRVEC));
    Table_Set(seel, S(m, "data"), I16_Wrapped(m, TYPE_TABLE));
    Hashed *h = Table_SetHashed(seel, S(m, "children"), I16_Wrapped(m, TYPE_TABLE));
    /* Node End */
    Table_Set(seel, S(m, "gens"), I16_Wrapped(m, TYPE_SPAN));
    return Seel_Seel(m, seel, S(m, "Route"), TYPE_WWW_ROUTE);
}
```

**Property Index Constants** [route.h:14-20](../../../src/inter/include/www/route.h#L14-L20):

```c
enum route_prop_idx {
    ROUTE_PROPIDX_PATH = 0,       // StrVec: URL path segments
    ROUTE_PROPIDX_DATA = 1,       // Table: Configuration and metadata
    ROUTE_PROPIDX_CHILDREN = 2,   // Table: Child routes (tree structure)
    /* NodeObj end */
    ROUTE_PROPIDX_ROUTE_GENS = 3, // Span: Generator context
};
```

**Note**: Routes inherit the first three properties from NodeObj (path, data, children), making them compatible with hierarchical navigation patterns used throughout Caneka.

### Route Flags

Routes carry bitflags describing content type and handling [route.h:3-12](../../../src/inter/include/www/route.h#L3-L12):

```c
enum route_flags {
    ROUTE_STATIC = 1 << 8,     // Static file (no processing)
    ROUTE_DYNAMIC = 1 << 9,    // Dynamic template (.templ)
    ROUTE_FMT = 1 << 10,       // Pencil format (.fmt)
    ROUTE_INDEX = 1 << 13,     // Index file (default for directory)
    ROUTE_BINSEG = 1 << 11,    // BinSeg database (.rbs)
    ROUTE_ASSET = 1 << 12,     // Cacheable asset (images, CSS, JS)
    ROUTE_ACTION = 1 << 14,    // Action handler (future use)
    ROUTE_FORBIDDEN = 1 << 15, // Explicitly forbidden route
};
```

These flags are set during route building based on file extension and stored in the route's `type.state` field.

### Handler Registration

Handlers are registered in global tables initialized at startup [route.c:423-505](../../../src/inter/www/route.c#L423-L505):

```c
// Global handler tables
Span *RouteFuncTable = NULL;  // Extension -> RouteFunc mapping
Span *RouteMimeTable = NULL;  // Extension -> MIME type mapping

// Example registration (.templ handler)
key = S(m, "templ");
funcW = Func_Wrapped(m, routeFuncTempl);  // Wrap function pointer
funcW->type.state |= ROUTE_DYNAMIC;       // Set flags
Table_Set(RouteFuncTable, key, funcW);    // Register handler
Table_Set(RouteMimeTable, key, S(m, "text/html")); // Register MIME
```

**Registered Handlers:**

| Extension | Handler Function | MIME Type | Flags | Description |
|-----------|-----------------|-----------|-------|-------------|
| `.html` | `routeFuncStatic` | `text/html` | `ROUTE_STATIC` | Pre-written HTML |
| `.templ` | `routeFuncTempl` | `text/html` | `ROUTE_DYNAMIC` | Templ templates |
| `.fmt` | `routeFuncFmt` | `text/html` | `ROUTE_FMT` | Pencil documents |
| `.rbs` | `routeFuncFileDb` | `*/*` | `ROUTE_BINSEG` | BinSeg databases |
| `.png` | `routeFuncStatic` | `image/png` | `ROUTE_STATIC\|ROUTE_ASSET` | PNG images |
| `.jpg` | `routeFuncStatic` | `image/jpeg` | `ROUTE_STATIC\|ROUTE_ASSET` | JPEG images |
| `.js` | `routeFuncStatic` | `text/javascript` | `ROUTE_STATIC\|ROUTE_ASSET` | JavaScript |
| `.css` | `routeFuncStatic` | `text/css` | `ROUTE_STATIC\|ROUTE_ASSET` | Stylesheets |
| `.txt` | `routeFuncStatic` | `text/plain` | `ROUTE_STATIC\|ROUTE_ASSET` | Plain text |
| `.body` | `routeFuncStatic` | `text/html` | `ROUTE_STATIC` | HTML fragments |

### Route Tree Structure

Routes form a hierarchical tree mirroring the filesystem:

```
Root Route
├── /stats              (stats.templ)
├── /tests              (tests.fmt)
├── /static/
│   ├── style.css       (ROUTE_ASSET)
│   ├── ui.js           (ROUTE_ASSET)
│   └── logo.png        (ROUTE_ASSET)
├── /system/
│   ├── error           (error.templ)
│   └── not-found       (not-found.templ)
└── /                   (index.fmt - ROUTE_INDEX)
```

**Tree Navigation**: Routes use `Inst_ByPath` for hierarchical lookup:

```c
// Get route for /stats
StrVec *path = IoPath(m, "/stats");
Route *route = Inst_ByPath(root, path, NULL, SPAN_OP_GET, NULL);

// Set route for /api/users
Route *apiUsersRoute = Inst_Make(m, TYPE_WWW_ROUTE);
Inst_ByPath(root, IoPath(m, "/api/users"), apiUsersRoute, SPAN_OP_SET, NULL);
```


## Implementation Details

### Route Building Process

Route building occurs at web server startup via `Route_CollectConfig` [route.c:185-219](../../../src/inter/www/route.c#L185-L219):

**Phase 1: Filesystem Scanning**

```c
status Route_CollectConfig(Route *root, StrVec *name,
                          StrVec *path, Table *configAtts){
    MemCh *m = root->m;

    // Get allowed extensions from config (or use all)
    Span *ext = Config_Sequence(m, Table_Get(configAtts, K(m, "ext")));
    if(ext != NULL){
        ext = AllExtSpan;  // Use all registered extensions
    }

    // Gather all matching files recursively
    Span *p = Span_Make(m);
    Dir_GatherByExt(m, StrVec_Str(m, path), p, ext);
```

**Phase 2: Per-File Route Creation**

```c
    // Iterate over discovered files
    Iter it;
    Iter_Init(&it, p);
    while((Iter_Next(&it) & END) == 0){
        StrVec *fpath = Iter_Get(&it);  // Absolute file path

        // Convert to URL path (relative to root)
        name = StrVec_Copy(m, fpath);
        StrVec_Incr(name, path->total);  // Remove base directory
        IoUtil_Annotate(m, name);        // Normalize path

        // Build route for this file
        Route *rt = Route_BuildRoute(root, name, fpath, configAtts);
    }
    return ZERO;
}
```

**Phase 3: Individual Route Building**

`Route_BuildRoute` [route.c:132-183](../../../src/inter/www/route.c#L132-L183) creates each route:

```c
Route *Route_BuildRoute(Route *root, StrVec *name,
                       StrVec *path, Table *configAtts){
    MemCh *m = root->m;

    // Look up handler by file extension
    StrVec *ext = IoUtil_GetExt(m, path);
    Str *mime = (Str *)Table_Get(RouteMimeTable, ext);
    Single *funcW = (Single *)Table_Get(RouteFuncTable, ext);

    // Skip if no handler or forbidden
    if(mime == NULL || funcW == NULL) return NULL;
    if(funcW->type.state & ROUTE_FORBIDDEN) return NULL;

    // Create route instance
    Route *rt = Inst_Make(m, TYPE_WWW_ROUTE);

    // Handle index files specially
    Str *index = Str_FromCstr(m, "index", ZERO);
    word flags = ZERO;
    if(Equals(name, index)){
        flags |= ROUTE_INDEX;
        // Use parent directory path for index
        route = Inst_ByPath(root, name, NULL, SPAN_OP_GET, NULL);
        if(route == NULL){
            route = Inst_Make(m, TYPE_WWW_ROUTE);
        }
    } else {
        // Strip extension for non-asset routes
        if((funcW->type.state & ROUTE_ASSET) == 0){
            IoUtil_SwapExt(m, name, NULL);  // Remove .templ, .fmt
        } else {
            name = Path_ReJoinExt(m, name); // Keep .png, .css
        }
        route = Inst_Make(m, TYPE_WWW_ROUTE);
    }

    // Insert route into tree
    Inst_ByPath(root, name, rt, SPAN_OP_SET, NULL);

    return route;
}
```

**Key Algorithm Details:**

1. **Extension Lookup**: File extension determines handler and MIME type
2. **Index Handling**: `index.*` files map to their parent directory URL
3. **Extension Stripping**: Non-asset routes drop extension (e.g., `/stats.templ` → `/stats`)
4. **Asset Preservation**: Assets keep extension (e.g., `/static/style.css`)
5. **Tree Insertion**: `Inst_ByPath` with `SPAN_OP_SET` creates hierarchical path

### Route Preparation

After routes are built, they must be **prepared** via `Route_Prepare` [route.c:264-367](../../../src/inter/www/route.c#L264-L367). This happens **once at startup**, not per-request.

**Preparation Tasks:**

1. **Static Files**: Store absolute path for direct file serving
2. **Templates**: Parse and prepare Templ objects
3. **Formats**: Parse Pencil documents into Mess tree
4. **BinSeg**: Open database context and parse configuration
5. **ETags**: Generate ETag headers for cacheable assets
6. **Configuration**: Load and attach .config file data

**Template Preparation Example** [route.c:94-125](../../../src/inter/www/route.c#L94-L125):

```c
static Templ *prepareTempl(Route *rt, StrVec *path){
    MemCh *m = rt->m;

    // Read template file
    StrVec *content = File_ToVec(m, StrVec_Str(m, path));
    if(content == NULL || content->total == 0){
        // Error handling...
        rt->type.state |= ERROR;
        return NULL;
    }

    // Parse template syntax
    Cursor *curs = Cursor_Make(m, content);
    TemplCtx *ctx = TemplCtx_FromCurs(m, curs, NULL);

    // Create and prepare Templ object
    Templ *templ = (Templ *)Templ_Make(m, ctx->it.p);
    if((Templ_Prepare(templ) & PROCESSING) == 0){
        // Preparation failed
        rt->type.state |= ERROR;
        return NULL;
    }

    return templ;  // Stored in route for reuse
}
```

**BinSeg Preparation** (from commented code in route.c:324-362):

```c
// For .rbs files, prepare database context
if(funcW->type.state & ROUTE_BINSEG){
    word flags = BINSEG_REVERSED;
    Table *seel = NULL;

    // Load configuration if present
    if(config != NULL){
        NodeObj *rbsConfig = Inst_ByPath(config,
            Sv(m, "binseg"), NULL, SPAN_OP_GET);

        // Parse allowed actions (read, add, modify)
        StrVec *actionV = NodeObj_Att(rbsConfig, K(m, "action"));
        Span *actions = Config_Sequence(m, actionV);
        Iter it;
        Iter_Init(&it, actions);
        while((Iter_Next(&it) & END) == 0){
            Abstract *a = Iter_Get(&it);
            flags |= BinSeg_ActionByStr(a);  // Set READ/ADD/MODIFY flags
        }

        // Get schema name for typed deserialization
        StrVec *seelName = NodeObj_Att(rbsConfig, K(m, "seel"));
        if(seelName != NULL){
            seel = Table_Get(SeelByName, seelName);
        }
    }

    // Create and open BinSeg context
    BinSegCtx *ctx = BinSegCtx_Make(m, flags);
    BinSegCtx_Open(ctx, StrVec_Str(m, path));
    ctx->seel = seel;

    // Store context in route
    Span_Set(rt, ROUTE_PROPIDX_ACTION, ctx);
}
```

**ETag Generation** [route.c:232-262](../../../src/inter/www/route.c#L232-L262):

```c
status Route_SetEtag(Route *rt, Str *path, struct timespec *mod){
    MemCh *m = rt->m;

    // Generate ETag from path + modification time
    StrVec *etag = HttpCtx_MakeEtag(rt->m, path, mod);

    // Create .etag cache file
    StrVec *etagPath = StrVec_From(m, Str_Clone(m, path));
    IoUtil_AddExt(m, etagPath, S(m, "etag"));

    Str *etagPathS = StrVec_Str(m, etagPath);
    Buff *bf = Buff_Make(m, NOOP);

    if(File_Open(bf, etagPathS, O_RDONLY) & ERROR){
        // Create new ETag file
        bf->type.state = BUFF_UNBUFFERED;
        File_Open(bf, etagPathS, O_CREAT|O_WRONLY);
        Buff_AddVec(bf, etag);
        File_Close(bf);
    } else {
        // Check if ETag changed
        Buff_Read(bf);
        File_Close(bf);
        if(!Equals(bf->v, etag)){
            // Update ETag file
            bf->type.state = BUFF_UNBUFFERED|BUFF_CLOBBER;
            File_Open(bf, etagPathS, O_WRONLY|O_TRUNC);
            Buff_AddVec(bf, etag);
            File_Close(bf);
        }
    }

    // Store ETag in route headers
    Table *headers = Seel_Get(rt, K(m, "headers"));
    Table_Set(headers, S(m, "Etag"), etag);

    return ZERO;
}
```

### Route Matching

Route matching happens in the HTTP request handler via `Route_Get` [route.c:369-371](../../../src/inter/www/route.c#L369-L371):

```c
Route *Route_Get(Route *root, StrVec *path){
    return Inst_ByPath(root, path, NULL, SPAN_OP_GET, NULL);
}
```

**This is remarkably simple** because routes are Inst objects: hierarchical navigation is handled by `Inst_ByPath`, which walks the tree using the path segments.

**Request Flow in WebServer_GatherPage** [webserver.c:100-186](../../../src/inter/www/webserver.c#L100-L186):

```c
status WebServer_GatherPage(Step *st, Task *tsk){
    MemCh *m = tsk->m;

    // Extract HTTP context
    TcpCtx *tcp = (TcpCtx *)as(tsk->source, TYPE_TCP_CTX);
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Normalize path
    IoUtil_Annotate(tsk->m, ctx->path);

    // Look up route
    ctx->route = Route_Get(tcp->pages, ctx->path);

    if(ctx->route == NULL){
        // Handle 404 Not Found
        ctx->code = 404;

        // Check for custom 404 handler
        Single *funcW = Route_MimeFunc(ctx->path);
        if(funcW != NULL && (funcW->type.state & ROUTE_ASSET) == 0){
            ctx->route = Route_Get(tcp->pages, IoPath(m, "/system/not-found"));
            if(ctx->route != NULL){
                // Populate error data
                Table *error = Table_Make(m);
                Table_Set(error, S(m, "name"), S(m, "Page not found"));
                Table_Set(error, S(m, "details"), ctx->path);
                Table_Set(ctx->data, S(m, "error"), error);

                // Serve custom 404 page
                Task_AddStep(tsk, WebServer_ServePage, NULL, NULL, ZERO);
                return (MORE|SUCCESS);
            }
        }

        // Default 404 response
        ctx->mime = S(m, "text/plain");
        Str *s = S(m, "not found");
        ctx->contentLength = s->length;

        Buff *bf = Buff_Make(m, ZERO);
        Buff_AddBytes(bf, s->bytes, s->length);
        Span_Add(proto->outSpan, bf);

        HttpProto_PrepareResponse(proto, tsk);
        Task_AddDataStep(tsk, TcpTask_WriteStep, NULL, NULL, NULL, ZERO);
        return (MORE|SUCCESS);
    }

    // Check ETag for 304 Not Modified
    StrVec *etag = Table_Get(ctx->headersIt.p, K(m, "If-None-Match"));
    if((etag != NULL) && Route_CheckEtag(ctx->route, etag) & SUCCESS){
        ctx->code = 304;
        HttpProto_PrepareResponse(proto, tsk);
        Task_AddDataStep(tsk, TcpTask_WriteStep, NULL, NULL, NULL, ZERO);
        return (MORE|SUCCESS);
    }

    // Load configuration from route
    Table *routeData = Seel_Get(ctx->route, K(m, "data"));
    if(routeData != NULL && routeData->nvalues > 0){
        Table *config = Table_Get(routeData, K(m, "config"));
        Table_Set(ctx->data, S(m, "config"), config);
    }

    // Add page serving step
    Task_AddStep(tsk, WebServer_ServePage, NULL, NULL, ZERO);

    // Execute custom gather function if present
    Single *gatherFunc = Seel_Get(ctx->route, K(m, "addStep"));
    if(gatherFunc != NULL && gatherFunc->type.of == TYPE_WRAPPED_PTR){
        Task_AddStep(tsk, gatherFunc->val.ptr, NULL, NULL, ZERO);
    }

    return (MORE|SUCCESS);
}
```

**Matching Algorithm:**

1. **Normalize Path**: `IoUtil_Annotate` ensures consistent path format
2. **Tree Lookup**: `Route_Get` walks Inst tree to find matching route
3. **404 Handling**: If no route, try custom `/system/not-found` handler
4. **ETag Check**: For assets, check `If-None-Match` header for 304 response
5. **Configuration Loading**: Attach route config to request data
6. **Custom Steps**: Execute route-specific gather functions if defined

### Handler Dispatch

Handler dispatch happens in `Route_Handle` [route.c:373-406](../../../src/inter/www/route.c#L373-L406):

```c
status Route_Handle(Route *rt, Span *dest, Table *data, HttpCtx *ctx){
    DebugStack_Push(rt, rt->type.of);
    status r = READY;

    // Get handler function from route
    Single *funcW = (Single *)as(Seel_Get(rt, S(m, "func")),
                                  TYPE_WRAPPED_FUNC);

    // Copy route headers to HTTP response
    Table *headers = Seel_Get(rt, K(m, "headers"));
    if(ctx != NULL && headers != NULL){
        Iter it;
        Iter_Init(&it, headers);
        while((Iter_Next(&it) & END) == 0){
            Hashed *h = Iter_Get(&it);
            if(h != NULL){
                Table_Set(ctx->headersOut, h->key, h->value);
            }
        }
    }

    // Call handler function
    RouteFunc func = (RouteFunc)funcW->val.ptr;
    status r = func(dest, rt, data, ctx);

    DebugStack_Pop();
    return r;
}
```

**Handler Function Signature:**

```c
typedef status (*RouteFunc)(Buff *bf, Route *rt, Inst *data, HttpCtx *ctx);
```

**Parameters:**
- `bf`: Output buffer for generated content
- `rt`: Route object containing prepared content (templates, etc.)
- `data`: Table of template variables and request data
- `ctx`: HTTP context for headers, query params, etc.

### Handler Implementations

#### Static File Handler

[route.c:8-15](../../../src/inter/www/route.c#L8-L15):

```c
static status routeFuncStatic(Buff *bf, Route *rt,
                              Table *_data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get absolute file path from route action
    Str *pathS = StrVec_Str(bf->m,
        (StrVec *)as(Seel_Get(rt, K(m, "action")), TYPE_STRVEC));

    // Enable unbuffered mode for direct file streaming
    bf->type.state |= BUFF_UNBUFFERED;

    // Open file for reading (content piped directly to socket)
    return File_Open(bf, pathS, O_RDONLY);
}
```

**Key Design**: Static files use **unbuffered I/O** to stream content directly to the socket without intermediate copying, maximizing performance for large assets.

#### Template Handler

[route.c:17-26](../../../src/inter/www/route.c#L17-L26):

```c
static status routeFuncTempl(Buff *bf, Route *rt,
                             Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get prepared Templ object from route
    Templ *templ = (Templ *)as(Seel_Get(rt, K(m, "templ")), TYPE_TEMPL);

    // Reset template state (reusable across requests)
    Templ_Reset(templ);
    templ->type.state |= bf->type.state;

    // Render template with data to buffer
    Templ_ToS(templ, bf, data, NULL);

    return templ->type.state;
}
```

**Key Design**: Templates are **prepared once** at startup and **reused** across requests. Only rendering (variable substitution) happens per-request, making template serving extremely fast.

#### Format Handler

[route.c:28-33](../../../src/inter/www/route.c#L28-L33):

```c
static status routeFuncFmt(Buff *bf, Route *rt,
                          Table *_data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get prepared Mess tree from route action
    Mess *mess = (Mess *)as(Seel_Get(rt, K(m, "action")), TYPE_MESS);

    // Convert Pencil format to HTML
    return Fmt_ToHtml(bf, mess);
}
```

**Key Design**: Pencil documents are **parsed once** into a Mess tree structure during preparation. Per-request work is just HTML serialization of the pre-built tree.

#### BinSeg Database Handler

[route.c:35-71](../../../src/inter/www/route.c#L35-L71):

```c
static status routeFuncFileDb(Buff *bf, Route *rt,
                              Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get database context from route
    BinSegCtx *bsCtx = (BinSegCtx *)as(Seel_Get(rt, K(m, "action")),
                                       TYPE_BINSEG_CTX);

    // Get requested action from query string
    Abstract *action = Table_Get(ctx->queryIt.p, K(m, "action"));
    if(action == NULL){
        ctx->code = 403;
        ctx->type.state |= ERROR;
        return ctx->type.state;
    }

    // Handle different actions
    if(Equals(action, K(m, "add")) && ctx->body != NULL &&
       (ctx->body->type.of == TYPE_TABLE ||
        ctx->body->type.of == TYPE_SPAN ||
        (ctx->body->type.of & TYPE_INSTANCE))){
        // Add new record to database
        BinSegCtx_Send(bsCtx, ctx->body);

    } else if(Equals(action, K(m, "modify"))){
        // Modify existing record (future implementation)

    } else if(Equals(action, K(m, "read"))){
        // Read from database (future implementation)

    } else {
        // Invalid action
        ctx->code = 403;
        ctx->type.state |= ERROR;
        return ctx->type.state;
    }

    // Check Accept header for response format
    StrVec *acceptHeader = Table_Get(ctx->headersIt.p, K(m, "Accept"));
    if(acceptHeader != NULL && Equals(acceptHeader, K(m, "text/html"))){
        // Render HTML confirmation page via template
        Table_Set(data, K(m, "form"), ctx->body);
        return routeFuncTempl(bf, rt, data, ctx);
    } else {
        // Return JSON response (future implementation)
    }

    return NOOP;
}
```

**Key Design**: BinSeg handlers provide **RESTful database endpoints** with action-based routing (`?action=add`, `?action=read`). The response format adapts based on the `Accept` header (HTML for browsers, JSON for APIs).

### Configuration Loading

Routes can have associated `.config` files that control behavior. Configuration is loaded during preparation and stored in the route's data table.

**Configuration Structure** (from test [route_tests.c:209](../../../src/programs/test/option/inter/route_tests.c#L209)):

```c
Str *path = IoUtil_GetAbsPath(m,
    Str_CstrRef(m, "./examples/test/pages/public/stats.config"));
Inst *config = Config_FromPath(m, path);
Table_Set(data, Str_CstrRef(m, "config"), config);
```

**Config File Format Example:**

```
[page]
pre-content = header
post-content = footer

[binseg]
action = read add
seel = UserSchema
```

**Configuration Inheritance**: Configuration files can be placed at any level of the directory hierarchy. Routes inherit configuration from their parent directories, allowing **cascading configuration** similar to .htaccess files in Apache.

### Page Serving

Complete page serving happens in `WebServer_ServePage` [webserver.c:188-262](../../../src/inter/www/webserver.c#L188-L262):

```c
status WebServer_ServePage(Step *st, Task *tsk){
    MemCh *m = tsk->m;
    status r = READY;

    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    TcpCtx *tcp = (TcpCtx *)as(tsk->source, TYPE_TCP_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Set MIME type from route
    ctx->mime = (Str *)Seel_Get(ctx->route, K(m, "mime"));
    Single *funcW = (Single *)as(Span_Get(ctx->route, ROUTE_PROPIDX_FUNC),
                                  TYPE_WRAPPED_FUNC);

    // For non-asset pages, add header
    if((funcW->type.state & ROUTE_ASSET) == 0){
        StrVec *path = Sv(m, "header");
        Route *header = Inst_ByPath(tcp->inc, path, NULL, SPAN_OP_GET, NULL);

        Buff *bf = Buff_Make(m, ZERO);
        r |= Route_Handle(header, bf, ctx->data, ctx);
        HttpProto_AddBuff(proto, bf);
    }

    // Check for pre-content from config
    NodeObj *config = Table_Get(ctx->data, K(m, "config"));
    NodeObj *pageNode = NodeObj_GetChild(config, K(m, "page"));
    StrVec *preContent = NodeObj_Att(pageNode, K(m, "pre-content"));
    if(preContent != NULL){
        Route *route = Inst_ByPath(tcp->inc, preContent, NULL, SPAN_OP_GET, NULL);
        if(route != NULL){
            Buff *bf = Buff_Make(m, ZERO);
            r |= Route_Handle(route, bf, ctx->data, ctx);
            HttpProto_AddBuff(proto, bf);
        }
    }

    // Render main content
    Buff *bf = Buff_Make(m, ZERO);
    r |= Route_Handle(ctx->route, bf, ctx->data, ctx);
    Buff_Stat(bf);  // Update content length
    HttpProto_AddBuff(proto, bf);

    // Check for post-content from config
    StrVec *postContent = NodeObj_Att(pageNode, K(m, "post-content"));
    if(postContent != NULL){
        Route *route = Inst_ByPath(tcp->inc, postContent, NULL, SPAN_OP_GET, NULL);
        if(route != NULL){
            Buff *bf = Buff_Make(m, ZERO);
            r |= Route_Handle(route, bf, ctx->data, ctx);
            HttpProto_AddBuff(proto, bf);
        }
    }

    // For non-asset pages, add footer
    if((funcW->type.state & ROUTE_ASSET) == 0){
        StrVec *path = Sv(m, "footer");
        Route *footer = Inst_ByPath(tcp->inc, path, NULL, SPAN_OP_GET, NULL);

        Buff *bf = Buff_Make(m, ZERO);
        r |= Route_Handle(footer, bf, ctx->data, ctx);
        HttpProto_AddBuff(proto, bf);
    }

    // Finalize response
    if(ctx->code == 0){
        ctx->code = 200;
    }

    HttpProto_PrepareResponse(proto, tsk);
    Task_AddDataStep(tsk, TcpTask_WriteStep, NULL, NULL, NULL, ZERO);

    return (MORE|SUCCESS);
}
```

**Page Composition Pattern:**

1. **Header Inclusion** (for non-assets): Shared header template
2. **Pre-Content** (from config): Optional content before main page
3. **Main Content**: Route handler output
4. **Post-Content** (from config): Optional content after main page
5. **Footer Inclusion** (for non-assets): Shared footer template

This creates a **template composition system** without requiring explicit master pages or layouts in templates themselves.



---

**Part 1 of 3** | [Part 2 →](www-routing-complete-part2)
