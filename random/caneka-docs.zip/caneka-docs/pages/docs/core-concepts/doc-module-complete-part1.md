# Doc Module: Complete Guide - Part 1

**Part 1 of 3** | [Part 2 →](doc-module-complete-part2)

---

## Core Philosophy

The Doc module in Caneka embodies a **parse-once, generate-many** architecture for high-performance document rendering. Unlike traditional markdown processors that re-parse content on every request, the Doc module:

1. **Parses documents once** at server startup into an intermediate tree representation (Mess)
2. **Caches the parsed structure** in route objects for reuse
3. **Generates HTML on demand** through fast tree traversal (~50-200μs per request)
4. **Integrates seamlessly** with the Roebling parser and WWW routing system

The module demonstrates Caneka's "glass-bottom-boat" philosophy by providing a transparent, inspectable pipeline from markup text to HTML output, with each stage clearly separated and accessible.

**Important Clarification**: Despite the name "Doc module", this is NOT a code documentation generator (like Doxygen or JavaDoc). It's a **content document formatter** that converts Pencil (.fmt) markup files into HTML for web serving.


## Architecture Overview

The Doc module spans two layers of Caneka's architecture:

### Inter Layer (High-Level Interface)

Located in `src/inter/doc/`, this layer provides the HTTP server integration:

- Route handler registration for .fmt files
- Cache management for parsed documents
- Integration with WWW routing system
- HTTP response generation

### Ext Layer (Implementation)

Located in `src/ext/format/fmt/`, this layer implements the actual parsing and HTML generation:

- **fmt_roebling.c** - Roebling-based Pencil parser with pattern matching
- **fmt_html.c** - HTML generation from parsed Mess trees
- **fmt_tokenize.c** - Tokenization rules for tree structure
- **fmt.h** - Public parser API
- **fmt_html.h** - Public HTML generation API

### Processing Pipeline

```
.fmt file → Cursor → Roebling Parser → Mess Tree → HTML Generator → HTML Output
                         ↓                  ↓            ↓
                   (startup, cached)   (in Route)  (per request)
```


## Structure and Key Definitions

### Mess - Message Tree Structure

The Mess structure represents the parsed document as a hierarchical tree:

```c
typedef struct mess {
    Type type;              // TYPE_MESS
    MemCh *m;              // Memory context for all allocations
    Node *root;            // Root node of the document tree
    Node *current;         // Current node during parsing (state tracking)
    Table *nextAtts;       // Attributes to apply to next node (buffered)
    void *currentValue;    // Current value being built (accumulator)
    Lookup *tokenizer;     // captureKey → Tokenize function mapping
    void *source;          // Original source data (Cursor typically)
    TranspCtx *transp;     // HTML generation context (if active)
} Mess;
```

**Key Fields**:
- **root**: Entry point for tree traversal during HTML generation
- **current**: Parser state - which node is being built during Roebling execution
- **nextAtts**: Buffered attributes like CSS classes that apply to the next element
- **tokenizer**: Maps Roebling capture keys to Node creation rules

### Node - Tree Element

Each element in the document tree is a Node:

```c
typedef struct node {
    Type type;              // TYPE_NODE
    Tokenize tk;            // Tokenization rules (how to create children)
    i16 typeOfChild;        // TYPE_STRVEC (text), TYPE_SPAN (nodes), TYPE_RELATION (table)
    i16 captureKey;         // FORMATTER_INDENT, FORMATTER_BULLET, etc.
    i16 latestKey;          // Last capture key processed (state tracking)
    struct node *parent;    // Parent node in tree (enables upward navigation)
    Table *atts;            // Attributes: class, href, src, alt, etc.
    Abstract *value;        // Direct value (StrVec for text content)
    Abstract *child;        // Children (Span of Nodes, or Relation for tables)
} Node;
```

**Node Types by captureKey**:
- **FORMATTER_INDENT** - Headings (H1, H2, H3 based on = count)
- **FORMATTER_PARAGRAPH** - Paragraphs (P tags)
- **FORMATTER_BULLET** - List items (UL/LI structure)
- **FORMATTER_TABLE** - Table rows (TABLE/TR/TD structure)
- **FORMATTER_TAG** - Inline tags (A for links, IMG for images)
- **FORMATTER_CLASS** - CSS class application (.classname syntax)

### TranspCtx - HTML Generation Context

The TranspCtx manages the HTML generation process:

```c
typedef struct transp_ctx {
    Type type;              // TYPE_TRANSP_CTX
    word status;            // Generation status flags
    i16 stackIdx;           // Current nesting depth (for indentation)
    MemCh *m;              // Memory context for generation
    Buff *bf;              // Output buffer (accumulated HTML)
    Iter it;               // Current position in tree traversal
    Lookup *lk;            // captureKey → TranspFunc mapping
    TranspFunc func;       // Current generator function
    Roebling *htmlEntRbl;  // HTML entity escaper (XSS prevention)
} TranspCtx;
```

**Key Responsibilities**:
- Tree traversal state (Iter it)
- Output accumulation (Buff bf)
- HTML entity escaping (htmlEntRbl)
- Nesting depth tracking (stackIdx)

### TranspFunc - HTML Generator Function

HTML generation is pluggable via function pointers:

```c
typedef i64 (*TranspFunc)(TranspCtx *ctx, word flags);
```

**Flags**:
- **TRANSP_OPEN** - Generate opening tag (e.g., `<H1>`)
- **TRANSP_BODY** - Generate content (escaped text)
- **TRANSP_CLOSE** - Generate closing tag (e.g., `</H1>`)

**Example Implementation**:
```c
static i64 headerFunc(TranspCtx *ctx, word flags){
    Node *node = (Node *)Iter_Get(&ctx->it);
    i32 level = /* extract heading level from node */;
    char *tagName = (level == 1) ? "H1" : (level == 2) ? "H2" : "H3";

    if(flags & TRANSP_OPEN){
        Tag_Out(ctx->bf, tagName, 0);
    }

    if(flags & TRANSP_BODY){
        // Escape content to prevent XSS
        HtmlEnt_IntoVec(ctx->m, ctx->htmlEntRbl, (StrVec *)node->value);
        StrVec *escaped = (StrVec *)ctx->htmlEntRbl->dest;
        ToS(ctx->bf, escaped, 0, ZERO);
    }

    if(flags & TRANSP_CLOSE){
        Tag_Out(ctx->bf, tagName, TAG_CLOSE);
    }

    return SUCCESS;
}
```


## Pencil Format Syntax Reference

The Pencil format (.fmt) provides a lightweight markup syntax for documents:

### Headings

```pencil
= Top Level Heading
== Second Level Heading
=== Third Level Heading
```

**Output**:
```html
<H1>Top Level Heading</H1>
<H2>Second Level Heading</H2>
<H3>Third Level Heading</H3>
```

**Rules**:
- Number of `=` symbols determines heading level (1-3)
- Space after `=` symbols is optional
- Heading text continues to end of line

### Paragraphs

```pencil
This is a paragraph of text.
It can span multiple lines.
Blank lines separate paragraphs.

This is a second paragraph.
```

**Output**:
```html
<P>This is a paragraph of text. It can span multiple lines. Blank lines separate paragraphs.</P>
<P>This is a second paragraph.</P>
```

**Rules**:
- Consecutive non-blank lines form a single paragraph
- Blank lines terminate paragraphs
- Text is automatically HTML-entity-escaped

### Links

```pencil
_link=Link Text@https://example.com
_link=Another Link@/local/path
```

**Output**:
```html
<A href="https://example.com">Link Text</A>
<A href="/local/path">Another Link</A>
```

**Syntax**:
- `_link=` prefix
- Link text (displayed)
- `@` separator
- URL (can be absolute or relative)

### Images

```pencil
_image=Alt Text@/images/diagram.png
_image=Photo@https://example.com/photo.jpg
```

**Output**:
```html
<IMG src="/images/diagram.png" alt="Alt Text">
<IMG src="https://example.com/photo.jpg" alt="Photo">
```

**Syntax**:
- `_image=` prefix
- Alt text (for accessibility)
- `@` separator
- Image URL or path

### Bullet Lists

```pencil
- First item
- Second item
- Third item
```

**Output**:
```html
<UL>
<LI>First item</LI>
<LI>Second item</LI>
<LI>Third item</LI>
</UL>
```

**Rules**:
- Each line starting with `- ` is a list item
- Consecutive items form a single list
- Blank line terminates the list

### Tables

```pencil
+Column A,Column B,Column C
Value 1A,Value 1B,Value 1C
Value 2A,Value 2B,Value 2C
```

**Output**:
```html
<TABLE>
<TR><TH>Column A</TH><TH>Column B</TH><TH>Column C</TH></TR>
<TR><TD>Value 1A</TD><TD>Value 1B</TD><TD>Value 1C</TD></TR>
<TR><TD>Value 2A</TD><TD>Value 2B</TD><TD>Value 2C</TD></TR>
</TABLE>
```

**Rules**:
- First line starting with `+` defines headers
- Comma-separated values
- Subsequent lines become data rows
- Blank line or different syntax terminates table

### CSS Classes

```pencil
.important
This paragraph has the 'important' CSS class applied.

.highlight
= This heading is highlighted
```

**Output**:
```html
<P class="important">This paragraph has the 'important' CSS class applied.</P>
<H1 class="highlight">This heading is highlighted</H1>
```

**Rules**:
- Line starting with `.` applies class to next element
- Class name follows the dot
- Applies to the immediately following paragraph, heading, list, etc.


## Implementation Details

### Pattern Matching with Roebling

The Fmt parser uses Roebling's pattern matching system to identify document elements:

#### Pattern Definitions

```c
// Heading markers: =, ==, ===
PatCharDef indentDef[] = {
    {PAT_MANY|PAT_TERM, '=', '='},  // One or more = symbols
    {PAT_SPACE, 0, 0},               // Optional whitespace
    {PAT_END, 0, 0}                  // Pattern terminator
};

// Bullet list markers: -
PatCharDef dashDef[] = {
    {PAT_CHAR|PAT_TERM, '-', 0},    // Single - character
    {PAT_SPACE, 0, 0},               // Required space after
    {PAT_END, 0, 0}
};

// Table markers: +
PatCharDef tableDef[] = {
    {PAT_CHAR|PAT_TERM, '+', 0},    // Single + character
    {PAT_END, 0, 0}
};

// CSS class markers: .
PatCharDef clsDef[] = {
    {PAT_CHAR|PAT_TERM, '.', 0},    // Single . character
    {PAT_END, 0, 0}
};

// Inline tag markers: _
PatCharDef tagDef[] = {
    {PAT_CHAR|PAT_TERM, '_', 0},    // Single _ character
    {PAT_END, 0, 0}
};

// Link/image label: text@url
PatCharDef labelDef[] = {
    {PAT_MANY|PAT_NOT, '@', 0},     // Everything until @
    {PAT_CHAR|PAT_TERM, '@', 0},    // @ separator
    {PAT_END, 0, 0}
};
```

#### State Machine Flow

The parser operates as a state machine with these key states:

```
FORMATTER_START
    ↓
    ├── Initialize patterns
    └── Set up Mess structure
    ↓
FORMATTER_LINE (beginning of each line)
    ↓
    ├→ FORMATTER_INDENT (= detected) → Create heading Node
    ├→ FORMATTER_BULLET (- detected) → Create list item Node
    ├→ FORMATTER_TABLE (+ detected) → Create table row
    ├→ FORMATTER_CLASS (. detected) → Buffer CSS class
    ├→ FORMATTER_TAG (_ detected) → Parse inline tag
    └→ FORMATTER_PARAGRAPH (default) → Accumulate text
    ↓
FORMATTER_VALUE / FORMATTER_LABEL (attribute parsing)
    ↓
    ├── Parse key-value pairs (class:value)
    ├── Parse labels (text@url)
    └── Apply to current Node
    ↓
FORMATTER_END
    ↓
    └── Return Mess tree
```

#### Capture Callbacks

When patterns match, Roebling invokes capture callbacks:

```c
status Capture(Roebling *rbl, word captureKey, StrVec *v){
    Mess *mess = (Mess *)rbl->dest;
    MemCh *m = mess->m;

    switch(captureKey){
    case FORMATTER_INDENT:{
        // Count = symbols to determine heading level
        i32 level = StrVec_CountChar(v, '=');

        // Create heading node
        Node *node = Node_Make(m, mess, FORMATTER_INDENT);
        node->value = (Abstract *)StrVec_Make(m);

        // Store level as attribute
        Single levelSingle = {.type = {TYPE_WRAPPED_I32, 0}, .val.w = level};
        Table_Set(node->atts, S(m, "level"), &levelSingle);

        // Update tokenizer for content
        Tokenize_Set(mess, FORMATTER_LINE, Token(TOKEN_SEPERATE, TYPE_STRVEC));
        break;
    }

    case FORMATTER_BULLET:{
        // Create list item node
        Node *node = Node_Make(m, mess, FORMATTER_BULLET);
        node->value = (Abstract *)StrVec_Make(m);

        // Set tokenization for list content
        Tokenize_Set(mess, FORMATTER_LINE, Token(TOKEN_NO_CONTENT|TOKEN_BY_TYPE, TYPE_STRVEC));
        break;
    }

    case FORMATTER_TAG:{
        // Parse tag type (link or image)
        Str *tagType = StrVec_Str(m, v);

        if(Str_EqualsS(tagType, "link")){
            // Create link node, prepare for text@url parsing
            Node *node = Node_Make(m, mess, FORMATTER_TAG);
            Table_Set(node->atts, S(m, "tag"), S(m, "A"));
        }else if(Str_EqualsS(tagType, "image")){
            // Create image node
            Node *node = Node_Make(m, mess, FORMATTER_TAG);
            Table_Set(node->atts, S(m, "tag"), S(m, "IMG"));
        }
        break;
    }

    case FORMATTER_CLASS:{
        // Buffer CSS class for next element
        Str *className = StrVec_Str(m, v);
        Table_Set(mess->nextAtts, S(m, "class"), className);
        break;
    }

    case FORMATTER_LABEL:{
        // Parse text@url syntax
        Cursor *curs = Cursor_Make(m, v);
        StrVec *text = StrVec_Make(m);
        StrVec *url = StrVec_Make(m);

        // Split on @ character
        while(!Cursor_AtEnd(curs)){
            quad c = Cursor_Read(curs);
            if(c == '@'){
                break;
            }
            StrVec_AppendChar(text, c);
        }

        // Remainder is URL
        while(!Cursor_AtEnd(curs)){
            StrVec_AppendChar(url, Cursor_Read(curs));
        }

        // Apply to current tag node
        Node *current = mess->current;
        current->value = (Abstract *)text;
        Table_Set(current->atts, S(m, "href"), StrVec_Str(m, url));  // or "src" for images
        break;
    }

    default:
        return ERROR;
    }

    return SUCCESS;
}
```

### Tokenization System

Tokenization rules determine how Nodes structure their children:

```c
typedef struct tokenize {
    word flags;     // TOKEN_* flags
    i16 typeOf;     // Child type: TYPE_NODE, TYPE_STRVEC, TYPE_RELATION
} Tokenize;
```

**Tokenization Flags**:
- **TOKEN_SEPERATE** - Each capture creates separate child
- **TOKEN_BY_TYPE** - Group children by type
- **TOKEN_NO_CONTENT** - Don't store content directly
- **TOKEN_ATTR_VALUE** - Store as attribute instead of child
- **TOKEN_INLINE** - Don't create new nesting level
- **TOKEN_OUTDENT** - Move up tree hierarchy
- **TOKEN_NO_COMBINE** - Don't merge with siblings

**Example Mappings**:

```c
Lookup *tokenizer = Lookup_Make(m);

// Headings: content is direct StrVec value
Lookup_Set(tokenizer, FORMATTER_INDENT,
           Token(TOKEN_ATTR_VALUE|TOKEN_OUTDENT, TYPE_NODE));

// Paragraphs: content accumulated as StrVec
Lookup_Set(tokenizer, FORMATTER_PARAGRAPH,
           Token(TOKEN_BY_TYPE, TYPE_STRVEC));

// Lists: items are separate Nodes
Lookup_Set(tokenizer, FORMATTER_BULLET,
           Token(TOKEN_NO_CONTENT|TOKEN_BY_TYPE, TYPE_STRVEC));

// Tables: use Relation for tabular structure
Lookup_Set(tokenizer, FORMATTER_TABLE,
           Token(TOKEN_NO_COMBINE, TYPE_RELATION));

// Inline tags: don't nest
Lookup_Set(tokenizer, FORMATTER_TAG,
           Token(TOKEN_ATTR_VALUE|TOKEN_INLINE, TYPE_NODE));
```

### HTML Generation Algorithm

HTML generation is a three-phase process for each Node:

#### Phase 1: Opening Tag

Generate the opening HTML tag with attributes:

```c
if(flags & TRANSP_OPEN){
    Node *node = (Node *)Iter_Get(&ctx->it);

    // Get tag name from captureKey mapping
    char *tagName = GetTagName(node->captureKey);

    // Start tag
    ToS(ctx->bf, S(ctx->m, "<"), 0, ZERO);
    ToS(ctx->bf, S(ctx->m, tagName), 0, ZERO);

    // Add attributes
    if(node->atts != NULL && Table_Count(node->atts) > 0){
        Iter attIter;
        Iter_Init(&attIter, node->atts);

        while((Iter_Next(&attIter) & END) == 0){
            Str *key = (Str *)Iter_Key(&attIter);
            Str *val = (Str *)Iter_Get(&attIter);

            ToS(ctx->bf, S(ctx->m, " "), 0, ZERO);
            ToS(ctx->bf, key, 0, ZERO);
            ToS(ctx->bf, S(ctx->m, "=\""), 0, ZERO);
            ToS(ctx->bf, val, 0, ZERO);
            ToS(ctx->bf, S(ctx->m, "\""), 0, ZERO);
        }
    }

    ToS(ctx->bf, S(ctx->m, ">"), 0, ZERO);
}
```

**Example Output**: `<H1>`, `<P class="important">`, `<A href="/docs">`

#### Phase 2: Body Content

Generate the content, with automatic HTML entity escaping:

```c
if(flags & TRANSP_BODY){
    Node *node = (Node *)Iter_Get(&ctx->it);

    if(node->value != NULL && node->value->type.of == TYPE_STRVEC){
        StrVec *content = (StrVec *)node->value;

        // Escape HTML entities to prevent XSS
        HtmlEnt_IntoVec(ctx->m, ctx->htmlEntRbl, content);
        StrVec *escaped = (StrVec *)ctx->htmlEntRbl->dest;

        // Output escaped content
        ToS(ctx->bf, escaped, 0, ZERO);
    }

    // Process children if present
    if(node->child != NULL){
        ProcessChildren(ctx, node);
    }
}
```

**HTML Entity Escaping**:
```
&  →  &amp;
<  →  &lt;
>  →  &gt;
"  →  &quot;
'  →  &apos;
```

This prevents XSS attacks by ensuring user content can't inject HTML tags.

#### Phase 3: Closing Tag

Generate the closing HTML tag:

```c
if(flags & TRANSP_CLOSE){
    Node *node = (Node *)Iter_Get(&ctx->it);
    char *tagName = GetTagName(node->captureKey);

    ToS(ctx->bf, S(ctx->m, "</"), 0, ZERO);
    ToS(ctx->bf, S(ctx->m, tagName), 0, ZERO);
    ToS(ctx->bf, S(ctx->m, ">"), 0, ZERO);
}
```

**Example Output**: `</H1>`, `</P>`, `</A>`

#### Complete Generator Example

```c
static i64 bulletFunc(TranspCtx *ctx, word flags){
    Node *node = (Node *)Iter_Get(&ctx->it);
    MemCh *m = ctx->m;

    if(flags & TRANSP_OPEN){
        // Check if this is first item in list
        if(node->parent != NULL && node->parent->captureKey != FORMATTER_BULLET){
            // Start new <UL>
            Tag_Out(ctx->bf, "UL", 0);
        }

        // Start <LI>
        Tag_Out(ctx->bf, "LI", 0);
    }

    if(flags & TRANSP_BODY){
        // Output escaped list item content
        if(node->value != NULL){
            HtmlEnt_IntoVec(m, ctx->htmlEntRbl, (StrVec *)node->value);
            ToS(ctx->bf, ctx->htmlEntRbl->dest, 0, ZERO);
        }
    }

    if(flags & TRANSP_CLOSE){
        // Close </LI>
        Tag_Out(ctx->bf, "LI", TAG_CLOSE);

        // Check if this is last item in list
        Iter peekIter = ctx->it;
        if((Iter_Next(&peekIter) & END) ||
           ((Node *)Iter_Get(&peekIter))->captureKey != FORMATTER_BULLET){
            // Close </UL>
            Tag_Out(ctx->bf, "UL", TAG_CLOSE);
        }
    }

    return SUCCESS;
}
```

This demonstrates context-aware tag generation - the UL wrapper is only created for the first/last items.

### Tree Walking with Iterator

HTML generation walks the Mess tree using the Iter system:

```c
status Fmt_ToHtml(Buff *bf, Mess *mess){
    MemCh *m = bf->m;

    // Create generation context
    TranspCtx *ctx = MemCh_Calloc(m, sizeof(TranspCtx));
    ctx->type.of = TYPE_TRANSP_CTX;
    ctx->m = m;
    ctx->bf = bf;
    ctx->htmlEntRbl = HtmlEnt_Make(m);
    ctx->lk = GetHtmlGeneratorLookup(m);

    // Initialize iterator at tree root
    Iter_Init(&ctx->it, mess->root);

    // Walk tree depth-first
    while((Iter_Next(&ctx->it) & END) == 0){
        Node *node = (Node *)Iter_Get(&ctx->it);

        // Look up generator function for this node type
        TranspFunc func = (TranspFunc)Lookup_Get(ctx->lk, node->captureKey);

        if(func == NULL){
            // Unknown node type - skip
            continue;
        }

        // Generate HTML (all three phases)
        word result = func(ctx, TRANSP_OPEN | TRANSP_BODY | TRANSP_CLOSE);

        if(result & ERROR){
            return ERROR;
        }
    }

    return SUCCESS;
}
```

**Iter Advantages**:
- Automatic depth-first traversal
- Stack-based nesting tracking
- Gap detection (between sibling nodes)
- Type-safe Node retrieval

### Integration with WWW Routing

The Doc module integrates with WWW routing through a two-phase lifecycle:

#### Startup Phase: Parse and Cache

When the web server starts and builds its route tree:

```c
status Route_Build(MemCh *m, Route *root, Str *basePath){
    // ... route tree construction ...

    // For each .fmt file found
    if(funcW->type.state & ROUTE_FMT){
        // Load file content
        StrVec *content = File_ToVec(m, pathS);
        Cursor *curs = Cursor_Make(m, content);

        // Parse Fmt → Mess tree
        Roebling *rbl = FormatFmt_Make(m, curs, NULL);
        status r = Roebling_Run(rbl);

        if(r & ERROR){
            Error(m, FUNCNAME, FILENAME, LINENUMBER,
                  "Fmt parse failed: $", (void *[]){pathS, NULL});
            return ERROR;
        }

        // Cache Mess in route for request handling
        Mess *mess = (Mess *)rbl->dest;
        Span_Set(rt, ROUTE_PROPIDX_ACTION, mess);

        // Set route handler function
        funcW->func = routeFuncFmt;
    }
}
```

**Key Points**:
- Parsing happens once during startup
- Mess tree stored in route's action property
- Parsing errors fail server startup (fail-fast)

#### Request Phase: Generate HTML

When a client requests a .fmt file:

```c
static status routeFuncFmt(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Retrieve cached Mess from route
    Mess *mess = (Mess *)as(Seel_Get(rt, K(m, "action")), TYPE_MESS);

    if(mess == NULL){
        return ERROR;
    }

    // Generate HTML from cached tree (fast!)
    return Fmt_ToHtml(bf, mess);
}
```

**Performance**:
- No file I/O (content already in memory)
- No parsing (Mess tree already built)
- Only tree walk + HTML generation
- Typical time: 50-200μs per request

### Comparison: Traditional vs Caneka Approach

**Traditional Markdown Processor (e.g., CommonMark)**:
```
Request → Load File → Parse → AST → Generate HTML → Response
          100μs      500μs    50μs    200μs
          Total: ~850μs per request
```

**Caneka Doc Module**:
```
Startup: Load File → Parse → Mess Tree (cached in Route)
         100μs      500μs

Request: Generate HTML from cached Mess → Response
         50-200μs
         Total: ~50-200μs per request
```

**Speedup**: 4-17x faster per request, with the tradeoff of higher memory usage (cached trees).



---

**Part 1 of 3** | [Part 2 →](doc-module-complete-part2)
