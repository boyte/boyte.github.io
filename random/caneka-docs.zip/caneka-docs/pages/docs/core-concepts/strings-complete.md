---
sidebar_position: 5
---

# String Handling - Complete Guide

Caneka's string system provides powerful, efficient text handling through three interconnected structures: **Str**, **StrVec**, and **Cursor**.

## Core Concepts

### Why Three String Types?

1. **Str**: Single contiguous string (like C strings, but managed)
2. **StrVec**: Multiple strings concatenated logically (zero-copy composition)
3. **Cursor**: Navigator for traversing strings with gap awareness

**Key Insight**: StrVec allows building large strings from pieces without copying, and Cursor provides unified access to both Str and StrVec.

## Str - Single String

A **Str** is a managed, growable string with explicit length tracking.

### Structure

```c
typedef struct str {
    Type type;
    word length;      // Current string length (excluding null terminator)
    word alloc;       // Allocated capacity
    byte *bytes;      // Byte buffer (null-terminated)
} Str;
```

### Creating Strings

```c
// From C string literal
Str *str = Str_From(m, "hello");

// From C string pointer
char *cstr = "world";
Str *str2 = Str_FromCstr(m, cstr);

// Empty string with capacity
Str *str3 = Str_Make(m, 100);  // Allocates 100 bytes
```

### Modifying Strings

```c
// Append
Str_Add(str, "!");              // str = "hello!"
Str_AddCstr(str, " world");     // str = "hello! world"

// Append character
Str_AddByte(str, '!');          // str = "hello! world!"

// Clear
Str_Clear(str);                 // str = "" (keeps allocation)
```

### String Flags

Strings have behavioral flags:

```c
STRING_TEXT      // Printable text
STRING_CONST     // Immutable
STRING_BINARY    // Binary data (not text)
STRING_ENCODED   // Encoded (e.g., UTF-8, hex)
STRING_COPY      // Copied from external source
STRING_UTF8      // UTF-8 encoded
```

**Setting Flags:**
```c
Type_SetFlag(&str->type, STRING_TEXT | STRING_UTF8);
```

## StrVec - Multi-Part String

A **StrVec** is a vector of Str objects that logically concatenates them without copying.

### Structure

```c
typedef struct strvec {
    Type type;
    i32 anchor;       // Anchor index (for snapshotting)
    i64 total;        // Total bytes across all strings
    Span *p;          // Span of Str pointers
} StrVec;
```

### Why Use StrVec?

**Problem**: Building large strings by repeatedly copying is slow:

```c
// SLOW - Each append copies entire string
Str *big = Str_Make(m, 0);
for (int i = 0; i < 10000; i++) {
    Str_Add(big, "chunk");  // Reallocs and copies!
}
```

**Solution**: StrVec stores pieces separately:

```c
// FAST - No copying, just append references
StrVec *vec = StrVec_Make(m);
for (int i = 0; i < 10000; i++) {
    StrVec_Add(vec, "chunk");  // Adds pointer, no copy
}
```

### Creating StrVec

```c
// Empty vector
StrVec *vec = StrVec_Make(m);

// From C string
StrVec *vec2 = StrVec_From(m, "initial content");
```

### Adding to StrVec

```c
StrVec *vec = StrVec_Make(m);

// Add C string literal
StrVec_Add(vec, "hello");      // Creates Str, adds to span

// Add C string pointer
StrVec_AddCstr(vec, cstr);

// Add existing Str
Str *str = Str_From(m, "world");
StrVec_AddStr(vec, str);

// Add another StrVec (concatenate)
StrVec_AddVec(vec, vec2);

// Result: All pieces stored separately, accessed as one string
```

### Accessing StrVec Content

```c
// Get total length
i64 len = vec->total;

// Get individual Str
Str *part = StrVec_GetStr(vec, 0);  // First string

// Get as single C string (creates copy)
char *cstr = StrVec_GetCStr(m, vec);
```

### StrVec Anchoring

**Anchoring** creates a snapshot point in the vector:

```c
StrVec *vec = StrVec_Make(m);
StrVec_Add(vec, "before");

// Set anchor
vec->anchor = vec->p->count;  // Remember current position

StrVec_Add(vec, "after");

// Can now work with "before anchor" vs "after anchor" sections
```

**Use Case**: Template engines use anchors to mark insertion points.

## Cursor - String Navigator

A **Cursor** provides unified navigation over Str and StrVec with gap awareness.

### Structure

```c
typedef struct cursor {
    Type type;
    i32 offset;           // Current byte offset
    StrVec *v;            // StrVec being navigated
    util slot;            // Current Str index in vector
    byte *ptr;            // Current position in current Str
    byte *end;            // End of current Str
    byte *start;          // Start of current Str
    Iter it;              // Iterator over StrVec span
} Cursor;
```

### Creating Cursors

```c
// From StrVec
StrVec *vec = StrVec_Make(m);
StrVec_Add(vec, "hello");
StrVec_Add(vec, "world");
Cursor *curs = Cursor_Make(m, vec);

// From Str (wraps in StrVec)
Str *str = Str_From(m, "text");
Cursor *curs2 = Cursor_FromStr(m, str);
```

### Navigating Cursors

```c
// Forward navigation
byte b = Cursor_NextByte(curs);   // Get next byte, advance
boolean hasMore = Cursor_HasMore(curs);  // More bytes?

// Backward navigation
Cursor_Prev(curs);                // Move back one byte

// Increment/Decrement
Cursor_Incr(curs, 5);             // Move forward 5 bytes
Cursor_Decr(curs, 3);             // Move backward 3 bytes

// Position checks
boolean atEnd = Cursor_AtEnd(curs);
boolean atStart = Cursor_AtStart(curs);

// Get current byte without advancing
byte current = Cursor_PeekByte(curs);
```

### Gap Detection

**Gaps** occur at boundaries between Str objects in a StrVec:

```c
StrVec *vec = StrVec_Make(m);
StrVec_Add(vec, "hello");   // Str 0
StrVec_Add(vec, "world");   // Str 1

Cursor *curs = Cursor_Make(m, vec);

// Navigate "hello"
while (!Cursor_AtGap(curs)) {
    byte b = Cursor_NextByte(curs);  // h, e, l, l, o
}

// Now at gap between "hello" and "world"
boolean gap = Cursor_AtGap(curs);  // true

// Cross gap
Cursor_Incr(curs, 1);  // Move into "world"
```

**Use Cases**:
- Detecting word boundaries
- Parsing whitespace-separated tokens
- Template insertion points

### Cursor Positioning

```c
// Set absolute position
Cursor_SetOffset(curs, 10);  // Jump to byte 10

// Reset to start
Cursor_Reset(curs);

// Jump to end
Cursor_SeekEnd(curs);
```

## Practical Examples

### Example 1: Building HTTP Response

```c
// Using StrVec to build response without copying
StrVec *response = StrVec_Make(m);

// Add status line
StrVec_Add(response, "HTTP/1.1 200 OK\r\n");

// Add headers
StrVec_Add(response, "Content-Type: text/html\r\n");
StrVec_Add(response, "Content-Length: ");
StrVec_Add(response, IntToStr(contentLength));
StrVec_Add(response, "\r\n\r\n");

// Add body
StrVec_AddVec(response, bodyContent);

// Send (StrVec can be sent directly via Buff)
Buff_AddVec(outputBuffer, response);
```

### Example 2: Parsing with Cursor

```c
// Parse key=value pairs
Cursor *curs = Cursor_Make(m, input);
StrVec *key = StrVec_Make(m);
StrVec *value = StrVec_Make(m);

// Read until '='
while (!Cursor_AtEnd(curs)) {
    byte b = Cursor_NextByte(curs);
    if (b == '=') break;
    StrVec_AddByte(key, b);
}

// Read until newline
while (!Cursor_AtEnd(curs)) {
    byte b = Cursor_NextByte(curs);
    if (b == '\n') break;
    StrVec_AddByte(value, b);
}

// Now have key="username", value="alice"
```

### Example 3: Template Rendering with Anchors

```c
StrVec *template = StrVec_Make(m);
StrVec_Add(template, "<html><body>");
StrVec_Add(template, "<h1>Title</h1>");

// Set anchor before content
template->anchor = template->p->count;

StrVec_Add(template, "</body></html>");

// Insert content at anchor
StrVec *content = StrVec_Make(m);
StrVec_Add(content, "<p>Dynamic content</p>");

// Splice at anchor
StrVec_InsertAt(template, template->anchor, content);

// Result: <html><body><h1>Title</h1><p>Dynamic content</p></body></html>
```

## String Formatting (Fmt)

Caneka provides a custom formatting system:

```c
// Format into StrVec
StrVec *result = Fmt(m, "User %s has %d points", username, points);

// Common patterns
StrVec *msg = Fmt(m, "Error: %s at line %d", error, line);
StrVec *path = Fmt(m, "/users/%s/data", userId);
```

## Performance Characteristics

| Operation | Str | StrVec | Notes |
|-----------|-----|--------|-------|
| Create | O(n) | O(1) | Str copies, StrVec just allocates span |
| Append | O(n) | O(1) | Str may realloc, StrVec adds pointer |
| Access | O(1) | O(k) | StrVec requires finding correct Str (k = parts) |
| Concatenate | O(n+m) | O(1) | Str copies both, StrVec adds reference |
| Iterate | O(n) | O(n) | Cursor provides unified iteration |

## Memory Considerations

### Str Memory

```c
Str *s = Str_Make(m, 100);
// Allocates: sizeof(Str) + 100 bytes
// Total: ~12 bytes (header) + 100 = 112 bytes
```

### StrVec Memory

```c
StrVec *v = StrVec_Make(m);
StrVec_Add(v, "a");  // Allocates: Str + span entry
StrVec_Add(v, "b");  // Allocates: Str + span entry

// Total: sizeof(StrVec) + span overhead + (Str overhead × parts)
// More overhead than single Str, but avoids copying
```

**Trade-off**: StrVec has higher fixed cost but scales better for large strings built incrementally.

## Best Practices

1. **Use Str for small, final strings**: Names, short messages
2. **Use StrVec for building large strings**: HTTP responses, templates
3. **Use Cursor for parsing**: Token extraction, format parsing
4. **Minimize StrVec parts**: Consolidate when possible
5. **Set STRING_TEXT flag**: Helps debugging and validation
6. **Check gaps with Cursor**: Avoid assuming contiguous bytes

## Common Pitfalls

### Pitfall 1: Modifying Const Strings

```c
// WRONG - Modifying STRING_CONST
Str *s = Str_From(m, "literal");
Type_SetFlag(&s->type, STRING_CONST);
Str_Add(s, "!");  // ERROR - modifying const string

// RIGHT - Check const flag
if (!Type_HasFlag(&s->type, STRING_CONST)) {
    Str_Add(s, "!");
}
```

### Pitfall 2: StrVec Aliasing

```c
// WRONG - Same Str added twice
Str *shared = Str_From(m, "shared");
StrVec_AddStr(vec, shared);
StrVec_AddStr(vec, shared);  // Same pointer twice
Str_Add(shared, "!");  // Affects both entries!

// RIGHT - Clone if needed
StrVec_AddStr(vec, shared);
StrVec_AddStr(vec, Str_Clone(m, shared));
```

### Pitfall 3: Cursor Past End

```c
// WRONG - Reading past end
while (true) {
    byte b = Cursor_NextByte(curs);  // May read garbage
    if (b == '\n') break;
}

// RIGHT - Check bounds
while (!Cursor_AtEnd(curs)) {
    byte b = Cursor_NextByte(curs);
    if (b == '\n') break;
}
```

## See Also

- [Memory Management](memory/overview.md) - Understanding allocations
- [Parser](parser/overview.md) - Using Cursor for parsing
- [Templates](templ-complete.md) - StrVec in template rendering
