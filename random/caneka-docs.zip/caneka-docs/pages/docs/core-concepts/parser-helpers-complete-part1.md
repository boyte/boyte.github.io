# Parser Helpers: Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](parser-helpers-complete-part2)

---

## Why Parser Helpers?

The [Roebling Parser](parser/overview.md) provides a powerful concurrent pattern-matching engine, but complex parsing tasks require supporting utilities. Caneka's Parser Helpers provide the building blocks for string manipulation, tokenization, pattern creation, and content extraction:

1. **Split** - Break strings on delimiters or patterns
2. **Snip** - Mark and extract string regions
3. **Tokenize** - Classify parsed content with metadata
4. **PatChar** - Create pattern definitions from strings
5. **Match** - Execute pattern matching on input
6. **Match_Replace** - Perform search-and-replace operations

These helpers form a **layered system**: high-level operations (Split, Tokenize) use lower-level primitives (Snip, Match, PatChar), all orchestrated by the Roebling parser for complex tasks.

**Key Advantages:**
- **Composability**: Helpers work together seamlessly
- **Type Safety**: All operations integrate with Caneka's type system
- **Memory Safety**: MemCh integration prevents leaks
- **Performance**: Zero-copy operations where possible
- **Flexibility**: Simple APIs for simple tasks, full Roebling for complex parsing

---


## Table of Contents

1. [Split - Delimiter-Based Splitting](#split---delimiter-based-splitting)
   - [Basic String Splitting](#basic-string-splitting)
   - [StrVec Splitting](#strvec-splitting)
   - [Delimiter Types](#delimiter-types)
   - [Split Flags](#split-flags)
2. [Snip - String Segmentation](#snip---string-segmentation)
   - [Snip Structure and Flags](#snip-structure-and-flags)
   - [Creating and Managing Snips](#creating-and-managing-snips)
   - [SnipSpan Operations](#snipspan-operations)
   - [Content Extraction](#content-extraction)
3. [Tokenize - Content Classification](#tokenize---content-classification)
   - [Tokenize Structure](#tokenize-structure)
   - [Token Flags](#token-flags)
   - [Creating Tokenizers](#creating-tokenizers)
4. [PatChar - Pattern Definitions](#patchar---pattern-definitions)
   - [Pattern Creation from Strings](#pattern-creation-from-strings)
   - [Knockout Patterns](#knockout-patterns)
   - [Pattern Macros](#pattern-macros)
5. [Match - Pattern Execution](#match---pattern-execution)
   - [Match Lifecycle](#match-lifecycle)
   - [Feeding Input](#feeding-input)
   - [Match State Management](#match-state-management)
   - [Boundary and Overlay Handling](#boundary-and-overlay-handling)
6. [Match_Replace - Search and Replace](#match_replace---search-and-replace)
7. [Helper Integration Patterns](#helper-integration-patterns)
8. [Performance Characteristics](#performance-characteristics)
9. [Best Practices](#best-practices)
10. [Common Pitfalls](#common-pitfalls)

---


## Split - Delimiter-Based Splitting

### Basic String Splitting

#### Str_SplitToSpan() - Split String to Span

**Signature:**
```c
Span *Str_SplitToSpan(MemCh *m, Str *s, void *split, word flags);
```

Splits a single Str on a delimiter and returns a Span containing the parts.

**Parameters:**
- `m` - Memory context for allocations
- `s` - String to split
- `split` - Delimiter (can be `TYPE_WRAPPED_I8`, `TYPE_STR`, or `TYPE_PATMATCH`)
- `flags` - Splitting behavior flags (e.g., `SPLIT_SKIP_FIRST_CHAR`)

**Example: Split on Single Character**
```c
Str *csv = S(m, "apple,banana,cherry");

// Split on comma
Span *parts = Str_SplitToSpan(m, csv, Single_WrapI8(m, ','), 0);

// Result: Span containing ["apple", "banana", "cherry"]

Iter *it = Iter_Make(m, parts);
while(Iter_Avail(it)){
    Str *part = Iter_Deref(it);
    printf("%s\n", Str_Chars(part));
    Iter_Next(it);
}
```

**Output:**
```
apple
banana
cherry
```

**Example: Split on String Delimiter**
```c
Str *log = S(m, "INFO: starting server :: DEBUG: loading config :: ERROR: connection failed");

// Split on " :: " delimiter
Str *delim = S(m, " :: ");
Span *entries = Str_SplitToSpan(m, log, delim, 0);

// Result: ["INFO: starting server", "DEBUG: loading config", "ERROR: connection failed"]
```

### StrVec Splitting

#### StrVec_Split() - In-Place Splitting

**Signature:**
```c
status StrVec_Split(StrVec *v, void *split);
```

Splits all strings in a StrVec on the delimiter, modifying the StrVec in-place by inserting separator markers.

**Example:**
```c
StrVec *path = Sv(m, "/usr/local/bin");
StrVec_Split(path, Single_WrapI8(m, '/'));

// path now contains: ["", "usr", "local", "bin"]
// Each component is a separate Str in the vector
```

**Key Behavior:** This function **modifies** the StrVec by inserting `STRING_SEPERATOR` flags between split components.

#### StrVec_SplitToSpan() - Split to New Span

**Signature:**
```c
Span *StrVec_SplitToSpan(MemCh *m, StrVec *v, void *split);
```

Splits a StrVec and returns result as a new Span (non-destructive).

**Example:**
```c
StrVec *input = Sv(m, "one two three");
Span *words = StrVec_SplitToSpan(m, input, Single_WrapI8(m, ' '), 0);

// input unchanged, words contains separate Str objects
```

#### StrVec_ToSpan() - Convert Without Splitting

**Signature:**
```c
Span *StrVec_ToSpan(MemCh *m, StrVec *v);
```

Converts a StrVec to a Span without splitting. Useful for converting between collection types.

**Example:**
```c
StrVec *vec = Sv(m, "hello");
Span *span = StrVec_ToSpan(m, vec);

// span[0] = "hello" (single element)
```

### Delimiter Types

The `split` parameter accepts three types:

#### 1. Single Character (`TYPE_WRAPPED_I8`)

**Example:**
```c
// Split on space
Span *words = Str_SplitToSpan(m, S(m, "hello world"), Single_WrapI8(m, ' '), 0);
```

**Use Case:** Simple delimiter like comma, space, tab, newline.

#### 2. String Delimiter (`TYPE_STR`)

**Example:**
```c
// Split on multi-character delimiter
Span *parts = Str_SplitToSpan(m, S(m, "A::B::C"), S(m, "::"), 0);
// Result: ["A", "B", "C"]
```

**Use Case:** Multi-character separators like `::`, `=>`, `<br>`.

#### 3. Pattern Delimiter (`TYPE_PATMATCH`)

**Example:**
```c
// Split on any whitespace (space, tab, newline)
PatCharDef *ws = PatChar_FromStr(m, S(m, " \t\n"));
Span *tokens = Str_SplitToSpan(m, S(m, "a\tb  c\nd"), ws, 0);
// Result: ["a", "b", "c", "d"]
```

**Use Case:** Complex patterns like "any whitespace", "any punctuation", regex-like splits.

### Split Flags

#### SPLIT_SKIP_FIRST_CHAR

Skips the first character of each result fragment.

**Example:**
```c
Str *quoted = S(m, "'apple','banana','cherry'");
Span *parts = Str_SplitToSpan(m, quoted, Single_WrapI8(m, ','), SPLIT_SKIP_FIRST_CHAR);

// Result: ["apple'", "banana'", "cherry'"]
// The leading ' after comma is skipped
```

**Use Case:** Trimming leading characters after split.

---


## Snip - String Segmentation

### Snip Structure and Flags

A **Snip** represents a labeled segment of a string with metadata about its content type.

**Structure:**
```c
typedef struct snip {
    Type type;      // TYPE_SNIP
    i32 length;     // Length of this segment in bytes
} Snip;
```

**Snip Classification Flags:**

| Flag | Symbol | Description |
|------|--------|-------------|
| `SNIP_CONTENT` | `C` | Actual captured content |
| `SNIP_GAP` | `G` | Gap/skipped region |
| `SNIP_STR_BOUNDRY` | `B` | String boundary marker |
| `SNIP_UNCLAIMED` | `U` | Unclaimed/unmatched region |
| `SNIP_SKIPPED` | `K` | Intentionally skipped |
| `SNIP_SEP` | `S` | Separator |
| `SNIP_NOTAIL` | `T` | No tail processing |

**Conceptual Example:**

Parsing HTML: `<b>hello</b>`

```
Snips:
[0] length=3, SNIP_GAP        // "<b>"
[1] length=5, SNIP_CONTENT    // "hello"
[2] length=4, SNIP_GAP        // "</b>"
```

Only the `SNIP_CONTENT` region ("hello") gets extracted as actual content.

### Creating and Managing Snips

#### Snip_Make() - Create Empty Snip

**Signature:**
```c
Snip *Snip_Make(MemCh *m);
```

Creates a new empty Snip structure.

**Example:**
```c
Snip *sn = Snip_Make(m);
sn->length = 10;
Snip_Set(sn, SNIP_CONTENT);  // Mark as content
```

#### Snip_From() - Clone Snip

**Signature:**
```c
Snip *Snip_From(MemCh *m, Snip *sn);
```

Creates a copy of an existing Snip.

**Example:**
```c
Snip *original = Snip_Make(m);
original->length = 5;

Snip *copy = Snip_From(m, original);
// copy->length == 5
```

### SnipSpan Operations

A **SnipSpan** is a Span of Snip objects, representing a complete segmentation of a string.

#### SnipSpan_Add() - Add Existing Snip

**Signature:**
```c
status SnipSpan_Add(Span *sns, Snip *sn);
```

Adds a pre-constructed Snip to the span.

**Example:**
```c
Span *snips = Span_Make(m, TYPE_SNIP);

Snip *s1 = Snip_Make(m);
s1->length = 10;
Snip_Set(s1, SNIP_CONTENT);

SnipSpan_Add(snips, s1);
```

#### SnipSpan_AddFrom() - Add New Snip Inline

**Signature:**
```c
status SnipSpan_AddFrom(Span *sns, i32 length, word flags);
```

Creates and adds a new Snip in one operation.

**Example:**
```c
Span *snips = Span_Make(m, TYPE_SNIP);

// Add content region
SnipSpan_AddFrom(snips, 5, SNIP_CONTENT);

// Add gap region
SnipSpan_AddFrom(snips, 3, SNIP_GAP);

// Add another content region
SnipSpan_AddFrom(snips, 7, SNIP_CONTENT);

// snips now represents: [C:5, G:3, C:7]
```

#### SnipSpan_Remove() - Remove from End

**Signature:**
```c
status SnipSpan_Remove(Span *sns, i32 length);
```

Removes `length` bytes from the end of the SnipSpan, potentially removing or shrinking the last Snip.

**Example:**
```c
Span *snips = Span_Make(m, TYPE_SNIP);
SnipSpan_AddFrom(snips, 10, SNIP_CONTENT);
SnipSpan_AddFrom(snips, 5, SNIP_GAP);

// Remove 3 bytes from end
SnipSpan_Remove(snips, 3);
// Now: [C:10, G:2]  (gap reduced from 5 to 2)
```

#### SnipSpan_Set() - Mark Region with Type

**Signature:**
```c
status SnipSpan_Set(MemCh *m, Span *sns, i32 length, word flags);
```

Marks the next `length` bytes with specific flags. If a Snip of that type exists at the end, extends it; otherwise creates new Snip.

**Example:**
```c
Span *snips = Span_Make(m, TYPE_SNIP);

// Mark 10 bytes as content
SnipSpan_Set(m, snips, 10, SNIP_CONTENT);

// Mark 5 bytes as gap
SnipSpan_Set(m, snips, 5, SNIP_GAP);

// Mark 3 more bytes as content (creates new snip)
SnipSpan_Set(m, snips, 3, SNIP_CONTENT);

// Result: [C:10, G:5, C:3]
```

#### SnipSpan_SetAll() - Mark All with Type

**Signature:**
```c
status SnipSpan_SetAll(Span *sns, word flags);
```

Marks all Snips in the span with specified flags (bitwise OR).

**Example:**
```c
Span *snips = Span_Make(m, TYPE_SNIP);
SnipSpan_AddFrom(snips, 10, SNIP_CONTENT);
SnipSpan_AddFrom(snips, 5, SNIP_CONTENT);

// Mark all as SNIP_SEP
SnipSpan_SetAll(snips, SNIP_SEP);

// All snips now have both SNIP_CONTENT and SNIP_SEP flags
```

#### SnipSpan_Total() - Sum Lengths by Type

**Signature:**
```c
i64 SnipSpan_Total(Span *sns, word flags);
```

Returns the total length of all Snips matching the specified flags.

**Example:**
```c
Span *snips = Span_Make(m, TYPE_SNIP);
SnipSpan_AddFrom(snips, 10, SNIP_CONTENT);
SnipSpan_AddFrom(snips, 3, SNIP_GAP);
SnipSpan_AddFrom(snips, 7, SNIP_CONTENT);
SnipSpan_AddFrom(snips, 2, SNIP_GAP);

i64 contentSize = SnipSpan_Total(snips, SNIP_CONTENT);
// Result: 17 (10 + 7)

i64 gapSize = SnipSpan_Total(snips, SNIP_GAP);
// Result: 5 (3 + 2)
```

**Use Case:** Calculate output buffer size before extraction.

### Content Extraction

#### StrVec_Snip() - Extract Content by Snips

**Signature:**
```c
StrVec *StrVec_Snip(MemCh *m, Span *sns, Cursor *curs);
```

Extracts actual content from a Cursor based on Snip markers. Only regions marked `SNIP_CONTENT` are included in the result.

**Example:**
```c
// Parse HTML tags, extract text content
Str *html = S(m, "<p>Hello <b>World</b>!</p>");
Cursor *curs = Cursor_Make(m, html);

// Build snips to track regions
Span *snips = Span_Make(m, TYPE_SNIP);
SnipSpan_AddFrom(snips, 3, SNIP_GAP);        // "<p>"
SnipSpan_AddFrom(snips, 6, SNIP_CONTENT);    // "Hello "
SnipSpan_AddFrom(snips, 3, SNIP_GAP);        // "<b>"
SnipSpan_AddFrom(snips, 5, SNIP_CONTENT);    // "World"
SnipSpan_AddFrom(snips, 4, SNIP_GAP);        // "</b>"
SnipSpan_AddFrom(snips, 1, SNIP_CONTENT);    // "!"
SnipSpan_AddFrom(snips, 4, SNIP_GAP);        // "</p>"

// Extract content
StrVec *content = StrVec_Snip(m, snips, curs);

// Result: StrVec containing ["Hello ", "World", "!"]
```

**Key Behavior:** Only `SNIP_CONTENT` regions are extracted. All other flags (GAP, UNCLAIMED, etc.) are skipped.

---


## Tokenize - Content Classification

### Tokenize Structure

**Tokenize** objects attach metadata to parsed regions, classifying them by type and capture behavior.

**Structure:**
```c
typedef struct tokenize {
    Type type;        // TYPE_TOKENIZE
    i16 captureKey;   // Unique ID for this token pattern
    cls typeOf;       // Type classification for output
} Tokenize;
```

**Fields:**
- `captureKey` - Unique identifier for this token type (used by Roebling capture callbacks)
- `typeOf` - Type classification (e.g., `TYPE_STR`, `TYPE_I32`, custom types)

### Token Flags

| Flag | Description |
|------|-------------|
| `TOKEN_SEPARATE` | Mark token as separate entity (don't combine with adjacent) |
| `TOKEN_OUTDENT` | Token represents dedentation |
| `TOKEN_INLINE` | Token is inline (not block-level) |
| `TOKEN_BY_TYPE` | Classify token by type field |
| `TOKEN_ATTR_KEY` | Token is an attribute key |
| `TOKEN_ATTR_VALUE` | Token is an attribute value |
| `TOKEN_NO_COMBINE` | Don't combine with adjacent tokens |
| `TOKEN_NO_CONTENT` | Token has no content (structural only) |

### Creating Tokenizers

#### Tokenize_Make() - Create Tokenizer

**Signature:**
```c
Tokenize *Tokenize_Make(MemCh *m, word captureKey, word flags, cls typeOf);
```

Creates a Tokenize configuration object.

**Example: Classify CSV Fields**
```c
// Define token types
#define TOKEN_NAME    1
#define TOKEN_AGE     2
#define TOKEN_CITY    3

// Create tokenizers for each field type
Tokenize *nameToken = Tokenize_Make(m, TOKEN_NAME, TOKEN_SEPARATE, TYPE_STR);
Tokenize *ageToken = Tokenize_Make(m, TOKEN_AGE, TOKEN_SEPARATE, TYPE_I32);
Tokenize *cityToken = Tokenize_Make(m, TOKEN_CITY, TOKEN_SEPARATE, TYPE_STR);

// Use with Roebling parser to classify captured regions
```

**Example: HTML Element Types**
```c
#define TOKEN_HEADING     10
#define TOKEN_PARAGRAPH   11
#define TOKEN_LIST_ITEM   12

Tokenize *h1Token = Tokenize_Make(m, TOKEN_HEADING, TOKEN_INLINE, TYPE_STR);
Tokenize *pToken = Tokenize_Make(m, TOKEN_PARAGRAPH, 0, TYPE_STR);
Tokenize *liToken = Tokenize_Make(m, TOKEN_LIST_ITEM, TOKEN_SEPARATE, TYPE_STR);
```

**Integration with Roebling:**

Tokenize objects are typically used within Roebling capture callbacks to classify matched regions:

```c
status CaptureField(void *ctx, i16 captureKey, StrVec *content){
    switch(captureKey){
    case TOKEN_NAME:
        ProcessName(content);
        break;
    case TOKEN_AGE:
        ProcessAge(content);
        break;
    case TOKEN_CITY:
        ProcessCity(content);
        break;
    }
    return SUCCESS;
}
```

---


## PatChar - Pattern Definitions

### Pattern Creation from Strings

#### PatChar_FromStr() - Create Pattern from String

**Signature:**
```c
PatCharDef *PatChar_FromStr(MemCh *m, Str *s);
```

Converts a string to a terminal pattern definition. Each character in the string becomes an alternative match.

**Example:**
```c
// Match any vowel
PatCharDef *vowels = PatChar_FromStr(m, S(m, "aeiouAEIOU"));

// Use in pattern matching
Match *mt = Match_Make(m, vowels, NULL);
Match_Feed(m, mt, 'a');  // SUCCESS
Match_Feed(m, mt, 'z');  // ERROR
```

**Use Case:** Character class matching (digits, letters, punctuation).

**Example: Digit Pattern**
```c
PatCharDef *digits = PatChar_FromStr(m, S(m, "0123456789"));

// Match any digit
```

#### PatChar_FromStrVec() - Create Pattern from StrVec

**Signature:**
```c
PatCharDef *PatChar_FromStrVec(MemCh *m, StrVec *v);
```

Creates pattern definition from a StrVec where each Str is an alternative.

**Example:**
```c
StrVec *keywords = Sv(m, "if");
StrVec_Add(keywords, S(m, "else"));
StrVec_Add(keywords, S(m, "while"));
StrVec_Add(keywords, S(m, "for"));

PatCharDef *kwPattern = PatChar_FromStrVec(m, keywords);

// Matches: "if", "else", "while", or "for"
```

**Use Case:** Multi-character token matching (keywords, operators).

### Knockout Patterns

#### PatChar_KoFromStr() - Create Knockout Pattern

**Signature:**
```c
PatCharDef *PatChar_KoFromStr(MemCh *m, Str *s);
```

Creates a "knockout" pattern that matches any character **except** those in the string.

**Example:**
```c
// Match any non-whitespace
PatCharDef *nonWs = PatChar_KoFromStr(m, S(m, " \t\n\r"));

// Matches any character except space, tab, newline, carriage return
```

**Use Case:** Inverse character classes (non-digits, non-letters, non-whitespace).

**Example: Non-Quote Characters**
```c
// Match anything except quotes
PatCharDef *notQuote = PatChar_KoFromStr(m, S(m, "\"'"));

// Useful for parsing quoted strings
```

### Pattern Macros

Located in `match_predefs.h`, these macros provide pre-defined patterns for common parsing tasks:

**Text Matching:**
```c
#define patText         // Match any text
#define patTextChar     // Match one text character
#define patAnyText      // Match any text (alternative)
```

**Whitespace:**
```c
#define patWhiteSpace   // Match whitespace characters
#define WS_REQUIRED     // Whitespace must be present
#define WS_OPTIONAL     // Whitespace is optional
#define WS_INVERT_MANY  // Match non-whitespace
```

**Special:**
```c
#define TEXT_DEF        // Text pattern definition
#define NL_DEF          // Newline definition
#define UPPER_DEF       // Uppercase letter pattern
```

**Example Using Macros:**
```c
// Parse identifier: letter followed by letters/digits
PatCharDef *letter = UPPER_DEF;  // or custom letter pattern
PatCharDef *alnum = PatChar_FromStr(m, S(m, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"));

// Use in Roebling parser
```

---


## Match - Pattern Execution

### Match Lifecycle

**Match** objects execute pattern matching by processing input byte-by-byte and tracking match state.

**Structure (simplified):**
```c
typedef struct match {
    Type type;
    MemCh *m;
    PatCharDef *def;    // Pattern to match
    Span *backlog;      // Pending matches
    // ... internal state
} Match;
```

#### Match_Make() - Create Match

**Signature:**
```c
Match *Match_Make(MemCh *m, PatCharDef *def, Span *backlog);
```

Creates a new Match object for executing a pattern definition.

**Parameters:**
- `m` - Memory context
- `def` - Pattern definition to match
- `backlog` - Optional Span to store match history (can be NULL)

**Example:**
```c
PatCharDef *digits = PatChar_FromStr(m, S(m, "0123456789"));
Match *mt = Match_Make(m, digits, NULL);
```

### Feeding Input

#### Match_Feed() - Feed One Byte

**Signature:**
```c
status Match_Feed(MemCh *m, Match *mt, byte c);
```

Feeds a single byte to the matcher and returns SUCCESS if it matches the pattern, ERROR otherwise.

**Example: Match Digits**
```c
PatCharDef *digits = PatChar_FromStr(m, S(m, "0123456789"));
Match *mt = Match_Make(m, digits, NULL);

if(Match_Feed(m, mt, '5') == SUCCESS){
    printf("Matched digit\n");
}

if(Match_Feed(m, mt, 'x') == ERROR){
    printf("Not a digit\n");
}
```

**Example: Match Word**
```c
PatCharDef *word = PatChar_FromStr(m, S(m, "hello"));
Match *mt = Match_Make(m, word, NULL);

const char *input = "hello";
for(i32 i = 0; input[i] != '\0'; i++){
    if(Match_Feed(m, mt, input[i]) == ERROR){
        printf("Match failed at position %d\n", i);
        break;
    }
}

printf("Full word matched\n");
```

#### Match_FeedStrVec() - Feed Vector

**Signature:**
```c
status Match_FeedStrVec(MemCh *m, Match *mt, StrVec *v, i32 offset);
```

Feeds an entire StrVec starting from `offset` to the matcher.

**Example:**
```c
StrVec *input = Sv(m, "12345abc");
PatCharDef *digits = PatChar_FromStr(m, S(m, "0123456789"));
Match *mt = Match_Make(m, digits, NULL);

// Feed entire vector
status result = Match_FeedStrVec(m, mt, input, 0);

// result indicates if entire vector matched pattern
```

#### Match_FeedEnd() - Signal EOF

**Signature:**
```c
status Match_FeedEnd(MemCh *m, Match *mt);
```

Signals end-of-input to the matcher. Required for patterns that need to know input is complete.

**Example:**
```c
Match_Feed(m, mt, 'a');
Match_Feed(m, mt, 'b');
Match_Feed(m, mt, 'c');

// Signal input complete
Match_FeedEnd(m, mt);

// Matcher can now finalize state
```

### Match State Management

#### Match_StartOver() - Reset Match

**Signature:**
```c
status Match_StartOver(Match *mt);
```

Resets the matcher to initial state without destroying it. Allows reusing matcher for new input.

**Example:**
```c
PatCharDef *pattern = PatChar_FromStr(m, S(m, "test"));
Match *mt = Match_Make(m, pattern, NULL);

// First match attempt
Match_Feed(m, mt, 't');
Match_Feed(m, mt, 'e');
Match_Feed(m, mt, 's');
Match_Feed(m, mt, 't');

// Reset for new input
Match_StartOver(mt);

// Second match attempt
Match_Feed(m, mt, 't');
// ...
```

**Use Case:** Reusing matchers in loops without re-allocating.

#### Match_SetCount() - Set Repetition Count

**Signature:**
```c
status Match_SetCount(Match *mt, i32 count);
```

Sets the repetition count for pattern matching. Used for quantifiers like "match 3-5 times".

**Example:**
```c
PatCharDef *digit = PatChar_FromStr(m, S(m, "0123456789"));
Match *mt = Match_Make(m, digit, NULL);

// Match exactly 4 digits
Match_SetCount(mt, 4);

Match_Feed(m, mt, '1');
Match_Feed(m, mt, '2');
Match_Feed(m, mt, '3');
Match_Feed(m, mt, '4');
// Match complete
```

### Boundary and Overlay Handling

#### Match_AddBoundrySnip() - Mark Boundaries

**Signature:**
```c
status Match_AddBoundrySnip(MemCh *m, Match *mt);
```

Adds boundary markers to the match's Snip span. Used to mark start/end of matches.

**Example:**
```c
Span *backlog = Span_Make(m, TYPE_SNIP);
Match *mt = Match_Make(m, pattern, backlog);

// Feed input...
Match_Feed(m, mt, 'a');

// Mark boundary
Match_AddBoundrySnip(m, mt);

// Snip span now contains boundary marker
```

#### Match_ResolveOverlay() - Handle Overlapping Matches

**Signature:**
```c
status Match_ResolveOverlay(Match *mt, i32 length);
```

Resolves overlapping match regions of specified length. Used when multiple patterns match the same input.

**Example:**
```c
// When two patterns overlap, resolve conflict
Match_ResolveOverlay(mt, overlapLength);
```

**Use Case:** Complex parsing where ambiguous matches need resolution strategy.

---


## Match_Replace - Search and Replace

### Match_StrReplace() - Replace Matched Pattern

**Signature:**
```c
status Match_StrReplace(
    MemCh *m,
    Str *s,
    Str *new,
    Match *mt,
    i32 *_pos
);
```

Performs search-and-replace operation using a Match object to find patterns.

**Parameters:**
- `m` - Memory context
- `s` - String to search in (modified in-place)
- `new` - Replacement string
- `mt` - Match object with pattern
- `_pos` - (Output) Position of replacement

**Example: Replace First Occurrence**
```c
Str *text = S(m, "Hello World, Hello Universe");
Str *replacement = S(m, "Hi");

// Create matcher for "Hello"
PatCharDef *pattern = PatChar_FromStr(m, S(m, "Hello"));
Match *mt = Match_Make(m, pattern, NULL);

i32 pos;
Match_StrReplace(m, text, replacement, mt, &pos);

// Result: "Hi World, Hello Universe"
// pos = 0 (position of replacement)
```

**Example: Replace All Occurrences**
```c
Str *text = S(m, "cat dog cat bird cat");
Str *replacement = S(m, "animal");

PatCharDef *pattern = PatChar_FromStr(m, S(m, "cat"));
Match *mt = Match_Make(m, pattern, NULL);

i32 pos = 0;
while(Match_StrReplace(m, text, replacement, mt, &pos) == SUCCESS){
    Match_StartOver(mt);  // Reset for next match
}

// Result: "animal dog animal bird animal"
```

**Use Case:** Template variable substitution, text sanitization, string normalization.

---


## Helper Integration Patterns

### Pattern 1: CSV Parsing with Split and Tokenize

**Problem:** Parse CSV data with field type classification.

**Solution:**
```c
// Sample CSV
Str *csv = S(m, "Alice,30,Engineer\nBob,25,Designer");

// Split on newlines
Span *lines = Str_SplitToSpan(m, csv, Single_WrapI8(m, '\n'), 0);

// Process each line
Iter *it = Iter_Make(m, lines);
while(Iter_Avail(it)){
    Str *line = Iter_Deref(it);

    // Split on comma
    Span *fields = Str_SplitToSpan(m, line, Single_WrapI8(m, ','), 0);

    // Extract fields
    Str *name = Span_At(fields, 0);
    Str *age = Span_At(fields, 1);
    Str *job = Span_At(fields, 2);

    printf("Name: %s, Age: %s, Job: %s\n",
           Str_Chars(name), Str_Chars(age), Str_Chars(job));

    Iter_Next(it);
}
```

### Pattern 2: HTML Tag Removal with Snip

**Problem:** Extract text content from HTML, removing all tags.

**Solution:**
```c
status ParseHTML(MemCh *m, Str *html, StrVec **_content){
    Cursor *curs = Cursor_Make(m, html);
    Span *snips = Span_Make(m, TYPE_SNIP);

    bool inTag = false;
    i32 contentStart = 0;

    // Scan for tags
    for(i32 i = 0; i < Str_Len(html); i++){
        byte c = Str_At(html, i);

        if(c == '<'){
            // Mark preceding content
            if(!inTag && i > contentStart){
                SnipSpan_AddFrom(snips, i - contentStart, SNIP_CONTENT);
            }
            inTag = true;
            contentStart = i;
        } else if(c == '>'){
            // Mark tag as gap
            if(inTag){
                SnipSpan_AddFrom(snips, (i - contentStart) + 1, SNIP_GAP);
                contentStart = i + 1;
            }
            inTag = false;
        }
    }

    // Mark final content
    if(!inTag && contentStart < Str_Len(html)){
        SnipSpan_AddFrom(snips, Str_Len(html) - contentStart, SNIP_CONTENT);
    }

    // Extract content
    *_content = StrVec_Snip(m, snips, curs);
    return SUCCESS;
}

// Usage
Str *html = S(m, "<p>Hello <b>World</b>!</p>");
StrVec *text;
ParseHTML(m, html, &text);
// text contains: ["Hello ", "World", "!"]
```

### Pattern 3: Whitespace Normalization with Match_Replace

**Problem:** Replace multiple whitespace with single space.

**Solution:**
```c
Str *text = S(m, "Hello    World\t\tTest\n\nData");

// Create pattern matching any whitespace
PatCharDef *ws = PatChar_FromStr(m, S(m, " \t\n\r"));
Match *mt = Match_Make(m, ws, NULL);

// Replacement: single space
Str *space = S(m, " ");

i32 pos = 0;
while(Match_StrReplace(m, text, space, mt, &pos) == SUCCESS){
    Match_StartOver(mt);
}

// Result: "Hello World Test Data"
```

### Pattern 4: INI File Parsing with PatChar and Split

**Problem:** Parse INI configuration file with sections and key-value pairs.

**Solution:**
```c
void ParseINI(MemCh *m, Str *ini){
    // Split on newlines
    Span *lines = Str_SplitToSpan(m, ini, Single_WrapI8(m, '\n'), 0);

    Str *currentSection = NULL;

    Iter *it = Iter_Make(m, lines);
    while(Iter_Avail(it)){
        Str *line = Iter_Deref(it);

        // Trim whitespace
        line = Str_Trim(m, line);

        // Check for section header [Section]
        if(Str_At(line, 0) == '['){
            // Extract section name
            currentSection = Str_Sub(m, line, 1, Str_Len(line) - 2);
            printf("Section: %s\n", Str_Chars(currentSection));
        }
        // Check for key=value
        else if(Str_IndexOf(line, S(m, "=")) >= 0){
            // Split on =
            Span *pair = Str_SplitToSpan(m, line, Single_WrapI8(m, '='), 0);

            Str *key = Str_Trim(m, Span_At(pair, 0));
            Str *value = Str_Trim(m, Span_At(pair, 1));

            printf("  %s = %s\n", Str_Chars(key), Str_Chars(value));
        }

        Iter_Next(it);
    }
}

// Usage
Str *ini = S(m,
    "[Database]\n"
    "host = localhost\n"
    "port = 5432\n"
    "\n"
    "[Logging]\n"
    "level = debug\n"
);

ParseINI(m, ini);
```

**Output:**
```
Section: Database
  host = localhost
  port = 5432
Section: Logging
  level = debug
```

### Pattern 5: URL Query Parameter Parsing

**Problem:** Extract query parameters from URL.

**Solution:**
```c
void ParseQueryParams(MemCh *m, Str *url){
    // Find query string start
    i32 qPos = Str_IndexOf(url, S(m, "?"));
    if(qPos < 0) return;

    // Extract query string
    Str *query = Str_Sub(m, url, qPos + 1, Str_Len(url) - qPos - 1);

    // Split on &
    Span *params = Str_SplitToSpan(m, query, Single_WrapI8(m, '&'), 0);

    Iter *it = Iter_Make(m, params);
    while(Iter_Avail(it)){
        Str *param = Iter_Deref(it);

        // Split on =
        Span *kv = Str_SplitToSpan(m, param, Single_WrapI8(m, '='), 0);

        if(Span_Len(kv) == 2){
            Str *key = Span_At(kv, 0);
            Str *value = Span_At(kv, 1);

            printf("%s: %s\n", Str_Chars(key), Str_Chars(value));
        }

        Iter_Next(it);
    }
}

// Usage
Str *url = S(m, "http://example.com/search?q=caneka&lang=en&page=2");
ParseQueryParams(m, url);
```

**Output:**
```
q: caneka
lang: en
page: 2
```

---



---

**Part 1 of 2** | [Part 2 →](parser-helpers-complete-part2)
