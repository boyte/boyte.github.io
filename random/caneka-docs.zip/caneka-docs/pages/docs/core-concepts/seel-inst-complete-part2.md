# Seel/Inst Property System: Complete Guide - Part 2

[← Part 1](seel-inst-complete-part1) | **Part 2 of 2**

---

## Real-World Examples

### Example 1: NodeObj (Basic Hierarchical Structure)

**Use case**: Configuration files, hierarchical data trees.

**Structure**:

```c
// NodeObj Seel (from nodeobj.c)
Table *seel = Table_Make(m);
Table_Set(seel, S(m, "name"), I16_Wrapped(m, TYPE_STRVEC));
Table_Set(seel, S(m, "atts"), I16_Wrapped(m, TYPE_TABLE));
Table_Set(seel, S(m, "children"), I16_Wrapped(m, TYPE_TABLE));
Seel_Seel(m, seel, S(m, "NodeObj"), TYPE_NODEOBJ);
```

**Usage**:

```c
// Create a config tree
Inst *config = Inst_Make(m, TYPE_NODEOBJ);
Seel_Set(config, K(m, "name"), Sv(m, "app_config"));

// Add database settings
Inst *dbConfig = Inst_Make(m, TYPE_NODEOBJ);
Seel_Set(dbConfig, K(m, "name"), Sv(m, "database"));
Inst_SetAtt(dbConfig, K(m, "host"), Sv(m, "localhost"));
Inst_SetAtt(dbConfig, K(m, "port"), I32_Wrapped(m, 5432));

// Add as child of root config
Table *children = Seel_Get(config, K(m, "children"));
Table_Set(children, K(m, "database"), dbConfig);

// Add server settings
Inst *serverConfig = Inst_Make(m, TYPE_NODEOBJ);
Seel_Set(serverConfig, K(m, "name"), Sv(m, "server"));
Inst_SetAtt(serverConfig, K(m, "port"), I32_Wrapped(m, 8080));
Inst_SetAtt(serverConfig, K(m, "threads"), I32_Wrapped(m, 4));

Table_Set(children, K(m, "server"), serverConfig);

// Result tree:
// config (app_config)
// ├── database
// │   ├── host: "localhost"
// │   └── port: 5432
// └── server
//     ├── port: 8080
//     └── threads: 4

// Retrieve a nested value
Inst *db = Inst_GetChild(config, K(m, "database"));
StrVec *host = Inst_Att(db, K(m, "host"));
// host → "localhost"
```

**Serialization**:

```c
Buff *bf = Buff_Make(m, ZERO);
Inst_ShowKeys(bf, config, 0);

// Output:
//  -> database=NodeObj
//    -> host=StrVec
//    -> port=Wrapped
//  -> server=NodeObj
//    -> port=Wrapped
//    -> threads=Wrapped
```

### Example 2: Route (Web Framework)

**Use case**: HTTP routing with file handlers, templates, and dynamic content.

**Structure** (simplified):

```c
typedef Inst Route;

enum route_prop_idx {
    ROUTE_PROPIDX_PATH = 0,      // StrVec
    ROUTE_PROPIDX_DATA = 1,      // Table (atts)
    ROUTE_PROPIDX_CHILDREN = 2,  // Table (child routes)
    ROUTE_ROUTE_GENS = 3,        // Single (generation count)
};
```

**Usage**:

```c
// Create root route
Route *root = Inst_Make(m, TYPE_ROUTE);
Seel_Set(root, K(m, "name"), Sv(m, "/"));

// Add a static file route
Route *indexRoute = Inst_Make(m, TYPE_ROUTE);
Seel_Set(indexRoute, K(m, "name"), Sv(m, "index.html"));
indexRoute->type.state |= ROUTE_STATIC;

// Set file path in atts
Inst_SetAtt(indexRoute, K(m, "action"), Sv(m, "/var/www/index.html"));
Inst_SetAtt(indexRoute, K(m, "mime"), Sv(m, "text/html"));

// Add to root's children
Table *children = Seel_Get(root, K(m, "children"));
Table_Set(children, K(m, "index.html"), indexRoute);

// Add a template route
Route *blogRoute = Inst_Make(m, TYPE_ROUTE);
Seel_Set(blogRoute, K(m, "name"), Sv(m, "blog.templ"));
blogRoute->type.state |= ROUTE_DYNAMIC;

// Prepare template and store in atts
Templ *templ = Templ_Make(m);
// ... parse and prepare template ...
Inst_SetAtt(blogRoute, K(m, "templ"), templ);

Table_Set(children, K(m, "blog.templ"), blogRoute);

// Route lookup at request time
StrVec *requestPath = Sv(m, "/index.html");
Route *matched = Route_Get(root, requestPath);

if(matched != NULL){
    // Get handler based on route type
    if(matched->type.state & ROUTE_STATIC){
        StrVec *filePath = Inst_Att(matched, K(m, "action"));
        // Serve file at filePath
    }else if(matched->type.state & ROUTE_DYNAMIC){
        Templ *templ = Inst_Att(matched, K(m, "templ"));
        // Render template
    }
}
```

**Route tree structure**:

```
root (/)
├── index.html [ROUTE_STATIC]
│   ├── action: "/var/www/index.html"
│   └── mime: "text/html"
└── blog.templ [ROUTE_DYNAMIC]
    └── templ: <Templ instance>
```

### Example 3: HttpCtx (Request Context)

**Use case**: HTTP request handling, embedding session, body, headers.

**Structure** (simplified from http_ctx.h):

```c
typedef struct {
    Type type;
    MemCh *m;
    i32 method;           // HTTP_METHOD_GET, POST, etc.
    i32 code;             // HTTP status code
    i64 contentLength;    // Response content length
    Str *mime;            // Content-Type
    StrVec *httpVersion;  // "HTTP/1.1"
    StrVec *path;         // Request path
    Abstract *body;       // Parsed request body
    Inst *route;          // Matched route (embeds another Inst!)
    Table *data;          // Template data context
    Span *errors;         // Error collection
    Table *headersOut;    // Response headers
    Iter queryIt;         // Query parameters iterator
    Iter headersIt;       // Request headers iterator
} HttpCtx;
```

**Not an Inst** in the traditional sense (it's a struct, not a Span), but it **contains** an Inst:

```c
HttpCtx *ctx = HttpCtx_Make(m);

// Set basic properties
ctx->method = HTTP_METHOD_GET;
ctx->code = 200;
ctx->path = Sv(m, "/api/users");

// Embed a Route Inst
ctx->route = Inst_Make(m, TYPE_ROUTE);
Seel_Set(ctx->route, K(m, "name"), Sv(m, "/api/users"));
Inst_SetAtt(ctx->route, K(m, "handler"), funcPointer);

// Set data for template rendering
ctx->data = Table_Make(m);
Table_Set(ctx->data, K(m, "session"), sessionTable);
Table_Set(ctx->data, K(m, "user"), userInst);

// Access embedded Route properties
StrVec *routeName = Seel_Get(ctx->route, K(m, "name"));
// routeName → "/api/users"

void *handler = Inst_Att(ctx->route, K(m, "handler"));
// handler → function pointer
```

**Key insight**: HttpCtx demonstrates **composition**—it's a struct that contains an Inst (`route`), which itself can contain child Insts. This allows flexible data structures without deep inheritance.

### Example 4: Login Session (Complex Inst with Nested Tables)

**Use case**: User session management with authentication state.

**Structure** (conceptual):

```c
// Login Seel
Table *loginSeel = Table_Make(m);
Table_Set(loginSeel, S(m, "name"), I16_Wrapped(m, TYPE_STRVEC));
Table_Set(loginSeel, S(m, "atts"), I16_Wrapped(m, TYPE_TABLE));
Table_Set(loginSeel, S(m, "children"), I16_Wrapped(m, TYPE_TABLE));
Table_Set(loginSeel, S(m, "user_id"), I16_Wrapped(m, TYPE_WRAPPED_I32));
Table_Set(loginSeel, S(m, "session_token"), I16_Wrapped(m, TYPE_STRVEC));
Table_Set(loginSeel, S(m, "expires"), I16_Wrapped(m, TYPE_WRAPPED_I64));
Seel_Seel(m, loginSeel, S(m, "Login"), TYPE_LOGIN);
```

**Usage**:

```c
// Create a login session
Inst *session = Inst_Make(m, TYPE_LOGIN);

// Set session properties
Seel_Set(session, K(m, "user_id"), I32_Wrapped(m, 42));
Seel_Set(session, K(m, "session_token"), Sv(m, "abc123xyz"));

struct timespec expires;
Time_Now(&expires);
expires.tv_sec += 3600;  // Expires in 1 hour
Seel_Set(session, K(m, "expires"), I64_Wrapped(m, expires.tv_sec));

// Set user details in atts
Inst_SetAtt(session, K(m, "username"), Sv(m, "alice"));
Inst_SetAtt(session, K(m, "email"), Sv(m, "alice@example.com"));
Inst_SetAtt(session, K(m, "roles"), Sv(m, "admin,editor"));

// Store session in global session table
extern Table *SessionTable;
Table_Set(SessionTable, session->session_token, session);

// Later: Validate session
StrVec *token = Sv(m, "abc123xyz");
Inst *retrieved = Table_Get(SessionTable, token);

if(retrieved != NULL){
    struct timespec now;
    Time_Now(&now);

    Single *expiresW = Seel_Get(retrieved, K(m, "expires"));
    if(expiresW->val.i64 > now.tv_sec){
        // Session valid
        StrVec *username = Inst_Att(retrieved, K(m, "username"));
        Out("Welcome back, $!\n", (void *[]){username, NULL});
    }else{
        // Session expired
        Table_Remove(SessionTable, token);
    }
}
```

**Result**: Sessions are Inst objects that can be:
- Serialized to BinSeg for persistence
- Stored in Tables for O(1) lookup by token
- Extended with custom attributes without schema changes
- Type-checked at access time


## Performance Characteristics

### Memory Layout

**Seel overhead** (per type, not per instance):
- Seel Table: ~64 bytes base + (properties × 32 bytes)
- For 5 properties: ~64 + 160 = 224 bytes
- Ordered Span: ~32 bytes + (properties × 8 bytes) = ~72 bytes
- **Total per type: ~300 bytes**

**Inst overhead** (per instance):
- Span base: 32 bytes
- Properties: depends on Span capacity
- For 5 properties: Span with capacity 8 → 32 + (8 × 8) = 96 bytes minimum
- **Total: ~96 bytes + property values**

**Comparison to C structs**:
- C struct: Exact size of fields (e.g., 3 pointers = 24 bytes)
- Inst: Span overhead (~96 bytes) + property values
- **Trade-off**: Inst uses ~4x more memory than equivalent struct, but gains dynamic properties and introspection

### Access Performance

**`Seel_Get` time complexity**:

1. Lookup Seel in `SeelLookup`: **O(1)** (Lookup is O(1))
2. Find property in Seel Table: **O(1)** (hash table lookup)
3. Access Span element: **O(1)** (array index)
4. **Total: O(1)** with 3 pointer dereferences + 1 hash lookup

**Actual timing** (approximate):
- Modern CPU: ~5-10 nanoseconds for the hash lookup
- 3 pointer dereferences: ~3 nanoseconds
- **Total: ~8-13 ns per `Seel_Get`**

**Comparison**:
- C struct field access: `ctx->field` → 1 pointer dereference → ~1 ns
- **Seel_Get is ~8-13x slower than struct access**

**Optimization**: Use `Span_Get` directly when index is known:

```c
// Slow (but type-safe)
StrVec *name = Seel_Get(inst, K(m, "name"));

// Fast (but requires knowing index)
StrVec *name = Span_Get(inst, INST_PROPIDX_NAME);
```

For hot paths (called millions of times), use `Span_Get` with enum indices. For everything else, `Seel_Get` is fine.

### Initialization Cost

**`Inst_Make` time**:
- Span allocation: ~100 ns
- Iterate Seel properties (e.g., 5 properties): ~50 ns
- Allocate container properties (Table/Span): ~200 ns per container
- **Total for 3 properties (2 Tables + 1 StrVec): ~400 ns**

**Comparison**:
- `malloc` a struct: ~50 ns
- **Inst_Make is ~8x slower than malloc**

**When it matters**: If you're creating millions of Inst objects in a tight loop, consider using a simpler structure. For typical usage (hundreds or thousands of instances), the overhead is negligible.

### Iteration Performance

**Iterating properties via Seel**:

```c
// Get ordered property list
Span *ordSeel = Seel_OrdSeel(m, TYPE_NODEOBJ);

Iter it;
Iter_Init(&it, ordSeel);
while((Iter_Next(&it) & END) == 0){
    StrVec *propName = Iter_Get(&it);
    void *propValue = Seel_Get(inst, propName);
    // Process property
}
```

**Cost**: ~10 ns per property access × number of properties
- 5 properties: ~50 ns total
- 50 properties: ~500 ns

**Comparison**:
- Iterating struct fields (via reflection in C++): Not directly possible without codegen
- **Seel enables runtime introspection at modest cost**

### Best Practices for Performance

1. **Use Span_Get for hot paths**: When you know the property index, bypass Seel lookup.
2. **Cache Seel lookups**: If you're accessing the same property many times, cache the Seel index.
3. **Avoid deep nesting in tight loops**: Each level of `Inst_ByPath` adds ~10 ns overhead.
4. **Use NodeObj helpers**: `Inst_Att` is faster than `Seel_Get` for the `atts` property.
5. **Pre-allocate Inst instances**: Reuse instances instead of creating new ones if possible.


## Integration with Type System

### Type Registration Flow

When you create a new Seel:

1. **Define properties in Table**:
   ```c
   Table *seel = Table_Make(m);
   Table_Set(seel, S(m, "prop1"), I16_Wrapped(m, TYPE_STRVEC));
   Table_Set(seel, S(m, "prop2"), I16_Wrapped(m, TYPE_TABLE));
   ```

2. **Register with `Seel_Seel`**:
   ```c
   Seel_Seel(m, seel, S(m, "MyType"), TYPE_MYTYPE);
   ```

3. **Side effects**:
   - `SeelLookup[TYPE_MYTYPE] = seel` (enables `Seel_Get/Set`)
   - `SeelOrdLookup[TYPE_MYTYPE] = orderedSpan` (enables iteration)
   - `SeelNameLookup[TYPE_MYTYPE] = "MyType"` (enables type name queries)
   - `SeelByName["MyType"] = TYPE_MYTYPE` (enables name → type lookup)
   - `ToStreamLookup[TYPE_MYTYPE] = Inst_Print` (enables serialization)

4. **Result**: All Caneka type system functions now recognize `TYPE_MYTYPE` as a valid type.

### Type-Safe Casting

**The type system's `as()` macro** integrates with Seel:

```c
// Get a property that should be TYPE_STRVEC
void *value = Seel_Get(inst, K(m, "name"));

// Cast with type check
StrVec *name = (StrVec *)as(value, TYPE_STRVEC);
if(name == NULL){
    // Type mismatch or NULL value
}
```

**Seel's built-in type check**:

```c
// Inside Seel_Get:
Single *sg = (Single *)h->value;  // sg->val.w is expected type
Abstract *value = Span_Get(inst, h->orderIdx);

if(value != NULL){
    as(value, sg->val.w);  // Validate actual type matches Seel type
}
```

This **double validation** ensures:
1. Seel says property should be type X
2. Actual value in Span is type X
3. You cast to type X

If any step fails, you get an error message with file/line number.

### String Representation

**`Inst_Print` function** (registered in `ToStreamLookup`):

```c
status Inst_Print(Buff *bf, Inst *inst){
    // Get type name
    Str *typeName = Lookup_Get(SeelNameLookup, inst->type.of);

    // Start output
    Fmt(bf, "${\n", (void *[]){typeName, NULL});

    // Get ordered properties
    Span *ordSeel = Seel_OrdSeel(inst->m, inst->type.of);

    // Print each property
    Iter it;
    Iter_Init(&it, ordSeel);
    while((Iter_Next(&it) & END) == 0){
        StrVec *propName = Iter_Get(&it);
        void *propValue = Seel_Get(inst, propName);

        Fmt(bf, "  $: ", (void *[]){propName, NULL});
        ToS(bf, propValue, 0, ZERO);  // Recursively print value
        Buff_AddBytes(bf, (byte *)"\n", 1);
    }

    Fmt(bf, "}\n", NULL);
    return READY;
}
```

**Example output**:

```
NodeObj{
  name: "database"
  atts: Table{
    host: "localhost"
    port: 5432
  }
  children: Table{
    users: NodeObj{...}
  }
}
```

**Usage**:

```c
Buff *bf = Buff_Make(m, ZERO);
ToS(bf, inst, 0, ZERO);  // Calls Inst_Print via ToStreamLookup

Out("$\n", (void *[]){bf->v, NULL});
```

This makes debugging Inst structures trivial—just print them!


## Common Patterns

### Pattern 1: Config File Loading

**Goal**: Load a hierarchical config file into Inst structure.

**Implementation**:

```c
Inst *LoadConfig(MemCh *m, Str *filePath){
    // Parse config file (e.g., .config format)
    StrVec *content = File_ToVec(m, filePath);
    Table *parsed = Config_Parse(m, content);

    // Convert Table to Inst
    Inst *config = Inst_Make(m, TYPE_NODEOBJ);
    Seel_Set(config, K(m, "name"), Str_Copy(m, filePath));

    // Populate attributes
    Iter it;
    Iter_Init(&it, parsed);
    while((Iter_Next(&it) & END) == 0){
        Hashed *h = Iter_Get(&it);

        if(h->value->type.of == TYPE_TABLE){
            // Nested config → create child Inst
            Inst *child = LoadConfigFromTable(m, (Table *)h->value);
            Inst_SetAtt(config, h->key, child);
        }else{
            // Simple value → set as attribute
            Inst_SetAtt(config, h->key, h->value);
        }
    }

    return config;
}
```

**Usage**:

```c
Inst *appConfig = LoadConfig(m, Sv(m, "/etc/app/config.ini"));

// Access nested values
StrVec *dbHost = Inst_Att(Inst_Att(appConfig, K(m, "database")), K(m, "host"));
```

### Pattern 2: Route Tree Building

**Goal**: Scan filesystem and create Route Insts for each file.

**Implementation**:

```c
Route *BuildRouteTree(MemCh *m, StrVec *dirPath){
    Route *route = Inst_Make(m, TYPE_ROUTE);
    Seel_Set(route, K(m, "name"), dirPath);

    Table *children = Seel_Get(route, K(m, "children"));

    DIR *dir = opendir(StrVec_Cstr(m, dirPath));
    struct dirent *entry;

    while((entry = readdir(dir)) != NULL){
        if(entry->d_type == DT_DIR && strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0){
            // Recursive directory
            StrVec *subdir = StrVec_Copy(m, dirPath);
            StrVec_AddCstr(subdir, "/");
            StrVec_AddCstr(subdir, entry->d_name);

            Route *childRoute = BuildRouteTree(m, subdir);
            Table_Set(children, Sv(m, entry->d_name), childRoute);

        }else if(entry->d_type == DT_REG){
            // File → create leaf route
            Route *fileRoute = Inst_Make(m, TYPE_ROUTE);
            Seel_Set(fileRoute, K(m, "name"), Sv(m, entry->d_name));

            // Determine handler based on file extension
            if(Str_EndsWith(Sv(m, entry->d_name), K(m, ".html"))){
                fileRoute->type.state |= ROUTE_STATIC;
                Inst_SetAtt(fileRoute, K(m, "mime"), Sv(m, "text/html"));
            }else if(Str_EndsWith(Sv(m, entry->d_name), K(m, ".templ"))){
                fileRoute->type.state |= ROUTE_DYNAMIC;
                // Prepare template and store
                Templ *templ = PrepareTemplate(m, dirPath, Sv(m, entry->d_name));
                Inst_SetAtt(fileRoute, K(m, "templ"), templ);
            }

            Table_Set(children, Sv(m, entry->d_name), fileRoute);
        }
    }

    closedir(dir);
    return route;
}
```

**Result**: Complete route tree where each file/directory is an Inst with appropriate properties.

### Pattern 3: JSON to Inst Conversion

**Goal**: Parse JSON and create typed Inst structures.

**Implementation**:

```c
Inst *JsonToInst(MemCh *m, Abstract *jsonObj, cls instType){
    if(jsonObj->type.of != TYPE_TABLE){
        return NULL;  // JSON object must be a table
    }

    Inst *inst = Inst_Make(m, instType);
    Table *json = (Table *)jsonObj;
    Table *atts = Seel_Get(inst, K(m, "atts"));

    // Map JSON properties to Inst attributes
    Iter it;
    Iter_Init(&it, json);
    while((Iter_Next(&it) & END) == 0){
        Hashed *h = Iter_Get(&it);
        Table_Set(atts, h->key, h->value);
    }

    return inst;
}
```

**Usage**:

```c
// JSON: {"name": "Alice", "age": 30, "email": "alice@example.com"}
Table *json = JsonParser_Parse(m, jsonStr);

Inst *user = JsonToInst(m, json, TYPE_NODEOBJ);

// Access properties
StrVec *name = Inst_Att(user, K(m, "name"));    // "Alice"
Single *age = Inst_Att(user, K(m, "age"));      // 30
StrVec *email = Inst_Att(user, K(m, "email"));  // "alice@example.com"
```

### Pattern 4: Inst Validation

**Goal**: Validate that an Inst has required properties and types.

**Implementation**:

```c
status ValidateInst(Inst *inst, Table *schema){
    Iter it;
    Iter_Init(&it, schema);

    while((Iter_Next(&it) & END) == 0){
        Hashed *h = Iter_Get(&it);
        StrVec *propName = (StrVec *)h->key;
        Single *expectedType = (Single *)h->value;

        // Get property value
        void *value = Seel_Get(inst, propName);

        if(value == NULL){
            Error(inst->m, FUNCNAME, FILENAME, LINENUMBER,
                "Missing required property $", (void *[]){propName, NULL});
            return ERROR;
        }

        // Check type
        Abstract *abstractValue = (Abstract *)value;
        if(abstractValue->type.of != expectedType->val.w){
            Error(inst->m, FUNCNAME, FILENAME, LINENUMBER,
                "Property $ has wrong type: expected $, got $",
                (void *[]){
                    propName,
                    Type_ToStr(inst->m, expectedType->val.w),
                    Type_ToStr(inst->m, abstractValue->type.of),
                    NULL
                });
            return ERROR;
        }
    }

    return READY;
}
```

**Usage**:

```c
// Define schema
Table *userSchema = Table_Make(m);
Table_Set(userSchema, S(m, "name"), I16_Wrapped(m, TYPE_STRVEC));
Table_Set(userSchema, S(m, "age"), I16_Wrapped(m, TYPE_WRAPPED_I32));
Table_Set(userSchema, S(m, "email"), I16_Wrapped(m, TYPE_STRVEC));

// Validate instance
Inst *user = ...;
status r = ValidateInst(user, userSchema);

if(r & ERROR){
    Out("Validation failed\n", NULL);
}else{
    Out("User is valid\n", NULL);
}
```


## Best Practices

1. **Use standard NodeObj base**: Start with `name`, `atts`, `children` properties (indices 0-2) for consistency.

2. **Seal Seels immediately**: Call `Seel_Seel` right after defining properties to prevent accidental modification.

3. **Type-check at boundaries**: When receiving external data (JSON, user input), validate types before creating Inst.

4. **Use helpers for common properties**: `Inst_Att` is clearer than `Seel_Get` for the `atts` property.

5. **Cache frequently-accessed properties**: If you're calling `Seel_Get(inst, K(m, "name"))` in a loop, cache the result.

6. **Auto-create containers**: `Inst_Make` pre-allocates Tables and Spans—rely on this for clean initialization.

7. **Document property indices**: Use enums for custom properties beyond the NodeObj base.

8. **Serialize with `ToS`**: Register `Inst_Print` via `Seel_Seel` so instances print nicely for debugging.


## Common Pitfalls

1. **Forgetting to seal**: If you don't call `Seel_Seel`, Seel lookups fail.

2. **Type mismatches**: Seel says property is TYPE_STRVEC, but you set it to TYPE_TABLE → runtime error.

3. **Using wrong indices**: If you use `Span_Get(inst, 5)` but the Seel only has 3 properties → out of bounds.

4. **Not checking NULL**: `Seel_Get` returns NULL if property doesn't exist—always check before dereferencing.

5. **Modifying sealed Seels**: Once sealed, you can't add properties—create a new type instead.

6. **Assuming property order**: Don't rely on insertion order unless you use `Table_SetHashed` carefully.

7. **Mixing Inst and Span**: Remember that Inst *is* a Span—use `Span_Get` for index access, `Seel_Get` for name access.

8. **Forgetting TYPE_INSTANCE flag**: If you manually create a Span and don't set `TYPE_INSTANCE`, it won't work with `Seel_Get`.


## Cross-References

### Related Core Systems

- **[Type System Complete](type-system-complete.md)** - Seel integrates with runtime type checking, TYPE_INSTANCE flag, and `as()` macro
- **[Table/Lookup Complete](table-lookup-complete.md)** - Seels are Tables, property access uses hash lookups
- **[Memory Management](memory/memchapter.md)** - Inst instances allocated in MemChapter, freed atomically
- **[Span Complete](memory/span-complete.md)** - Inst is a Span, property storage uses Span indexing
- **[Navigate Task Complete](navigate/task-execution-complete.md)** - Tasks use Inst for data storage (NodeObj-based structures)
- **[Templ Complete](templ-complete.md)** - Templates use Fetcher to access Inst properties dynamically
- **[HTTP Lifecycle Complete](http-lifecycle-complete.md)** - Routes, HttpCtx use Seel/Inst extensively

### Filesystem References

**Seel/Inst implementation**:
- [src/ext/include/types/seel.h](../../../src/ext/include/types/seel.h) - Seel API
- [src/ext/types/seel.c](../../../src/ext/types/seel.c) - Seel_Get/Set, Seel_Seel registration
- [src/ext/include/types/inst.h](../../../src/ext/include/types/inst.h) - Inst API
- [src/ext/types/inst.c](../../../src/ext/types/inst.c) - Inst_Make, Inst_ByPath, Inst_Print

**Usage examples**:
- [src/ext/navigate/nodeobj.c](../../../src/ext/navigate/nodeobj.c) - Simplest Seel (NodeObj)
- [src/inter/www/route.c](../../../src/inter/www/route.c) - Route Seel (web framework)
- [src/passport/session/login.c](../../../src/passport/session/login.c) - Login Seel (session management)

### Next Steps

After understanding Seel/Inst:

1. **Study [BinSeg Complete](binseg-complete.md)** (when available) to see how Inst instances are serialized to binary format
2. **Read [Templ Complete](templ-complete.md)** to understand Fetcher usage for dynamic property access in templates
3. **Explore [Config Format](../formats/config.md)** to see how config files map to Inst structures
4. **Review [Route System](www-routing-complete.md)** (when available) for advanced Inst usage in web routing

---

**End of Seel/Inst Property System Complete Guide**



---

[← Part 1](seel-inst-complete-part1) | **Part 2 of 2**
