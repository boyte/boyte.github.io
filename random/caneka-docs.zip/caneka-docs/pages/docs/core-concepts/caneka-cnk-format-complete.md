# Caneka (.cnk) Format: Complete Guide

## Status and Scope

### Verified (implementation)
- There is **no `.cnk` parser** or build integration in `src/`.
- `.cnk` files exist only in `examples/` and are not used at runtime.
- C implementations live in `src/base` and `src/ext`.

### Inferred (spec)
- `.cnk` is a design-spec language for types, flags, and method behavior.
- Syntax is intended to map directly to C APIs.

## Example: `examples/str.cnk` (Spec)

```cnk
Type Str @ TEXT, CONST, BINARY, ENCODED, FMT_ANSI, COPY
    word length
    word alloc
    byte bytes[]
```

### Corresponding C Types (Verified)

From `src/base/include/bytes/str.h`:

```c
typedef struct str {
    Type type;
    word length;
    word alloc;
    byte *bytes;
} Str;
```

Flags defined in `str.h` match the `@` list:

```c
enum str_flags {
    STRING_TEXT = 1 << 8,
    STRING_CONST = 1 << 9,
    STRING_BINARY = 1 << 10,
    STRING_ENCODED = 1 << 11,
    STRING_FMT_ANSI = 1 << 12,
    STRING_COPY = 1 << 13,
};
```

### Corresponding C Functions (Verified)

The `.cnk` methods map to C functions in `src/base/bytes/str.c`. Examples:

| .cnk Intent | C Function | Signature (Verified) |
| --- | --- | --- |
| `reset()` | `Str_Reset` | `status Str_Reset(Str *s)` |
| `wipe()` | `Str_Wipe` | `status Str_Wipe(Str *s)` |
| `toFd(i32 fd)` | `Str_ToFd` | `i64 Str_ToFd(Str *s, int fd)` |
| `add(byte[], i64)` | `Str_Add` | `i64 Str_Add(Str *s, byte *b, i64 length)` |
| `cstr(MemCh m)` | `Str_Cstr` | `char *Str_Cstr(MemCh *m, Str *s)` |

These signatures are authoritative; `.cnk` is not compiled.

## Example: `examples/cash.cnk.full` (Spec)

```cnk
struct {
    data = Keys
    rbl = /between({^$.},$ -> value),value({_\{^\}.} -> between)/ -> Capture
}
```

This illustrates a **speculative** syntax for:
- Struct members
- Roebling pattern assignments
- Multi-branch capture handlers

No parser exists for these constructs in the current codebase.

## How to Read `.cnk` Today

- Treat `.cnk` files as **design notes**.
- Confirm behavior by reading the C source and tests.
- Use `.cnk` to understand intent, not runtime behavior.

## Open Gaps (Verified)

- No `.cnk` parser or compiler.
- No formal grammar or tokenization rules.
- No tooling integration in `build.sh` or `clineka`.

## See Also

- `examples/str.cnk`
- `examples/cash.cnk`
- `examples/cash.cnk.full`
