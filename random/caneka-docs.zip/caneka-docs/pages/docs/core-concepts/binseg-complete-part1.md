# BinSeg Serialization: Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](binseg-complete-part2)

---

## Core Philosophy

BinSeg (Binary Segment) is Caneka's serialization system for persisting Abstract data structures to binary format. It provides efficient, type-aware encoding of Caneka's core data model—Str, Span, Table, StrVec, and Inst—into a compact binary representation suitable for files, databases, or network transmission.

**The fundamental insight**: Most serialization systems impose their own type model (JSON's objects/arrays, Protocol Buffers' schemas). BinSeg directly serializes Caneka's native Abstract type hierarchy, preserving type information and structure without translation overhead.

**Design principles**:
- **Type preservation**: Each serialized entry includes its Caneka type (BINSEG_TYPE_*)
- **Hierarchical reconstruction**: Nested structures (Tables containing Spans containing Strs) serialize recursively with ID tracking to rebuild parent-child relationships
- **Bidirectional format**: Supports both normal (header-first) and reversed (header-last) layouts for different access patterns
- **Zero-copy integration**: Uses Buff I/O system for efficient file operations
- **Self-describing**: Binary format contains all information needed for deserialization without external schema

**Contrast with other formats**:

| Format | Characteristics | BinSeg Difference |
|--------|----------------|-------------------|
| JSON | Text, human-readable, ~2x data size | Binary, ~1.5x data size, faster parse |
| Protocol Buffers | Schema required, numeric field IDs | No schema needed, type-aware headers |
| MessagePack | Binary JSON, type markers | Similar approach, but Caneka-specific types |
| BSON | Binary JSON with length prefixes | BinSeg uses IDs for hierarchy, not lengths |

**Use cases**:
- RESTful database endpoints (POST JSON → BinSeg file)
- Form submission persistence
- Session data caching
- Configuration file storage
- Network protocol payloads

The BinSeg system sits in the Ext layer's persist module because it extends Base layer types (Str, Span, Table) with file persistence capabilities.


## Structure & Components

### Binary Format Specification

All BinSeg entries share a common header structure that identifies type, size, and hierarchical position:

#### BinSegHeader Structure

```c
typedef struct binseg_ident {
    i16 idx;    // Index within parent container
    i16 id;     // Hierarchical depth/generation ID
} BinSegIdent;

typedef struct binseg_hdr {
    word total;           // Type-specific count (bytes, elements, etc.)
    word kind;            // BINSEG_TYPE_* constant
    BinSegIdent ident;    // Hierarchical identifier
} BinSegHeader;           // 12 bytes total (4+4+2+2)
```

**Field semantics**:

| Field | Purpose | Interpretation by Type |
|-------|---------|----------------------|
| `total` | Count or size | BYTES: length; COLLECTION: element count; DICTIONARY: key-value pair count |
| `kind` | Type identifier | Determines deserialization function |
| `ident.id` | Depth level | 0 = root; increases by 1 for each nesting level |
| `ident.idx` | Container index | Position in parent Span/Table |

**Example header bytes** (little-endian):

```
02 00 00 00  05 00 00 00  00 00 01 00
└─ total=2   └─ kind=5    └─ id=0 idx=1
```

Interpretation: 2-entry dictionary (kind=5=DICTIONARY), root level (id=0), at parent index 1.

#### Type Kind Constants

From [binseg.h:3](../../../src/ext/include/persist/binseg.h):

```c
enum binseg_kinds {
    BINSEG_TYPE_BYTES = 1,              // Str: raw byte string
    BINSEG_TYPE_NUMBER = 2,             // Single: wrapped integer
    BINSEG_TYPE_COLLECTION = 3,         // Span: ordered array
    BINSEG_TYPE_BYTES_COLLECTION = 4,   // StrVec: string array
    BINSEG_TYPE_DICTIONARY = 5,         // Table: hash map
    BINSEG_TYPE_INST = 6,               // Inst: typed object
};
```

**Type mapping**:

| Caneka Type | BinSeg Kind | Footer Content |
|-------------|-------------|----------------|
| `Str` | BINSEG_TYPE_BYTES (1) | String bytes |
| `i16/i32/i64/util Single` | BINSEG_TYPE_NUMBER (2) | 8-byte i64 value |
| `Span` | BINSEG_TYPE_COLLECTION (3) | (children follow) |
| `StrVec` | BINSEG_TYPE_BYTES_COLLECTION (4) | (string children follow) |
| `Table` | BINSEG_TYPE_DICTIONARY (5) | (key-value pairs follow) |
| `Inst` | BINSEG_TYPE_INST (6) | 4-byte type ID, then children |

### Entry Layout Formats

Each type has a specific binary layout:

**BINSEG_TYPE_BYTES (Str)**:
```
[Header 12 bytes: total=length, kind=1, id, idx]
[Footer: N bytes of string data]
```

**BINSEG_TYPE_NUMBER (Single)**:
```
[Header 12 bytes: total=0, kind=2, id, idx]
[Footer: 8 bytes i64 value]
```

**BINSEG_TYPE_COLLECTION (Span)**:
```
[Header 12 bytes: total=count, kind=3, id, idx]
[Children: each element with id+1]
```

**BINSEG_TYPE_BYTES_COLLECTION (StrVec)**:
```
[Header 12 bytes: total=count, kind=4, id, idx]
[Children: each string with id+1, kind=BINSEG_TYPE_BYTES]
```

**BINSEG_TYPE_DICTIONARY (Table)**:
```
[Header 12 bytes: total=pairs, kind=5, id, idx]
[Children: key0 (idx=0), value0 (idx=1), key1 (idx=2), value1 (idx=3), ...]
```

**BINSEG_TYPE_INST (Instance)**:
```
[Header 12 bytes: total=field_count, kind=6, id, idx]
[Footer: 4 bytes type ID (word)]
[Children: fields 0...N with id+1]
```

### BinSegCtx Structure

The serialization context manages file I/O and object reconstruction:

```c
typedef struct binseg_ctx {
    Type type;           // type.of = TYPE_BINSEG_CTX
                        // type.state = flags (BINSEG_READ | BINSEG_ADD | ...)
    MemCh *m;           // Memory context for allocation
    Table *seel;        // Optional schema for validation
    Buff *read;         // Input buffer (deserialization source)
    Buff *add;          // Output buffer (serialization dest, append)
    Buff *modify;       // Modify buffer (in-place updates)
    Span *shelves;      // Hierarchical storage: shelves[id] = Span of children
    Span *records;      // Root-level deserialized objects (id=0)
} BinSegCtx;
```

**Field roles**:

| Field | Read Mode | Add Mode | Modify Mode |
|-------|-----------|----------|-------------|
| `read` | Source file buffer | NULL | Source file |
| `add` | NULL | Destination file buffer | NULL |
| `modify` | NULL | NULL | Update buffer |
| `shelves` | Temp storage during load | NULL | Temp storage |
| `records` | Final objects | NULL | NULL |

**Mode flags** (from [binseg.h:12](../../../src/ext/include/persist/binseg.h)):

```c
enum binseg_types {
    BINSEG_REVERSED = 1 << 8,   // Header-last format (footer-header order)
    BINSEG_READ = 1 << 9,       // Open for reading
    BINSEG_ADD = 1 << 10,       // Open for appending
    BINSEG_MODIFY = 1 << 11,    // Open for modification
};
```

**Typical combinations**:
- `BINSEG_READ`: Deserialize from file
- `BINSEG_ADD`: Serialize and append to file
- `BINSEG_READ | BINSEG_REVERSED`: Read reversed-format file (footer-header)
- `BINSEG_ADD | BINSEG_REVERSED`: Write reversed-format file

### Global Registries

**BinSegLookup**: Maps Caneka types to serialization functions

```c
Lookup *BinSegLookup = NULL;  // cls → BinSegFunc

status BinSeg_Init(MemCh *m){
    BinSegLookup = Lookup_Make(m, _TYPE_ZERO);

    Lookup_Add(m, BinSegLookup, TYPE_STR, (void *)Str_ToBinSeg);
    Lookup_Add(m, BinSegLookup, TYPE_SPAN, (void *)Span_ToBinSeg);
    Lookup_Add(m, BinSegLookup, TYPE_TABLE, (void *)Table_ToBinSeg);
    Lookup_Add(m, BinSegLookup, TYPE_STRVEC, (void *)StrVec_ToBinSeg);
    Lookup_Add(m, BinSegLookup, TYPE_INSTANCE, (void *)Inst_ToBinSeg);

    // Numeric types all use I64_ToBinSeg
    Lookup_Add(m, BinSegLookup, TYPE_WRAPPED_I16, (void *)I64_ToBinSeg);
    Lookup_Add(m, BinSegLookup, TYPE_WRAPPED_I32, (void *)I64_ToBinSeg);
    Lookup_Add(m, BinSegLookup, TYPE_WRAPPED_I64, (void *)I64_ToBinSeg);
    Lookup_Add(m, BinSegLookup, TYPE_WRAPPED_UTIL, (void *)I64_ToBinSeg);

    return READY;
}
```

**BinSegActionNames**: Maps action strings to mode flags

```c
Table *BinSegActionNames = NULL;

// In BinSeg_Init:
BinSegActionNames = Table_Make(m);
Table_Set(BinSegActionNames, S(m, "add"), I16_Wrapped(m, BINSEG_ADD));
Table_Set(BinSegActionNames, S(m, "read"), I16_Wrapped(m, BINSEG_READ));
Table_Set(BinSegActionNames, S(m, "modify"), I16_Wrapped(m, BINSEG_MODIFY));
```

Used in HTTP route configuration to convert action strings to flags.


## Serialization Process

### High-Level Flow

1. **Initialize context**: `BinSegCtx_Make(m, BINSEG_ADD)`
2. **Open file**: `BinSegCtx_Open(ctx, path)`
3. **Serialize objects**: `BinSegCtx_Send(ctx, object)`
4. **Close file**: `BinSegCtx_Close(ctx)`

### Recursive Serialization Algorithm

The entry point `BinSegCtx_SendByIdent(ctx, a, id, idx)` dispatches to type-specific serializers:

```c
status BinSegCtx_SendByIdent(BinSegCtx *ctx, void *_a, i16 id, i16 idx){
    Abstract *a = (Abstract *)_a;

    if(a == NULL){
        return NOOP;  // Skip NULL values
    }

    // Lookup serialization function for this type
    BinSegFunc func = (BinSegFunc)Lookup_Get(BinSegLookup, a->type.of);

    if(func == NULL){
        Error(ctx->m, FUNCNAME, FILENAME, LINENUMBER,
            "No BinSeg serializer for type $",
            (void *[]){Type_ToStr(ctx->m, a->type.of), NULL});
        return ERROR;
    }

    // Call type-specific serializer
    return func(ctx, a, id, idx);
}

// Convenience macro for root-level serialization
#define BinSegCtx_Send(ctx, a) BinSegCtx_SendByIdent((ctx), (a), 0, 0)
```

### Type-Specific Serializers

#### Str Serialization

From [binseg.c](../../../src/ext/persist/binseg.c) (Str_ToBinSeg):

```c
static status Str_ToBinSeg(BinSegCtx *ctx, void *a, i16 id, i16 idx){
    MemCh *m = ctx->m;
    Str *s = (Str *)as(a, TYPE_STR);

    // Calculate entry size: header + string bytes
    word sz = BinSegCtx_HeaderSize(BINSEG_TYPE_BYTES, s->length);

    // Allocate entry (temporarily at m->level+1)
    m->level++;
    Str *entry = Str_Make(m, sz);
    entry->length = entry->alloc;
    m->level--;

    // Fill header
    BinSegHeader *hdr = (BinSegHeader *)entry->bytes;
    hdr->total = s->length;
    hdr->kind = BINSEG_TYPE_BYTES;
    hdr->ident.id = id;
    hdr->ident.idx = idx;

    // Copy string data after header
    byte *ptr = entry->bytes + sizeof(BinSegHeader);
    memcpy(ptr, s->bytes, s->length);

    // Add to output buffer
    return Buff_Add(ctx->add, entry);
}
```

**Memory level management**: The `m->level++/m->level--` dance ensures temporary entries are allocated in a higher memory level, allowing cleanup after serialization without affecting the source objects.

#### Number Serialization

From [binseg.c:176](../../../src/ext/persist/binseg.c) (I64_ToBinSeg):

```c
static status I64_ToBinSeg(BinSegCtx *ctx, void *_a, i16 id, i16 idx){
    MemCh *m = ctx->m;
    Abstract *a = (Abstract *)_a;

    // Validate it's a wrapped numeric type
    if(a->type.of <= _TYPE_WRAPPED_START || a->type.of >= _TYPE_WRAPPED_END){
        return ERROR;
    }

    Single *sg = (Single *)a;
    word sz = BinSegCtx_HeaderSize(BINSEG_TYPE_NUMBER, 0);

    m->level++;
    Str *entry = Str_Make(m, sz);
    m->level--;

    // For reversed format: [i64][header]
    // For normal format: [header][i64]
    BinSegHeader *hdr = NULL;
    i64 *ptr = NULL;

    if(ctx->type.state & BINSEG_REVERSED){
        ptr = (i64 *)entry->bytes;
        hdr = (BinSegHeader *)(entry->bytes + sizeof(i64));
    }else{
        hdr = (BinSegHeader *)entry->bytes;
        ptr = (i64 *)(entry->bytes + sizeof(BinSegHeader));
    }

    hdr->total = 0;  // No additional count for numbers
    hdr->kind = BINSEG_TYPE_NUMBER;
    hdr->ident.id = id;
    hdr->ident.idx = idx;

    // Convert to i64 (handles i16, i32, i64, util)
    *ptr = Single_ToUtil(sg);

    entry->length = sz;
    return Buff_Add(ctx->add, entry);
}
```

**Key insight**: All numeric types (i16, i32, i64, util) serialize to 8-byte i64 values, allowing deserialization to reconstruct them as Single wrappers.

#### Span Serialization

From [binseg.c:104](../../../src/ext/persist/binseg.c) (Span_ToBinSeg):

```c
static status Span_ToBinSeg(BinSegCtx *ctx, void *a, i16 id, i16 idx){
    MemCh *m = ctx->m;
    Span *p = (Span *)as(a, TYPE_SPAN);
    status r = READY;

    word sz = BinSegCtx_HeaderSize(BINSEG_TYPE_COLLECTION, 0);

    m->level++;
    Str *entry = Str_Make(m, sz);
    entry->length = entry->alloc;
    m->level--;

    BinSegHeader *hdr = (BinSegHeader *)entry->bytes;
    hdr->total = p->max_idx;  // Number of elements
    hdr->kind = BINSEG_TYPE_COLLECTION;
    hdr->ident.id = id;
    hdr->ident.idx = idx;

    // REVERSED: write header first, then children
    if(ctx->type.state & BINSEG_REVERSED){
        r |= Buff_Add(ctx->add, entry);
    }

    // Recursively serialize each element with id+1
    Iter it;
    Iter_Init(&it, p);
    while((Iter_Next(&it) & END) == 0){
        r |= BinSegCtx_SendByIdent(ctx, Iter_Get(&it), id+1, it.idx);
    }

    // NORMAL: write children first, then header
    if((ctx->type.state & BINSEG_REVERSED) == 0){
        r |= Buff_Add(ctx->add, entry);
    }

    return r;
}
```

**Recursive depth tracking**: Children are serialized with `id+1`, creating hierarchical generations. This allows deserialization to distinguish:
- id=0: Root objects
- id=1: Children of root
- id=2: Grandchildren of root
- etc.

**Example Span serialization** for `Span[Str("a"), Str("b")]`:

```
Normal format:
  [Str("a") with id=1, idx=0]
  [Str("b") with id=1, idx=1]
  [Span header with id=0, idx=0, total=2]

Reversed format:
  [Span header with id=0, idx=0, total=2]
  [Str("a") with id=1, idx=0]
  [Str("b") with id=1, idx=1]
```

#### Table Serialization

From [binseg.c:62](../../../src/ext/persist/binseg.c) (Table_ToBinSeg):

```c
static status Table_ToBinSeg(BinSegCtx *ctx, void *a, i16 id, i16 idx){
    MemCh *m = ctx->m;
    Table *tbl = (Span *)as(a, TYPE_TABLE);
    status r = READY;

    word sz = BinSegCtx_HeaderSize(BINSEG_TYPE_DICTIONARY, 0);

    m->level++;
    Str *entry = Str_Make(m, sz);
    entry->length = entry->alloc;
    m->level--;

    BinSegHeader *hdr = (BinSegHeader *)entry->bytes;
    hdr->total = tbl->nvalues;  // Number of key-value pairs
    hdr->kind = BINSEG_TYPE_DICTIONARY;
    hdr->ident.id = id;
    hdr->ident.idx = idx;

    if(ctx->type.state & BINSEG_REVERSED){
        r |= Buff_Add(ctx->add, entry);
    }

    // Serialize key-value pairs
    Iter it;
    Iter_Init(&it, tbl);
    i32 count = 0;

    while((Iter_Next(&it) & END) == 0){
        Hashed *h = Iter_Get(&it);
        if(h != NULL){
            // Key at even idx (0, 2, 4, ...)
            r |= BinSegCtx_SendByIdent(ctx, h->key, id+1, count*2);

            // Value at odd idx (1, 3, 5, ...)
            r |= BinSegCtx_SendByIdent(ctx, h->value, id+1, (count*2)+1);

            count++;
        }
    }

    if((ctx->type.state & BINSEG_REVERSED) == 0){
        r |= Buff_Add(ctx->add, entry);
    }

    return r;
}
```

**Key-value interleaving**: Table entries are serialized as alternating keys and values, with indices:
- idx=0: first key
- idx=1: first value
- idx=2: second key
- idx=3: second value
- etc.

**Example Table** `{"name": "Alice", "age": 30}`:

```
[Str("name") id=1, idx=0]
[Str("Alice") id=1, idx=1]
[Str("age") id=1, idx=2]
[Number(30) id=1, idx=3]
[Table header id=0, idx=0, total=2]
```

#### Inst Serialization

From [binseg.c:16](../../../src/ext/persist/binseg.c) (Inst_ToBinSeg):

```c
static status Inst_ToBinSeg(BinSegCtx *ctx, void *a, i16 id, i16 idx){
    MemCh *m = ctx->m;
    Inst *inst = asInst(m, a);

    // Get ordered property list from Seel
    Span *ord = Seel_OrdSeel(m, inst->type.of);

    word sz = BinSegCtx_HeaderSize(BINSEG_TYPE_INST, 0);

    m->level++;
    Str *entry = Str_Make(m, sz);
    entry->length = entry->alloc;
    m->level--;

    // Layout depends on REVERSED flag
    BinSegHeader *hdr = NULL;
    word *ptr = NULL;

    if(ctx->type.state & BINSEG_REVERSED){
        ptr = (word *)entry->bytes;              // Type ID first
        hdr = (BinSegHeader *)(entry->bytes + sizeof(word));
    }else{
        hdr = (BinSegHeader *)entry->bytes;      // Header first
        ptr = (word *)(entry->bytes + sizeof(BinSegHeader));
    }

    hdr->total = ord->nvalues;  // Number of properties
    hdr->kind = BINSEG_TYPE_INST;
    hdr->ident.id = id;
    hdr->ident.idx = idx;

    *ptr = inst->type.of;  // Store type ID for reconstruction

    if(ctx->type.state & BINSEG_REVERSED){
        r |= Buff_Add(ctx->add, entry);
    }

    // Serialize each property field
    Iter it;
    Iter_Init(&it, inst);
    while((Iter_Next(&it) & END) == 0){
        r |= BinSegCtx_SendByIdent(ctx, Iter_Get(&it), id+1, it.idx);
    }

    if((ctx->type.state & BINSEG_REVERSED) == 0){
        r |= Buff_Add(ctx->add, entry);
    }

    return r;
}
```

**Type ID footer**: The 4-byte `type.of` value (e.g., TYPE_NODEOBJ, TYPE_ROUTE) is stored in the footer, allowing deserialization to call `Inst_Make(m, typeOf)` to create the correct instance type.

**Example NodeObj** with name="config", atts=Table with host="localhost":

```
[Str("config") id=1, idx=0]             // name property
[Table header id=1, idx=1]              // atts property
  [Str("host") id=2, idx=0]             // atts key
  [Str("localhost") id=2, idx=1]        // atts value
[Table (empty) id=1, idx=2]             // children property
[Inst header id=0, idx=0, total=3]
[Type ID: TYPE_NODEOBJ]
```

### Header Size Calculation

The function `BinSegCtx_HeaderSize` determines how much space to allocate:

```c
word BinSegCtx_HeaderSize(word kind, word length){
    word sz = sizeof(BinSegHeader);

    switch(kind){
        case BINSEG_TYPE_BYTES:
            sz += length;  // Add string bytes
            break;
        case BINSEG_TYPE_NUMBER:
            sz += sizeof(i64);  // Add 8-byte value
            break;
        case BINSEG_TYPE_INST:
            sz += sizeof(word);  // Add type ID
            break;
        // Containers have no footer (children serialized separately)
        case BINSEG_TYPE_COLLECTION:
        case BINSEG_TYPE_BYTES_COLLECTION:
        case BINSEG_TYPE_DICTIONARY:
        default:
            break;
    }

    return sz;
}
```

**Size formula**:
- BYTES: 12 + length
- NUMBER: 12 + 8 = 20
- INST: 12 + 4 = 16
- COLLECTION/DICTIONARY/BYTES_COLLECTION: 12 (children separate)


## Deserialization Process

### High-Level Flow

1. **Initialize context**: `BinSegCtx_Make(m, BINSEG_READ)`
2. **Open file**: `BinSegCtx_Open(ctx, path)`
3. **Load objects**: `BinSegCtx_Load(ctx)`
4. **Access results**: Iterate `ctx->records`
5. **Close file**: `BinSegCtx_Close(ctx)`

### Loading Algorithm

The `BinSegCtx_Load` function reads entries sequentially and reconstructs objects:

```c
status BinSegCtx_Load(BinSegCtx *ctx){
    // Position buffer based on format
    if(ctx->type.state & BINSEG_REVERSED){
        Buff_PosEnd(ctx->read);    // Start from file end
    }else{
        Buff_PosAbs(ctx->read, 0); // Start from file beginning
    }

    byte _hdrBytes[sizeof(BinSegHeader)];
    Str hdrS = {
        .type = {TYPE_STR, STRING_CONST},
        .length = 0,
        .alloc = sizeof(BinSegHeader),
        .bytes = _hdrBytes
    };

    // Read entries until EOF
    while(((ctx->read->type.state & (ERROR|END)) | ctx->type.state) &
            (SUCCESS|ERROR|NOOP|END)) == 0){

        hdrS.length = 0;

        // Read header (12 bytes)
        if(ctx->type.state & BINSEG_REVERSED){
            Buff_RevGetStr(ctx->read, &hdrS);  // Read backwards
        }else{
            Buff_GetStr(ctx->read, &hdrS);     // Read forwards
        }

        if(ctx->read->type.state & END) break;

        if(hdrS.length != sizeof(BinSegHeader)){
            ctx->type.state |= ERROR;
            break;
        }

        BinSegHeader *hdr = (BinSegHeader *)hdrS.bytes;

        // Calculate footer size
        i16 sz = BinSegCtx_HeaderSize(hdr->kind, hdr->total)
                 - sizeof(BinSegHeader);

        // Read footer if present
        Str *ftr = NULL;
        if(sz > 0){
            ftr = Str_Make(ctx->m, sz);
            if(ctx->type.state & BINSEG_REVERSED){
                Buff_RevGetStr(ctx->read, ftr);
            }else{
                Buff_GetStr(ctx->read, ftr);
            }
        }

        // Reconstruct object from header + footer
        BinSegCtx_buildKind(ctx, hdr, ftr);
    }

    ctx->type.state |= (ctx->read->type.state & (ERROR|END));
    return ctx->type.state;
}
```

**Key mechanisms**:
- **Buff_RevGetStr**: Reads bytes in reverse order (for BINSEG_REVERSED format)
- **Header-first parsing**: Always read 12-byte header, then determine footer size
- **Incremental reconstruction**: Each entry is reconstructed immediately via `buildKind`

### Object Reconstruction

The `BinSegCtx_buildKind` function creates live objects and organizes them hierarchically:

```c
static status BinSegCtx_buildKind(BinSegCtx *ctx, BinSegHeader *hdr, Str *ftr){
    MemCh *m = ctx->m;
    Abstract *a = NULL;

    // Dispatch by kind
    switch(hdr->kind){
        case BINSEG_TYPE_BYTES:
            // Footer is already a Str from Buff_GetStr
            a = (Abstract *)ftr;
            break;

        case BINSEG_TYPE_NUMBER:
            // Extract i64 value and wrap
            i64 *ip = (i64 *)ftr->bytes;
            a = (Abstract *)I64_Wrapped(m, *ip);
            break;

        case BINSEG_TYPE_COLLECTION:{
            // Create Span and populate from shelf
            Span *p = Span_Make(m);
            Span *shelf = Span_Get(ctx->shelves, hdr->ident.id);

            if(shelf != NULL){
                Iter it;
                Iter_Init(&it, shelf);
                while((Iter_Next(&it) & END) == 0){
                    Span_Add(p, Iter_Get(&it));
                }
            }

            a = (Abstract *)p;
            break;
        }

        case BINSEG_TYPE_DICTIONARY:{
            // Create Table and populate from shelf
            Table *tbl = Table_Make(m);
            Span *shelf = Span_Get(ctx->shelves, hdr->ident.id);

            if(shelf != NULL){
                Abstract *key = NULL;
                Iter it;
                Iter_Init(&it, shelf);

                while((Iter_Next(&it) & END) == 0){
                    Abstract *val = Iter_Get(&it);

                    if((it.idx & 1) == 0){
                        // Even idx = key
                        key = val;
                    }else{
                        // Odd idx = value
                        Table_Set(tbl, key, val);
                    }
                }
            }

            a = (Abstract *)tbl;
            break;
        }

        case BINSEG_TYPE_INST:{
            // Extract type ID and create instance
            word *wp = (word *)ftr->bytes;
            Inst *inst = Inst_Make(m, *wp);

            Span *shelf = Span_Get(ctx->shelves, hdr->ident.id);

            if(shelf != NULL){
                // Populate instance fields from shelf
                Iter it;
                Iter_Init(&it, shelf);

                while((Iter_Next(&it) & END) == 0){
                    Abstract *a = Iter_Get(&it);
                    if(a != NULL){
                        Span_Set(inst, it.idx, a);
                    }
                }
            }

            a = (Abstract *)inst;
            break;
        }
    }

    // Store object hierarchically
    if(hdr->ident.id == 0){
        // Root level: add to records
        Span_Add(ctx->records, a);

        // Clear shelves for next root object
        MemCh_FreeTemp(ctx->m);
        ctx->m++;
        ctx->shelves = Span_Make(m);
        ctx->m--;
    }else{
        // Child level: store in shelf at parent ID
        word parentId = hdr->ident.id - 1;
        Span *shelf = Span_Get(ctx->shelves, parentId);

        if(shelf == NULL){
            // Create shelf on first use
            ctx->m++;
            shelf = Span_Make(m);
            ctx->m--;
            Span_Set(ctx->shelves, parentId, shelf);
        }

        // Store child at its index
        Span_Set(shelf, hdr->ident.idx, a);
    }

    return ctx->type.state;
}
```

### Shelf-Based Hierarchy Reconstruction

**The shelves mechanism** is key to rebuilding nested structures:

**Shelves** is a Span indexed by `id`:
- `shelves[0]` = Span of children with id=1 (direct children of root)
- `shelves[1]` = Span of children with id=2 (grandchildren)
- `shelves[2]` = Span of children with id=3 (great-grandchildren)
- etc.

**Reconstruction flow** for Table with name → Alice:

1. Read `Str("Alice")` with id=1, idx=1
   - Create Str
   - Store in `shelves[0][1]` (parent id=1-1=0, idx=1)

2. Read `Str("name")` with id=1, idx=0
   - Create Str
   - Store in `shelves[0][0]`

3. Read `Table header` with id=0, total=1
   - Create Table
   - Retrieve `shelves[0]` = [Str("name"), Str("Alice")]
   - Iterate: idx=0 (even) → key=Str("name"); idx=1 (odd) → Table_Set(tbl, key, Str("Alice"))
   - Result: Table with "name" → "Alice"
   - id=0 → add to `records`
   - Clear shelves

**Why this works**: Children are always read before their parent (in normal format) or after (in reversed format). By the time we reconstruct a container (Span, Table, Inst), all its children are already in the appropriate shelf, indexed correctly.

### Example Deserialization Trace

**Binary input** (normal format):

```
[Str("Alice") id=1, idx=0]
[Str("Bob") id=1, idx=1]
[Span header id=0, total=2]
```

**Trace**:

| Step | Action | shelves[0] | records |
|------|--------|------------|---------|
| 1 | Read Str("Alice"), id=1, idx=0 | [0:Str("Alice")] | [] |
| 2 | Read Str("Bob"), id=1, idx=1 | [0:Str("Alice"), 1:Str("Bob")] | [] |
| 3 | Read Span header, id=0, total=2 | Cleared | [Span[Str("Alice"), Str("Bob")]] |

**Result**: `ctx->records[0]` = `Span[Str("Alice"), Str("Bob")]`


## File Format

### File Structure

BinSeg files (typically `.rbs` extension for reversed format, `.bs` for normal) are sequences of binary entries with no additional metadata, headers, or checksums.

**Format characteristics**:

| Aspect | Value |
|--------|-------|
| File extension | `.rbs` (reversed), `.bs` (normal) |
| Byte order | Little-endian (on x86/ARM) |
| Alignment | None (packed entries) |
| Checksums | Not included (external validation if needed) |
| Version marker | None (self-describing via kinds) |
| Magic number | None |

**File layout**:

```
Normal format:
[Entry 0][Entry 1][Entry 2]...[Entry N]EOF

Reversed format:
[Entry 0][Entry 1][Entry 2]...[Entry N]EOF
(Each entry has footer-before-header internally)
```

### Normal vs Reversed Format

**Normal format** (header-first):
- Each entry: `[Header][Footer]`
- File read from beginning to end
- Children written before parent
- Example: `[child][child][parent_header]`

**Reversed format** (header-last):
- Each entry: `[Footer][Header]`
- File read from end to beginning
- Parent written before children
- Example: `[parent_header][child][child]`

**Why reversed?** Allows append-only logs where new records are added at the file end, and the most recent entries are read first by scanning backwards.

**Example comparison**:

Normal: Table with "a" → 1
```
Offset  Data
0       [Str("a") header+data, id=1, idx=0]
14      [Number(1) header+data, id=1, idx=1]
34      [Table header, id=0, total=1]
```

Reversed: Table with "a" → 1
```
Offset  Data
0       [Table header, id=0, total=1]
12      [Str("a") data+header, id=1, idx=0]
26      [Number(1) data+header, id=1, idx=1]
```

### Real Binary Example

From `/examples/test/pages/forms/signup.rbs` (117 bytes, reversed format):

**Hexdump**:
```
00000000  02 00 00 00 05 00 00 00  00 00 01 00 0a 00 00 00
          └─ total=2  └─ kind=5    └─ id=0,idx=1  └─ total=10

00000010  01 00 00 00 04 00 00 00  01 00 00 00 66 69 72 73
          └─ kind=1   └─ id=0,idx=1 └─ id=1,idx=0  └─ "firs"

00000020  74 2d 6e 61 6d 65 06 00  00 00 01 00 00 00 04 00
          └─ "t-name" └─ total=6    └─ kind=1     └─ id=0,idx=1

00000030  02 00 01 00 00 00 46 61  6e 74 73 79 05 00 00 00
          └─ id=1,idx=2  └─ id=2,idx=0  └─ "Fantsy"  └─ total=5

...
```

**Decoded structure**:
```
Table {
  "first-name" → "Fantsy",
  "email" → "fancy.pantsy@example.com"
}
```

**Entry breakdown**:

1. Table header (12 bytes): total=2 (two key-value pairs), kind=5 (DICTIONARY), id=0 (root)
2. Key 0 header (12 bytes): total=10, kind=1 (BYTES), id=1, idx=0
3. Key 0 data (10 bytes): "first-name"
4. Value 0 header (12 bytes): total=6, kind=1, id=1, idx=1
5. Value 0 data (6 bytes): "Fantsy"
6. Key 1 header (12 bytes): total=5, kind=1, id=1, idx=2
7. Key 1 data (5 bytes): "email"
8. Value 1 header (12 bytes): total=24, kind=1, id=1, idx=3
9. Value 1 data (24 bytes): "fancy.pantsy@example.com"

**Total**: 12 + (12+10) + (12+6) + (12+5) + (12+24) = 105 bytes (plus some alignment padding → 117 bytes actual file size)



---

**Part 1 of 2** | [Part 2 →](binseg-complete-part2)
