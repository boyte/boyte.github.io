# Error Handling: Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](error-handling-complete-part2)

---

## Core Philosophy

Caneka's error handling system is built on three foundational principles: **type-aware extensibility**, **hierarchical propagation**, and **rich diagnostic context**. Unlike traditional C error handling that relies on global errno or return codes alone, Caneka provides a comprehensive framework that integrates errors with the type system, memory management, and formatting infrastructure.

### Design Principles

1. **Type-Aware Handlers**: Each type can register custom error handlers for context-specific error reporting
2. **Hierarchical Context**: Errors propagate through MemCh owner chains to find appropriate handlers
3. **Rich Diagnostics**: File, line, function, and formatted arguments provide complete context
4. **Format Flexibility**: Multiple output modes (content, debug, verbose) with ANSI color support
5. **Non-Recursive Safety**: Guards prevent error-in-error infinite loops
6. **Signal Integration**: Graceful handling of SIGINT, SIGTERM with double-fault detection

### Key Insight: Errors as First-Class Objects

Traditional C error handling:

```c
// Traditional approach
if(fopen("file.txt", "r") == NULL) {
    perror("fopen failed");  // Generic errno message
    return -1;               // Opaque error code
}
```

Problems:
- **No context**: Which file? Which function called this?
- **Limited info**: errno is a global int with no structure
- **No extensibility**: Can't customize error handling per type
- **Poor propagation**: Caller must manually check and forward

Caneka's approach:

```c
// Caneka approach
status File_Open(Buff *bf, Str *path, word flags){
    i32 fd = open(Str_Cstr(bf->m, path), flags);

    if(fd <= 0){
        Abstract *args[] = {
            path,                                    // The file path
            Str_CstrRef(bf->m, strerror(errno)),    // System error
            NULL
        };
        Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
            "Error opening file @: $", args);
        bf->type.state |= ERROR;
        return ERROR;
    }

    return SUCCESS;
}
```

Benefits:
- **Rich context**: File path, system error, source location all included
- **Automatic formatting**: Error message constructed from template
- **Type integration**: Buff's error state updated automatically
- **Handler chain**: If Buff's MemCh has an owner with error handler, it's invoked
- **Diagnostic output**: Error message formatted to ErrStream with colors

### Real-World Example: Command-Line Argument Errors

When CLI argument parsing fails, Caneka's type-specific error handler provides helpful output:

```c
// Args error handler (args.c)
status Args_ErrorFunc(MemCh *m, void *_cliArgs, void *_msg){
    CliArgs *cli = _cliArgs;
    ErrorMsg *msg = _msg;

    // Output help text specific to this CLI program
    Buff_Add(ErrStream, S(m, "help:\n\n"));
    CharPtr_ToHelp(cli);  // Shows available arguments

    // Show what was actually received vs parsed
    void *args[] = {
        Ptr_Wrapped(m, cli->argv, TYPE_CSTR_ARRAY),
        cli->args,
        NULL
    };
    Out("^p.Command line arguments received: @, gathered: @^0\n", args);

    return ERROR;  // Error handled, formatted
}
```

Result: Instead of "Invalid argument", users see exactly what they typed, what was expected, and complete help text—all handled automatically when `Error()` is called on an Args type.


## Structure and Key Definitions

### Error Function Signature

```c
void Error(MemCh *m, char *func, char *file, int line, char *fmt, void *args[]);
```

**Location**: [src/base/types/error.c](../../../src/base/types/error.c)

**Parameters**:
- **m** (MemCh*): Memory context, used to find error handler via owner chain
- **func** (char*): Function name where error occurred (use `FUNCNAME` macro)
- **file** (char*): Source file name (use `FILENAME` macro)
- **line** (int): Line number (use `LINENUMBER` macro)
- **fmt** (char*): Format string with placeholders (`$`, `@`, `&`, `^`)
- **args** (void*[]): NULL-terminated array of pointers to format arguments

**Macros**:

```c
#define FUNCNAME ((char *)__func__)
#define FILENAME __FILE__
#define LINENUMBER __LINE__
```

**Usage Pattern**:

```c
Error(m, FUNCNAME, FILENAME, LINENUMBER, "format string", args);
```

### Fatal Function Signature

```c
void Fatal(char *func, char *file, int line, char *fmt, void *args[]);
```

**Purpose**: Handle unrecoverable errors that terminate the program.

**Behavior**:
- Disables CLI raw mode (if active)
- Formats error message to ErrStream with red color
- Exits with code 13 (or 9 if already crashing)

**Implementation**:

```c
void Fatal(char *func, char *file, int line, char *fmt, void *args[]){
    if(_crashing){
        exit(9);  // Already crashing, exit immediately
    }
    _crashing = TRUE;

    // Disable raw mode for clean terminal output
    TermIo_Disable();

    Fmt(ErrStream, "\n^r.FatalError: ", NULL);
    Fmt(ErrStream, fmt, args);

    void *funcargs[] = {
        Str_CstrRef(ErrStream->m, func),
        Str_CstrRef(ErrStream->m, file),
        I32_Wrapped(ErrStream->m, line),
        NULL
    };

    Out("\n  ^D.$^d.:$ at line $\n^0", funcargs);
    Buff_Flush(ErrStream);

    exit(13);
}
```

### ErrorMsg Structure

```c
typedef struct error_msg {
    Type type;           // TYPE_ERROR_MSG
    void *lineInfo[4];   // [func_str, file_str, line_wrapped, NULL]
    Str *fmt;            // Format string
    void **args;         // NULL-terminated arguments array
} ErrorMsg;
```

**Location**: [src/base/include/types/error_msg.h](../../../src/base/include/types/error_msg.h)

**Fields**:
- **lineInfo**: Array storing function name, filename, and line number as objects
- **fmt**: Format string (converted from char* to Str*)
- **args**: Argument array for format substitution

**Creation**:

```c
ErrorMsg *ErrorMsg_Make(MemCh *m, char *func, char *file, int line,
                        char *fmt, void **args);
```

**Implementation**:

```c
ErrorMsg *ErrorMsg_Make(MemCh *m, char *func, char *file, int line,
                        char *fmt, void **args){
    ErrorMsg *msg = MemCh_AllocOf(m, sizeof(ErrorMsg), TYPE_ERROR_MSG);
    msg->type.of = TYPE_ERROR_MSG;

    // Store location info as objects
    msg->lineInfo[0] = Str_FromCstr(m, func, STRING_COPY);
    msg->lineInfo[1] = Str_FromCstr(m, file, STRING_COPY);
    msg->lineInfo[2] = I32_Wrapped(m, line);
    msg->lineInfo[3] = NULL;

    // Store format string
    msg->fmt = Str_FromCstr(m, fmt, STRING_COPY);

    // Copy arguments array
    i32 total = 0;
    if(args != NULL){
        while(args[total++] != NULL){}
        msg->args = Arr_Make(m, total);
    }else{
        msg->args = Arr_Make(m, 1);
    }

    for(i32 i = 0; i < total; i++){
        msg->args[i] = args[i];
    }

    return msg;
}
```

### Status Flags

```c
enum status_types {
    READY = 0,
    SUCCESS = 1,
    ERROR = 1 << 1,       // 0x02 - Error occurred
    NOOP = 1 << 2,        // 0x04 - No operation (often used with ERROR)
    DEBUG = 1 << 3,       // 0x08 - Debug mode
    MORE = 1 << 4,        // 0x10 - More data available
    LAST = 1 << 5,        // 0x20 - Last item
    END = 1 << 6,         // 0x40 - End of sequence
    PROCESSING = 1 << 7,  // 0x80 - Currently processing
};
```

**Location**: [src/base/include/core/status_types.h](../../../src/base/include/core/status_types.h)

**Flag Combinations**:
- **ERROR alone**: Fatal, unhandled error
- **ERROR | NOOP**: Error handled, output formatted message
- **SUCCESS**: Operation completed successfully
- **NOOP alone**: No-op, operation skipped

**Checking Flags**:

```c
status result = Operation();

if(result & ERROR){
    // Error occurred
    if(result & NOOP){
        // Error was handled by custom handler
    }else{
        // Fatal error
        return ERROR;
    }
}

if(result & SUCCESS){
    // Operation succeeded
}
```

### Global Error State

```c
// Global variables (error.c)
Lookup *ErrorHandlers = NULL;  // Type → handler function mapping
boolean _crashing = FALSE;      // Prevents recursive Fatal() calls
boolean _error = FALSE;         // Prevents error-in-error recursion
Abstract *ErrA = NULL;          // Current error-associated object
```

**Purpose**:
- **ErrorHandlers**: Registry of type-specific error handlers
- **_crashing**: Single-fault protection for Fatal()
- **_error**: Prevents infinite loop if Error() is called during error handling
- **ErrA**: Stores object that caused error for signal handler inspection

### Error Streams

```c
// Global I/O streams (init.c)
Buff *OutStream = NULL;   // stdout (fd 1)
Buff *ErrStream = NULL;   // stderr (fd 2)
```

**Initialization**:

```c
status Core_Init(MemCh *m){
    if(OutStream == NULL){
        OutStream = Buff_Make(m, ZERO);
    }
    if(ErrStream == NULL){
        ErrStream = Buff_Make(m, ZERO);
    }
    return SUCCESS;
}

status Core_Direct(MemCh *m, i32 out, i32 err){
    Buff_SetFd(ErrStream, err);
    Buff_SetFd(OutStream, out);

    // Unbuffered for immediate output
    ErrStream->type.state |= BUFF_UNBUFFERED;
    OutStream->type.state |= BUFF_UNBUFFERED;

    Buff_Flush(ErrStream);
    Buff_Flush(OutStream);

    return SUCCESS;
}
```

**Usage**:
- **OutStream**: Normal program output via `Out()` macro
- **ErrStream**: Error messages via `Error()` and `Fatal()`


## Implementation Details

### Error Formatting System

#### Format Placeholders

**Content Output ($)**:

```c
// Outputs object content without debug info
void *args[] = {I32_Wrapped(m, 42), NULL};
Fmt(bf, "Value: $", args);
// Output: Value: 42
```

**Minimal Debug (@)**:

```c
// Outputs type and basic debug info
void *args[] = {str, NULL};
Fmt(bf, "String: @", args);
// Output: String: Str<"hello">
```

**Maximal Debug (&)**:

```c
// Outputs full internal state
void *args[] = {span, NULL};
Fmt(bf, "Span: &", args);
// Output: Span<nvalues=5, max_idx=4, dims=1, ...>
```

**ANSI Colors (^)**:

```c
// ^r = red, ^c = cyan, ^p = purple, ^y = yellow, ^0 = reset
Fmt(ErrStream, "^r.Error:^0 ", NULL);
// Output: [RED]Error:[RESET]
```

**Color Codes**:
- `^r.` - Red (errors)
- `^c.` - Cyan (info)
- `^p.` - Purple (debug)
- `^y.` - Yellow (warnings)
- `^g.` - Green (success)
- `^D.` - Dim
- `^B.` - Bold
- `^0` - Reset all

#### Fmt Function Core Logic

```c
// From fmt.c (simplified)
status Fmt(Buff *bf, char *fmt, void **args){
    byte *bytes = (byte *)fmt;

    while(*bytes != '\0'){
        if(*bytes == '$' || *bytes == '@' || *bytes == '&'){
            // Format placeholder
            Abstract *a = *(args++);

            word mode = 0;
            if(*bytes == '@') mode |= MORE;        // Minimal debug
            if(*bytes == '&') mode |= (DEBUG|MORE); // Maximal debug

            ToS(bf, a, a->type.of, mode);  // Call type-specific formatter

        }else if(*bytes == '^'){
            // ANSI color code
            bytes++;
            AnsiStr(bf, *bytes);

        }else{
            // Literal character
            Buff_AddBytes(bf, bytes, 1);
        }

        bytes++;
    }

    return SUCCESS;
}
```

### Error Handler Chain

#### Handler Lookup Process

```c
void Error(MemCh *m, char *func, char *file, int line, char *fmt, void *args[]){
    if(_error){
        return;  // Prevent error-in-error recursion
    }
    _error = TRUE;

    status r = ZERO;
    Abstract *a = NULL;

    // Walk up owner chain to find error handler
    i16 g = 0;
    while(m != NULL && m->owner != NULL){
        Guard_Incr(ErrStream->m, &g, 6, FUNCNAME, FILENAME, LINENUMBER);

        a = m->owner;
        if(a->type.of == TYPE_MEMCTX){
            // Owner is another MemCh, continue walking
            m = (MemCh *)a;
        }else{
            // Found non-MemCh owner, stop
            break;
        }
    }

    // Look up type-specific error handler
    if(a != NULL){
        SourceFunc errFunc = (SourceFunc)Lookup_Get(ErrorHandlers, a->type.of);

        if(errFunc != NULL){
            // Create error message and invoke handler
            ErrorMsg *msg = ErrorMsg_Make(m, func, file, line, fmt, args);
            r |= errFunc(m, a, msg);
        }
    }else{
        r |= ERROR;  // No owner found
    }

    // Handle error based on handler response
    if(r & ERROR){
        if(r & NOOP){
            // Handler formatted error, just output it
            Fmt(ErrStream, fmt, args);
        }else{
            // Unhandled fatal error
            Fatal(func, file, line, fmt, args);
        }
    }

    _error = FALSE;  // Reset for next error
}
```

**Owner Chain Example**:

```
MemCh_1 → owner = MemCh_2
MemCh_2 → owner = MemCh_3
MemCh_3 → owner = CliArgs (TYPE_CLI_ARGS)

Error called on MemCh_1:
1. Check MemCh_1.owner → MemCh_2 (continue)
2. Check MemCh_2.owner → MemCh_3 (continue)
3. Check MemCh_3.owner → CliArgs (stop, found handler)
4. Lookup ErrorHandlers[TYPE_CLI_ARGS] → Args_ErrorFunc
5. Call Args_ErrorFunc(MemCh_3, CliArgs, ErrorMsg)
```

#### Handler Return Values

**Error Handler Signature**:

```c
typedef status (*SourceFunc)(MemCh *m, void *instance, void *source);
// Where source is ErrorMsg*
```

**Return Value Meanings**:
- **ERROR | NOOP**: "I handled this error, formatted output, don't Fatal"
- **ERROR alone**: "I couldn't handle this, Fatal"
- **SUCCESS or ZERO**: "Error fully handled, no Fatal needed"

**Example Handler**:

```c
status MyType_ErrorHandler(MemCh *m, void *_obj, void *_msg){
    MyType *obj = (MyType *)_obj;
    ErrorMsg *msg = (ErrorMsg *)_msg;

    // Custom error handling
    Out("^r.MyType Error in object @^0\n", (void *[]){obj, NULL});

    // Output the formatted error message
    Fmt(ErrStream, msg->fmt, msg->args);

    // Add context-specific info
    Out("  Object state: $\n", (void *[]){I32_Wrapped(m, obj->state), NULL});

    return ERROR | NOOP;  // Signal: handled, outputted, don't Fatal
}
```

### Error Handler Registration

```c
// During initialization
status MyType_Init(MemCh *m){
    Lookup_Add(m, ErrorHandlers, TYPE_MY_TYPE, (void *)MyType_ErrorHandler);
    return SUCCESS;
}
```

**Built-In Handlers**:
- **TYPE_CLI_ARGS**: Shows help text and received arguments
- **TYPE_TASK**: Dispatches to task-specific error handlers
- **TYPE_HTTP_CTX**: Shows HTTP request details
- **TYPE_ROEBLING**: Shows parser state and position

### Signal Handling Integration

#### SIGINT Handler (Ctrl+C)

```c
static boolean _fuse = TRUE;  // Double-fault detection

static void sigI(i32 sig, siginfo_t *info, void *ptr){
    if(_fuse){
        _fuse = FALSE;

        // Show error-associated object if available
        if(ErrA != NULL){
            void *args[] = {ErrA, NULL};
            Fmt(ErrStream, "^r.ErrA: &^0\n", args);
        }

        Error(ErrStream->m, FUNCNAME, FILENAME, LINENUMBER,
            "Sig Int", NULL);
    }else{
        // Double SIGINT - immediate exit
        if(ErrStream->fd > 0){
            write(ErrStream->fd, "Double SigH\n",
                strlen("Double SigH\n"));
        }
    }
    exit(1);
}
```

**Registration**:

```c
status Error_Init(MemCh *m){
    // Register signal handlers
    struct sigaction act;
    memset(&act, 0, sizeof(struct sigaction));

    act.sa_sigaction = sigI;
    act.sa_flags = SA_SIGINFO;
    sigaction(SIGINT, &act, NULL);

    act.sa_sigaction = sigQuit;
    sigaction(SIGTERM, &act, NULL);

    return SUCCESS;
}
```

#### SIGTERM Handler

```c
static void sigQuit(i32 sig, siginfo_t *info, void *ptr){
    if(_fuse){
        _fuse = FALSE;
        Error(ErrStream->m, FUNCNAME, FILENAME, LINENUMBER,
            "Sig Quit", NULL);
    }else{
        if(ErrStream->fd > 0){
            write(ErrStream->fd, "Double SigH\n",
                strlen("Double SigH\n"));
        }
    }
    exit(1);
}
```

### System Error Integration

#### ErrNoError: errno Capture

```c
void ErrNoError(Buff *bf){
    if(errno != 0){
        void *args[] = {
            S(ErrStream->m, strerror(errno)),
            NULL
        };
        Fmt(bf, "\n  IoError: ^D.$^d.", args);
    }
}
```

**Usage Pattern**:

```c
FILE *f = fopen("file.txt", "r");
if(f == NULL){
    ErrNoError(ErrStream);  // Captures errno message

    Error(m, FUNCNAME, FILENAME, LINENUMBER,
        "Failed to open file", NULL);

    return ERROR;
}
```

**Output Example**:

```
Failed to open file at file.c:123 in main

  IoError: No such file or directory
```

#### OpenSSL Error Capture

```c
// From openssl_crypto.c
void OpenSsl_Error(Buff *bf){
    unsigned long err;
    while((err = ERR_get_error()) != 0){
        char *str = ERR_error_string(err, NULL);
        void *args[] = {S(bf->m, str), NULL};
        Fmt(bf, "\n  OpenSSL: $", args);
    }
}

// Usage
if(ctx == NULL){
    OpenSsl_Error(ErrStream);
    Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
        "Error setting up encryption context", NULL);
    return ERROR;
}
```

### Memory Zeroing Check

```c
boolean IsZeroed(MemCh *m, byte *b, size_t sz,
                 char *func, char *file, int line){
    // Check word-by-word
    while(sz >= sizeof(util)){
        util *bu = (util *)b;
        if(*bu != 0){
            goto err;
        }
        sz -= sizeof(util);
        b += sizeof(util);
    }

    // Check remaining bytes
    while(sz > 0){
        if(*b != 0){
            goto err;
        }
        b++;
        sz--;
    }

    return TRUE;

err:
    Error(m, func, file, line, "Memory not Zeroed", NULL);
    return FALSE;
}
```

**Usage**:

```c
MyStruct *obj = MemCh_Alloc(m, sizeof(MyStruct));

// Verify clean allocation
if(!IsZeroed(m, (byte *)obj, sizeof(MyStruct),
    FUNCNAME, FILENAME, LINENUMBER)){
    return ERROR;
}
```


## Code Examples

### Example 1: Basic Error with Arguments

```c
status Lookup_Add(MemCh *m, Lookup *lk, word type, void *value){
    if(type < lk->offset){
        void *args[] = {
            I16_Wrapped(m, lk->offset),
            I16_Wrapped(m, type),
            NULL
        };
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
            "Adding lookup value below offset of $, have $", args);
        return ERROR;
    }

    // Continue if valid...
    return SUCCESS;
}
```

**Output**:
```
Adding lookup value below offset of 100, have 50 at lookup.c:73 in Lookup_Add
```

### Example 2: File Operation Error

```c
status File_Open(Buff *bf, Str *path, word ioFlags){
    char *cstr = Str_Cstr(bf->m, path);
    i32 fd = open(cstr, ioFlags, 0644);

    if(fd <= 0){
        Abstract *args[] = {
            path,                                 // @ placeholder
            Str_CstrRef(bf->m, strerror(errno)), // $ placeholder
            NULL
        };
        Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
            "Error opening file @: $", args);
        bf->type.state |= ERROR;
        return ERROR;
    }

    Buff_SetFd(bf, fd);
    return SUCCESS;
}
```

**Output**:
```
Error opening file Str<"config.txt">: No such file or directory at file.c:45 in File_Open
```

### Example 3: Guard Error

```c
status Guard_Incr(MemCh *m, i16 *g, i16 max,
                  char *func, char *file, int line){
    if(Guard(g, max, func, file, line)){
        return SUCCESS;
    }

    // Guard exceeded
    Single sg = {.type = {TYPE_WRAPPED_I16, 0}, .val.w = *g};
    Single max_sg = {.type = {TYPE_WRAPPED_I16, 0}, .val.w = max};

    void *args[] = {&sg, &max_sg, NULL};

    Error(m, func, file, line, "Guard Error $/$", args);
    return ERROR;
}
```

**Output**:
```
Guard Error 1024/1024 at iter.c:180 in Iter_Query
```

### Example 4: Custom Error Handler

```c
typedef struct my_service {
    Type type;
    Str *name;
    i32 status_code;
    Table *config;
} MyService;

status MyService_ErrorHandler(MemCh *m, void *_svc, void *_msg){
    MyService *svc = (MyService *)_svc;
    ErrorMsg *msg = (ErrorMsg *)_msg;

    // Custom error header
    void *header_args[] = {svc->name, NULL};
    Out("^r.Service Error: @^0\n", header_args);

    // Show service state
    void *state_args[] = {
        I32_Wrapped(m, svc->status_code),
        NULL
    };
    Out("  Status Code: $\n", state_args);

    // Show configuration if relevant
    if(svc->config != NULL){
        void *config_args[] = {svc->config, NULL};
        Out("  Config: @\n", config_args);
    }

    // Output original error message
    Fmt(ErrStream, "  Error: ", NULL);
    Fmt(ErrStream, msg->fmt, msg->args);
    Out("\n", NULL);

    return ERROR | NOOP;  // Handled
}

// Registration
status MyService_Init(MemCh *m){
    Lookup_Add(m, ErrorHandlers, TYPE_MY_SERVICE,
        (void *)MyService_ErrorHandler);
    return SUCCESS;
}

// Usage
MemCh *m = MemCh_Make();
MyService *svc = MyService_Make(m, S(m, "WebServer"));
m->owner = svc;  // Attach as owner

// Later, when error occurs:
Error(m, FUNCNAME, FILENAME, LINENUMBER,
    "Connection timeout", NULL);
```

**Output**:
```
Service Error: Str<"WebServer">
  Status Code: 500
  Config: Table<5 entries>
  Error: Connection timeout
```

### Example 5: Task Error with Custom Handler

```c
// Task-specific error handler
status HttpTask_Error(MemCh *m, void *_tsk, void *_msg, void *source){
    Task *tsk = (Task *)_tsk;
    ErrorMsg *msg = (ErrorMsg *)_msg;
    HttpCtx *ctx = (HttpCtx *)source;

    // Show HTTP request details
    void *args[] = {
        ctx->request->method,
        ctx->request->path,
        NULL
    };
    Out("^r.HTTP Task Error: $ @^0\n", args);

    // Output original error
    Fmt(ErrStream, "  ", NULL);
    Fmt(ErrStream, msg->fmt, msg->args);
    Out("\n", NULL);

    // Show connection info
    Out("  Client: $:$\n", (void *[]){
        ctx->tcp->client_ip,
        I32_Wrapped(m, ctx->tcp->client_port),
        NULL
    });

    return NOOP;  // Handled
}

// Register task-specific handler
Single *key = Util_Wrapped(m, (util)http_task);
Single *handler = Ptr_Wrapped(m, HttpTask_Error, TYPE_TASK_POPULATE);
Table_Set(TaskErrorHandlers, key, handler);

// When error occurs in task:
Error(task->m, FUNCNAME, FILENAME, LINENUMBER,
    "Request processing failed", NULL);
```

**Output**:
```
HTTP Task Error: GET Str<"/api/users">
  Request processing failed
  Client: 192.168.1.100:54321
```

### Example 6: CLI Args Error

```c
// Built-in handler for CLI argument errors
status Args_ErrorFunc(MemCh *m, void *_cliArgs, void *_msg){
    CliArgs *cli = _cliArgs;
    ErrorMsg *msg = _msg;

    // Show help text
    Buff_Add(ErrStream, S(m, "help:\n\n"));
    CharPtr_ToHelp(cli);

    // Show what was received
    void *args[] = {
        Ptr_Wrapped(m, cli->argv, TYPE_CSTR_ARRAY),
        cli->args,
        NULL
    };
    Out("^p.Command line arguments received: @, gathered: @^0\n", args);

    return ERROR;
}

// Usage automatically invokes this when argument parsing fails
MemCh *m = MemCh_Make();
CliArgs *cli = Args_Make(m, argc, argv);
m->owner = cli;

// Parse fails with helpful output:
Args_Parse(cli, "--invalid-flag");
```

**Output**:
```
help:

  --config <file>    Configuration file path
  --port <number>    Server port (default: 8080)
  --help             Show this help message

Command line arguments received: ["./program", "--invalid-flag"],
gathered: Table<0 entries>
```

### Example 7: Formatted Debug Output

```c
void debug_memory_state(MemCh *m){
    void *args[] = {
        I64_Wrapped(m, m->it.p->nvalues),
        MemCount_Wrapped(m, MemCh_Used(m, 0)),
        NULL
    };

    // $ = content only
    Out("Pages: $, Used: $ bytes\n", args);
    // Output: Pages: 5, Used: 4096 bytes

    // @ = minimal debug
    Out("MemCh: @\n", (void *[]){m, NULL});
    // Output: MemCh<5 pages, 4096 used>

    // & = maximal debug
    Out("MemCh: &\n", (void *[]){m, NULL});
    // Output: MemCh<type=0x0001, level=0, guard=0, nvalues=5,
    //              max_idx=4, totalCeiling=0, ...>
}
```

### Example 8: Error with ANSI Colors

```c
void report_status(Task *tsk){
    if(tsk->type.state & SUCCESS){
        void *args[] = {tsk->name, NULL};
        Out("^g.✓ Task @ completed successfully^0\n", args);
        // Green checkmark and text
    }else if(tsk->type.state & ERROR){
        void *args[] = {tsk->name, NULL};
        Out("^r.✗ Task @ failed^0\n", args);
        // Red X and text
    }else{
        void *args[] = {tsk->name, NULL};
        Out("^y.⧗ Task @ in progress^0\n", args);
        // Yellow timer symbol
    }
}
```

### Example 9: OpenSSL Error Integration

```c
status Crypto_Encrypt(Buff *bf, byte *plaintext, i64 len){
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    if(ctx == NULL){
        OpenSsl_Error(ErrStream);  // Capture OpenSSL error queue

        Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
            "Failed to create encryption context", NULL);

        return ERROR;
    }

    // Continue encryption...
}
```

**Output**:
```
Failed to create encryption context at crypto.c:234 in Crypto_Encrypt

  OpenSSL: error:0308010C:digital envelope routines::unsupported
```

### Example 10: Memory Debugging with IsZeroed

```c
void test_clean_allocation(){
    MemCh *m = MemCh_Make();

    MyStruct *obj = MemCh_Alloc(m, sizeof(MyStruct));

    // Verify memory was zeroed
    if(!IsZeroed(m, (byte *)obj, sizeof(MyStruct),
        FUNCNAME, FILENAME, LINENUMBER)){

        Out("^r.WARNING: Uninitialized memory detected^0\n", NULL);
        return;
    }

    Out("^g.Memory properly zeroed^0\n", NULL);
    MemCh_Free(m);
}
```

### Example 11: Error State Propagation

```c
status ProcessFile(MemCh *m, Str *path){
    Buff *bf = Buff_Make(m, ZERO);

    status result = File_Open(bf, path, O_RDONLY);

    if(result & ERROR){
        // Error already reported by File_Open
        // Just propagate the error state
        return ERROR;
    }

    result = Buff_Read(bf);

    if(result & ERROR){
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
            "Failed to read file contents", NULL);
        File_Close(bf);
        return ERROR;
    }

    File_Close(bf);
    return SUCCESS;
}
```

### Example 12: Task Timeout Error

```c
status Task_Execute(Task *tsk){
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);

    // Check if task exceeded timeout
    if(tsk->type.state & TASK_CHECK_ELAPSED &&
       Time_Beyond(&tsk->metrics.start, &now, &tsk->timeout)){

        void *args[] = {
            tsk->name,
            I64_Wrapped(tsk->m, tsk->timeout.tv_sec),
            NULL
        };

        Error(tsk->m, FUNCNAME, FILENAME, LINENUMBER,
            "Task @ timed out after $ seconds", args);

        tsk->type.state |= ERROR;
        return ERROR;
    }

    // Continue execution...
    return SUCCESS;
}
```


## Performance Characteristics

### Error Overhead

**Fast Path** (no error):
```c
// No error - zero overhead
status result = Operation();
if(result & ERROR){  // Branch not taken
    // Not executed
}
```

**Error Path** (error occurred):

| Operation | Cost |
|-----------|------|
| **Owner chain walk** | O(D) where D=depth, typically 1-3 |
| **Handler lookup** | O(1) hash table lookup |
| **ErrorMsg creation** | ~100-200 cycles (allocations) |
| **Handler invocation** | Variable (depends on handler) |
| **Format/output** | ~1000+ cycles (I/O operations) |

**Total Error Handling Cost**: ~1-10 microseconds

**Key Point**: Error path is intentionally slow but provides rich diagnostics. Normal execution has zero overhead since errors don't occur on hot paths.

### Memory Usage

```c
sizeof(ErrorMsg) = ~64 bytes
  + lineInfo[4] = 4 × 8 = 32 bytes (pointers)
  + fmt (Str*) = 8 bytes (pointer)
  + args (void**) = 8 bytes (pointer)
  + Type = 16 bytes

Total per error = ~64 bytes + argument data
```

**ErrorHandlers Lookup**: O(1) memory per registered type (~8 bytes/type)



---

**Part 1 of 2** | [Part 2 →](error-handling-complete-part2)
