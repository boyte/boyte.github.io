---
sidebar_position: 4
---

# Iter

Iter provides iteration capabilities for traversing Caneka's memory structures.

## Diagram

![Iter Structure](/static/diagrams/iter.svg)

## Overview

Iter allows:
- Sequential access
- Efficient traversal
- Pointer-based iteration
- Offset mathematics

## Usage

```c
Iter iter = Iter_Make(span);
while (Iter_HasNext(&iter)) {
    void *elem = Iter_Next(&iter);
    // Process element
}
```

## See Also

- [Memory Overview](overview.md)
- [Span](span.md)
