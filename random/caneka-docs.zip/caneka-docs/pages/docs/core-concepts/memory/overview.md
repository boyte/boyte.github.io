---
sidebar_position: 1
---

# Memory Management Overview

Caneka features a custom OS-independent memory management system that provides transparency, efficiency, and control.

## Why Custom Memory Management?

Traditional malloc/free has limitations:
- Hidden allocations
- Fragmentation
- Difficult to track
- Opaque to developers

Caneka's memory system provides:
- **Transparency**: See exactly where memory is allocated
- **Bulk operations**: Free entire allocation groups at once
- **Statistics**: Track memory usage in real-time
- **Recycling**: Reuse deallocated pages

## Three-Level Hierarchy

```
MemBook (top level)
  └── MemChapter (mid level)
        └── MemPage (page level)
```

### MemBook
Top-level allocation unit. Create one per major subsystem.

### MemChapter
Mid-level container within a book. Automatically created as needed.

### MemPage
Individual memory pages (typically 4KB or 8KB).

## Supporting Structures

### Span
Flexible array that can grow and shrink.

![Span Structure](/static/diagrams/span.svg)

### Iter
Iterator for traversing memory structures.

![Iter Structure](/static/diagrams/iter.svg)

## Basic Usage

```c
#include "mem/mem_book.h"

// Create a memory book
MemBook *book = MemBook_Make(NULL);

// Allocate memory
void *data = MemCh_AllocOf(book, size, TYPE_DATA);

// Use the memory...

// Clean up - frees all allocations from this book
MemBook_WipePages(book);
```

## Benefits

1. **Bulk Deallocation**: Free entire subsystems at once
2. **No Leaks**: Automatic cleanup of related allocations
3. **Debugging**: Inspect all active allocations
4. **Performance**: Page recycling reduces system calls

## Next Steps

- [MemBook Details](membook.md)
- [Span Details](span.md)
- [Iter Details](iter.md)
