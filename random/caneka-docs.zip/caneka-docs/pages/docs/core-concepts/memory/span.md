---
sidebar_position: 3
---

# Span

Span is Caneka's flexible array structure that can efficiently grow and shrink.

## Diagram

![Span Structure](/static/diagrams/span.svg)

## Overview

Span provides:
- Dynamic resizing
- Efficient access
- Memory-managed growth
- Type-safe elements

## Usage

```c
Span *span = Span_Make(book, element_size, initial_capacity);
Span_Add(span, element);
void *elem = Span_Get(span, index);
```

## Benefits

- No manual reallocation
- Grows as needed
- Integrated with MemBook system
- Efficient iteration

## See Also

- [Memory Overview](overview.md)
- [Iter](iter.md)
