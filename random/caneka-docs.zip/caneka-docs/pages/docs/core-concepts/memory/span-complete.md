---
sidebar_position: 6
---

# Span - Multi-Dimensional Sparse Arrays

Span is Caneka's fundamental dynamic array structure. It's a **sparse, multi-dimensional array** that efficiently handles data with gaps and supports up to 4 dimensions.

## What is a Span?

Think of Span as a smart array that:
- Grows automatically as you add elements
- Handles missing indices efficiently (sparse)
- Supports multi-dimensional access (up to 4D)
- Tracks gaps for efficient iteration
- Can be ordered or hash-based

![Span Structure](/static/diagrams/span.svg)

## Core Concept: Sparsity

Unlike traditional arrays, Span doesn't allocate space for every index between 0 and N. It only allocates for indices you actually use.

**Traditional Array:**
```c
int arr[1000];  // Wastes space if you only use indices 0, 500, 999
```

**Span:**
```c
Span *sp = Span_Make(m);
Span_Set(sp, 0, value1);      // Allocates slot 0
Span_Set(sp, 500, value2);    // Allocates slot 1 (not 500 slots)
Span_Set(sp, 999, value3);    // Allocates slot 2
// Only 3 slots allocated, not 1000
```

## Structure (Conceptual)

```c
typedef struct span {
    Type type;
    i32 max_idx;        // Highest index ever set
    i32 count;          // Number of elements (including gaps)
    byte dims;          // Number of dimensions (1-4)
    byte dimPos;        // Current dimension position
    word size;          // Size of each element
    void **slots;       // Storage (inline or allocated)
    // ... internal fields
} Span;
```

## Flags

Spans have several operational modes:

```c
FLAG_SPAN_INLINE_SLOTS    // Slots stored inline (small spans)
FLAG_SPAN_HAS_GAPS        // Contains removed/never-set indices
FLAG_SPAN_ORDERED         // Maintains insertion order
FLAG_SPAN_RAW             // Contains raw pointers (not typed objects)
FLAG_SPAN_TABLE           // Used as hash table
```

## Basic Operations

### Creating a Span

```c
Span *Span_Make(MemCh *m);
```

Creates an empty 1-dimensional span.

**Example:**
```c
MemBook *book = MemBook_Make(NULL);
MemCh *m = &book->m;
Span *sp = Span_Make(m);
```

### Setting Values

```c
status Span_Set(Span *sp, i32 idx, void *value);
```

Sets the value at `idx`. Grows the span if necessary.

**Example:**
```c
Str *name = Str_From(m, "Alice");
Span_Set(sp, 0, name);

Str *name2 = Str_From(m, "Bob");
Span_Set(sp, 10, name2);  // Creates gap from 1-9

// sp->max_idx = 10
// sp->count = 2 (only 2 actual elements)
```

### Getting Values

```c
void *Span_Get(Span *sp, i32 idx);
```

Retrieves the value at `idx`, or NULL if not set.

**Example:**
```c
Str *name = Span_Get(sp, 0);
if (name) {
    printf("Name: %s\n", StrVec_GetCStr(name));
}

void *gap = Span_Get(sp, 5);  // Returns NULL (gap)
```

### Removing Values

```c
status Span_Remove(Span *sp, i32 idx);
```

Removes the value at `idx`, creating a gap.

**Example:**
```c
Span_Remove(sp, 0);
// sp->count = 1
// Sets FLAG_SPAN_HAS_GAPS
```

## Multi-Dimensional Spans

Spans support up to **4 dimensions**, with a maximum total of **1,048,576 elements** (SPAN_MAX_DIMS).

### Dimension Calculation

Each dimension uses bit positions:
- **Dim 0**: Bits 0-9 (1,024 elements)
- **Dim 1**: Bits 10-19 (1,024 elements)
- **Dim 2**: Bits 20-29 (1,024 elements)
- **Dim 3**: Bits 30-39 (not used in practice due to limits)

### Creating Multi-Dimensional Span

```c
Span *Span_MakeDim(MemCh *m, byte dims);
```

**Example - 2D Grid:**
```c
Span *grid = Span_MakeDim(m, 2);

// grid[y][x] access pattern
i32 idx = (y << 10) | x;  // Combine dimensions
Span_Set(grid, idx, value);
```

**Example - 3D Cube:**
```c
Span *cube = Span_MakeDim(m, 3);

// cube[z][y][x] access pattern
i32 idx = (z << 20) | (y << 10) | x;
Span_Set(cube, idx, value);
```

### Extracting Dimension Coordinates

```c
// Get individual dimensions from index
i32 dim0 = idx & 0x3FF;           // Bits 0-9
i32 dim1 = (idx >> 10) & 0x3FF;   // Bits 10-19
i32 dim2 = (idx >> 20) & 0x3FF;   // Bits 20-29
```

## Iteration

Spans are iterated using **Iter** objects (see [Iterator documentation](iter-complete.md)).

### Basic Iteration

```c
Iter it = Iter_Make(sp);
while (Iter_HasNext(&it)) {
    void *value = Iter_Next(&it);
    if (value) {  // Check for gaps
        // Process value
    }
}
```

### Iteration with Index

```c
Iter it = Iter_Make(sp);
while (Iter_HasNext(&it)) {
    i32 idx = it.idx;
    void *value = Iter_Next(&it);
    printf("sp[%d] = %p\n", idx, value);
}
```

### Skipping Gaps

```c
Iter it = Iter_Make(sp);
while (Iter_HasNext(&it)) {
    void *value = Iter_Next(&it);
    if (!value) continue;  // Skip gaps
    // Process non-null value
}
```

## Hash Table Mode

Spans can operate as **hash tables** using `FLAG_SPAN_TABLE`.

### Key Structure

```c
typedef struct hashed {
    Type type;
    i32 idx;          // Span index
    i32 orderIdx;     // Insertion order
    util id;          // Hash value
    void *key;        // Key object
    void *value;      // Value object
} Hashed;
```

### Hash Table Operations

```c
// Create table
Span *table = Span_Make(m);
Type_SetFlag(&table->type, FLAG_SPAN_TABLE);

// Set key-value
Str *key = Str_From(m, "username");
Str *value = Str_From(m, "alice");
Table_Set(table, key, value);

// Get value
Str *retrieved = Table_Get(table, key);

// Remove key
Table_UnSet(table, key);
```

### Hash Collision Handling

Caneka uses **open addressing** with linear probing:

1. Hash key to get initial index
2. If slot occupied by different key, increment index
3. Continue until empty slot or matching key found
4. Resize table if load factor exceeds threshold

## Ordered Spans

Setting `FLAG_SPAN_ORDERED` maintains insertion order via `orderIdx` in Hashed entries.

### Ordered Iteration

```c
Span *sp = Span_Make(m);
Type_SetFlag(&sp->type, FLAG_SPAN_ORDERED);

// Add in any order
Span_Set(sp, 100, value1);
Span_Set(sp, 50, value2);
Span_Set(sp, 200, value3);

// Iterate in insertion order: 100, 50, 200
Iter it = Iter_Make(sp);
while (Iter_HasNext(&it)) {
    Hashed *h = Iter_Next(&it);
    // h->orderIdx reflects insertion order
}
```

## Performance Characteristics

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| Set (no resize) | O(1) average | O(n) worst case with collisions |
| Get | O(1) average | O(n) worst case with collisions |
| Remove | O(1) | Creates gap |
| Iteration | O(n + g) | n = elements, g = gaps |
| Resize | O(n) | Rare, happens when load factor exceeds threshold |

## Memory Efficiency

Spans use two storage modes:

### Inline Storage (Small Spans)

For spans with few elements, slots are stored directly in the Span structure:

```c
FLAG_SPAN_INLINE_SLOTS

// Slots stored in Span itself
void *inline_slots[SPAN_INLINE_MAX];  // e.g., 8 slots
```

### Allocated Storage (Large Spans)

When capacity exceeds inline limit, storage moves to separate allocation:

```c
// Slots pointer to separate allocation
void **slots = MemCh_AllocOf(m, capacity * sizeof(void*), TYPE_SPAN);
```

## Practical Examples

### Example 1: User Database

```c
MemCh *m = &book->m;
Span *users = Span_Make(m);
Type_SetFlag(&users->type, FLAG_SPAN_TABLE);

// Add users by ID
for (int i = 0; i < user_count; i++) {
    User *user = LoadUser(m, user_ids[i]);
    Span_Set(users, user->id, user);
}

// Lookup user by ID
User *alice = Span_Get(users, 42);
```

### Example 2: Sparse Matrix

```c
// 1000x1000 matrix with only 100 non-zero elements
Span *matrix = Span_MakeDim(m, 2);

// Set only non-zero values
for (int i = 0; i < non_zero_count; i++) {
    i32 row = nz[i].row;
    i32 col = nz[i].col;
    i32 idx = (row << 10) | col;
    Span_Set(matrix, idx, &nz[i].value);
}

// Only allocates ~100 slots, not 1,000,000
```

### Example 3: Configuration Table

```c
Span *config = Span_Make(m);
Type_SetFlag(&config->type, FLAG_SPAN_TABLE);

// Store configuration key-value pairs
Table_Set(config, Str_From(m, "host"), Str_From(m, "localhost"));
Table_Set(config, Str_From(m, "port"), I32_Wrapped(m, 8080));
Table_Set(config, Str_From(m, "debug"), Bool_Wrapped(m, true));

// Retrieve configuration
Str *host = Table_Get(config, Str_From(m, "host"));
i32 port = Single_GetI32(Table_Get(config, Str_From(m, "port")));
```

## Best Practices

1. **Use Spans for dynamic collections**: Don't pre-allocate large arrays
2. **Leverage sparsity**: Only set indices you need
3. **Iterate carefully**: Check for NULL (gaps) during iteration
4. **Choose dimensions wisely**: Match your data structure (1D list, 2D grid, etc.)
5. **Use table mode for key-value**: Set FLAG_SPAN_TABLE for hash table semantics

## Common Pitfalls

### Pitfall 1: Assuming No Gaps

```c
// DON'T ASSUME CONTIGUOUS
for (i32 i = 0; i < sp->max_idx; i++) {
    void *val = Span_Get(sp, i);  // May be NULL
    ProcessValue(val);  // CRASH if val is NULL
}

// DO THIS INSTEAD
Iter it = Iter_Make(sp);
while (Iter_HasNext(&it)) {
    void *val = Iter_Next(&it);
    if (val) ProcessValue(val);
}
```

### Pitfall 2: Dimension Overflow

```c
// DON'T EXCEED DIMENSION LIMITS
Span *sp = Span_MakeDim(m, 2);
i32 idx = (2000 << 10) | 500;  // Exceeds 1024 limit per dimension
Span_Set(sp, idx, value);  // Undefined behavior
```

### Pitfall 3: Modifying During Iteration

```c
// DON'T MODIFY SPAN DURING ITERATION
Iter it = Iter_Make(sp);
while (Iter_HasNext(&it)) {
    void *val = Iter_Next(&it);
    Span_Remove(sp, it.idx);  // CORRUPTS ITERATOR
}
```

## See Also

- [Iterator](iter-complete.md) - Span iteration details
- [Table](../sequences/table.md) - Hash table wrapper around Span
- [Memory Overview](overview.md) - Memory management context
