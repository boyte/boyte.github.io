---
sidebar_position: 7
---

# Iterator (Iter) - Complete Guide

The **Iterator** (Iter) is Caneka's universal traversal mechanism for collections. It provides a consistent interface for navigating Spans, Tables, and other sequential structures.

## What is an Iterator?

An Iter is a **cursor** that tracks position in a collection and provides methods to move forward, backward, and access elements.

![Iter Structure](/static/diagrams/iter.svg)

## Structure

```c
typedef struct iter {
    Span *p;          // Collection being iterated
    i32 idx;          // Current index
    Type type;        // State and operation flags
} Iter;
```

## Key Concepts

### Iterator State

Iterators maintain state through flags in the `type` field:

- **Position**: Current `idx` in the Span
- **Direction**: Forward or backward traversal
- **Stack mode**: Push/pop operations
- **Gap awareness**: Can skip or report gaps

### Creating Iterators

Iterators are created from collections:

```c
Span *sp = Span_Make(m);
Iter it = Iter_Make(sp);  // Creates iterator at index -1 (before start)
```

**Initial State:**
- `it.idx = -1` (before first element)
- Ready to call `Iter_Next()` to get first element

## Core Operations

### Forward Iteration

```c
boolean Iter_HasNext(Iter *it);
void *Iter_Next(Iter *it);
```

**Pattern:**
```c
Iter it = Iter_Make(sp);
while (Iter_HasNext(&it)) {
    void *elem = Iter_Next(&it);
    if (elem) {
        // Process element (may be NULL if gap)
    }
}
```

### Backward Iteration

```c
boolean Iter_HasPrev(Iter *it);
void *Iter_Prev(Iter *it);
```

**Pattern:**
```c
Iter it = Iter_Make(sp);
Iter_SeekEnd(&it);  // Move to end

while (Iter_HasPrev(&it)) {
    void *elem = Iter_Prev(&it);
    // Process in reverse order
}
```

### Peeking (No Advancement)

```c
void *Iter_Peek(Iter *it);
```

Returns current element without advancing:

```c
void *current = Iter_Peek(&it);
// idx unchanged
```

### Seeking

```c
status Iter_Seek(Iter *it, i32 idx);
status Iter_SeekEnd(Iter *it);
```

Jump to specific position:

```c
Iter_Seek(&it, 10);  // Jump to index 10
void *elem = Iter_Peek(&it);  // Get element at 10

Iter_SeekEnd(&it);   // Jump to last element
```

## Stack Operations

Iterators support stack semantics (LIFO):

### Push

```c
status Iter_Push(Iter *it, void *value);
```

Adds element at current position and advances:

```c
Iter it = Iter_Make(sp);
Iter_Push(&it, value1);  // Adds at index 0
Iter_Push(&it, value2);  // Adds at index 1
// Stack: [value1, value2]
```

### Pop

```c
void *Iter_Pop(Iter *it);
```

Removes and returns current element, moves backward:

```c
void *top = Iter_Pop(&it);    // Returns value2, idx now 0
void *next = Iter_Pop(&it);   // Returns value1, idx now -1
```

## Gap Handling

Spans can have gaps (removed or never-set indices). Iterators handle gaps in two ways:

### Method 1: Check for NULL

```c
while (Iter_HasNext(&it)) {
    void *elem = Iter_Next(&it);
    if (!elem) {
        // Gap encountered, skip it
        continue;
    }
    // Process non-null element
}
```

### Method 2: Skip Gaps Automatically

Some iteration modes automatically skip gaps:

```c
Iter it = Iter_Make(sp);
Type_SetFlag(&it.type, ITER_SKIP_GAPS);  // Skip gaps

while (Iter_HasNext(&it)) {
    void *elem = Iter_Next(&it);  // Never NULL
    // Process element
}
```

## Iterator Flags

Control iteration behavior via type flags:

```c
ITER_FORWARD        // Iterate forward (default)
ITER_BACKWARD       // Iterate backward
ITER_SKIP_GAPS      // Skip NULL elements
ITER_STACK_MODE     // Enable push/pop
ITER_ORDERED        // Respect orderIdx (hash tables)
ITER_RESET          // Reset to start
```

**Setting Flags:**
```c
Type_SetFlag(&it.type, ITER_SKIP_GAPS | ITER_ORDERED);
```

## Multi-Dimensional Iteration

For multi-dimensional Spans, iterators traverse in row-major order:

### 2D Example

```c
Span *grid = Span_MakeDim(m, 2);  // 2D grid

// Fill grid
for (int y = 0; y < 10; y++) {
    for (int x = 0; x < 10; x++) {
        i32 idx = (y << 10) | x;
        Span_Set(grid, idx, CreateCell(x, y));
    }
}

// Iterate all cells
Iter it = Iter_Make(grid);
while (Iter_HasNext(&it)) {
    Cell *cell = Iter_Next(&it);

    // Extract coordinates from idx
    i32 x = it.idx & 0x3FF;
    i32 y = (it.idx >> 10) & 0x3FF;

    printf("Cell(%d,%d) = %p\n", x, y, cell);
}
```

## Nested Iteration

Iterate over collection while iterating inner collections:

```c
Span *outer = Span_Make(m);
// Fill outer with Spans

Iter outerIt = Iter_Make(outer);
while (Iter_HasNext(&outerIt)) {
    Span *inner = Iter_Next(&outerIt);

    Iter innerIt = Iter_Make(inner);
    while (Iter_HasNext(&innerIt)) {
        void *elem = Iter_Next(&innerIt);
        // Process nested element
    }
}
```

## Performance Considerations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| HasNext/HasPrev | O(1) | Simple index check |
| Next/Prev | O(1) average | O(g) if skipping gaps |
| Seek | O(1) | Direct index access |
| Push | O(1) amortized | May trigger Span resize |
| Pop | O(1) | No reallocation |

## Practical Examples

### Example 1: Filter Collection

```c
// Filter even numbers
Span *numbers = /* ... filled with integers ... */;
Span *evens = Span_Make(m);

Iter it = Iter_Make(numbers);
while (Iter_HasNext(&it)) {
    i32 *num = Iter_Next(&it);
    if (num && *num % 2 == 0) {
        Span_Set(evens, evens->count, num);
    }
}
```

### Example 2: Reverse a Collection

```c
Span *reversed = Span_Make(m);
Iter it = Iter_Make(original);
Iter_SeekEnd(&it);  // Start at end

while (Iter_HasPrev(&it)) {
    void *elem = Iter_Prev(&it);
    Iter_Push(&reversed_it, elem);
}
```

### Example 3: Find Element

```c
Str *FindByName(Span *users, const char *name) {
    Iter it = Iter_Make(users);
    while (Iter_HasNext(&it)) {
        User *user = Iter_Next(&it);
        if (user && strcmp(user->name, name) == 0) {
            return user;
        }
    }
    return NULL;
}
```

## Best Practices

1. **Always check HasNext/HasPrev** before Next/Prev
2. **Check for NULL** unless ITER_SKIP_GAPS is set
3. **Don't modify collection during iteration** (causes undefined behavior)
4. **Use stack mode for LIFO semantics** (cleaner than manual index management)
5. **Reset iterator** with Iter_Seek if reusing

## Common Pitfalls

### Pitfall 1: Not Checking HasNext

```c
// DON'T DO THIS
while (true) {
    void *elem = Iter_Next(&it);  // May go past end
    if (!elem) break;  // Wrong! NULL could be a gap, not end
}

// DO THIS
while (Iter_HasNext(&it)) {
    void *elem = Iter_Next(&it);
    if (elem) {
        // Process
    }
}
```

### Pitfall 2: Modifying During Iteration

```c
// DON'T DO THIS
while (Iter_HasNext(&it)) {
    void *elem = Iter_Next(&it);
    Span_Remove(sp, it.idx);  // CORRUPTS ITERATOR
}

// DO THIS (collect indices first)
Span *toRemove = Span_Make(m);
while (Iter_HasNext(&it)) {
    if (ShouldRemove(Iter_Next(&it))) {
        Span_Set(toRemove, toRemove->count, I32_Wrapped(m, it.idx));
    }
}
// Now remove
Iter removeIt = Iter_Make(toRemove);
while (Iter_HasNext(&removeIt)) {
    i32 idx = Single_GetI32(Iter_Next(&removeIt));
    Span_Remove(sp, idx);
}
```

### Pitfall 3: Assuming Contiguous Indices

```c
// DON'T ASSUME idx IS CONTIGUOUS
Iter it = Iter_Make(sp);
i32 count = 0;
while (Iter_HasNext(&it)) {
    Iter_Next(&it);
    assert(it.idx == count);  // FAILS if gaps exist
    count++;
}

// Gaps mean idx jumps: 0, 1, 5, 10, ...
```

## See Also

- [Span](span-complete.md) - Collection being iterated
- [Table](../sequences/table.md) - Hash table iteration
- [Memory Overview](overview.md) - Memory context
