---
sidebar_position: 2
---

# MemBook

MemBook is the top-level memory allocation unit in Caneka's memory management system.

## Structure

```c
typedef struct mem_book {
    Type type;
    i32 size;
    i32 idx;
    i32 wipeIdx;
    void *start;
    struct iter retired;
    struct iter recycled;
    struct mem_ctx m;
} MemBook;
```

## Diagram

![MemBook Structure](/static/diagrams/mem_book.svg)

## Key Functions

### Creating a MemBook

```c
MemBook *MemBook_Make(MemBook *prev);
```

Creates a new MemBook. The `prev` parameter allows linking books together, or pass `NULL` for a standalone book.

### Allocating Memory

```c
void *MemCh_AllocOf(MemBook *book, i32 size, Type type);
```

Allocate memory of a specific size and type within this book.

### Freeing Memory

```c
status MemBook_WipePages(void *addr);
```

Free all pages allocated from this book. Much more efficient than freeing individually.

### Statistics

```c
status MemBook_GetStats(void *addr, MemBookStats *st);
```

Get statistics about memory usage for this book.

## Lifecycle

1. **Create**: `MemBook_Make(NULL)`
2. **Use**: Allocate many objects with `MemCh_AllocOf`
3. **Cleanup**: `MemBook_WipePages` frees everything at once

## Best Practices

- Create one MemBook per major subsystem
- Use bulk deallocation with WipePages
- Check stats to monitor memory usage
- Link related books with the `prev` parameter

## See Also

- [Memory Overview](overview.md)
- [MemChapter](overview.md)
- [MemPage](overview.md)
