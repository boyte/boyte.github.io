---
sidebar_position: 5
---

# MemChapter (MemCh) - Memory Context

MemChapter, abbreviated as **MemCh**, is the mid-level memory allocation unit in Caneka's memory hierarchy. It represents a **memory context** - a logical grouping of related allocations that can be freed together.

## Purpose

MemCh serves as the primary interface for memory allocation in Caneka. While MemBook provides the high-level container, MemCh is where actual allocations happen.

### Key Responsibilities

1. **Allocation Interface**: Primary API for allocating typed memory
2. **Context Management**: Groups related allocations for bulk cleanup
3. **Metrics Tracking**: Monitors memory usage within the context
4. **External Free Tracking**: Handles objects allocated outside normal heap

## Structure

```c
typedef struct mem_ctx {
    Type type;                  // Type header (all objects have this)
    i16 level;                  // Hierarchy level (for debugging)
    i16 guard;                  // Guard counter for loop detection
    Iter it;                    // Iterator over allocated pages
    void *owner;                // Owning MemBook
    struct {
        i32 totalCeiling;       // Peak memory usage
    } metrics;
    Span *extFree;              // External free list
} MemCh;
```

## Key Concepts

### Memory Context

A **memory context** is a logical boundary for allocations. All allocations within a context can be freed in one operation, making cleanup simple and preventing memory leaks.

#### Common Contexts

- **Per-request contexts**: Web server creates one MemCh per HTTP request
- **Per-task contexts**: Navigate tasks use one MemCh for all task data
- **Per-subsystem contexts**: Parser, template engine, etc. each have their own

### External Free Tracking

Some objects are allocated outside the normal memory manager (e.g., file descriptors, mmap regions, external library allocations). The **extFree** Span tracks these for cleanup.

```c
// Track external allocation
ExtFree_Init(m, obj, cleanup_function);

// When context is freed, cleanup_function is called for obj
```

#### Use Cases

- File descriptors that need `close()`
- Socket connections requiring `shutdown()`
- mmap regions needing `munmap()`
- External library handles requiring library-specific cleanup

## Core Operations

### Allocating Memory

```c
void *MemCh_AllocOf(MemBook *book, i32 size, Type type);
```

Primary allocation function. Allocates `size` bytes of memory tagged with `type`.

**Parameters:**
- `book`: MemBook to allocate from (provides the MemCh)
- `size`: Bytes to allocate
- `type`: Type identifier (from `types/range.h`)

**Returns:** Pointer to allocated memory, or NULL on failure

**Example:**
```c
MemBook *book = MemBook_Make(NULL);
MemCh *m = &book->m;  // Get the memory context

// Allocate a string
Str *str = MemCh_AllocOf(book, sizeof(Str), TYPE_STR);

// Allocate an array
MyStruct *arr = MemCh_AllocOf(book, sizeof(MyStruct) * 100, TYPE_ARRAY);
```

### Reallocating Memory

```c
void *MemCh_Realloc(MemCh *m, void *addr, i32 oldSize, i32 newSize);
```

Resize an existing allocation. Copies data to new location if necessary.

**Parameters:**
- `m`: Memory context
- `addr`: Current allocation address
- `oldSize`: Current size in bytes
- `newSize`: Desired size in bytes

**Returns:** New address (may differ from addr)

**Example:**
```c
// Growing an array
oldSize = 100 * sizeof(int);
newSize = 200 * sizeof(int);
arr = MemCh_Realloc(m, arr, oldSize, newSize);
```

### Freeing Context

```c
status MemCh_Free(MemCh *m);
```

Frees all allocations within the context and calls external cleanup functions.

**Important:** This is typically called via `MemBook_WipePages()` rather than directly.

## Memory Metrics

MemCh tracks allocation statistics:

```c
typedef struct {
    i32 totalCeiling;  // Peak memory usage in bytes
} MemChMetrics;
```

Access via:
```c
MemBookStats stats;
MemBook_GetStats(addr, &stats);
printf("Peak usage: %d bytes\n", stats.total);
```

## Memory Hierarchy Position

```
MemBook (16MB container)
  ├─ MemCh (Memory Context) ← You are here
  │   ├─ Allocation 1
  │   ├─ Allocation 2
  │   └─ Allocation N
  └─ MemPage (4KB pages)
      └─ Storage for allocations
```

## Allocation Strategy

When you call `MemCh_AllocOf()`:

1. **Check size**: Determine if allocation fits in a page (< 4KB)
2. **Find space**: Locate a MemPage with sufficient remaining space
3. **Allocate**: Carve out the requested bytes
4. **Track**: Add to the iterator tracking allocations
5. **Update metrics**: Increment totalCeiling if this is peak usage

For large allocations (> 4KB), a dedicated MemPage is used.

## Guard Mechanism

The `guard` field prevents infinite loops during recursive operations:

```c
MemCh *m = &book->m;
m->guard = 0;

while (condition) {
    if (m->guard++ > MAX_GUARD) {
        return ERROR_INFINITE_LOOP;
    }
    // ... do work
}
```

Common in iteration and traversal operations.

## Practical Patterns

### Per-Request Pattern

```c
// HTTP request handler
status HandleRequest(HttpCtx *ctx) {
    MemBook *book = MemBook_Make(NULL);
    MemCh *m = &book->m;

    // All allocations use this context
    HttpRequest *req = ParseRequest(m, ctx->input);
    HttpResponse *resp = BuildResponse(m, req);
    SendResponse(ctx->socket, resp);

    // Free everything at once
    MemBook_WipePages(book);
    return SUCCESS;
}
```

### External Resource Pattern

```c
// Open file with external tracking
Buff *OpenFile(MemCh *m, const char *path) {
    Buff *bf = MemCh_AllocOf(m, sizeof(Buff), TYPE_BUFF);
    bf->fd = open(path, O_RDONLY);

    // Track FD for cleanup
    ExtFree_Init(m, bf, BuffCleanup);

    return bf;
}

status BuffCleanup(MemCh *m, Buff *bf) {
    close(bf->fd);
    return SUCCESS;
}
```

### Nested Context Pattern

```c
// Parent owns child contexts
MemBook *parentBook = MemBook_Make(NULL);
MemCh *parent = &parentBook->m;

// Child allocations
MemBook *childBook = MemBook_Make(parentBook);  // Linked
MemCh *child = &childBook->m;

// Work with child...

// Cleanup frees child first, then parent
MemBook_WipePages(parentBook);
```

## Best Practices

1. **One Context Per Operation**: Create a MemCh for each major operation
2. **Bulk Cleanup**: Always free via `MemBook_WipePages()` to ensure external cleanup
3. **Track External Resources**: Use ExtFree for file descriptors, sockets, etc.
4. **Check Metrics**: Monitor totalCeiling to detect memory growth
5. **Avoid Manual Free**: Let MemBook handle cleanup to prevent leaks

## Common Pitfalls

### Pitfall 1: Freeing Individual Allocations

```c
// DON'T DO THIS
void *ptr = MemCh_AllocOf(book, size, type);
free(ptr);  // WRONG - Caneka doesn't use free()
```

**Solution**: Let MemBook_WipePages() handle all cleanup.

### Pitfall 2: Ignoring External Resources

```c
// DON'T DO THIS
Buff *bf = MemCh_AllocOf(m, sizeof(Buff), TYPE_BUFF);
bf->fd = open(path, O_RDONLY);
// Forgot to track FD - will leak on cleanup
```

**Solution**: Always use ExtFree_Init() for external resources.

### Pitfall 3: Mixing Contexts

```c
// DON'T DO THIS
MemCh *m1 = &book1->m;
MemCh *m2 = &book2->m;
MyStruct *obj1 = MemCh_AllocOf(book1, size, type);
obj1->child = MemCh_AllocOf(book2, size, type);  // Different book!
MemBook_WipePages(book1);  // obj1->child now dangling
```

**Solution**: Keep related allocations in the same context.

## See Also

- [MemBook](membook.md) - Parent container
- [MemPage](overview.md) - Page-level storage
- [Memory Overview](overview.md) - Complete hierarchy
- [External Free Tracking](overview.md#external-free) - Cleanup mechanisms
