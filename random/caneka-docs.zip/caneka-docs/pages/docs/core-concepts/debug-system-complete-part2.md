# Debug System: Complete Guide - Part 2

[← Part 1](debug-system-complete-part1) | **Part 2 of 2**

---

## Best Practices

### 1. Always Push/Pop Balanced

Ensure every DebugStack_Push() has a matching Pop(), or let Error() handle cleanup.

```c
// Good: Balanced
void Function(MemCh *m){
    DebugStack_Push(NULL, 0);
    // ... work ...
    DebugStack_Pop();
}

// Also Good: Error cleans up
void Function(MemCh *m){
    DebugStack_Push(NULL, 0);
    if(condition) Error(m, "Failed");  // No need to pop
    DebugStack_Pop();
}

// Bad: Missing pop
void Function(MemCh *m){
    DebugStack_Push(NULL, 0);
    // ... work ...
    // Missing DebugStack_Pop()!
}
```

### 2. Use Guards in All Loops

Even "impossible" infinite loops can happen due to bugs. Guards catch them early.

```c
// Good: Guarded loop
i16 guard = 0;
while(node){
    Guard_Incr(m, &guard, 100);
    node = node->next;
}

// Bad: Unguarded (may infinite loop on cycle)
while(node){
    node = node->next;  // What if cycle exists?
}
```

### 3. Provide Multiple Debug Levels

Implement ZERO, MORE, and DEBUG output in custom printers.

```c
status MyType_Print(Buff *bf, void *a, cls type, word flags){
    if(flags & DEBUG){
        // Exhaustive output with all fields
    } else if(flags & MORE){
        // Summary with key fields
    } else {
        // Minimal, user-friendly output
    }
}
```

### 4. Use Fmt for Structured Output

Prefer Fmt() over manual Buff_Add() chains for readability.

```c
// Good: Clean and readable
void *args[] = {name, age, city, NULL};
Fmt(bf, "Name: $, Age: $, City: $", args);

// Bad: Verbose
Buff_Add(bf, S(m, "Name: "));
ToS(bf, name, 0, ZERO);
Buff_Add(bf, S(m, ", Age: "));
ToS(bf, age, 0, ZERO);
Buff_Add(bf, S(m, ", City: "));
ToS(bf, city, 0, ZERO);
```

### 5. Test Memory Leaks Regularly

Add leak detection to test harnesses.

```c
void RunAllTests(){
    MemCh *m = MemCh_Make();
    i64 baseline = MemChapterCount();

    Test_Feature1(m);
    Test_Feature2(m);
    Test_Feature3(m);

    i64 final = MemChapterCount();

    if(final != baseline){
        printf("LEAK: %lld contexts not freed\n", final - baseline);
        exit(1);
    }

    MemCh_Free(m);
}
```

---


## Common Pitfalls

### Pitfall 1: Forgetting to Pop Debug Stack

**Problem:** Stack grows unbounded, consuming memory and producing confusing traces.

```c
// Bad: No pop
void BadFunction(MemCh *m){
    DebugStack_Push(NULL, 0);
    // ... work ...
    return;  // Missing DebugStack_Pop()!
}

// After 1000 calls, stack has 1000 entries!
```

**Solution:** Always pop, or let Error() handle it.

### Pitfall 2: Guard Maximum Too Low

**Problem:** Legitimate operations exceed guard, causing false errors.

```c
// Bad: Max too low for large files
i16 guard = 0;
while(ReadLine(file)){
    Guard_Incr(m, &guard, 100);  // ERROR after 100 lines!
}

// Good: Reasonable maximum
i16 guard = 0;
while(ReadLine(file)){
    Guard_Incr(m, &guard, 100000);  // OK for large files
}
```

### Pitfall 3: Printing Uninitialized Objects

**Problem:** ToS() on uninitialized memory produces garbage or crashes.

```c
// Bad: Print before initialization
MyObject *obj = (MyObject *)MemCh_Alloc(m, sizeof(MyObject));
ToS(OutStream, obj, TYPE_MY_OBJECT, DEBUG);  // obj->type not set!

// Good: Initialize first
MyObject *obj = (MyObject *)MemCh_Alloc(m, sizeof(MyObject));
obj->type.of = TYPE_MY_OBJECT;
obj->type.state = ZERO;
// ... initialize other fields ...
ToS(OutStream, obj, TYPE_MY_OBJECT, DEBUG);  // Safe
```

### Pitfall 4: Fmt Argument Count Mismatch

**Problem:** More specifiers than arguments causes crash.

```c
// Bad: 3 specifiers, 2 arguments
void *args[] = {arg1, arg2, NULL};
Fmt(bf, "$ $ $", args);  // args[2] is NULL, should be third arg!

// Good: Matching counts
void *args[] = {arg1, arg2, arg3, NULL};
Fmt(bf, "$ $ $", args);
```

### Pitfall 5: Type Mismatch in ToS()

**Problem:** Passing wrong type ID causes incorrect printer to be called.

```c
Str *str = S(m, "hello");
ToS(OutStream, str, TYPE_BUFF, ZERO);  // Wrong! Uses Buff printer on Str

// Good: Correct type (or auto-detect with 0)
ToS(OutStream, str, TYPE_STR, ZERO);
ToS(OutStream, str, 0, ZERO);  // Auto-detect from str->type.of
```

### Pitfall 6: Not NULL-Terminating Fmt Args

**Problem:** Missing NULL terminator causes Fmt() to read garbage pointers.

```c
// Bad: No NULL terminator
void *args[] = {arg1, arg2, arg3};  // Missing NULL!
Fmt(bf, "$ $ $", args);  // Reads past args[2] - undefined behavior

// Good: NULL-terminated
void *args[] = {arg1, arg2, arg3, NULL};
Fmt(bf, "$ $ $", args);
```

---


## Related Documentation

- **[Error Handling Complete](error-handling-complete.md)** - Error system details
- **[Guard Mechanism Complete](guard-mechanism-complete.md)** - Loop protection
- **[Type System Complete](type-system-complete.md)** - Type infrastructure
- **[MemCh](memory/memchapter.md)** - Memory contexts
- **[Terminal I/O Complete](terminal-io-complete.md)** - ANSI colors, CLI output
- **[Testing Complete](../guides/testing.md)** - Test framework integration

---


## Summary

The Debug System provides a comprehensive framework for debugging C programs with several key components:

**Debug Stack:**
- Automatic call stack tracking with `__func__`, `__FILE__`, `__LINE__`
- Object reference tracking for context
- Stack trace printing on errors

**Universal ToString:**
- Type-aware object printing
- Extensible printer registry
- Multiple output levels (ZERO, MORE, DEBUG)

**Format System:**
- Custom format specifiers ($, @, &)
- ANSI color support
- Global output streams

**Memory Debugging:**
- Live allocation iteration
- Memory statistics and validation
- Leak detection patterns

**Guard System:**
- Infinite loop prevention
- Recursion depth limits
- Automatic error generation on exceeded

**Error Handling:**
- Structured error reporting
- Signal integration
- Pluggable error handlers

**Type Introspection:**
- Runtime type name lookup
- State flag formatting
- Extensible type registry

**Integration Points:**
- MemCh for automatic cleanup
- Type system for runtime dispatch
- Buff for stream-based output
- Signal handlers for crash reporting

This system transforms C debugging from "printf debugging" to a structured, type-aware, context-preserving approach that rivals high-level language debugging tools while maintaining zero runtime cost in release builds.



---

[← Part 1](debug-system-complete-part1) | **Part 2 of 2**
