---
sidebar_position: 3
---

# Task Execution Model - Complete Guide

The Navigate module's **Task/Step execution model** is Caneka's approach to asynchronous, chainable workflows. Understanding how tasks execute is critical for building reliable applications.

## Core Concept

A **Task** is a container for a **chain of Steps**. Each Step is a function that performs work and returns a status. The Task executes Steps in a **backward-iterating loop** until all Steps complete successfully.

### Why Backward Iteration?

Unlike traditional forward loops, Tasks iterate **backward** through the step chain after each step completes. This allows:
- Steps to be **removed as they complete**
- **Dynamic step insertion** during execution
- **Loop back** to previous steps for retry logic
- **Early termination** without breaking the chain

## Task Structure

```c
typedef struct task {
    Type type;                      // Type header with state flags
    i32 idx;                        // Task index (for tracking)
    i16 stepGuardMax;               // Max iterations before guard fails
    util u;                         // Custom state (criteria, etc.)
    MemCh *m;                       // Memory context
    Abstract *data;                 // Task-specific data (Queue, custom)
    Abstract *source;               // Source context (parent, etc.)
    Task *parent;                   // Parent task (for child chains)
    Iter chainIt;                   // Iterator over step chain
    struct {
        timespec start;             // Task start time
        timespec consumed;          // Time consumed so far
        timespec end;               // Task end time
    } metrics;
    timespec timeout;               // Timeout duration
} Task;
```

### Key Fields

- **chainIt**: Iterator pointing to the current Step in the chain
- **stepGuardMax**: Safety limit to prevent infinite loops (default: 16,000)
- **data**: Task-specific data (e.g., Queue for queue-managed tasks)
- **source**: Context from parent or initiator
- **parent**: Link to parent Task for nested executions

## Step Structure

```c
typedef struct step {
    Type type;                      // Type header with state flags
    StepFunc func;                  // Function pointer to execute
    Abstract *arg;                  // Function argument
    Abstract *source;               // Source context
    Abstract *data;                 // Step-specific data
} Step;
```

### Step Function Signature

```c
typedef status (*StepFunc)(Task *task, Step *step);
```

**Every step function**:
- Takes Task and Step pointers
- Returns a status code (SUCCESS, ERROR, MORE, etc.)
- Can modify the Task chain
- Can store state in step->data

## Task Execution Algorithm (Task_Tumble)

The `Task_Tumble` function is the **heart of the execution model**. Here's how it works:

### Pseudo-Code

```c
status Task_Tumble(Task *task) {
    i16 guard = 0;

    while (guard++ < task->stepGuardMax) {
        // 1. Check timeout if enabled
        if (TASK_CHECK_ELAPSED flag set) {
            if (timeout exceeded) {
                return ERROR | TIMEOUT;
            }
        }

        // 2. Iterate BACKWARD through chain
        while (Iter_HasPrev(&task->chainIt)) {
            Step *step = Iter_Prev(&task->chainIt);

            // 3. Skip if already SUCCESS or ERROR
            if (Type_HasFlag(&step->type, SUCCESS | ERROR)) {
                continue;
            }

            // 4. Execute step function
            status result = step->func(task, step);

            // 5. Handle result
            if (result & SUCCESS) {
                Type_SetFlag(&step->type, SUCCESS);
                Iter_Remove(&task->chainIt);  // Remove completed step
                break;  // Move to next backward iteration
            }

            if (result & STEP_LOOP) {
                // Loop back to this step (don't remove)
                break;
            }

            if (result & ERROR) {
                Type_SetFlag(&step->type, ERROR);
                return ERROR;
            }

            if (result & MORE) {
                // Continue processing this step later
                continue;
            }
        }

        // 6. Update criteria if queue-managed
        if (TASK_UPDATE_CRIT flag set) {
            Queue_UpdateCriteria(task->data);
        }

        // 7. Check if all steps complete
        if (chain is empty) {
            return SUCCESS | END;
        }
    }

    // Guard exceeded - infinite loop detected
    return ERROR | GUARD_EXCEEDED;
}
```

### Execution Flow Diagram

```
Start → [Step N, Step N-1, ..., Step 1, Step 0]
        ↓
    Iter at end of chain
        ↓
    ┌─→ Iterate BACKWARD (Iter_Prev)
    │       ↓
    │   Get Step N
    │       ↓
    │   Execute step->func()
    │       ↓
    │   ┌─ SUCCESS? → Remove step, break, continue backward loop
    │   ├─ ERROR? → Set ERROR flag, return ERROR
    │   ├─ STEP_LOOP? → Break, continue backward loop (keep step)
    │   └─ MORE? → Continue to next step in backward iteration
    │       ↓
    └──── Loop back
        ↓
    Chain empty? → SUCCESS | END
```

## Step States and Transitions

Steps progress through states based on execution results:

### States

```c
// Initial state (no flags)
step->type = 0;

// After successful execution
Type_SetFlag(&step->type, SUCCESS);

// After error
Type_SetFlag(&step->type, ERROR);

// Processing flag (optional)
Type_SetFlag(&step->type, PROCESSING);
```

### Status Codes

| Status | Meaning | Action |
|--------|---------|--------|
| **SUCCESS** | Step completed successfully | Remove from chain, continue backward |
| **ERROR** | Step failed | Stop execution, return error |
| **MORE** | Step needs more processing | Continue backward iteration, keep step |
| **STEP_LOOP** | Loop back to this step | Break, restart backward iteration |
| **NOOP** | No operation performed | Continue backward iteration |

## Practical Examples

### Example 1: Simple Task with 3 Steps

```c
// Step functions
status Step1_Init(Task *task, Step *step) {
    printf("Step 1: Initialize\n");
    return SUCCESS;  // Completes, will be removed
}

status Step2_Process(Task *task, Step *step) {
    static int count = 0;
    printf("Step 2: Processing (%d)\n", count++);

    if (count < 3) {
        return STEP_LOOP;  // Loop back, run again
    }

    return SUCCESS;  // Done, will be removed
}

status Step3_Finalize(Task *task, Step *step) {
    printf("Step 3: Finalize\n");
    return SUCCESS;  // Completes, will be removed
}

// Create and execute task
Task *task = Task_Make(m);
Task_AddStep(task, Step1_Init, NULL);
Task_AddStep(task, Step2_Process, NULL);
Task_AddStep(task, Step3_Finalize, NULL);

status result = Task_Execute(task);
// Output:
// Step 3: Finalize
// Step 2: Processing (0)
// Step 2: Processing (1)
// Step 2: Processing (2)
// Step 1: Initialize
```

**Key Observations:**
- Steps execute in **reverse order** (3, 2, 1)
- Step 2 loops 3 times before completing
- Each step is removed after SUCCESS

### Example 2: Dynamic Step Insertion

```c
status Step_MaybeAddMore(Task *task, Step *step) {
    if (SomeCondition()) {
        // Add a new step dynamically
        Task_AddStep(task, NewStepFunction, data);
    }
    return SUCCESS;
}
```

**Use Case**: Conditionally add error handling or retry steps during execution.

### Example 3: State Passing Between Steps

```c
typedef struct my_state {
    i32 value;
    Str *result;
} MyState;

status Step_Compute(Task *task, Step *step) {
    MyState *state = step->data;
    state->value = 42;  // Compute value
    return SUCCESS;
}

status Step_UseResult(Task *task, Step *step) {
    MyState *state = task->data;  // Shared task data
    printf("Value: %d\n", state->value);
    return SUCCESS;
}

// Setup
Task *task = Task_Make(m);
MyState *state = MemCh_AllocOf(m, sizeof(MyState), TYPE_STATE);
task->data = state;

Task_AddStep(task, Step_Compute, NULL);
step->data = state;  // Share state

Task_AddStep(task, Step_UseResult, NULL);
```

## Parent-Child Task Relationships

Tasks can have **child tasks** for nested operations.

### Creating Child Tasks

```c
Task *parent = Task_Make(m);
Task *child = Task_Make(m);
child->parent = parent;
child->source = parent->data;  // Inherit parent's data
```

### Use Cases

1. **Request-Response Pattern**: Parent waits for child to complete
2. **Parallel Execution**: Multiple children run concurrently
3. **Nested Workflows**: Complex multi-stage operations

### Example: HTTP Request with Subtasks

```c
status HandleRequest(Task *task, Step *step) {
    HttpRequest *req = task->data;

    // Create child task for database query
    Task *dbTask = Task_MakeChild(task);
    dbTask->source = req;
    Task_AddStep(dbTask, QueryDatabase, req->query);
    Task_AddStep(dbTask, FormatResults, NULL);

    // Child executes independently
    Task_Execute(dbTask);

    return SUCCESS;
}
```

## Guard Protection

The **guard** prevents infinite loops by counting iterations:

```c
task->stepGuardMax = 16000;  // Default limit

// If loop exceeds this, Task_Tumble returns:
ERROR | GUARD_EXCEEDED
```

### When Guard Triggers

- **Infinite STEP_LOOP**: Step always returns STEP_LOOP
- **Circular step insertion**: Steps keep adding themselves
- **Never-completing steps**: Steps never return SUCCESS

### Adjusting Guard

```c
// For long-running tasks
task->stepGuardMax = 100000;

// For safety-critical tasks
task->stepGuardMax = 1000;
```

## Source and Data Propagation

### Source vs Data

- **task->source**: Context from initiator (e.g., HTTP request, parent task)
- **task->data**: Task-specific working data (e.g., Queue, state machine)

### Propagation Pattern

```c
// Parent task
Task *parent = Task_Make(m);
parent->data = myData;

// Child task inherits source
Task *child = Task_MakeChild(parent);
child->source = parent->data;  // Parent's data becomes child's source
child->data = childSpecificData;
```

### Step-Level Source

```c
Step *step = Step_Make(m);
step->source = context;  // Step-specific context
step->data = stepData;   // Step-specific data
```

## Task Flags

Tasks use type flags to control behavior:

```c
TASK_CHILD              // This is a child task
TASK_UPDATE_CRIT        // Update queue criteria after each step
TASK_CHECK_ELAPSED      // Check timeout during execution
TASK_ASYNC              // Execute asynchronously (future)
```

**Setting Flags:**
```c
Type_SetFlag(&task->type, TASK_CHECK_ELAPSED);
task->timeout = (timespec){ .tv_sec = 5 };  // 5 second timeout
```

## Timeouts

Enable timeout checking:

```c
task->timeout.tv_sec = 10;  // 10 seconds
Type_SetFlag(&task->type, TASK_CHECK_ELAPSED);

status result = Task_Execute(task);
if (result & TIMEOUT) {
    // Task exceeded timeout
}
```

**Timeout Calculation:**
```c
elapsed = current_time - task->metrics.start;
if (elapsed > task->timeout) {
    return ERROR | TIMEOUT;
}
```

## Common Patterns

### Pattern 1: Retry with Backoff

```c
status StepWithRetry(Task *task, Step *step) {
    static int attempts = 0;

    status result = TryOperation();

    if (result & ERROR && attempts < MAX_RETRIES) {
        attempts++;
        sleep(attempts);  // Exponential backoff
        return STEP_LOOP;  // Retry
    }

    if (result & ERROR) {
        return ERROR;  // Max retries exceeded
    }

    return SUCCESS;
}
```

### Pattern 2: Conditional Branching

```c
status StepBranch(Task *task, Step *step) {
    if (Condition()) {
        Task_AddStep(task, PathA_Step1, NULL);
        Task_AddStep(task, PathA_Step2, NULL);
    } else {
        Task_AddStep(task, PathB_Step1, NULL);
    }
    return SUCCESS;
}
```

### Pattern 3: Pipeline Processing

```c
// Create pipeline: Input → Transform → Validate → Output
Task *pipeline = Task_Make(m);
Task_AddStep(pipeline, InputStep, source);
Task_AddStep(pipeline, TransformStep, NULL);
Task_AddStep(pipeline, ValidateStep, NULL);
Task_AddStep(pipeline, OutputStep, destination);

Task_Execute(pipeline);
```

## Best Practices

1. **Keep steps focused**: One step = one responsibility
2. **Use STEP_LOOP for retries**: Don't manually loop within a step
3. **Check step->data for state**: Avoid global variables
4. **Set reasonable guards**: Adjust stepGuardMax based on expected iterations
5. **Use SUCCESS for completion**: Always return SUCCESS when done
6. **Propagate errors**: Return ERROR on unrecoverable failures
7. **Clean up in final step**: Free resources before returning SUCCESS

## Common Pitfalls

### Pitfall 1: Returning Nothing

```c
// WRONG - No return statement
status BadStep(Task *task, Step *step) {
    DoWork();
    // Missing return!
}

// RIGHT
status GoodStep(Task *task, Step *step) {
    DoWork();
    return SUCCESS;
}
```

### Pitfall 2: Infinite STEP_LOOP

```c
// WRONG - Always loops
status InfiniteStep(Task *task, Step *step) {
    DoWork();
    return STEP_LOOP;  // Never completes!
}

// RIGHT - Loop with exit condition
status FiniteStep(Task *task, Step *step) {
    static int count = 0;
    DoWork();

    if (count++ < MAX) {
        return STEP_LOOP;
    }
    return SUCCESS;
}
```

### Pitfall 3: Modifying Chain During Iteration

```c
// DANGEROUS - Can corrupt iterator
status DangerousStep(Task *task, Step *step) {
    // Adding steps while iterating can cause issues
    Task_AddStep(task, SomeStep, NULL);  // Risky
    return SUCCESS;
}

// SAFER - Add to separate queue, merge later
status SaferStep(Task *task, Step *step) {
    // Queue new steps for later addition
    QueueStep(task, SomeStep, NULL);
    return SUCCESS;
}
```

## See Also

- [Navigate Overview](overview.md) - System architecture
- [Queue System](queue-complete.md) - Queue-managed task execution
- [Task System](task-system.md) - Basic concepts
- [Iterator](../memory/iter-complete.md) - Understanding chain iteration
