# Mess (Message Tree) System - Complete Guide - Part 1

**Part 1 of 3** | [Part 2 →](mess-complete-part2)

---

## Core Philosophy

The **Mess (Message Tree)** system is Caneka's unified hierarchical data structure for representing parsed and structured content. Think of it as Caneka's DOM—a tree representation that bridges the gap between raw parser output and final formatted content.

### The Bridge Between Parsing and Meaning

In traditional parsing systems, you often find:
- **Syntax Trees**: Reflect the grammar structure (AST)
- **Semantic Trees**: Reflect the meaning and presentation
- **Complex Transformations**: Code to convert between these representations

Caneka's Mess system solves this by providing a **semantic tree built directly during parsing**. The Roebling parser doesn't generate an AST that must be transformed—it builds the Mess tree directly through a capture callback mechanism. This eliminates an entire transformation phase.

### Key Design Principles

1. **Polymorphic Children**: A node can contain a single value, a span of values, a relation (table), or another node. The system automatically promotes from simple to complex as content is added.

2. **Lazy Allocation**: Tables for attributes and spans for multiple children are only created when actually needed, keeping simple trees lightweight.

3. **Parser Independence**: The Roebling parser knows nothing about Mess semantics. All meaning comes from Tokenize definitions in a lookup table, enabling the same parser to build different tree types.

4. **Incremental Building**: A cursor (`current` pointer) maintains O(1) insertion point, enabling single-pass tree construction without backtracking.

5. **Type-Driven Behavior**: Token flags encode tree operations (outdent, inline, combine) as data rather than code, making the system highly extensible.

### Why "Mess"?

The name reflects the system's role: it accepts messy, unstructured parser output and organizes it into a clean tree. It's a "message tree" that conveys semantic structure from the parser to downstream consumers (formatters, template renderers, etc.).

---


## Structure and Definitions

### The Mess Structure

The Mess structure is defined in [src/ext/include/navigate/mess.h](../../../src/ext/include/navigate/mess.h):

```c
typedef struct mess {
    Type type;                  // TYPE_MESS identifier
    MemCh *m;                   // Memory context for all allocations
    Node *root;                 // Root node of the tree
    Node *current;              // Current insertion point (cursor)
    Table *nextAtts;            // Pending attributes for next node
    void *currentValue;         // Reference to current child value
    Lookup *tokenizer;          // Token definitions (captureKey → Tokenize)
    void *source;               // Reference to source material (optional)
    struct transp_ctx *transp;  // Transport context (optional)
} Mess;
```

**Key Fields**:

- **`root`**: The top-level node. Always exists, even in an empty Mess.
- **`current`**: Cursor pointing to where new content should be added. Moves through the tree as it's built.
- **`nextAtts`**: Accumulator for attributes. When content is added, these become the node's attributes.
- **`currentValue`**: Cached reference to the current node's child for quick access.
- **`tokenizer`**: Maps semantic keys (like `FORMATTER_PARAGRAPH`) to Tokenize definitions that control tree building.

### The Node Structure

Individual tree nodes are defined in [src/ext/include/navigate/node.h](../../../src/ext/include/navigate/node.h):

```c
typedef struct node {
    Type type;              // TYPE_NODE identifier
    Tokenize tk;            // Token definition for this node
    i16 typeOfChild;        // Type discriminator (TYPE_STRVEC, TYPE_NODE, TYPE_SPAN, etc.)
    i16 captureKey;         // Semantic identifier (FORMATTER_PARAGRAPH, etc.)
    i16 latestKey;          // Most recent capture key processed
    i16 _;                  // Padding for alignment
    struct node *parent;    // Parent node (enables outdenting)
    Table *atts;            // Attributes (key-value pairs, lazily allocated)
    Abstract *value;        // Single value (rarely used in Mess context)
    Abstract *child;        // Child content (type determined by typeOfChild)
} Node;
```

**Key Fields**:

- **`typeOfChild`**: Discriminator that determines how to interpret the `child` pointer. Can be:
  - `TYPE_STRVEC`: String vector (most common for text content)
  - `TYPE_NODE`: Single child node
  - `TYPE_SPAN`: Multiple children of mixed types
  - `TYPE_RELATION`: Tabular data
  - `ZERO`: No child yet

- **`captureKey`**: Semantic meaning of this node (e.g., `FORMATTER_PARAGRAPH`, `FORMATTER_INDENT`). Used for rendering and traversal.

- **`parent`**: Pointer to parent node, enabling upward traversal (`Mess_Outdent`).

- **`atts`**: Lazily allocated attribute table. Created only when first attribute is added.

### The Tokenize Structure

Tokenize definitions control how parsed content becomes tree nodes. Defined in [src/ext/include/parser/tokenize.h](../../../src/ext/include/parser/tokenize.h):

```c
enum token_flags {
    TOKEN_SEPERATE = 1 << 8,      // Add separator when combining content
    TOKEN_OUTDENT = 1 << 9,        // Exit current nesting level after adding
    TOKEN_INLINE = 1 << 10,        // Content doesn't create new nesting level
    TOKEN_BY_TYPE = 1 << 11,       // Group content by type instead of combining
    TOKEN_ATTR_KEY = 1 << 12,      // This content is an attribute key
    TOKEN_ATTR_VALUE = 1 << 13,    // This content is an attribute value
    TOKEN_NO_COMBINE = 1 << 14,    // Don't combine with previous content
    TOKEN_NO_CONTENT = 1 << 15,    // Node has no content itself
};

typedef struct tokenize {
    Type type;          // TYPE_TOKENIZE identifier
    i16 captureKey;     // Semantic identifier
    cls typeOf;         // Expected child type (TYPE_STRVEC, TYPE_NODE, etc.)
} Tokenize;
```

**Flag Meanings**:

- **`TOKEN_OUTDENT`**: After processing this token, move `current` back to parent. Used for closing sections.
- **`TOKEN_INLINE`**: Don't nest under current; add at current level then exit. Used for inline elements like links.
- **`TOKEN_BY_TYPE`**: Create new node if type differs from existing child. Prevents mixing incompatible content.
- **`TOKEN_ATTR_VALUE`**: Content becomes an attribute value, not a child.
- **`TOKEN_NO_COMBINE`**: Force new node even if previous could accept this content.
- **`TOKEN_NO_CONTENT`**: This token triggers structural changes but adds no content itself.

### The Relation Structure

Relations represent tabular data within the Mess tree. Defined in [src/ext/include/navigate/relation.h](../../../src/ext/include/navigate/relation.h):

```c
typedef struct relation {
    Type type;          // TYPE_RELATION identifier
    i16 _;              // Padding
    i16 stride;         // Number of columns
    void **headers;     // Column header names (array of StrVec)
    Iter it;            // Iterator for row traversal
} Relation;
```

Relations enable table representation directly in the tree:
```
Node (FORMATTER_TABLE)
 └── child: Relation (stride=3)
     ├── headers: ["Name", "Age", "City"]
     ├── row 0: ["Alice", "30", "NYC"]
     ├── row 1: ["Bob", "25", "LA"]
     └── row 2: ["Carol", "35", "SF"]
```

### The MessClimber Structure

MessClimber is a traversal helper for walking the Mess tree. Defined in [src/ext/include/navigate/mess.h](../../../src/ext/include/navigate/mess.h):

```c
typedef struct mess_climber {
    Type type;          // TYPE_MESS_CLIMBER identifier
    i32 nested;         // Current nesting depth
    Mess *mess;         // Reference to Mess being traversed
    void *current;      // Current node during traversal
    void *currentChild; // Current child reference
    Table *nextAtts;    // Pending attributes (unused in traversal)
} MessClimber;
```

Used primarily for rendering and debugging, MessClimber maintains traversal state while walking the tree to generate HTML or debug output.

---


## Implementation Details

### Tree Construction: Mess_Make

Creating a new Mess is straightforward ([src/ext/navigate/mess.c](../../../src/ext/navigate/mess.c)):

```c
Mess *Mess_Make(MemCh *m){
    Mess *mess = (Mess *)MemCh_AllocOf(m, sizeof(Mess), TYPE_MESS);
    mess->type.of = TYPE_MESS;
    mess->m = m;

    // Create root node
    Node *root = Node_Make(m, 0, NULL);
    mess->root = root;
    mess->current = root;  // Start at root

    return mess;
}
```

**Initial State**:
- Both `root` and `current` point to an empty node
- No tokenizer set (must be configured)
- No pending attributes
- Ready to accept content

### Core Algorithm: Mess_Tokenize

The `Mess_Tokenize` function is the heart of tree building. It processes captured content from the parser and integrates it into the tree:

```c
status Mess_Tokenize(Mess *mess, Tokenize *tk, StrVec *v){
    DebugStack_Push(NULL, TYPE_MESS);

    // Handle TOKEN_OUTDENT: exit nesting levels
    if(tk->type.state & TOKEN_OUTDENT){
        if(mess->current->parent != NULL){
            Mess_Outdent(mess);
        }
    }

    // Create new node with this token definition
    Node *node = Node_Make(mess->m, 0, mess->current);
    memcpy(&node->tk, tk, sizeof(Tokenize));
    node->captureKey = tk->captureKey;

    // Special handling for attribute values
    if(tk->type.state & TOKEN_ATTR_VALUE){
        // Content becomes attribute, not child
        if(mess->nextAtts == NULL){
            mess->nextAtts = Table_Make(mess->m);
        }
        Table_Set(mess->nextAtts, I16_Wrapped(mess->m, tk->captureKey), v);

        DebugStack_Pop();
        return SUCCESS;
    }

    // Get or set child position in tree
    Mess_GetOrSet(mess, mess->current, node, tk);

    // Add pending attributes to node
    if(mess->nextAtts != NULL){
        node->atts = mess->nextAtts;
        mess->nextAtts = NULL;
    }

    // Add content to node if present
    if((tk->type.state & TOKEN_NO_CONTENT) == 0){
        Mess_Append(mess, node, v);
    }

    // Handle TOKEN_INLINE: exit nesting immediately
    if(tk->type.state & TOKEN_INLINE){
        if(mess->current == node){
            Mess_Outdent(mess);
        }
    }

    DebugStack_Pop();
    return SUCCESS;
}
```

**Algorithm Steps**:

1. **Pre-Outdent**: If `TOKEN_OUTDENT` is set, exit current level first
2. **Create Node**: New node with token definition
3. **Handle Attributes**: If `TOKEN_ATTR_VALUE`, store in pending attributes and return
4. **Position in Tree**: `Mess_GetOrSet` determines where this node goes
5. **Attach Attributes**: Move pending attributes to node's attribute table
6. **Add Content**: Unless `TOKEN_NO_CONTENT`, append the string vector
7. **Post-Inline**: If `TOKEN_INLINE`, immediately exit nesting

### Content Placement: Mess_GetOrSet

This is the most complex function, handling all scenarios of where content goes:

```c
Node *Mess_GetOrSet(Mess *mess, Node *node, void *a, Tokenize *tk){
    DebugStack_Push(NULL, TYPE_MESS_GET_OR_SET);

    Abstract *abs = (Abstract *)a;
    Node *r = NULL;

    // Case 1: Node has no child yet → simple assignment
    if(node->typeOfChild == ZERO){
        node->child = a;
        node->typeOfChild = abs->type.of;
        mess->current = (Node *)a;
        mess->currentValue = node->child;
        r = (Node *)a;
    }
    // Case 2: Attribute value → becomes attribute, not child
    else if(tk != NULL && (tk->type.state & TOKEN_ATTR_VALUE)){
        Mess_AddAtt(mess, node, I16_Wrapped(mess->m, tk->captureKey), a);
        r = node;
    }
    // Case 3: Single child exists, need to add another
    else if(node->typeOfChild != TYPE_SPAN && node->typeOfChild != TYPE_RELATION){
        void *existingChild = node->child;

        // Try combining if types are compatible
        if((tk == NULL || (tk->type.state & TOKEN_NO_COMBINE) == 0) &&
           CanCombine(existingChild, a)){
            Combine(existingChild, a);
            r = node;
        }
        // Create new node if TOKEN_BY_TYPE and types differ
        else if(tk != NULL && (tk->type.state & TOKEN_BY_TYPE) &&
                ((Abstract *)existingChild)->type.of != abs->type.of){
            // Convert single child to Span
            Span *sp = Span_Make(mess->m);
            Span_Add(sp, existingChild);
            Span_Add(sp, a);
            node->child = sp;
            node->typeOfChild = TYPE_SPAN;
            mess->current = (Node *)a;
            mess->currentValue = sp;
            r = (Node *)a;
        }
        // Otherwise convert to Span with both children
        else {
            Span *sp = Span_Make(mess->m);
            Span_Add(sp, existingChild);
            Span_Add(sp, a);
            node->child = sp;
            node->typeOfChild = TYPE_SPAN;
            mess->current = (Node *)a;
            mess->currentValue = sp;
            r = (Node *)a;
        }
    }
    // Case 4: Span child → add to span
    else if(node->typeOfChild == TYPE_SPAN){
        Span *sp = (Span *)node->child;
        Span_Add(sp, a);
        mess->current = (Node *)a;
        mess->currentValue = sp;
        r = (Node *)a;
    }
    // Case 5: Relation child → add to relation
    else if(node->typeOfChild == TYPE_RELATION){
        Relation *rel = (Relation *)node->child;
        Relation_Add(rel, a);
        mess->current = node;
        mess->currentValue = rel;
        r = node;
    }

    DebugStack_Pop();
    return r;
}
```

**Key Scenarios**:

1. **Empty Node** (`typeOfChild == ZERO`): First child, simple assignment
2. **Single Child Exists**:
   - If combinable (Str+Str, StrVec+StrVec): Combine in place
   - If `TOKEN_BY_TYPE` and different type: Create Span
   - Otherwise: Create Span with both children
3. **Span Child**: Add to existing span
4. **Relation Child**: Add to existing relation

This automatic promotion from single child → Span → Relation enables flexible tree growth without manual restructuring.

### Adding Attributes: Mess_AddAtt

Attributes are key-value metadata attached to nodes:

```c
status Mess_AddAtt(Mess *mess, Node *node, void *key, void *value){
    if(node->atts == NULL){
        node->atts = Table_Make(mess->m);
    }
    Table_Set(node->atts, key, value);
    return SUCCESS;
}
```

**Lazy Allocation**: The attribute table is only created when the first attribute is added, keeping nodes lightweight when attributes aren't needed.

**Common Uses**:
- CSS class names: `atts[FORMATTER_CLASS] = "highlight"`
- Heading levels: `atts[FORMATTER_INDENT] = "="`
- Link URLs: `atts[FORMATTER_URL] = "http://example.com"`
- Tag labels: `atts[FORMATTER_LABEL] = "Click here"`

### Tree Navigation: Mess_Outdent

Moving up the tree is simple due to parent pointers:

```c
status Mess_Outdent(Mess *mess){
    if(mess->current->parent != NULL){
        mess->current = mess->current->parent;
        mess->currentValue = mess->current->child;
    }
    return SUCCESS;
}
```

**When Used**:
- After completing a section (heading followed by content)
- After inline elements (links that don't nest)
- At the end of list items before next item
- When `TOKEN_OUTDENT` flag is set

### Tree Comparison: Mess_Compare

The comparison function enables testing by verifying expected tree structure:

```c
status Mess_Compare(MemCh *m, Mess *a, Mess *b){
    Comp *comp = Comp_Make(m);
    comp->a = a->root;
    comp->b = b->root;

    // Recursively compare all nodes
    status result = Comp_Run(comp);

    return result;
}
```

The Comparator ([src/ext/include/navigate/compare.h](../../../src/ext/include/navigate/compare.h)) walks both trees in parallel, checking:
- Node types match
- Capture keys match
- Attributes match
- Children match (recursively)
- String content matches

This is extensively used in [src/programs/test/option/ext/mess_tests.c](../../../src/programs/test/option/ext/mess_tests.c) to validate parser output.

---


## Integration with Roebling Parser

### The Parser-Mess Pipeline

The Roebling parser is a state machine that matches patterns and captures content. It integrates with Mess through a callback mechanism.

**Example from Format (Fmt) Parser** ([src/ext/format/fmt/fmt_roebling.c](../../../src/ext/format/fmt/fmt_roebling.c)):

```c
Roebling *FormatFmt_Make(MemCh *m, Cursor *curs, void *source){
    // 1. Create Roebling parser with Capture callback
    Roebling *rbl = Roebling_Make(m, curs, Capture, NULL);
    rbl->type.state |= (ROEBLING_TO_BOUND|ROEBLING_STOP_ADVANCE);

    // 2. Configure state machine
    Roebling_AddStep(rbl, I16_Wrapped(m, FORMATTER_START));
    Roebling_AddStep(rbl, Do_Wrapped(m, (DoFunc)start));
    Roebling_AddStep(rbl, I16_Wrapped(m, FORMATTER_PARAGRAPH));
    Roebling_AddStep(rbl, Do_Wrapped(m, (DoFunc)paragraph));
    // ... more states

    // 3. Create Mess as destination
    Mess *mess = Mess_Make(m);
    mess->tokenizer = FormatFmt_Defs;  // Load tokenizer lookup
    mess->source = source;
    rbl->dest = (Abstract *)mess;

    return rbl;
}
```

**Pipeline Flow**:
1. Input → Roebling state machine
2. Pattern matches → Capture callback invoked
3. Capture callback → `Mess_Tokenize` builds tree
4. Final tree available in `rbl->dest`

### The Capture Callback

When Roebling matches a pattern, it invokes the Capture callback with the captured content:

```c
static status Capture(Roebling *rbl, word captureKey, StrVec *v){
    Mess *mess = (Mess *)as(rbl->dest, TYPE_MESS);

    // Look up token definition for this capture key
    Tokenize *tk = Lookup_Get(mess->tokenizer, captureKey);

    if(tk != NULL){
        // Special case: promote LINE to PARAGRAPH at root level
        if(mess->current->parent == NULL &&
           tk->captureKey == FORMATTER_LINE){
            tk = Lookup_Get(mess->tokenizer, FORMATTER_PARAGRAPH);
        }

        // Build tree with captured content
        Mess_Tokenize(mess, tk, v);
    }

    return SUCCESS;
}
```

**Key Points**:

- **Lookup**: `captureKey` (like `FORMATTER_PARAGRAPH`) looks up the Tokenize definition
- **Decoupling**: Parser doesn't know tree semantics; tokenizer provides the mapping
- **Flexibility**: Same parser can build different trees by swapping tokenizer tables

### Token Definitions

Token definitions are created during initialization ([src/ext/format/fmt/fmt_tokenize.c](../../../src/ext/format/fmt/fmt_tokenize.c)):

```c
status FormatFmt_DefSpan(MemCh *m, Lookup *lk){
    // FORMATTER_NEXT: Exit nesting, no content
    Lookup_Set(lk, FORMATTER_NEXT,
        Tokenize_Make(m, FORMATTER_NEXT,
            TOKEN_OUTDENT|TOKEN_NO_CONTENT, ZERO));

    // FORMATTER_INDENT: Heading with level indicator
    Lookup_Set(lk, FORMATTER_INDENT,
        Tokenize_Make(m, FORMATTER_INDENT,
            TOKEN_ATTR_VALUE|TOKEN_OUTDENT, TYPE_NODE));

    // FORMATTER_PARAGRAPH: Text content, type-grouped
    Lookup_Set(lk, FORMATTER_PARAGRAPH,
        Tokenize_Make(m, FORMATTER_PARAGRAPH,
            TOKEN_BY_TYPE, TYPE_STRVEC));

    // FORMATTER_BULLET: List item
    Lookup_Set(lk, FORMATTER_BULLET,
        Tokenize_Make(m, FORMATTER_BULLET,
            TOKEN_NO_CONTENT|TOKEN_BY_TYPE|TOKEN_NO_COMBINE, TYPE_STRVEC));

    // FORMATTER_TABLE: Tabular data
    Lookup_Set(lk, FORMATTER_TABLE,
        Tokenize_Make(m, FORMATTER_TABLE,
            TOKEN_NO_COMBINE, TYPE_RELATION));

    // FORMATTER_TAG: Inline element (link, image)
    Lookup_Set(lk, FORMATTER_TAG,
        Tokenize_Make(m, FORMATTER_TAG,
            TOKEN_ATTR_VALUE|TOKEN_INLINE|TOKEN_BY_TYPE, TYPE_NODE));

    // FORMATTER_LABEL: Label for tags
    Lookup_Set(lk, FORMATTER_LABEL,
        Tokenize_Make(m, FORMATTER_LABEL,
            TOKEN_ATTR_VALUE, TYPE_STRVEC));

    // FORMATTER_URL: URL for links/images
    Lookup_Set(lk, FORMATTER_URL,
        Tokenize_Make(m, FORMATTER_URL,
            TOKEN_ATTR_VALUE, TYPE_STRVEC));

    // FORMATTER_CLASS: CSS class attribute
    Lookup_Set(lk, FORMATTER_CLASS,
        Tokenize_Make(m, FORMATTER_CLASS,
            TOKEN_ATTR_VALUE, TYPE_STRVEC));

    return SUCCESS;
}
```

**Pattern**:
- Each semantic type gets a Tokenize definition
- Flags encode structural behavior
- Child type specifies what content to expect

### Semantic Keys

Semantic keys are defined in [src/ext/include/types/range.h](../../../src/ext/include/types/range.h):

```c
enum formatter_range {
    FORMATTER_START = 420,
    FORMATTER_INDENT,        // Section headings (=, ==, ===)
    FORMATTER_LINE,          // Single text line
    FORMATTER_PARAGRAPH,     // Grouped lines
    FORMATTER_BULLET,        // List item
    FORMATTER_TABLE,         // Tabular data
    FORMATTER_TAG,           // Inline tag (link, image)
    FORMATTER_LABEL,         // Tag label text
    FORMATTER_URL,           // Tag URL/source
    FORMATTER_CLASS,         // CSS class name
    FORMATTER_KEY,           // Config key
    FORMATTER_NEXT,          // Transition marker
    FORMATTER_END,           // Parse end
};
```

These constants are used throughout the system to identify node types.

---



---

**Part 1 of 3** | [Part 2 →](mess-complete-part2)
