# Relation (Tabular Data) System - Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](relation-complete-part2)

---

## Core Philosophy

The **Relation** system is Caneka's tabular data structure that represents 2D grids of values organized into rows and columns. It's a lightweight abstraction over a flat Span that interprets sequential data as a table through a **stride** parameter.

### The Power of Flat + Stride

Traditional table implementations often use arrays of arrays (2D arrays) or linked lists of rows. This creates indirection, poor cache locality, and complexity. Caneka's Relation takes a different approach:

**Physical Storage**: All values in a single flat Span (1D array)
**Logical Structure**: The stride value determines column count, dividing the flat array into rows
**Result**: O(1) indexing, excellent cache locality, minimal overhead

This is the same philosophy that drives modern GPU memory layouts and high-performance linear algebra libraries—row-major or column-major flat storage with stride calculation.

### Key Design Principles

1. **Zero Indirection**: Single Span, not array of arrays. One memory allocation, one iterator, no pointer chasing.

2. **Adaptive Sizing**: Stride auto-detected from header count. Tables grow naturally without predeclaring dimensions.

3. **Boundary Detection**: Row start/end flags set automatically during iteration, enabling proper formatting without manual calculation.

4. **Integrated Headers**: Column headers stored separately as metadata, not intermingled with data rows.

5. **Mess Integration**: Relations serve as Node children in the Mess tree, enabling tables within hierarchical documents.

### Why "Relation"?

The name comes from relational algebra—a set of tuples (rows) with named attributes (columns). Caneka Relations support:
- Fixed schema (stride determines column count)
- Named columns (headers array)
- Sequential iteration (like cursors in SQL)
- Integration with document formatting

---


## Structure and Definitions

### The Relation Structure

Defined in [src/ext/include/navigate/relation.h](../../../../src/ext/include/navigate/relation.h):

```c
enum relation_flags {
    RELATION_ROW_START = 1 << 8,   // Column index == 0
    RELATION_ROW_END = 1 << 9,     // Column index == stride-1
};

typedef struct relation {
    Type type;              // TYPE_RELATION identifier
    i16 _;                  // Padding/reserved
    i16 stride;             // Number of columns (table width)
    void **headers;         // Array of column header pointers
    Iter it;                // Iterator into underlying Span
} Relation;
```

**Key Fields**:

- **`stride`**: Column count. Determines how the flat Span is interpreted as 2D. Initially 0 until `Relation_HeadFromValues()` is called.

- **`headers`**: C array of void pointers to column headers. Created by `Span_ToArr()` from header values. This is metadata, not data.

- **`it`**: Iterator pointing into the underlying Span. The Span stores all values sequentially: `[header0, header1, ..., row0_col0, row0_col1, ..., row1_col0, ...]`

- **Flags**: `RELATION_ROW_START` and `RELATION_ROW_END` are set on `type.state` during iteration to indicate row boundaries.

### How Stride Works

The stride system converts a flat 1D array into a 2D table:

**Flat Storage**:
```
Index:  0  1  2  3  4  5  6  7  8
Value: [A, B, C, D, E, F, G, H, I]
```

**With Stride = 3**:
```
Row 0: [A, B, C]  (indices 0-2)
Row 1: [D, E, F]  (indices 3-5)
Row 2: [G, H, I]  (indices 6-8)
```

**Index Calculation**:
```c
flat_index = row * stride + col
col = flat_index % stride
row = flat_index / stride
```

**During Iteration**:
```c
// When iterator at index 0, 3, 6, 9, ...
if(it->idx % stride == 0) {
    type.state |= RELATION_ROW_START;
}

// When iterator at index 2, 5, 8, 11, ...
if((it->idx + 1) % stride == 0) {
    type.state |= RELATION_ROW_END;
}
```

This enables detecting row boundaries without separate bookkeeping.

### Row Boundary Flags

The flags encode important information during iteration:

| Condition | Flag Set | Meaning |
|---|---|---|
| `col == 0` | `RELATION_ROW_START` | Beginning of a row |
| `col == stride-1` | `RELATION_ROW_END` | End of a row |
| `0 < col < stride-1` | Neither | Middle of a row |

**Use Cases**:
- HTML generation: `<tr>` at ROW_START, `</tr>` at ROW_END
- CSV formatting: No comma before ROW_START, newline after ROW_END
- Debug printing: Indent at ROW_START, newline at ROW_END

---


## Implementation Details

### Creation: Relation_Make

Creating a new Relation ([src/ext/navigate/relation.c](../../../../src/ext/navigate/relation.c)):

```c
Relation *Relation_Make(MemCh *m, i16 stride, void **headers){
    Relation *rel = (Relation *)MemCh_AllocOf(m, sizeof(Relation), TYPE_RELATION);
    rel->type.of = TYPE_RELATION;
    rel->stride = stride;
    rel->headers = headers;

    // Create underlying Span
    Span *sp = Span_Make(m);

    // Initialize iterator in SET mode (append)
    Iter_Setup(&rel->it, sp, SPAN_OP_SET, ZERO);

    return rel;
}
```

**Parameters**:
- `stride`: Initial stride. Typically 0 for auto-detection from headers.
- `headers`: Initial headers array. Typically NULL (extracted later).

**Initial State**:
- Empty Span ready to receive values
- Iterator in SPAN_OP_SET mode (append mode)
- Stride and headers as specified (usually both 0/NULL)

### Header Extraction: Relation_HeadFromValues

After adding header values, extract them as metadata:

```c
status Relation_HeadFromValues(Relation *rel){
    // Extract stride from current Span size
    rel->stride = (i16)rel->it.p->max_idx + 1;

    // Convert header values to C array
    rel->headers = Span_ToArr(rel->it.p);

    // Wipe the Span clean (reset for data)
    Span_Wipe(rel->it.p);

    // Reset iterator to SET mode at position 0
    Iter_Setup(&rel->it, rel->it.p, SPAN_OP_SET, ZERO);

    return SUCCESS;
}
```

**Algorithm**:
1. Calculate stride from number of values added so far
2. Extract those values as a C array (headers)
3. Clear the Span completely
4. Reset iterator to beginning in append mode
5. Now ready to receive data rows

**Why Separate Step**: Enables flexible construction—headers can be added dynamically like regular values, then separated once complete.

### Adding Values: Relation_AddValue

Append a value sequentially:

```c
status Relation_AddValue(Relation *rel, void *value){
    return Iter_Add(&rel->it, value);
}
```

Simply wraps the iterator's add operation. Values are appended in row-major order.

**Usage**:
```c
// Add row 0
Relation_AddValue(rel, val_0_0);
Relation_AddValue(rel, val_0_1);
Relation_AddValue(rel, val_0_2);

// Add row 1
Relation_AddValue(rel, val_1_0);
Relation_AddValue(rel, val_1_1);
Relation_AddValue(rel, val_1_2);
```

### Random Access: Relation_SetValue

Set a value at a specific row/column position:

```c
status Relation_SetValue(Relation *rel, i16 row, i16 col, void *value){
    i32 idx = row * rel->stride + col;
    return Iter_SetByIdx(&rel->it, idx, value);
}
```

**Index Calculation**: `row * stride + col` converts 2D coordinates to flat index.

**Usage**:
```c
// Set cell at row 2, column 1
Relation_SetValue(rel, 2, 1, someValue);
```

**Requirements**:
- Stride must be set (non-zero)
- Span must be large enough to hold the calculated index
- If index exceeds current size, Span will grow automatically

### Row Counting: Relation_RowCount

Calculate number of complete rows:

```c
status Relation_RowCount(Relation *rel){
    if(rel->stride == 0) return 0;

    i32 total_values = rel->it.p->max_idx + 1;
    return total_values / rel->stride;
}
```

**Returns**: Integer division of total values by stride.

**Incomplete Rows**: If total values is not evenly divisible by stride, the incomplete final row is not counted. For example:
- 10 values, stride 3 → 3 rows (row 4 incomplete with only 1 value)
- 12 values, stride 3 → 4 rows (perfect alignment)

### Iteration: Relation_Start and Relation_Next

#### Relation_Start

Reset iterator to beginning:

```c
status Relation_Start(Relation *rel){
    Iter_Setup(&rel->it, rel->it.p, SPAN_OP_SET, ZERO);
    return rel->type.state;
}
```

Sets iterator to position 0 in SET mode. Called before iteration begins.

#### Relation_Next

Advance to next value:

```c
status Relation_Next(Relation *rel){
    status r = Iter_Next(&rel->it);

    // Clear previous row flags
    rel->type.state &= ~(RELATION_ROW_START|RELATION_ROW_END);

    // Set row boundary flags
    i32 col = rel->it.idx % rel->stride;
    if(col == 0){
        rel->type.state |= RELATION_ROW_START;
    }
    if(col == rel->stride - 1){
        rel->type.state |= RELATION_ROW_END;
    }

    return r;
}
```

**Returns**: Iterator status (END when exhausted, otherwise READY)

**Side Effects**: Sets `RELATION_ROW_START` and/or `RELATION_ROW_END` on `type.state` based on current column.

#### Relation_ResetIter

Reset iterator for re-iteration:

```c
status Relation_ResetIter(Relation *rel){
    Iter_Setup(&rel->it, rel->it.p, SPAN_OP_GET, ZERO);
    return rel->type.state;
}
```

Resets to beginning in GET mode. Used when you need to iterate multiple times.

---


## Integration with Mess System

Relations integrate into the Mess (Message Tree) system as a child type for Nodes. This enables hierarchical documents to contain tabular data.

### Node Structure with Relation Child

From [src/ext/include/navigate/node.h](../../../../src/ext/include/navigate/node.h):

```c
typedef struct node {
    Type type;
    Tokenize tk;
    i16 typeOfChild;        // Can be TYPE_RELATION
    i16 captureKey;
    i16 latestKey;
    i16 _;
    struct node *parent;
    Table *atts;
    Abstract *value;
    Abstract *child;        // Can point to Relation
} Node;
```

When `typeOfChild == TYPE_RELATION`, the `child` pointer points to a Relation structure.

### Creating Relations in Mess

From [src/ext/navigate/mess.c](../../../../src/ext/navigate/mess.c):

```c
// When tokenizer specifies TYPE_RELATION
if(tk->typeOf == TYPE_RELATION){
    nd->typeOfChild = TYPE_RELATION;
    nd->child = (Abstract *)Relation_Make(mess->m, 0, NULL);
}
```

**Flow**:
1. Tokenize definition specifies `TYPE_RELATION`
2. New Node created with `typeOfChild = TYPE_RELATION`
3. Empty Relation allocated as child
4. Ready to receive values

### Adding Values to Relations in Mess

```c
else if(node->typeOfChild == TYPE_RELATION){
    Relation *rel = (Relation *)node->child;
    Relation_AddValue(rel, a);

    // Extract headers when LAST token encountered
    if(tk->type.state & LAST){
        if(rel->stride == 0){
            Relation_HeadFromValues(rel);
        }
    }
}
```

**Pattern**:
1. Parser captures table rows
2. Each cell added via `Relation_AddValue`
3. When LAST token received (end of header row), extract headers
4. Subsequent values become data rows

### Comparing Relations in Mess

From [src/ext/navigate/compare.c](../../../../src/ext/navigate/compare.c):

```c
if(nb->child->type.of == TYPE_RELATION){
    Relation *ra = (Relation *)na->child;
    Relation *rb = (Relation *)nb->child;

    // Reset iterators to beginning
    Iter_Setup(&ra->it, ra->it.p, SPAN_OP_GET, 0);
    Iter_Setup(&rb->it, rb->it.p, SPAN_OP_GET, 0);

    // Push iterators onto comparison stack
    Compare_Push(comp, &ra->it, &rb->it);
}
```

Relations are compared by comparing their underlying Span iterators element-by-element. Stride and headers are compared structurally before data.

---


## Formatter Integration

### HTML Table Generation

The Fmt formatter converts Relations to HTML tables ([src/ext/format/fmt/fmt_html.c](../../../../src/ext/format/fmt/fmt_html.c)):

```c
static i64 tableFunc(TranspCtx *ctx, word flags){
    i64 total = 0;
    Abstract *a = Iter_Get(&ctx->it);
    Relation *rel = (Relation *)as(a, TYPE_RELATION);

    // Reset relation iterator
    Relation_ResetIter(rel);

    // Open table
    total += Tag_Out(ctx->bf, table, ZERO);
    total += Tag_Out(ctx->bf, thead, ZERO);
    total += Tag_Out(ctx->bf, tr, ZERO);

    // Output headers
    void **hdr = rel->headers;
    for(i32 i = 0; i < rel->stride; i++, hdr++){
        total += Tag_Out(ctx->bf, td, ZERO);
        total += ToS(ctx->bf, *hdr, 0, ZERO);
        total += Tag_Out(ctx->bf, td, TAG_CLOSE);
    }

    total += Tag_Out(ctx->bf, tr, TAG_CLOSE);
    total += Tag_Out(ctx->bf, thead, TAG_CLOSE);
    total += Tag_Out(ctx->bf, tbody, ZERO);

    // Iterate through data rows
    while((Relation_Next(rel) & END) == 0){
        if(rel->type.state & RELATION_ROW_START){
            total += Tag_Out(ctx->bf, tr, ZERO);
        }

        total += Tag_Out(ctx->bf, td, ZERO);
        total += ToS(ctx->bf, Iter_Get(&rel->it), 0, ZERO);
        total += Tag_Out(ctx->bf, td, TAG_CLOSE);

        if(rel->type.state & RELATION_ROW_END){
            total += Tag_Out(ctx->bf, tr, TAG_CLOSE);
        }
    }

    total += Tag_Out(ctx->bf, tbody, TAG_CLOSE);
    total += Tag_Out(ctx->bf, table, TAG_CLOSE);

    return total;
}
```

**Algorithm**:
1. Reset iterator to beginning
2. Generate `<table><thead>` tags
3. Output headers in `<th>` tags
4. Close header, open `<tbody>`
5. Iterate data, opening `<tr>` at ROW_START, closing at ROW_END
6. Each cell wrapped in `<td>`
7. Close tbody and table

**Result**:
```html
<table>
  <thead>
    <tr><th>Name</th><th>Age</th><th>City</th></tr>
  </thead>
  <tbody>
    <tr><td>Alice</td><td>30</td><td>NYC</td></tr>
    <tr><td>Bob</td><td>25</td><td>LA</td></tr>
  </tbody>
</table>
```

### Tokenize Definitions for Relations

From [src/ext/format/fmt/fmt_tokenize.c](../../../../src/ext/format/fmt/fmt_tokenize.c):

```c
// Table formatter
Lookup_Add(m, lk, FORMATTER_TABLE,
    Tokenize_Make(m, FORMATTER_TABLE, TOKEN_NO_COMBINE, TYPE_RELATION));

// Module formatter (also uses Relation)
Lookup_Add(m, lk, FORMATTER_MODULE,
    Tokenize_Make(m, FORMATTER_MODULE, TOKEN_NO_COMBINE, TYPE_RELATION));
```

**Two Formatters Create Relations**:
- `FORMATTER_TABLE`: Markdown-style tables
- `FORMATTER_MODULE`: Code/data modules

Both use `TOKEN_NO_COMBINE` to prevent merging with previous content.

---


## Code Examples

### Example 1: Creating a Simple Table

```c
MemCh *m = MemCh_Make();

// Create empty relation
Relation *rel = Relation_Make(m, 0, NULL);

// Add headers (3 columns)
Relation_AddValue(rel, Str_CstrRef(m, "Name"));
Relation_AddValue(rel, Str_CstrRef(m, "Age"));
Relation_AddValue(rel, Str_CstrRef(m, "City"));

// Extract headers (stride becomes 3)
Relation_HeadFromValues(rel);

// Add row 0
Relation_AddValue(rel, Str_CstrRef(m, "Alice"));
Relation_AddValue(rel, I32_Wrapped(m, 30));
Relation_AddValue(rel, Str_CstrRef(m, "NYC"));

// Add row 1
Relation_AddValue(rel, Str_CstrRef(m, "Bob"));
Relation_AddValue(rel, I32_Wrapped(m, 25));
Relation_AddValue(rel, Str_CstrRef(m, "LA"));

// Add row 2
Relation_AddValue(rel, Str_CstrRef(m, "Carol"));
Relation_AddValue(rel, I32_Wrapped(m, 35));
Relation_AddValue(rel, Str_CstrRef(m, "SF"));

// Now have: 3x3 table with headers
// Stride: 3
// Rows: 3
// Total values: 9
```

### Example 2: Using Random Access

```c
MemCh *m = MemCh_Make();

// Create with known stride
Relation *rel = Relation_Make(m, 4, NULL);

// Pre-allocate space if needed
// ... (Span auto-grows, so not required)

// Fill table using row/col coordinates
for(i32 row = 0; row < 10; row++){
    for(i32 col = 0; col < 4; col++){
        i32 value = row * 10 + col;
        Relation_SetValue(rel, row, col, I32_Wrapped(m, value));
    }
}

// Result: 10x4 table
// Row 0: [0, 1, 2, 3]
// Row 1: [10, 11, 12, 13]
// ...
// Row 9: [90, 91, 92, 93]
```

### Example 3: Iterating with Row Boundaries

```c
Relation_ResetIter(rel);

while((Relation_Next(rel) & END) == 0){
    // Check for row start
    if(rel->type.state & RELATION_ROW_START){
        printf("[ ");
    }

    // Get current value
    void *value = Iter_Get(&rel->it);
    printf("%p ", value);

    // Check for row end
    if(rel->type.state & RELATION_ROW_END){
        printf("]\n");
    }
}

// Output:
// [ 0x... 0x... 0x... ]
// [ 0x... 0x... 0x... ]
// ...
```

### Example 4: Generating CSV

```c
Buff *bf = Buff_Make(m, ZERO);

// Output headers
for(i16 i = 0; i < rel->stride; i++){
    if(i > 0) Buff_WriteStr(bf, ",");
    ToS(bf, rel->headers[i], 0, ZERO);
}
Buff_WriteStr(bf, "\n");

// Output data rows
Relation_ResetIter(rel);
while((Relation_Next(rel) & END) == 0){
    if((rel->type.state & RELATION_ROW_START) == 0){
        Buff_WriteStr(bf, ",");  // Comma between columns
    }

    ToS(bf, Iter_Get(&rel->it), 0, ZERO);

    if(rel->type.state & RELATION_ROW_END){
        Buff_WriteStr(bf, "\n");  // Newline at row end
    }
}

// bf now contains CSV output
```

### Example 5: Accessing Specific Cells

```c
// Calculate flat index for row 2, col 1
i32 row = 2;
i32 col = 1;
i32 idx = row * rel->stride + col;

// Access via iterator
Iter *it = &rel->it;
void *value = Iter_Get_By_Idx(it, idx);

// Or use SetValue/GetValue wrappers
Relation_SetValue(rel, row, col, newValue);
```

### Example 6: Getting Row Count

```c
i32 total_rows = Relation_RowCount(rel);
i32 total_cols = rel->stride;
i32 total_cells = total_rows * total_cols;

printf("Table dimensions: %dx%d (%d cells)\n",
       total_rows, total_cols, total_cells);
```

### Example 7: Relation in Mess Tree

```c
// After parsing a document with table
Mess *mess = /* ... from parser ... */;

// Find table node
Node *node = /* ... traverse tree to find node ... */;

if(node->typeOfChild == TYPE_RELATION){
    Relation *rel = (Relation *)node->child;

    printf("Table with %d columns, %d rows:\n",
           rel->stride, Relation_RowCount(rel));

    // Iterate table
    Relation_ResetIter(rel);
    while((Relation_Next(rel) & END) == 0){
        if(rel->type.state & RELATION_ROW_START){
            printf("  Row: ");
        }
        printf("%p ", Iter_Get(&rel->it));
        if(rel->type.state & RELATION_ROW_END){
            printf("\n");
        }
    }
}
```

### Example 8: Building Table from 2D Array

```c
// Source data
i32 data[3][4] = {
    {1, 2, 3, 4},
    {5, 6, 7, 8},
    {9, 10, 11, 12}
};

char *headers[] = {"A", "B", "C", "D"};

// Create relation
Relation *rel = Relation_Make(m, 0, NULL);

// Add headers
for(i32 i = 0; i < 4; i++){
    Relation_AddValue(rel, Str_CstrRef(m, headers[i]));
}
Relation_HeadFromValues(rel);

// Add data
for(i32 row = 0; row < 3; row++){
    for(i32 col = 0; col < 4; col++){
        Relation_AddValue(rel, I32_Wrapped(m, data[row][col]));
    }
}
```

### Example 9: Transposing a Relation

```c
// Create transposed relation (swap rows and cols)
Relation *src = /* original */;
i32 src_rows = Relation_RowCount(src);
i32 src_cols = src->stride;

Relation *dst = Relation_Make(m, 0, NULL);

// Transpose headers (becomes first column)
for(i32 i = 0; i < src_cols; i++){
    Relation_AddValue(dst, src->headers[i]);
}
Relation_HeadFromValues(dst);  // stride = src_cols

// Transpose data
for(i32 col = 0; col < src_cols; col++){
    for(i32 row = 0; row < src_rows; row++){
        // Read from src[row][col]
        i32 src_idx = row * src_cols + col;
        void *value = /* get from src at src_idx */;

        // Write to dst[col][row]
        Relation_AddValue(dst, value);
    }
}

// dst is now transposed version of src
```

### Example 10: Filtering Rows

```c
// Create new relation with filtered rows
Relation *src = /* original */;
Relation *dst = Relation_Make(m, src->stride, src->headers);

Relation_ResetIter(src);
Span *row_buffer = Span_Make(m);

while((Relation_Next(src) & END) == 0){
    void *value = Iter_Get(&src->it);

    // Accumulate row values
    Span_Add(row_buffer, value);

    if(src->type.state & RELATION_ROW_END){
        // Check filter condition
        if(ShouldIncludeRow(row_buffer)){
            // Add entire row to destination
            Iter it;
            Iter_Init(&it, row_buffer);
            while((Iter_Next(&it) & END) == 0){
                Relation_AddValue(dst, Iter_Get(&it));
            }
        }

        // Clear buffer for next row
        Span_Wipe(row_buffer);
    }
}

// dst now contains filtered rows
```

---


## Performance Characteristics

### Time Complexity

| Operation | Complexity | Notes |
|---|---|---|
| `Relation_Make` | O(1) | Simple allocation |
| `Relation_HeadFromValues` | O(s) | s = stride, creates header array |
| `Relation_AddValue` | O(1) amortized | Span growth is exponential |
| `Relation_SetValue` | O(1) | Direct index calculation |
| `Relation_RowCount` | O(1) | Simple arithmetic |
| `Relation_Next` | O(1) | Iterator advance + modulo |
| `Relation_ResetIter` | O(1) | Iterator reset |
| Full iteration | O(n) | n = total values |

### Space Complexity

| Component | Size | Notes |
|---|---|---|
| Relation header | ~64 bytes | Fixed size structure |
| Headers array | `stride * 8` bytes | One pointer per column |
| Underlying Span | Variable | Depends on total values |
| Total for n values | ~O(n) | Linear in value count |

**Memory Overhead**:
- No per-cell overhead (flat storage)
- Headers stored once, not per row
- Iterator overhead: ~200 bytes
- Span overhead: ~48 bytes + dynamic arrays

### Cache Performance

**Excellent Locality**:
- All values stored contiguously in flat Span
- Sequential iteration accesses memory linearly
- No pointer chasing between rows
- Headers separate from data (no intermingling)

**Row-Major Ordering**:
- Values stored left-to-right, top-to-bottom
- Iterating entire table is cache-friendly
- Accessing specific row is efficient
- Column access less efficient (stride jumps)

**Comparison to Alternatives**:
- **Array of arrays**: Indirection, poor locality
- **Linked lists**: Terrible cache performance
- **Flat + stride (Caneka)**: Best cache performance

### Scaling Characteristics

**Small Tables** (< 100 cells):
- Minimal overhead
- Excellent performance
- Comparable to 2D arrays

**Medium Tables** (100-10,000 cells):
- O(1) access remains constant
- Cache-friendly iteration
- Modest memory footprint

**Large Tables** (> 10,000 cells):
- May benefit from chunking/pagination
- Iteration still efficient
- Random access still O(1)
- Consider sparse representation if many cells empty

---


## Best Practices

### 1. Always Extract Headers Before Adding Data

```c
// GOOD: Headers extracted before data
Relation *rel = Relation_Make(m, 0, NULL);
Relation_AddValue(rel, header1);
Relation_AddValue(rel, header2);
Relation_HeadFromValues(rel);  // stride set here
Relation_AddValue(rel, data1);
Relation_AddValue(rel, data2);

// BAD: Data added before headers extracted
Relation *rel = Relation_Make(m, 0, NULL);
Relation_AddValue(rel, header1);
Relation_AddValue(rel, header2);
Relation_AddValue(rel, data1);  // WRONG: stride still 0
Relation_HeadFromValues(rel);   // TOO LATE: data1 interpreted as header
```

### 2. Use Row Boundary Flags for Formatting

```c
// GOOD: Check flags for proper formatting
while((Relation_Next(rel) & END) == 0){
    if(rel->type.state & RELATION_ROW_START){
        printf("<tr>");
    }
    printf("<td>%p</td>", Iter_Get(&rel->it));
    if(rel->type.state & RELATION_ROW_END){
        printf("</tr>\n");
    }
}

// BAD: Manual counter for rows
i32 col = 0;
while((Relation_Next(rel) & END) == 0){
    if(col == 0) printf("<tr>");
    printf("<td>%p</td>", Iter_Get(&rel->it));
    col = (col + 1) % rel->stride;
    if(col == 0) printf("</tr>\n");
}
```

### 3. Reset Iterator for Re-Iteration

```c
// GOOD: Reset before second iteration
Relation_ResetIter(rel);
while((Relation_Next(rel) & END) == 0){ /* ... */ }

Relation_ResetIter(rel);  // Reset again
while((Relation_Next(rel) & END) == 0){ /* ... */ }

// BAD: Forgetting to reset
while((Relation_Next(rel) & END) == 0){ /* ... */ }
while((Relation_Next(rel) & END) == 0){ /* ... */ }  // EMPTY: already at end
```

### 4. Check Headers Pointer Before Access

```c
// GOOD: Check for NULL
if(rel->headers != NULL){
    for(i16 i = 0; i < rel->stride; i++){
        printf("%s ", (char *)rel->headers[i]);
    }
}

// BAD: Assuming headers exist
for(i16 i = 0; i < rel->stride; i++){
    printf("%s ", (char *)rel->headers[i]);  // CRASH if headers NULL
}
```

### 5. Use Consistent Row Sizes

```c
// GOOD: Each row has exactly stride values
for(i32 row = 0; row < rows; row++){
    for(i32 col = 0; col < rel->stride; col++){
        Relation_AddValue(rel, values[row][col]);
    }
}

// BAD: Inconsistent row sizes
Relation_AddValue(rel, val1);
Relation_AddValue(rel, val2);
// Missing third value! Next row starts at wrong position
Relation_AddValue(rel, val4);
```

### 6. Use SetValue Only After Stride Known

```c
// GOOD: Stride set first
Relation_HeadFromValues(rel);  // stride = 3
Relation_SetValue(rel, 0, 0, value);  // Correct calculation

// BAD: SetValue before stride set
Relation *rel = Relation_Make(m, 0, NULL);
Relation_SetValue(rel, 0, 0, value);  // stride=0, calculation wrong!
Relation_HeadFromValues(rel);
```

### 7. Free via MemCh

```c
// GOOD: Free entire relation with MemCh
MemCh *m = MemCh_Make();
Relation *rel = Relation_Make(m, 0, NULL);
// ... use relation ...
MemCh_Free(m);  // Frees relation, Span, all values

// BAD: Attempting manual free
free(rel->headers);  // WRONG: allocated from MemCh
free(rel);           // WRONG: allocated from MemCh
```

### 8. Use RowCount for Dimension Queries

```c
// GOOD: Use RowCount function
i32 rows = Relation_RowCount(rel);
i32 cols = rel->stride;

// ACCEPTABLE: Manual calculation
i32 total = rel->it.p->max_idx + 1;
i32 rows = (rel->stride > 0) ? (total / rel->stride) : 0;

// BEST: Use provided function (clearer intent)
i32 rows = Relation_RowCount(rel);
```

### 9. Consider Stride for Performance

```c
// Column-major access (poor cache performance)
for(i32 col = 0; col < cols; col++){
    for(i32 row = 0; row < rows; row++){
        i32 idx = row * stride + col;  // Stride jumps
        // Access index idx
    }
}

// Row-major access (good cache performance)
for(i32 row = 0; row < rows; row++){
    for(i32 col = 0; col < cols; col++){
        i32 idx = row * stride + col;  // Sequential
        // Access index idx
    }
}
```

### 10. Study Existing Formatters

Learn from production code:
- [src/ext/format/fmt/fmt_html.c](../../../../src/ext/format/fmt/fmt_html.c) - HTML table generation
- [src/ext/navigate/navigate_cls.c](../../../../src/ext/navigate/navigate_cls.c) - Debug printing
- [src/programs/test/option/ext/relation_tests.c](../../../../src/programs/test/option/ext/relation_tests.c) - Comprehensive tests

---



---

**Part 1 of 2** | [Part 2 →](relation-complete-part2)
