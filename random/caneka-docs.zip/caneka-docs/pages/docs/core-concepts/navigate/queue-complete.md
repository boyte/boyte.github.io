---
sidebar_position: 4
---

# Queue System - Complete Guide

The **Queue** is Navigate's task scheduling and management system. It maintains an ordered collection of tasks and uses a **criteria system** to determine task priority and execution order.

## Core Concept

A Queue is a **managed collection of tasks** where:
- Tasks are added and removed dynamically
- **Criteria** determine which task executes next
- **Slab-based storage** efficiently handles large queues
- Tasks can be **recycled** to avoid allocation overhead

## Queue Structure

```c
typedef struct queue {
    Type type;                      // Type header with state flags
    gobits go;                      // Bit flags for queue state
    i32 slabIdx;                    // Current slab index (position in queue)
    Abstract *value;                // Current task/item
    Iter it;                        // Iterator over items
    Iter availableIt;               // Iterator over recycled slots
    Span *handlers;                 // Array of QueueCrit handlers
} Queue;
```

### Key Fields

- **slabIdx**: Index of the current slab being processed
- **value**: Currently active task or item
- **it**: Main iterator for traversing queue items
- **availableIt**: Iterator over recycled slots (for reuse)
- **handlers**: Span of QueueCrit criterion handlers

## Queue Criteria System

The **criteria system** is what makes queues powerful. Criteria determine:
- Which task should execute next
- How tasks are prioritized
- When tasks should be skipped or delayed

### QueueCrit Structure

```c
typedef struct queue_crit {
    Type type;
    i32 idx;                        // Criterion index
    util discriminator;             // Unique identifier
    Span *data;                     // Slab-based criterion data
    QueueCritFunc func;             // Criterion evaluation function
} QueueCrit;
```

### Criterion Function

```c
typedef status (*QueueCritFunc)(
    QueueCrit *crit,
    i32 taskIdx,
    void *value
);
```

**Purpose**: Evaluate whether a task at `taskIdx` meets this criterion.

**Returns**:
- **SUCCESS**: Task meets criterion, can proceed
- **SKIP**: Task doesn't meet criterion, skip it
- **ERROR**: Criterion evaluation failed

## Slab-Based Storage

Queues use **slabs** to avoid allocating massive sparse arrays.

### What is a Slab?

A **slab** is a fixed-size chunk of storage (typically 64 elements).

```c
#define CRIT_SLAB_STRIDE 64

// Instead of allocating array[10000]
// Allocate slabs: [slab0: 0-63], [slab1: 64-127], ...
```

### Slab Calculation

```c
i32 taskIdx = 250;
i32 slabIdx = taskIdx / CRIT_SLAB_STRIDE;  // 250 / 64 = 3
i32 slabOffset = taskIdx % CRIT_SLAB_STRIDE;  // 250 % 64 = 58

// Access: crit->data[slabIdx][slabOffset]
```

### Benefits

1. **Memory Efficiency**: Only allocate slabs for used indices
2. **Sparse Support**: Handle queues with large gaps efficiently
3. **Cache Friendly**: Contiguous slab memory improves locality

## Core Operations

### Creating a Queue

```c
Queue *Queue_Make(MemCh *m);
```

Creates an empty queue.

**Example:**
```c
Queue *q = Queue_Make(m);
q->handlers = Span_Make(m);  // Initialize criteria handlers
```

### Adding Tasks

```c
status Queue_Add(Queue *q, void *task);
```

Adds a task to the queue, reusing recycled slots if available.

**Algorithm:**
```c
1. Check availableIt for recycled slots
2. If found, reuse slot
3. Otherwise, append to main iterator (it)
4. Update criteria for new task
5. Return SUCCESS
```

**Example:**
```c
Task *task = Task_Make(m);
task->data = q;  // Associate with queue
Queue_Add(q, task);
```

### Removing Tasks

```c
status Queue_Remove(Queue *q, i32 idx);
```

Removes a task and marks the slot as available for reuse.

**Algorithm:**
```c
1. Get task at idx
2. Remove from main iterator
3. Add idx to availableIt (for recycling)
4. Update criteria
5. Return SUCCESS
```

**Example:**
```c
// Task at index 5 completes
Queue_Remove(q, 5);
// Slot 5 now in availableIt, can be reused
```

### Getting Next Task

```c
void *Queue_Next(Queue *q);
```

Returns the next task that meets all criteria, or NULL if none available.

**Algorithm:**
```c
1. Iterate through queue (via it)
2. For each task:
    a. Evaluate all criteria
    b. If all criteria pass, return task
    c. Otherwise, continue
3. Return NULL if no task meets criteria
```

**Example:**
```c
while (true) {
    Task *task = Queue_Next(q);
    if (!task) {
        break;  // No tasks ready
    }

    // Execute task
    Task_Execute(task);

    // Remove completed task
    Queue_Remove(q, task->idx);
}
```

### Setting Criteria

```c
status Queue_SetCriteria(
    Queue *q,
    i32 critIdx,
    i32 taskIdx,
    util value
);
```

Updates criterion value for a specific task.

**Parameters:**
- `critIdx`: Which criterion to update
- `taskIdx`: Which task to update
- `value`: New criterion value

**Example:**
```c
// Set file descriptor criterion for task 5
Queue_SetCriteria(q, CRIT_FD, 5, fd);
```

## Standard Criteria

### File Descriptor Criterion (CRIT_FD)

**Purpose**: Track which file descriptors are ready for I/O.

**Usage:**
```c
QueueCrit *fdCrit = QueueCrit_Make(m, CRIT_FD);
fdCrit->func = Crit_CheckFdReady;

// Add to queue
Span_Set(q->handlers, CRIT_FD, fdCrit);

// Set FD for task
Queue_SetCriteria(q, CRIT_FD, taskIdx, fd);
```

**Criterion Function:**
```c
status Crit_CheckFdReady(QueueCrit *crit, i32 taskIdx, void *value) {
    // Get FD from slab
    i32 slabIdx = taskIdx / CRIT_SLAB_STRIDE;
    i32 offset = taskIdx % CRIT_SLAB_STRIDE;
    util *slab = Span_Get(crit->data, slabIdx);

    i32 fd = slab[offset];

    // Check if FD is ready (using select/poll/epoll)
    if (FdIsReady(fd)) {
        return SUCCESS;  // Task can proceed
    }

    return SKIP;  // Wait for FD to be ready
}
```

### Timeout Criterion (CRIT_TIMEOUT)

**Purpose**: Only execute tasks after a specific time.

**Usage:**
```c
QueueCrit *timeoutCrit = QueueCrit_Make(m, CRIT_TIMEOUT);
timeoutCrit->func = Crit_CheckTimeout;

// Set timeout for task (in seconds)
time_t deadline = time(NULL) + 5;  // 5 seconds from now
Queue_SetCriteria(q, CRIT_TIMEOUT, taskIdx, deadline);
```

**Criterion Function:**
```c
status Crit_CheckTimeout(QueueCrit *crit, i32 taskIdx, void *value) {
    // Get deadline from slab
    util *slab = Span_Get(crit->data, taskIdx / CRIT_SLAB_STRIDE);
    time_t deadline = slab[taskIdx % CRIT_SLAB_STRIDE];

    if (time(NULL) >= deadline) {
        return SUCCESS;  // Timeout reached, execute
    }

    return SKIP;  // Not yet time
}
```

### Priority Criterion (CRIT_PRIORITY)

**Purpose**: Execute higher-priority tasks first.

**Usage:**
```c
// Priority 0 = highest, 10 = lowest
Queue_SetCriteria(q, CRIT_PRIORITY, taskIdx, priority);
```

**Criterion Function:**
```c
status Crit_CheckPriority(QueueCrit *crit, i32 taskIdx, void *value) {
    util *slab = Span_Get(crit->data, taskIdx / CRIT_SLAB_STRIDE);
    i32 priority = slab[taskIdx % CRIT_SLAB_STRIDE];

    // Only execute if priority is high enough
    if (priority <= CURRENT_PRIORITY_THRESHOLD) {
        return SUCCESS;
    }

    return SKIP;
}
```

## Complete Example: HTTP Server Queue

Let's build a queue for managing HTTP connections:

### Setup

```c
typedef struct http_server {
    Queue *connections;
    i32 maxConnections;
} HttpServer;

// Create server queue
HttpServer *server = MemCh_AllocOf(m, sizeof(HttpServer), TYPE_SERVER);
server->connections = Queue_Make(m);
server->maxConnections = 1000;

// Initialize criteria
QueueCrit *fdCrit = QueueCrit_Make(m, CRIT_FD);
fdCrit->func = Crit_CheckFdReady;
Span_Set(server->connections->handlers, CRIT_FD, fdCrit);

QueueCrit *timeoutCrit = QueueCrit_Make(m, CRIT_TIMEOUT);
timeoutCrit->func = Crit_CheckTimeout;
Span_Set(server->connections->handlers, CRIT_TIMEOUT, timeoutCrit);
```

### Accepting Connections

```c
status AcceptConnections(HttpServer *server) {
    while (true) {
        i32 fd = accept(server->listenFd, ...);
        if (fd < 0) break;

        // Create task for this connection
        Task *connTask = Task_Make(m);
        connTask->idx = server->connections->it.idx + 1;
        connTask->data = server->connections;

        // Add read/write steps
        Task_AddStep(connTask, HttpRead, NULL);
        Task_AddStep(connTask, HttpProcess, NULL);
        Task_AddStep(connTask, HttpWrite, NULL);

        // Add to queue
        Queue_Add(server->connections, connTask);

        // Set FD criterion
        Queue_SetCriteria(server->connections, CRIT_FD, connTask->idx, fd);

        // Set timeout (30 seconds)
        time_t deadline = time(NULL) + 30;
        Queue_SetCriteria(server->connections, CRIT_TIMEOUT, connTask->idx, deadline);
    }

    return SUCCESS;
}
```

### Processing Queue

```c
status ProcessQueue(HttpServer *server) {
    while (true) {
        // Get next ready task (FD ready OR timeout reached)
        Task *task = Queue_Next(server->connections);

        if (!task) {
            // No tasks ready, wait or return
            usleep(1000);  // 1ms
            continue;
        }

        // Execute task
        status result = Task_Execute(task);

        if (result & SUCCESS) {
            // Task completed, remove from queue
            Queue_Remove(server->connections, task->idx);
        }

        if (result & ERROR) {
            // Task failed, remove and log
            LogError(task);
            Queue_Remove(server->connections, task->idx);
        }

        // Task returns MORE - keep in queue, will process later
    }

    return SUCCESS;
}
```

## Queue Recycling

Queues reuse slots to avoid allocation churn:

### Recycling Flow

```
Add Task → Queue full? → Check availableIt → Reuse slot → Update criteria
                          ↓                    ↓
                    No recycled slots → Append to it → Update criteria
```

### Example

```c
Queue *q = Queue_Make(m);

// Add tasks 0-9
for (int i = 0; i < 10; i++) {
    Queue_Add(q, MakeTask(i));
}

// Remove tasks 3, 5, 7
Queue_Remove(q, 3);
Queue_Remove(q, 5);
Queue_Remove(q, 7);

// availableIt now contains: [3, 5, 7]

// Add new task - reuses slot 3
Queue_Add(q, MakeTask(10));  // Uses index 3

// Add another - reuses slot 5
Queue_Add(q, MakeTask(11));  // Uses index 5
```

## Criteria Evaluation Order

When `Queue_Next()` is called:

```c
for each task in queue:
    for each criterion in handlers:
        result = criterion->func(criterion, taskIdx, task)
        if result == SKIP:
            continue to next task
        if result == ERROR:
            log error, continue to next task
    // All criteria passed
    return task
```

**Key Insight**: ALL criteria must return SUCCESS for a task to be selected.

## Performance Considerations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| Add | O(1) average | O(1) if recycled slot, O(1) append |
| Remove | O(1) | Marks slot as available |
| Next | O(n * c) | n = tasks, c = criteria |
| SetCriteria | O(1) | Slab access is constant time |

### Optimizing Queue_Next

For large queues, optimize by:
1. **Limit iterations**: Check only first N tasks
2. **Cache criterion results**: Avoid re-evaluating unchanged criteria
3. **Index by criterion**: Maintain separate indices for each criterion

## Best Practices

1. **Use meaningful criteria**: Don't just queue tasks, prioritize them
2. **Recycle aggressively**: Remove completed tasks immediately
3. **Limit queue size**: Set max queue size to prevent memory bloat
4. **Tune slab size**: Adjust CRIT_SLAB_STRIDE based on queue characteristics
5. **Monitor criteria overhead**: Too many criteria slow down Queue_Next

## Common Pitfalls

### Pitfall 1: Not Removing Completed Tasks

```c
// WRONG - Queue grows infinitely
Task *task = Queue_Next(q);
Task_Execute(task);
// Forgot to remove!

// RIGHT
Task *task = Queue_Next(q);
Task_Execute(task);
Queue_Remove(q, task->idx);
```

### Pitfall 2: Criteria Never Succeed

```c
// WRONG - Criterion always returns SKIP
status BadCriterion(QueueCrit *crit, i32 idx, void *val) {
    return SKIP;  // Tasks never execute!
}

// RIGHT - Criterion has success condition
status GoodCriterion(QueueCrit *crit, i32 idx, void *val) {
    if (ConditionMet()) {
        return SUCCESS;
    }
    return SKIP;
}
```

### Pitfall 3: Forgetting to Update Criteria

```c
// WRONG - FD changes but criterion not updated
Task *task = GetTask();
task->fd = new_fd;
// Forgot to update criterion!

// RIGHT
Task *task = GetTask();
task->fd = new_fd;
Queue_SetCriteria(q, CRIT_FD, task->idx, new_fd);
```

## Advanced Patterns

### Pattern 1: Multi-Stage Pipeline

```c
Queue *stage1 = Queue_Make(m);  // Parsing
Queue *stage2 = Queue_Make(m);  // Processing
Queue *stage3 = Queue_Make(m);  // Output

// Task moves through stages
Task *task = MakeTask();
Queue_Add(stage1, task);
// ... stage1 completes ...
Queue_Remove(stage1, task->idx);
Queue_Add(stage2, task);
// ... stage2 completes ...
Queue_Remove(stage2, task->idx);
Queue_Add(stage3, task);
```

### Pattern 2: Priority Inheritance

```c
// High-priority task blocked by low-priority task
// Temporarily boost low-priority task
Queue_SetCriteria(q, CRIT_PRIORITY, blockedTaskIdx, HIGH_PRIORITY);
```

### Pattern 3: Deadline Scheduling

```c
// Sort tasks by deadline
QueueCrit *deadlineCrit = QueueCrit_Make(m, CRIT_DEADLINE);
deadlineCrit->func = Crit_EarliestDeadlineFirst;

status Crit_EarliestDeadlineFirst(QueueCrit *crit, i32 idx, void *val) {
    // Return SUCCESS for task with earliest deadline
    // Implementation uses min-heap or sorted order
}
```

## See Also

- [Task Execution](task-execution-complete.md) - How tasks execute
- [Navigate Overview](overview.md) - System architecture
- [Span](../memory/span-complete.md) - Understanding slab storage
