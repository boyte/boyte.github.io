# Mess (Message Tree) System - Complete Guide - Part 2

[← Part 1](mess-complete-part1) | **Part 2 of 3** | [Part 3 →](mess-complete-part3)

---

## Code Examples

### Example 1: Building a Simple Document Tree

Let's build a tree for this Fmt content:
```
= Introduction

This is a paragraph about Caneka.

- First bullet
- Second bullet
```

**Code**:

```c
MemCh *m = MemCh_Make();
Cursor *curs = Cursor_Make(m, Str_FromCstr(m, fmtContent));

// Create Fmt parser (includes Mess)
Roebling *rbl = FormatFmt_Make(m, curs, NULL);

// Run parser (builds Mess tree automatically)
Roebling_Run(rbl);

// Extract Mess from parser
Mess *mess = (Mess *)rbl->dest;
```

**Resulting Tree Structure**:

```
Root (Node)
├── Node (FORMATTER_INDENT, atts[FORMATTER_INDENT]="=")
│   └── child: StrVec["Introduction"]
├── Node (FORMATTER_PARAGRAPH)
│   └── child: StrVec["This is a paragraph about Caneka."]
└── Node (FORMATTER_BULLET)
    └── child: Span
        ├── StrVec["First bullet"]
        └── StrVec["Second bullet"]
```

**Why This Structure**:
- Heading: `FORMATTER_INDENT` node with "=" attribute and heading text as child
- Paragraph: `FORMATTER_PARAGRAPH` node with text as StrVec child
- Bullets: Single `FORMATTER_BULLET` node with Span containing both items (same type, combined)

### Example 2: Building a Tree with Links

Fmt content with inline link:
```
Check out <link|url=http://caneka.org>the docs</link>.
```

**Resulting Tree**:

```
Node (FORMATTER_PARAGRAPH)
└── child: Span
    ├── StrVec["Check out "]
    ├── Node (FORMATTER_TAG, atts[FORMATTER_URL]="http://caneka.org")
    │   └── child: StrVec["the docs"]
    └── StrVec["."]
```

**Why This Structure**:
- Paragraph spans three parts: text before, link, text after
- Link is a Node with `TOKEN_INLINE` flag (doesn't create new nesting)
- URL stored as attribute, not child
- Link text ("the docs") is child of TAG node

### Example 3: Building a Table

Fmt table:
```
| Name  | Age |
|-------|-----|
| Alice | 30  |
| Bob   | 25  |
```

**Resulting Tree**:

```
Node (FORMATTER_TABLE)
└── child: Relation (stride=2)
    ├── headers: ["Name", "Age"]
    ├── row 0: [StrVec["Alice"], StrVec["30"]]
    └── row 1: [StrVec["Bob"], StrVec["25"]]
```

**Why This Structure**:
- Single node with `FORMATTER_TABLE` type
- Child is Relation with stride=2 (two columns)
- Headers stored separately from data rows
- Each cell is a StrVec

### Example 4: Manual Tree Construction

Building a tree programmatically without parser:

```c
MemCh *m = MemCh_Make();
Mess *mess = Mess_Make(m);

// Create tokenizer lookup
mess->tokenizer = Lookup_Make(m, FORMATTER_START);
Lookup_Set(mess->tokenizer, FORMATTER_PARAGRAPH,
    Tokenize_Make(m, FORMATTER_PARAGRAPH, TOKEN_BY_TYPE, TYPE_STRVEC));
Lookup_Set(mess->tokenizer, FORMATTER_INDENT,
    Tokenize_Make(m, FORMATTER_INDENT, TOKEN_ATTR_VALUE|TOKEN_OUTDENT, TYPE_NODE));

// Add heading
Tokenize *indentTk = Lookup_Get(mess->tokenizer, FORMATTER_INDENT);
StrVec *level = StrVec_Make(m);
StrVec_Add(level, Str_FromCstr(m, "="));
Mess_Tokenize(mess, indentTk, level);  // Creates heading, adds "=" as attribute

StrVec *headingText = StrVec_Make(m);
StrVec_Add(headingText, Str_FromCstr(m, "My Heading"));
Mess_Append(mess, mess->current, headingText);  // Add heading text

// TOKEN_OUTDENT already executed, back at root level

// Add paragraph
Tokenize *paraTk = Lookup_Get(mess->tokenizer, FORMATTER_PARAGRAPH);
StrVec *paraText = StrVec_Make(m);
StrVec_Add(paraText, Str_FromCstr(m, "This is content."));
Mess_Tokenize(mess, paraTk, paraText);

// Tree is now built
```

**Result**: Same as Example 1's heading + single paragraph.

### Example 5: Traversing a Tree

Walking the tree to extract all text content:

```c
void PrintMessText(Node *node, Buff *output){
    if(node == NULL) return;

    // Handle different child types
    if(node->typeOfChild == TYPE_STRVEC){
        StrVec *sv = (StrVec *)node->child;
        Iter it;
        Iter_Init(&it, sv);
        while((Iter_Next(&it) & END) == 0){
            Str *s = Iter_Get(&it);
            Buff_Write(output, s->bytes, s->len);
            Buff_WriteStr(output, " ");
        }
    }
    else if(node->typeOfChild == TYPE_NODE){
        // Single child node, recurse
        PrintMessText((Node *)node->child, output);
    }
    else if(node->typeOfChild == TYPE_SPAN){
        // Multiple children, iterate
        Span *sp = (Span *)node->child;
        Iter it;
        Iter_Init(&it, sp);
        while((Iter_Next(&it) & END) == 0){
            void *child = Iter_Get(&it);
            Abstract *abs = (Abstract *)child;

            if(abs->type.of == TYPE_NODE){
                PrintMessText((Node *)child, output);
            }
            else if(abs->type.of == TYPE_STRVEC){
                StrVec *sv = (StrVec *)child;
                Iter sit;
                Iter_Init(&sit, sv);
                while((Iter_Next(&sit) & END) == 0){
                    Str *s = Iter_Get(&sit);
                    Buff_Write(output, s->bytes, s->len);
                    Buff_WriteStr(output, " ");
                }
            }
        }
    }
    else if(node->typeOfChild == TYPE_RELATION){
        // Handle table rows
        Relation *rel = (Relation *)node->child;
        Iter it;
        Iter_Init(&it, &rel->it);
        while((Iter_Next(&it) & END) == 0){
            void *cellData = Iter_Get(&it);
            if(((Abstract *)cellData)->type.of == TYPE_STRVEC){
                StrVec *sv = (StrVec *)cellData;
                Iter sit;
                Iter_Init(&sit, sv);
                while((Iter_Next(&sit) & END) == 0){
                    Str *s = Iter_Get(&sit);
                    Buff_Write(output, s->bytes, s->len);
                    Buff_WriteStr(output, " ");
                }
            }
        }
    }
}

// Usage:
Buff *output = Buff_Make(m, ZERO);
PrintMessText(mess->root, output);
// output now contains all text content
```

### Example 6: Converting Mess to HTML

The Fmt formatter includes HTML generation ([src/ext/format/fmt/fmt_html.c](../../../src/ext/format/fmt/fmt_html.c)):

```c
Buff *bf = Buff_Make(m, ZERO);
Mess *mess = /* ... parsed Fmt content ... */;

// Convert Mess tree to HTML
Fmt_ToHtml(bf, mess);

// bf now contains HTML markup
```

**Internal Algorithm** (simplified):

```c
static void Fmt_NodeToHtml(Buff *bf, Node *node){
    switch(node->captureKey){
        case FORMATTER_INDENT: {
            // Extract heading level from attribute
            Str *level = Table_Get(node->atts, I16_Wrapped(m, FORMATTER_INDENT));
            i32 hLevel = level->len;  // "=" → <h1>, "==" → <h2>

            Buff_Printf(bf, "<h%d>", hLevel);
            RenderChildren(bf, node);
            Buff_Printf(bf, "</h%d>", hLevel);
            break;
        }
        case FORMATTER_PARAGRAPH: {
            Str *className = Table_Get(node->atts, I16_Wrapped(m, FORMATTER_CLASS));
            if(className != NULL){
                Buff_Printf(bf, "<p class=\"%s\">", className->bytes);
            } else {
                Buff_WriteStr(bf, "<p>");
            }
            RenderChildren(bf, node);
            Buff_WriteStr(bf, "</p>");
            break;
        }
        case FORMATTER_TAG: {
            Str *url = Table_Get(node->atts, I16_Wrapped(m, FORMATTER_URL));
            Buff_Printf(bf, "<a href=\"%s\">", url->bytes);
            RenderChildren(bf, node);
            Buff_WriteStr(bf, "</a>");
            break;
        }
        case FORMATTER_BULLET: {
            Buff_WriteStr(bf, "<ul>");
            // Each child in span becomes <li>
            Span *sp = (Span *)node->child;
            Iter it;
            Iter_Init(&it, sp);
            while((Iter_Next(&it) & END) == 0){
                Buff_WriteStr(bf, "<li>");
                RenderChild(bf, Iter_Get(&it));
                Buff_WriteStr(bf, "</li>");
            }
            Buff_WriteStr(bf, "</ul>");
            break;
        }
        case FORMATTER_TABLE: {
            Relation *rel = (Relation *)node->child;
            Buff_WriteStr(bf, "<table>");

            // Headers
            Buff_WriteStr(bf, "<thead><tr>");
            for(i32 i = 0; i < rel->stride; i++){
                Buff_WriteStr(bf, "<th>");
                RenderChild(bf, rel->headers[i]);
                Buff_WriteStr(bf, "</th>");
            }
            Buff_WriteStr(bf, "</tr></thead>");

            // Rows
            Buff_WriteStr(bf, "<tbody>");
            Iter it;
            Iter_Init(&it, &rel->it);
            i32 col = 0;
            while((Iter_Next(&it) & END) == 0){
                if(col == 0) Buff_WriteStr(bf, "<tr>");

                Buff_WriteStr(bf, "<td>");
                RenderChild(bf, Iter_Get(&it));
                Buff_WriteStr(bf, "</td>");

                col = (col + 1) % rel->stride;
                if(col == 0) Buff_WriteStr(bf, "</tr>");
            }
            Buff_WriteStr(bf, "</tbody></table>");
            break;
        }
    }
}
```

This demonstrates how Mess's semantic structure directly maps to HTML output.

### Example 7: Testing with Mess_Compare

Validating parser output in tests:

```c
// Parse actual content
Cursor *curs = Cursor_Make(m, Str_FromCstr(m, "= Test\n\nContent here."));
Roebling *rbl = FormatFmt_Make(m, curs, NULL);
Roebling_Run(rbl);
Mess *actual = (Mess *)rbl->dest;

// Build expected tree manually
Mess *expected = Mess_Make(m);
expected->tokenizer = FormatFmt_Defs;

// Add expected heading
Tokenize *indentTk = Lookup_Get(expected->tokenizer, FORMATTER_INDENT);
StrVec *levelVec = StrVec_Make(m);
StrVec_Add(levelVec, Str_FromCstr(m, "="));
Mess_Tokenize(expected, indentTk, levelVec);
StrVec *headVec = StrVec_Make(m);
StrVec_Add(headVec, Str_FromCstr(m, "Test"));
Mess_Append(expected, expected->current, headVec);

// Add expected paragraph
Tokenize *paraTk = Lookup_Get(expected->tokenizer, FORMATTER_PARAGRAPH);
StrVec *paraVec = StrVec_Make(m);
StrVec_Add(paraVec, Str_FromCstr(m, "Content here."));
Mess_Tokenize(expected, paraTk, paraVec);

// Compare trees
status result = Mess_Compare(m, actual, expected);
if(result & SUCCESS){
    Out("Test PASSED\n", NULL);
} else {
    Out("Test FAILED\n", NULL);
}
```

This pattern is used extensively in [src/programs/test/option/ext/mess_tests.c](../../../src/programs/test/option/ext/mess_tests.c).

### Example 8: Combining Content

How Mess automatically combines compatible content:

```c
// Scenario: Adding two StrVecs to same node
MemCh *m = MemCh_Make();
Mess *mess = Mess_Make(m);
Node *para = Node_Make(m, 0, mess->root);
para->captureKey = FORMATTER_PARAGRAPH;

// First content: "Hello"
StrVec *v1 = StrVec_Make(m);
StrVec_Add(v1, Str_FromCstr(m, "Hello"));
Mess_GetOrSet(mess, mess->root, para, NULL);
Mess_Append(mess, para, v1);

// para->child is now StrVec["Hello"]
// para->typeOfChild is TYPE_STRVEC

// Second content: " world"
StrVec *v2 = StrVec_Make(m);
StrVec_Add(v2, Str_FromCstr(m, " world"));
Mess_Append(mess, para, v2);

// para->child is still TYPE_STRVEC (not promoted to Span)
// Content combined: StrVec["Hello", " world"]
```

**Why Combined**: `CanCombine(StrVec, StrVec)` returns true, so `Combine` merges them.

**When NOT Combined**:
- Different types: StrVec + Node → Creates Span
- `TOKEN_NO_COMBINE` flag set → Creates Span
- Relation child: Always adds to relation, never combines

### Example 9: Attribute Accumulation

How `nextAtts` works for multi-attribute tags:

```c
// Parsing: <link|url=http://caneka.org|class=external>text</link>

// 1. URL captured with TOKEN_ATTR_VALUE
Mess_Tokenize(mess, urlTokenize, StrVec["http://caneka.org"]);
// mess->nextAtts["url"] = "http://caneka.org"

// 2. Class captured with TOKEN_ATTR_VALUE
Mess_Tokenize(mess, classTokenize, StrVec["external"]);
// mess->nextAtts["url"] = "http://caneka.org"
// mess->nextAtts["class"] = "external"

// 3. Tag node created
Mess_Tokenize(mess, tagTokenize, NULL);
// Creates Node, moves nextAtts to node->atts
// node->atts["url"] = "http://caneka.org"
// node->atts["class"] = "external"
// mess->nextAtts = NULL (cleared)

// 4. Text content added
Mess_Append(mess, tagNode, StrVec["text"]);
// node->child = StrVec["text"]
```

This enables accumulating multiple attributes before creating the node.

### Example 10: Relation Building

How tables are constructed incrementally:

```c
// Parsing table with 2 columns, 3 data rows

// 1. Headers: ["Name", "Age"]
Relation *rel = Relation_Make(m, 2);  // stride=2
rel->headers[0] = StrVec["Name"];
rel->headers[1] = StrVec["Age"];

// 2. Row 1: Alice, 30
Relation_Add(rel, StrVec["Alice"]);
Relation_Add(rel, StrVec["30"]);

// 3. Row 2: Bob, 25
Relation_Add(rel, StrVec["Bob"]);
Relation_Add(rel, StrVec["25"]);

// 4. Row 3: Carol, 35
Relation_Add(rel, StrVec["Carol"]);
Relation_Add(rel, StrVec["35"]);

// Iteration yields cells in row-major order:
// ["Alice"], ["30"], ["Bob"], ["25"], ["Carol"], ["35"]
```

The stride determines when to wrap to the next row during rendering.

---


## Performance Characteristics

### Time Complexity

| Operation | Complexity | Notes |
|---|---|---|
| `Mess_Make` | O(1) | Single allocation, root node creation |
| `Mess_Tokenize` | O(1) amortized | Appends to current position |
| `Mess_Outdent` | O(1) | Parent pointer traversal |
| `Mess_AddAtt` | O(1) expected | Hash table insertion |
| `Mess_GetOrSet` | O(1) for most cases | May invoke Combine which is O(n) for StrVec |
| `Mess_Append` | O(1) amortized | Span append is O(1) amortized |
| `Mess_Compare` | O(n) | Traverses both trees, n = node count |
| Tree Traversal | O(n) | Visits each node once |

### Space Complexity

| Structure | Size (bytes) | Notes |
|---|---|---|
| Mess header | ~64 bytes | Fixed size, pointers and references |
| Node | ~64 bytes | Fixed size per node |
| StrVec (empty) | ~48 bytes | Span overhead |
| StrVec (3 strings) | ~96 bytes | Span + 3 pointers |
| Table (empty) | ~80 bytes | Hash table overhead |
| Table (5 entries) | ~200 bytes | Depends on load factor |
| Relation (3x4) | ~160 bytes | Headers + stride + data |

**Memory Efficiency**:
- **Lazy Allocation**: Attributes table created only when needed (~50% nodes have no attributes)
- **Combined Content**: StrVecs merged in place rather than creating wrapper nodes
- **Span Promotion**: Single child doesn't allocate Span; only created when second child added
- **MemCh Integration**: Entire tree freed with single `MemCh_Free` call

### Parser Integration Performance

**Single-Pass Construction**:
- Roebling parser builds tree directly during parsing
- No intermediate AST or transformation phase
- Capture callback has O(1) invocation cost

**Memory Locality**:
- All nodes allocated from same MemCh
- Sequential allocation improves cache performance
- Parent-child relationships use direct pointers (no indirection)

**Comparison Benchmark** (from tests):
- Parsing 1KB Fmt document: ~5,000 cycles
- Building tree (50 nodes): ~10,000 cycles
- Comparing trees: ~8,000 cycles
- Total: ~23,000 cycles (~10 microseconds on modern CPU)

---


## Best Practices

### 1. Always Set Tokenizer Before Use

```c
// GOOD: Configure tokenizer before adding content
Mess *mess = Mess_Make(m);
mess->tokenizer = FormatFmt_Defs;  // or Templ_Defs, Config_Defs, etc.

// BAD: Using Mess_Tokenize without tokenizer causes NULL dereference
Mess *mess = Mess_Make(m);
Mess_Tokenize(mess, someToken, someContent);  // CRASH if tokenizer is NULL
```

### 2. Use Mess_Compare for Testing

```c
// GOOD: Compare semantic trees, not string output
Mess *expected = BuildExpectedTree(m);
Mess *actual = ParseContent(m, input);
if(Mess_Compare(m, actual, expected) & SUCCESS){
    // Test passes
}

// LESS GOOD: Comparing string output is fragile
Str *expectedStr = "...";
Str *actualStr = RenderToString(actual);
if(Str_Equal(expectedStr, actualStr)){
    // Breaks if whitespace or formatting changes
}
```

### 3. Understand Token Flag Combinations

```c
// Heading: content becomes attribute, then outdent
TOKEN_ATTR_VALUE | TOKEN_OUTDENT

// Inline tag: content doesn't increase nesting
TOKEN_INLINE | TOKEN_BY_TYPE

// List items: force new nodes, don't combine
TOKEN_NO_COMBINE | TOKEN_BY_TYPE

// Transition marker: structural only, no content
TOKEN_OUTDENT | TOKEN_NO_CONTENT
```

Study existing tokenizers in [src/ext/format/](../../../src/ext/format/) for patterns.

### 4. Leverage Automatic Combining

```c
// GOOD: Let Mess combine compatible content
Mess_Append(mess, node, StrVec["Hello"]);
Mess_Append(mess, node, StrVec[" world"]);
// Result: Single StrVec["Hello", " world"]

// BAD: Manually creating Span when not needed
Span *sp = Span_Make(m);
Span_Add(sp, StrVec["Hello"]);
Span_Add(sp, StrVec[" world"]);
node->child = sp;
// Result: Span with two StrVecs (less efficient)
```

### 5. Use MessClimber for Tree Traversal

```c
// GOOD: Use MessClimber for structured traversal
MessClimber *climber = MessClimber_Make(m, mess);
while((MessClimber_Next(climber) & END) == 0){
    Node *current = MessClimber_GetNode(climber);
    // Process node
}

// ACCEPTABLE: Manual recursion for simple cases
void ProcessNode(Node *node){
    // Handle current node
    if(node->typeOfChild == TYPE_NODE){
        ProcessNode((Node *)node->child);
    } else if(node->typeOfChild == TYPE_SPAN){
        // Iterate span children
    }
}
```

### 6. Lazy Attribute Allocation is Intentional

```c
// GOOD: Check for NULL before accessing attributes
if(node->atts != NULL){
    Str *className = Table_Get(node->atts, classKey);
    if(className != NULL){
        // Use className
    }
}

// BAD: Assuming attributes table exists
Str *className = Table_Get(node->atts, classKey);  // CRASH if atts is NULL
```

### 7. Understand Child Type Promotion

```c
// Initially empty
node->typeOfChild == ZERO

// Add first child
Mess_Append(mess, node, StrVec["first"]);
// node->typeOfChild == TYPE_STRVEC
// node->child → StrVec["first"]

// Add second child (incompatible type)
Mess_Append(mess, node, Node[...]);
// node->typeOfChild == TYPE_SPAN
// node->child → Span[StrVec["first"], Node[...]]

// Add third child
Mess_Append(mess, node, StrVec["third"]);
// node->typeOfChild == TYPE_SPAN (unchanged)
// node->child → Span[StrVec["first"], Node[...], StrVec["third"]]
```

### 8. Free Mess via MemCh

```c
// GOOD: Free entire tree with single call
MemCh *m = MemCh_Make();
Mess *mess = Mess_Make(m);
// ... build tree ...
MemCh_Free(m);  // Frees mess, all nodes, all content

// BAD: Attempting to free individual nodes
Node *node = mess->root;
free(node);  // WRONG: Allocated from MemCh, not malloc
```

### 9. Use Semantic Keys, Not Magic Numbers

```c
// GOOD: Named constants for semantic meaning
node->captureKey = FORMATTER_PARAGRAPH;
if(node->captureKey == FORMATTER_INDENT){
    // Handle heading
}

// BAD: Magic numbers
node->captureKey = 423;
if(node->captureKey == 421){
    // What does 421 mean?
}
```

### 10. Study Existing Formatters

The best way to understand Mess is to study working implementations:

- **Simple**: [src/ext/format/html/html_escape_roebling.c](../../../src/ext/format/html/html_escape_roebling.c) - HTML entity escaping
- **Moderate**: [src/ext/format/config/config_roebling.c](../../../src/ext/format/config/config_roebling.c) - Configuration parsing
- **Complex**: [src/ext/format/fmt/fmt_roebling.c](../../../src/ext/format/fmt/fmt_roebling.c) - Full document formatting
- **Advanced**: [src/inter/templ/templ_roebling.c](../../../src/inter/templ/templ_roebling.c) - Template engine

Each shows different patterns of token flags, nesting, and tree construction.

---


## Common Pitfalls and Solutions

### Pitfall 1: Forgetting TOKEN_OUTDENT

**Problem**:
```c
// Token definition missing TOKEN_OUTDENT
Tokenize_Make(m, FORMATTER_INDENT, TOKEN_ATTR_VALUE, TYPE_NODE);

// Input: "= Section 1\n\n= Section 2"
// Expected: Two headings at root level
// Actual: Second heading nested under first
```

**Why**: After creating the first heading node, `current` points to that heading. Without `TOKEN_OUTDENT`, the second heading is added as a child of the first instead of a sibling at root level.

**Solution**:
```c
// Add TOKEN_OUTDENT to exit nesting
Tokenize_Make(m, FORMATTER_INDENT, TOKEN_ATTR_VALUE|TOKEN_OUTDENT, TYPE_NODE);
```

**Effect**: After processing heading content, `current` returns to parent (root), so next heading is added at correct level.

### Pitfall 2: Incorrect Child Type Assumptions

**Problem**:
```c
// Assuming child is always StrVec
void PrintNode(Node *node){
    StrVec *sv = (StrVec *)node->child;  // CRASH if child is Node or Span
    // ...
}
```

**Why**: Nodes can have different child types (StrVec, Node, Span, Relation). Type casting without checking `typeOfChild` causes crashes.

**Solution**:
```c
void PrintNode(Node *node){
    if(node->typeOfChild == TYPE_STRVEC){
        StrVec *sv = (StrVec *)node->child;
        // Handle StrVec
    } else if(node->typeOfChild == TYPE_NODE){
        Node *childNode = (Node *)node->child;
        // Handle Node
    } else if(node->typeOfChild == TYPE_SPAN){
        Span *sp = (Span *)node->child;
        // Handle Span
    } else if(node->typeOfChild == TYPE_RELATION){
        Relation *rel = (Relation *)node->child;
        // Handle Relation
    }
}
```

**Better**: Use type system's `as()` macro for safe casting with runtime checks.

### Pitfall 3: Modifying Tree During Traversal

**Problem**:
```c
// Attempting to remove nodes while iterating
Iter it;
Iter_Init(&it, span);
while((Iter_Next(&it) & END) == 0){
    Node *node = Iter_Get(&it);
    if(ShouldRemove(node)){
        Span_Remove(span, node);  // UNDEFINED: Modifying during iteration
    }
}
```

**Why**: Modifying a Span while iterating over it invalidates the iterator state, causing undefined behavior (skipped elements, crashes).

**Solution**:
```c
// Collect nodes to remove first
Span *toRemove = Span_Make(m);
Iter it;
Iter_Init(&it, span);
while((Iter_Next(&it) & END) == 0){
    Node *node = Iter_Get(&it);
    if(ShouldRemove(node)){
        Span_Add(toRemove, node);
    }
}

// Remove after iteration complete
Iter removeIt;
Iter_Init(&removeIt, toRemove);
while((Iter_Next(&removeIt) & END) == 0){
    Span_Remove(span, Iter_Get(&removeIt));
}
```

### Pitfall 4: Losing Attributes with Premature Tokenize

**Problem**:
```c
// Order matters: attribute values must come before node creation
Mess_Tokenize(mess, tagToken, NULL);           // Creates node (no attributes)
Mess_Tokenize(mess, urlToken, StrVec["url"]);  // Adds to nextAtts (too late!)
```

**Why**: When tag node is created, `nextAtts` is moved to node's `atts` and cleared. Subsequent attribute values go into the *next* node's attributes, not this one.

**Solution**:
```c
// Attributes first, then node
Mess_Tokenize(mess, urlToken, StrVec["url"]);    // Adds to nextAtts
Mess_Tokenize(mess, classToken, StrVec["big"]);  // Adds to nextAtts
Mess_Tokenize(mess, tagToken, NULL);             // Creates node with both attributes
```

**Parser Design**: Ensure parser captures attributes before the element they belong to.

### Pitfall 5: Incorrectly Using TOKEN_BY_TYPE

**Problem**:
```c
// Using TOKEN_BY_TYPE for content that should combine
Tokenize_Make(m, FORMATTER_PARAGRAPH, TOKEN_BY_TYPE, TYPE_STRVEC);

// Input: "Line 1\nLine 2\nLine 3"
// Expected: Single paragraph with all lines
// Actual: Three separate paragraph nodes
```

**Why**: `TOKEN_BY_TYPE` creates a new node when the incoming type differs from existing child type. If each line is tokenized separately, each creates its own node.

**Solution**:
```c
// Remove TOKEN_BY_TYPE to allow combining
Tokenize_Make(m, FORMATTER_PARAGRAPH, ZERO, TYPE_STRVEC);

// OR: Combine lines before tokenizing
StrVec *allLines = CombineLines(lines);
Mess_Tokenize(mess, paragraphToken, allLines);
```

**When to Use**: `TOKEN_BY_TYPE` is correct for list items where each bullet should be separate even though they're the same type.

### Pitfall 6: Ignoring TOKEN_INLINE for Nested Elements

**Problem**:
```c
// Tag definition without TOKEN_INLINE
Tokenize_Make(m, FORMATTER_TAG, TOKEN_ATTR_VALUE, TYPE_NODE);

// Input: "Text with <link|url=...>link</link> continues"
// Expected: Paragraph with [text, link, text] as children
// Actual: Paragraph → text → link (deeply nested)
```

**Why**: Without `TOKEN_INLINE`, the link node becomes `current`, and subsequent text is added as a child of the link instead of a sibling.

**Solution**:
```c
// Add TOKEN_INLINE to exit nesting immediately
Tokenize_Make(m, FORMATTER_TAG, TOKEN_ATTR_VALUE|TOKEN_INLINE, TYPE_NODE);
```

**Effect**: Link is added to paragraph, then immediately exited, so next text is also added to paragraph (siblings, not parent-child).

### Pitfall 7: Memory Leaks from External Allocations

**Problem**:
```c
// Allocating content outside MemCh
char *str = malloc(100);
strcpy(str, "content");
StrVec *sv = StrVec_Make(m);
StrVec_Add(sv, Str_FromBytes(m, str, strlen(str)));

// Later: MemCh_Free(m)
// Result: 'str' buffer leaks (not in MemCh)
```

**Why**: Mess tree lives in MemCh, but external allocations (malloc) are not tracked. When MemCh is freed, external memory leaks.

**Solution**:
```c
// Allocate from MemCh or use stack
char str[100];
strcpy(str, "content");
StrVec *sv = StrVec_Make(m);
StrVec_Add(sv, Str_FromBytes(m, str, strlen(str)));

// OR: Copy into MemCh immediately
char *external = GetExternalString();
Str *s = Str_FromCstr(m, external);  // Copies into MemCh
free(external);  // Free external now
```

### Pitfall 8: Confusing captureKey and typeOfChild

**Problem**:
```c
// Checking typeOfChild instead of captureKey for semantic meaning
if(node->typeOfChild == TYPE_NODE){
    // This matches ALL nodes with Node children
    // Not specific to links, headings, etc.
}
```

**Why**: `typeOfChild` indicates child *type* (StrVec, Node, Span), not child *meaning*. Multiple semantic types can have same child type.

**Solution**:
```c
// Check captureKey for semantic meaning
if(node->captureKey == FORMATTER_TAG){
    // This specifically matches link/image tags
}
if(node->captureKey == FORMATTER_INDENT){
    // This specifically matches headings
}

// Check typeOfChild for iteration logic
if(node->typeOfChild == TYPE_SPAN){
    // Iterate multiple children
} else if(node->typeOfChild == TYPE_STRVEC){
    // Handle single StrVec
}
```

### Pitfall 9: Incorrect Relation Stride

**Problem**:
```c
// Creating relation with wrong stride
Relation *rel = Relation_Make(m, 3);  // Stride = 3

// Adding data (4 columns)
Relation_Add(rel, StrVec["Col1"]);
Relation_Add(rel, StrVec["Col2"]);
Relation_Add(rel, StrVec["Col3"]);
Relation_Add(rel, StrVec["Col4"]);  // Overflows to next row!
```

**Why**: Relation uses stride to determine row boundaries. After 3 cells, it wraps to next row, so 4th cell is treated as first cell of row 2.

**Solution**:
```c
// Match stride to actual column count
Relation *rel = Relation_Make(m, 4);  // Stride = 4
```

**Validation**: Count columns in first row to determine correct stride before creating Relation.

### Pitfall 10: Relying on Attribute Ordering

**Problem**:
```c
// Assuming attributes appear in specific order
Iter it;
Iter_Init(&it, node->atts);
void *firstKey = Iter_Get(&it);  // Assuming this is "url"
```

**Why**: Attributes are stored in a hash Table, which has no guaranteed ordering. Iteration order is based on hash values, not insertion order.

**Solution**:
```c
// Access attributes by key, not position
Str *url = Table_Get(node->atts, I16_Wrapped(m, FORMATTER_URL));
Str *className = Table_Get(node->atts, I16_Wrapped(m, FORMATTER_CLASS));
```

**Alternative**: If order matters, use a Span instead of Table for attributes (non-standard but possible).

---



---

[← Part 1](mess-complete-part1) | **Part 2 of 3** | [Part 3 →](mess-complete-part3)
