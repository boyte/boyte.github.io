# Relation (Tabular Data) System - Complete Guide - Part 2

[← Part 1](relation-complete-part1) | **Part 2 of 2**

---

## Common Pitfalls and Solutions

### Pitfall 1: Forgetting Relation_HeadFromValues

**Problem**:
```c
Relation *rel = Relation_Make(m, 0, NULL);
Relation_AddValue(rel, header1);
Relation_AddValue(rel, header2);
Relation_AddValue(rel, header3);
// Forgot to call Relation_HeadFromValues()
Relation_AddValue(rel, data1);
```

**Result**: `stride` remains 0, iteration immediately returns END, data not accessible.

**Solution**:
```c
Relation_HeadFromValues(rel);  // Extract headers, set stride = 3
Relation_AddValue(rel, data1);  // Now works correctly
```

### Pitfall 2: Mismatched Row Sizes

**Problem**:
```c
// Row 0: 3 values
Relation_AddValue(rel, v1);
Relation_AddValue(rel, v2);
Relation_AddValue(rel, v3);

// Row 1: Only 2 values!
Relation_AddValue(rel, v4);
Relation_AddValue(rel, v5);

// Row 2: 3 values
Relation_AddValue(rel, v6);
Relation_AddValue(rel, v7);
Relation_AddValue(rel, v8);
```

**Result**: Rows misaligned. Row 1 ends early, v6 treated as end of row 1 instead of start of row 2.

**Visual**:
```
Expected:
Row 0: [v1, v2, v3]
Row 1: [v4, v5, ??]
Row 2: [v6, v7, v8]

Actual (stride=3):
Row 0: [v1, v2, v3]
Row 1: [v4, v5, v6]  ← Wrong!
Row 2: [v7, v8, ??]  ← Wrong!
```

**Solution**: Always add exactly `stride` values per row, or use padding/NULL for missing cells.

### Pitfall 3: Using SetValue Before Stride Set

**Problem**:
```c
Relation *rel = Relation_Make(m, 0, NULL);
Relation_SetValue(rel, 0, 0, value);  // stride=0, calculation: 0*0+0 = 0
Relation_SetValue(rel, 1, 2, value);  // stride=0, calculation: 1*0+2 = 2
// All values go to wrong indices
```

**Result**: Index calculations are wrong, values placed incorrectly.

**Solution**:
```c
// Option 1: Set stride in constructor
Relation *rel = Relation_Make(m, 3, NULL);
Relation_SetValue(rel, 0, 0, value);  // Correct: 0*3+0 = 0

// Option 2: Extract headers first
Relation_HeadFromValues(rel);  // Sets stride
Relation_SetValue(rel, 0, 0, value);  // Correct calculation
```

### Pitfall 4: Not Resetting Iterator for Re-Iteration

**Problem**:
```c
// First iteration
while((Relation_Next(rel) & END) == 0){ /* ... */ }
// Iterator now at end

// Second iteration (WRONG)
while((Relation_Next(rel) & END) == 0){ /* ... */ }  // Immediately END
```

**Result**: Second loop never executes; iterator already exhausted.

**Solution**:
```c
Relation_ResetIter(rel);  // Reset to beginning
while((Relation_Next(rel) & END) == 0){ /* ... */ }  // Now works
```

### Pitfall 5: Accessing NULL Headers

**Problem**:
```c
Relation *rel = Relation_Make(m, 3, NULL);
// Add data but no headers extracted
for(i16 i = 0; i < rel->stride; i++){
    printf("%s ", (char *)rel->headers[i]);  // CRASH: headers is NULL
}
```

**Result**: Segmentation fault dereferencing NULL pointer.

**Solution**:
```c
if(rel->headers != NULL){
    for(i16 i = 0; i < rel->stride; i++){
        printf("%s ", (char *)rel->headers[i]);
    }
} else {
    printf("(no headers)\n");
}
```

### Pitfall 6: Modifying Relation During Iteration

**Problem**:
```c
while((Relation_Next(rel) & END) == 0){
    void *value = Iter_Get(&rel->it);
    if(ShouldDelete(value)){
        // Attempting to remove current value
        Span_Remove(rel->it.p, value);  // UNDEFINED BEHAVIOR
    }
}
```

**Result**: Iterator state invalid, may skip values or crash.

**Solution**:
```c
// Collect items to remove
Span *toRemove = Span_Make(m);
while((Relation_Next(rel) & END) == 0){
    void *value = Iter_Get(&rel->it);
    if(ShouldDelete(value)){
        Span_Add(toRemove, value);
    }
}

// Remove after iteration complete
Iter rmIt;
Iter_Init(&rmIt, toRemove);
while((Iter_Next(&rmIt) & END) == 0){
    Span_Remove(rel->it.p, Iter_Get(&rmIt));
}
```

### Pitfall 7: Confusing Column Index and Iterator Index

**Problem**:
```c
while((Relation_Next(rel) & END) == 0){
    i32 col = rel->it.idx;  // WRONG: This is flat index, not column
    printf("Column %d\n", col);
}
```

**Result**: Prints 0, 1, 2, 3, 4, 5, ... (flat indices), not 0, 1, 2, 0, 1, 2, ... (column indices).

**Solution**:
```c
while((Relation_Next(rel) & END) == 0){
    i32 col = rel->it.idx % rel->stride;  // Correct: column index
    i32 row = rel->it.idx / rel->stride;  // Row index
    printf("Row %d, Col %d\n", row, col);
}
```

### Pitfall 8: Assuming Stride Divides Evenly

**Problem**:
```c
Relation *rel = /* ... */;
i32 total = rel->it.p->max_idx + 1;  // 10 values
i32 rows = total / rel->stride;      // 10 / 3 = 3 rows

// Assuming 3 complete rows (9 values)
// But 10 values means partial 4th row!
```

**Result**: Last row incomplete, but code assumes all rows complete.

**Solution**:
```c
i32 complete_rows = Relation_RowCount(rel);  // Returns 3
i32 total = rel->it.p->max_idx + 1;          // 10
i32 remainder = total % rel->stride;         // 1 extra value

if(remainder > 0){
    printf("Warning: Incomplete final row with %d values\n", remainder);
}
```

### Pitfall 9: Header Array Lifecycle

**Problem**:
```c
// Headers extracted from Span
Relation_HeadFromValues(rel);  // rel->headers points to extracted array

// Later: Freeing MemCh frees headers array
MemCh_Free(m);

// Using headers after free
for(i16 i = 0; i < old_stride; i++){
    printf("%s ", (char *)old_rel->headers[i]);  // DANGLING POINTER
}
```

**Result**: Use-after-free, undefined behavior.

**Solution**: Never access Relation data after freeing its MemCh. Ensure proper lifecycle management.

### Pitfall 10: Row Boundary Flags Not Cleared

**Problem** (hypothetical if implementation didn't clear flags):
```c
// Implementation bug: flags not cleared between iterations
while((Relation_Next(rel) & END) == 0){
    if(rel->type.state & RELATION_ROW_START){
        // This might stay set from previous iteration
    }
}
```

**Solution**: Current implementation clears flags each iteration:
```c
rel->type.state &= ~(RELATION_ROW_START|RELATION_ROW_END);
```

This is correct. But when writing custom iteration, always clear flags between uses.

---


## Cross-References

### Related Core Concepts

- **[Mess (Message Tree)](mess-complete.md)**: Hierarchical tree structure that contains Relations as Node children
- **[Span](../memory/span-complete.md)**: Underlying storage for Relation values (flat sparse array)
- **[Iter](../memory/iter-complete.md)**: Iterator interface used for Relation traversal
- **[Type System](../type-system-complete.md)**: Runtime type identification, TYPE_RELATION constant
- **[Node](node-complete.md)**: Tree node structure that can have Relation as child type

### Format System Integration

- **[Format System Complete](../format-system-complete.md)**: How formatters use Relations for tabular data
- **[Fmt/Pencil Formatter](../../formats/pencil-fmt.md)**: Markdown-style table syntax that creates Relations

### Navigate System Components

- **[Task Execution Complete](task-execution-complete.md)**: Task/Step system that processes Relations
- **[Queue Complete](queue-complete.md)**: Queue management for task scheduling

### HTTP/Web Integration

- **[HTTP Lifecycle Complete](../http-lifecycle-complete.md)**: HTTP request/response handling
- **[WWW Routing Complete](../www-routing-complete.md)**: Web routing and page generation

### Implementation Files

**Core Implementation**:
- [src/ext/include/navigate/relation.h](../../../../src/ext/include/navigate/relation.h) - Relation structure definition
- [src/ext/navigate/relation.c](../../../../src/ext/navigate/relation.c) - Core Relation operations

**Mess Integration**:
- [src/ext/include/navigate/mess.h](../../../../src/ext/include/navigate/mess.h) - Mess structure definition
- [src/ext/navigate/mess.c](../../../../src/ext/navigate/mess.c) - Mess operations including Relation handling

**Formatter Integration**:
- [src/ext/format/fmt/fmt_html.c](../../../../src/ext/format/fmt/fmt_html.c) - HTML table generation
- [src/ext/format/fmt/fmt_tokenize.c](../../../../src/ext/format/fmt/fmt_tokenize.c) - Token definitions

**Type System**:
- [src/ext/navigate/navigate_cls.c](../../../../src/ext/navigate/navigate_cls.c) - Relation_Print and ToString
- [src/ext/navigate/compare.c](../../../../src/ext/navigate/compare.c) - Relation comparison

**Testing**:
- [src/programs/test/option/ext/relation_tests.c](../../../../src/programs/test/option/ext/relation_tests.c) - Comprehensive tests

**Related Headers**:
- [src/base/include/mem/span.h](../../../../src/base/include/mem/span.h) - Span structure
- [src/base/include/mem/iter.h](../../../../src/base/include/mem/iter.h) - Iterator interface
- [src/ext/include/types/range.h](../../../../src/ext/include/types/range.h) - Type constants

---


## Summary

The Relation system provides lightweight tabular data representation in Caneka:

1. **Flat + Stride Architecture**: Single Span with stride parameter converts 1D to 2D, excellent cache performance

2. **Row Boundary Detection**: Automatic ROW_START/ROW_END flags during iteration enable proper formatting

3. **Header Separation**: Column headers stored as metadata, not intermingled with data rows

4. **Mess Integration**: Relations serve as Node children, enabling tables in hierarchical documents

5. **Formatter Support**: HTML table generation, CSV export, debug printing all use Relation iteration

6. **Performance**: O(1) access, O(n) iteration, minimal memory overhead, cache-friendly

7. **Simplicity**: No complex indexing, no 2D arrays, no pointer indirection

8. **Flexibility**: Auto-detect stride from headers, random access via SetValue, sequential via iteration

9. **Testing**: Comprehensive test suite validates all operations

10. **Integration**: Used throughout Navigate, Mess, and Formatter subsystems

Understanding Relations is essential for working with tabular data in Caneka's parsing, formatting, and document systems. The flat+stride design exemplifies Caneka's philosophy of simple, efficient data structures with minimal abstraction overhead.



---

[← Part 1](relation-complete-part1) | **Part 2 of 2**
