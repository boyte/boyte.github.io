# Frame (Nested Iteration Context) - Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](frame-complete-part2)

---

## Core Philosophy

The **Frame** system is Caneka's mechanism for capturing iterator state snapshots during nested iteration. Think of it as a "stack frame" for data iteration—it preserves context when entering nested loops or hierarchies, then restores that context when exiting.

### The Stack Frame Analogy

Just as function calls use stack frames to preserve local variables and return addresses, nested iteration uses Frames to preserve iteration state:

**Function Stack Frame**:
- Saves registers and local variables
- Tracks return address
- Pops on function return

**Iteration Frame**:
- Saves iterator position and state
- Tracks origin context (where nesting started)
- Pops on nesting exit

This enables elegant nested loops in the Templ template engine without complex recursion or manual state management.

### Key Design Principles

1. **Snapshot Semantics**: Frame captures complete iterator state at a point in time, not just position.

2. **Stack-Based Nesting**: Frames are pushed onto a data stack when entering nested contexts, popped when exiting. LIFO (Last In, First Out) naturally matches nesting structure.

3. **Origin Tracking**: Each frame remembers where it came from (`originIdx`, `originKey`), enabling context awareness and debugging.

4. **Embedded Iterator**: Frame contains a full `Iter` structure, not just a reference. This provides isolation between nesting levels.

5. **Lightweight**: Despite containing an iterator, Frames are cheap to create (~140 bytes, O(1) allocation).

### Why Frame Exists

Traditional approaches to nested iteration face challenges:

**Recursion**:
- Deep recursion = stack overflow risk
- Hard to debug/trace
- Implicit state (hard to inspect)

**Manual State Management**:
- Error-prone bookkeeping
- Complex nesting logic
- Difficult to maintain

**Frame-Based Approach**:
- Explicit stack (inspectable, controllable)
- O(1) push/pop operations
- Clear nesting semantics
- Natural template flow

---


## Structure and Definitions

### The Frame Structure

Defined in [src/ext/include/navigate/frame.h](../../../../src/ext/include/navigate/frame.h):

```c
typedef struct nested_frame {
    Type type;              // TYPE_FRAME identifier
    i32 originIdx;          // Index in parent iterator where nesting began
    Abstract *originKey;    // Key/identifier from parent context
    Abstract *value;        // The value being tracked/wrapped
    Iter it;                // Iterator for this frame's nested collection
} Frame;
```

**Field Details**:

- **`type`**: Standard type metadata (type.of == TYPE_FRAME)

- **`originIdx`**: Position in the *parent* iterator where this nesting level originated. Used for context tracking and debugging.

- **`originKey`**: Key or identifier associated with the origin. For example, if iterating over a hash table and entering a nested collection, this would be the hash key.

- **`value`**: The abstract value being wrapped. Often the Span or collection being iterated at this level.

- **`it`**: **The core field**. A complete Iter structure initialized to traverse the nested collection. This iterator maintains its own position, flags, and state independent of parent iterators.

### Size and Layout

```
Frame Total Size: ~140-160 bytes
├── Type (8 bytes): type.of, type.state
├── originIdx (4 bytes): Parent position
├── originKey (8 bytes): Pointer to key
├── value (8 bytes): Pointer to wrapped value
└── Iter (120+ bytes): Complete iterator
    ├── Type (8 bytes)
    ├── objType (8 bytes)
    ├── idx (4 bytes): Current position
    ├── p (8 bytes): Pointer to Span
    ├── value (8 bytes): Current value
    ├── stack (56 bytes): Multi-dimensional traversal stack
    ├── stackIdx (56 bytes): Stack indices
    └── metrics (16 bytes): get/set/selected/available counters
```

The Iter structure dominates Frame's size, but this is intentional—complete state capture enables full isolation between nesting levels.

### Relationship to Iter

The `Iter` structure ([src/base/include/mem/iter.h](../../../../src/base/include/mem/iter.h)) is embedded within Frame:

```c
typedef struct iter {
    Type type;                      // Iterator type metadata
    Type objType;                   // Type of objects being iterated
    i32 idx;                        // Current index in collection
    struct span *p;                 // Span being iterated
    void *value;                    // Current value (cached)
    void *stack[SPAN_MAX_DIMS+1];   // Stack for multi-dim traversal
    i32 stackIdx[SPAN_MAX_DIMS+1];  // Indices for each stack level
    struct {
        i32 get, set, selected, available;
    } metrics;                      // Iteration metrics
} Iter;
```

**Key Point**: Frame doesn't just reference an iterator—it *contains* one. This provides complete isolation: advancing the frame's iterator doesn't affect parent iterators on the stack.

### Relationship to Span

Each Frame's iterator (`it`) points to a Span ([src/base/include/mem/span.h](../../../../src/base/include/mem/span.h)):

```c
typedef struct span {
    Type type;                      // TYPE_SPAN identifier
    i32 nvalues;                    // Number of values stored
    i32 max_idx;                    // Maximum index used
    struct mem_ctx *m;              // Memory context
    slab *root;                     // Root storage slab
} Span;
```

The Span is the actual collection being iterated. Frame wraps an iterator that traverses this Span.

**Hierarchy**:
```
Span (collection)
  ↓
Iter (traversal cursor)
  ↓
Frame (context snapshot)
  ↓
Data Stack (nested contexts)
  ↓
Template Execution
```

---


## Implementation Details

### Frame Creation: Frame_Make

Creating a new Frame ([src/ext/navigate/frame.c](../../../../src/ext/navigate/frame.c)):

```c
Frame *Frame_Make(MemCh *m, i32 originIdx, void *originKey, void *value, Span *p){
    Frame *fm = (Frame *)MemCh_Alloc(m, sizeof(Frame));
    fm->type.of = TYPE_FRAME;
    fm->originIdx = originIdx;
    fm->originKey = (Abstract *)originKey;
    fm->value = (Abstract *)value;

    // Initialize iterator for this frame's Span
    Iter_Init(&fm->it, p);

    return fm;
}
```

**Parameters**:
- `m`: Memory context for allocation
- `originIdx`: Where in parent this frame originated
- `originKey`: Key/identifier from parent context
- `value`: Wrapped value (often the collection itself)
- `p`: Span to iterate at this nesting level

**Initialization**:
- Allocates Frame structure
- Sets type to TYPE_FRAME
- Records origin information
- Initializes embedded iterator via `Iter_Init`

**Returns**: Fully initialized Frame ready for stack

### Frame Display: Frame_Print

Debug representation ([src/ext/navigate/navigate_cls.c](../../../../src/ext/navigate/navigate_cls.c)):

```c
static status Frame_Print(Buff *bf, void *a, cls type, word flags){
    Frame *fm = (Frame *)as(a, TYPE_FRAME);

    void *args[] = {
        I32_Wrapped(bf->m, fm->originIdx),
        fm->originKey,
        (fm->value != NULL ? Type_ToStr(bf->m, fm->value->type.of) : NULL),
        I32_Wrapped(bf->m, fm->it.idx),
        Iter_Current(&fm->it),
        NULL
    };

    return Fmt(bf, "Frame<from:@/@ @[@]>", args);
}
```

**Output Format**:
```
Frame<from:originIdx/originKey valueType[currentIdx->currentValue]>
```

**Example**:
```
Frame<from:5/Str<"items"> Span[2->Wi32<42>]>
```

Interpretation:
- Frame originated from index 5 in parent
- Parent key was string "items"
- Wrapping a Span
- Currently at index 2 in nested Span
- Current value is wrapped int32 with value 42

---


## Integration with Template System

The Frame system's primary use case is the **Templ template engine**, which uses a data stack to manage nested loops and contexts.

### The Templ Structure

From [src/inter/include/templ.h](../../../../src/inter/include/templ.h):

```c
typedef struct templ {
    Type type;              // TYPE_TEMPL identifier
    Type objType;           // Object type being templated
    Iter content;           // Instruction stream (template commands)
    Iter data;              // DATA STACK - stores iterators/frames
} Templ;
```

**Key Field**: `data` is an iterator on a Span that serves as a **stack**. When entering nested contexts, new iterators (wrapped in Frames conceptually) are pushed onto this stack.

### Nested Loop Handling

From [src/inter/templ/templ_jump.c](../../../../src/inter/templ/templ_jump.c):

```c
static status Templ_handleForJump(Templ *templ, TemplJump *jump, Abstract *data){
    i32 curIdx = templ->content.idx;
    Fetcher *fch = jump->fch;
    status r = READY;

    if((fch->type.state & PROCESSING) == 0){
        // ENTER NESTED LOOP: Create and push new iterator
        void *value = as(Fetch(templ->m, fch, data, NULL), TYPE_ITER);
        Iter_Add(&templ->data, value);  // PUSH onto stack
        fch->type.state |= PROCESSING;
    } else {
        if((fch->type.state & MORE) == 0){
            // EXIT NESTED LOOP: Pop iterator
            Iter_Remove(&templ->data);  // POP from stack
            Iter_Prev(&templ->data);    // Return to previous context
        }
    }

    // Access current frame (top of stack)
    Iter *it = (Iter *)Iter_Get(&templ->data);

    // Process current iteration level
    // ...
}
```

**Algorithm**:

1. **First entry to FOR loop**:
   - Fetch the collection to iterate
   - Create iterator for that collection
   - Push iterator onto data stack
   - Mark fetcher as PROCESSING

2. **Subsequent iterations**:
   - Access top-of-stack iterator
   - Advance iterator with `Iter_Next`
   - Process current value

3. **Loop exhausted**:
   - Remove iterator from stack (pop)
   - Move data stack iterator back to previous context
   - Continue with outer loop

### Stack Progression Example

Template with nested loops:
```html
<ul>
;   categories...        <!-- Push Frame 1 -->
    <li>
        <strong>{*name}</strong>
        <ul>
;           *items...    <!-- Push Frame 2 -->
            <li>{*title}</li>
;                        <!-- Pop Frame 2 -->
        </ul>
    </li>
;                        <!-- Pop Frame 1 -->
</ul>
```

**Execution Stack States**:

```
Initial:
  data.stack = []

After "categories..." (enter outer loop):
  data.stack = [Iter_over_categories]
  Current frame: Iter_over_categories
    - idx = 0
    - value = first category

After "*items..." (enter inner loop):
  data.stack = [Iter_over_categories, Iter_over_items]
  Current frame: Iter_over_items
    - idx = 0
    - value = first item of current category

After processing all items (exit inner loop):
  data.stack = [Iter_over_categories]
  Current frame: Iter_over_categories (restored)
    - idx = 0 (still on first category)
    - Ready to process next category

After processing all categories (exit outer loop):
  data.stack = []
  No current frame
```

### IterUpper Flags

From [src/ext/include/navigate/iter_upper.h](../../../../src/ext/include/navigate/iter_upper.h):

```c
enum iter_upper_flags {
    UFLAG_ITER_INVERT   = 1 << 8,    // Reverse iteration direction
    UFLAG_ITER_STRICT   = 1 << 9,    // Strict mode enforcement
    UFLAG_ITER_SELECTED = 1 << 10,   // Item is selected/active
    UFLAG_ITER_INDENT   = 1 << 11,   // Start nesting (enter child)
    UFLAG_ITER_OUTDENT  = 1 << 12,   // Exit nesting (return to parent)
    UFLAG_ITER_LEAF     = 1 << 13,   // Leaf node (no children)
    UFLAG_ITER_REPEAT   = 1 << 14,   // Repeat current iteration
};
```

These flags control high-level iteration semantics:

- **`UFLAG_ITER_INDENT`**: Signals that this item has children; create new Frame and descend
- **`UFLAG_ITER_OUTDENT`**: Exit current nesting level; pop Frame
- **`UFLAG_ITER_LEAF`**: No children; don't create Frame

Frames inherit and preserve these flags, maintaining proper nesting semantics across levels.

---


## Code Examples

### Example 1: Simple Frame Creation

```c
MemCh *m = MemCh_Make();

// Parent iterator at position 5
i32 parentIdx = 5;
Str *parentKey = Str_FromCstr(m, "submenu");

// Nested collection to iterate
Span *nestedItems = Span_Make(m);
Span_Add(nestedItems, Str_FromCstr(m, "Item 1"));
Span_Add(nestedItems, Str_FromCstr(m, "Item 2"));
Span_Add(nestedItems, Str_FromCstr(m, "Item 3"));

// Create frame for this nesting level
Frame *frame = Frame_Make(m, parentIdx, parentKey, nestedItems, nestedItems);

// frame->originIdx == 5
// frame->originKey points to "submenu"
// frame->value points to nestedItems Span
// frame->it is initialized to iterate nestedItems
```

### Example 2: Iterating Within a Frame

```c
Frame *frame = /* ... created as above ... */;

// Iterate the frame's collection
while((Iter_Next(&frame->it) & END) == 0){
    void *value = Iter_Get(&frame->it);
    printf("Item at index %d: %p\n", frame->it.idx, value);
}

// Output:
// Item at index 0: 0x... (Str<"Item 1">)
// Item at index 1: 0x... (Str<"Item 2">)
// Item at index 2: 0x... (Str<"Item 3">)
```

The frame's iterator maintains position independently of any parent iterator.

### Example 3: Manual Stack Management

```c
MemCh *m = MemCh_Make();

// Create data stack (mimicking Templ.data)
Span *dataStack = Span_Make(m);
Iter dataIt;
Iter_Init(&dataIt, dataStack);

// Outer collection
Span *outerSpan = Span_Make(m);
Span_Add(outerSpan, Str_FromCstr(m, "Category 1"));
Span_Add(outerSpan, Str_FromCstr(m, "Category 2"));

// Create outer iterator
Iter *outerIter = MemCh_AllocOf(m, sizeof(Iter), TYPE_ITER);
Iter_Init(outerIter, outerSpan);

// Push outer iterator onto stack
Iter_Add(&dataIt, outerIter);

// Advance outer iterator
Iter_Next(outerIter);
void *category = Iter_Get(outerIter);  // "Category 1"

// Create inner collection
Span *innerSpan = Span_Make(m);
Span_Add(innerSpan, Str_FromCstr(m, "Item 1.1"));
Span_Add(innerSpan, Str_FromCstr(m, "Item 1.2"));

// Create frame for inner level
Frame *innerFrame = Frame_Make(m, outerIter->idx, category, innerSpan, innerSpan);

// Push inner iterator onto stack
Iter_Add(&dataIt, &innerFrame->it);

// Now stack contains: [outerIter, innerFrame->it]
// dataIt.idx == 1 (pointing to second item, the inner iterator)

// Access current context (top of stack)
Iter *currentIt = (Iter *)Iter_Get(&dataIt);
// currentIt points to innerFrame->it

// Iterate inner level
while((Iter_Next(currentIt) & END) == 0){
    void *item = Iter_Get(currentIt);
    printf("Inner item: %p\n", item);
}

// Exit inner level: pop stack
Iter_Remove(&dataIt);
Iter_Prev(&dataIt);

// Now dataIt.idx == 0, pointing to outerIter again
```

This mimics how Templ manages nested FOR loops.

### Example 4: Multi-Level Nesting

```c
// Three-level nesting: Menu → Category → Item

// Level 0: Root (data stack)
Span *dataStack = Span_Make(m);
Iter dataIt;
Iter_Setup(&dataIt, dataStack, SPAN_OP_SET, 0);

// Level 1: Menu items
Span *menuSpan = Span_Make(m);
Span_Add(menuSpan, Str_FromCstr(m, "File"));
Span_Add(menuSpan, Str_FromCstr(m, "Edit"));

Iter *menuIter = MemCh_AllocOf(m, sizeof(Iter), TYPE_ITER);
Iter_Init(menuIter, menuSpan);
Iter_Add(&dataIt, menuIter);  // Stack: [menuIter]

// Navigate to "File"
Iter_Next(menuIter);

// Level 2: Categories under "File"
Span *catSpan = Span_Make(m);
Span_Add(catSpan, Str_FromCstr(m, "Recent"));
Span_Add(catSpan, Str_FromCstr(m, "Open"));

Frame *catFrame = Frame_Make(m, menuIter->idx, Str_FromCstr(m, "File"),
                              catSpan, catSpan);
Iter_Add(&dataIt, &catFrame->it);  // Stack: [menuIter, catFrame->it]

// Navigate to "Recent"
Iter_Next(&catFrame->it);

// Level 3: Items under "Recent"
Span *itemSpan = Span_Make(m);
Span_Add(itemSpan, Str_FromCstr(m, "doc1.txt"));
Span_Add(itemSpan, Str_FromCstr(m, "doc2.txt"));

Frame *itemFrame = Frame_Make(m, catFrame->it.idx, Str_FromCstr(m, "Recent"),
                               itemSpan, itemSpan);
Iter_Add(&dataIt, &itemFrame->it);  // Stack: [menuIter, catFrame->it, itemFrame->it]

// Now at deepest nesting level
// dataIt.idx == 2 (three items on stack)

// Process items
while((Iter_Next(&itemFrame->it) & END) == 0){
    Str *doc = (Str *)Iter_Get(&itemFrame->it);
    printf("Document: %.*s\n", doc->len, doc->bytes);
}

// Exit level 3
Iter_Remove(&dataIt);
Iter_Prev(&dataIt);
// Stack: [menuIter, catFrame->it]

// Exit level 2
Iter_Remove(&dataIt);
Iter_Prev(&dataIt);
// Stack: [menuIter]

// Continue with menu...
```

### Example 5: Frame Origin Tracking

```c
// Create parent collection with keys
Table *parent = Table_Make(m);
Table_Set(parent, Str_FromCstr(m, "users"), userSpan);
Table_Set(parent, Str_FromCstr(m, "posts"), postSpan);

// Iterate parent
Iter parentIt;
Iter_Init(&parentIt, parent);
while((Iter_Next(&parentIt) & END) == 0){
    TablePair *pair = (TablePair *)Iter_Get(&parentIt);
    Str *key = (Str *)pair->key;
    Span *childSpan = (Span *)pair->value;

    // Create frame tracking origin
    Frame *frame = Frame_Make(m,
        parentIt.idx,        // Parent position
        key,                 // Parent key ("users" or "posts")
        childSpan,           // Nested collection
        childSpan);          // Iterate nested collection

    // Process nested items
    while((Iter_Next(&frame->it) & END) == 0){
        void *item = Iter_Get(&frame->it);

        // Origin info available:
        printf("Processing item from parent[%d] (key: %.*s)\n",
               frame->originIdx,
               ((Str *)frame->originKey)->len,
               ((Str *)frame->originKey)->bytes);
    }
}
```

This enables tracing back to the parent context that spawned each frame.

### Example 6: Debugging with Frame_Print

```c
Frame *frame = /* ... */;

Buff *bf = Buff_Make(m, ZERO);
Frame_Print(bf, frame, TYPE_FRAME, MORE|DEBUG);

// Output to buffer, then print
Str *output = Buff_ToStr(bf);
printf("%.*s\n", output->len, output->bytes);

// Example output:
// Frame<from:3/Str<"items"> Span[1->Str<"Item 2">]>
```

Useful for understanding stack state during template execution or debugging nested iteration issues.

### Example 7: Frame with Multi-Dimensional Span

```c
// Create 2D Span (matrix-like data)
Span *matrix = Span_Make(m);
Span_SetDim(matrix, 2);  // 2 dimensions

// Add data in nested structure
for(i32 row = 0; row < 3; row++){
    Span *rowSpan = Span_Make(m);
    for(i32 col = 0; col < 4; col++){
        Span_Add(rowSpan, I32_Wrapped(m, row * 10 + col));
    }
    Span_Add(matrix, rowSpan);
}

// Create frame for outer dimension
Frame *outerFrame = Frame_Make(m, 0, NULL, matrix, matrix);

// Iterate rows
while((Iter_Next(&outerFrame->it) & END) == 0){
    Span *row = (Span *)Iter_Get(&outerFrame->it);

    // Create frame for inner dimension (row)
    Frame *innerFrame = Frame_Make(m, outerFrame->it.idx, NULL, row, row);

    // Iterate columns
    while((Iter_Next(&innerFrame->it) & END) == 0){
        i32 *val = (i32 *)Iter_Get(&innerFrame->it);
        printf("[%d,%d]=%d ", outerFrame->it.idx, innerFrame->it.idx, *val);
    }
    printf("\n");
}

// Output:
// [0,0]=0 [0,1]=1 [0,2]=2 [0,3]=3
// [1,0]=10 [1,1]=11 [1,2]=12 [1,3]=13
// [2,0]=20 [2,1]=21 [2,2]=22 [2,3]=23
```

Frames naturally support multi-dimensional iteration through nested Spans.

---


## Performance Characteristics

### Time Complexity

| Operation | Complexity | Notes |
|---|---|---|
| `Frame_Make` | O(1) | Single allocation, Iter_Init is O(1) |
| Push frame to stack | O(1) | `Iter_Add` on Span |
| Pop frame from stack | O(1) | `Iter_Remove` on Span |
| Access current frame | O(1) | `Iter_Get` from stack |
| Iterate within frame | O(n) | n = size of nested collection |
| Context switch (pop + prev) | O(1) | Pointer updates only |

### Space Complexity

| Component | Size | Notes |
|---|---|---|
| Frame structure | ~140 bytes | Dominated by embedded Iter (~120 bytes) |
| Stack overhead | O(d) | d = maximum nesting depth |
| Per-level overhead | ~140 bytes | One Frame per nesting level |
| Total for depth d | O(d * 140) | Linear in nesting depth |

**Example**: 5-level nesting = ~700 bytes of Frame overhead (negligible).

### Memory Characteristics

**Allocation Pattern**:
- Frames allocated from MemCh (memory context)
- Entire stack freed when MemCh freed
- No manual cleanup required

**Locality**:
- Frames stored in Span (sequential allocation)
- Good cache locality when accessing stack
- Iterator state changes are local (no pointer chasing)

**Overhead**:
- Minimal for typical nesting depths (< 10 levels)
- Embedded Iter provides complete isolation (worth the cost)
- No hidden allocations or indirection

### Scalability

**Typical Use Cases**:
- **Template nesting**: 2-4 levels typical, 10 levels extreme
- **Menu hierarchies**: 3-5 levels typical
- **Document trees**: 5-10 levels possible

**Performance Impact**:
- **Shallow nesting** (< 5 levels): No measurable overhead
- **Medium nesting** (5-15 levels): < 2KB total, negligible
- **Deep nesting** (> 15 levels): Consider architectural redesign

**Comparison to Alternatives**:
- **Recursion**: Stack overflow risk at deep nesting, harder to debug
- **Manual state**: More memory for tracking, complex logic
- **Frame-based**: Optimal balance of performance and clarity

---


## Best Practices

### 1. Use Frames for Explicit Nesting

```c
// GOOD: Create frame when entering nested context
Frame *frame = Frame_Make(m, parentIdx, parentKey, childSpan, childSpan);
Iter_Add(&dataStack, &frame->it);

// Process nested items
while((Iter_Next(&frame->it) & END) == 0){
    // ...
}

// Pop when done
Iter_Remove(&dataStack);
Iter_Prev(&dataStack);

// BAD: Trying to manage state manually
i32 savedIdx = parentIt.idx;
void *savedValue = parentIt.value;
// ... iterate child ...
parentIt.idx = savedIdx;  // FRAGILE: misses other state
```

### 2. Always Pop Frames in LIFO Order

```c
// GOOD: Proper LIFO (stack) order
Iter_Add(&stack, frame1);  // Push
Iter_Add(&stack, frame2);  // Push
Iter_Remove(&stack);       // Pop frame2
Iter_Prev(&stack);
Iter_Remove(&stack);       // Pop frame1
Iter_Prev(&stack);

// BAD: Out-of-order removal
Iter_Add(&stack, frame1);
Iter_Add(&stack, frame2);
Iter_Remove(&stack);       // Remove frame1 first? WRONG ORDER
```

Violating LIFO breaks stack invariants and corrupts state.

### 3. Track Origin for Debugging

```c
// GOOD: Meaningful origin tracking
Frame *frame = Frame_Make(m,
    parentIt.idx,
    currentKey,  // Helpful for debugging
    childSpan,
    childSpan);

// Later when debugging:
printf("Frame originated from index %d, key %p\n",
       frame->originIdx, frame->originKey);

// BAD: No origin tracking
Frame *frame = Frame_Make(m, 0, NULL, childSpan, childSpan);
// Lost context information!
```

### 4. Use Frame_Print for Inspection

```c
// GOOD: Debug frame state
Buff *bf = Buff_Make(m, ZERO);
Frame_Print(bf, frame, TYPE_FRAME, DEBUG);
// Outputs: Frame<from:5/Str<"items"> Span[2->...]>

// Helps identify:
// - Where frame came from (from:5)
// - What key originated it (/"items")
// - Current position (Span[2->...])
```

### 5. Prefer Frames Over Recursion for Templates

```c
// GOOD: Iterative with frames (Templ approach)
while((Iter_Next(&currentFrame->it) & END) == 0){
    if(ShouldNest(value)){
        Frame *newFrame = CreateNestedFrame(...);
        PushFrame(stack, newFrame);
    }
}

// LESS GOOD: Recursive approach
void ProcessNode(Node *node){
    for(Node *child : node->children){
        ProcessNode(child);  // Recursion
    }
}
```

Frames provide explicit control and avoid stack overflow.

### 6. Check Frame Validity

```c
// GOOD: Validate frame before use
if(frame != NULL && frame->type.of == TYPE_FRAME){
    // Safe to use
    Iter_Next(&frame->it);
}

// BAD: Assuming frame is valid
Iter_Next(&frame->it);  // CRASH if frame is NULL or wrong type
```

### 7. Free Frames via MemCh

```c
// GOOD: Allocate from MemCh, auto-free
MemCh *m = MemCh_Make();
Frame *frame = Frame_Make(m, ...);
// ... use frame ...
MemCh_Free(m);  // Frees frame automatically

// BAD: Manual malloc/free
Frame *frame = malloc(sizeof(Frame));  // WRONG
free(frame);  // Doesn't work with Caneka's system
```

### 8. Understand Iter Isolation

```c
// Each frame has independent iterator state
Frame *outerFrame = Frame_Make(m, 0, NULL, outerSpan, outerSpan);
Frame *innerFrame = Frame_Make(m, 0, NULL, innerSpan, innerSpan);

// Advancing inner doesn't affect outer
Iter_Next(&innerFrame->it);  // innerFrame.it.idx = 1
// outerFrame.it.idx is unchanged

// This is BY DESIGN: frames provide isolation
```

### 9. Use for Navigation Structures

```c
// GOOD: Frames natural for hierarchical navigation
Frame *menuFrame = CreateMenuFrame();
while((Iter_Next(&menuFrame->it) & END) == 0){
    MenuItem *item = Iter_Get(&menuFrame->it);

    if(item->type.state & UFLAG_ITER_INDENT){
        // Enter submenu
        Frame *submenuFrame = CreateSubmenuFrame(item);
        PushFrame(stack, submenuFrame);
    }
}
```

### 10. Study Templ Implementation

The best way to understand Frames is to study the Templ template engine:

- [src/inter/templ/templ_jump.c](../../../../src/inter/templ/templ_jump.c) - FOR loop handling
- [src/inter/templ/templ.c](../../../../src/inter/templ/templ.c) - Data stack management
- [documentation/docs/core-concepts/templ-complete.md](../templ-complete.md) - Complete Templ guide

---



---

**Part 1 of 2** | [Part 2 →](frame-complete-part2)
