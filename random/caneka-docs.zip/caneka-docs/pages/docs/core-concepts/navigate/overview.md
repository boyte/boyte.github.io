---
sidebar_position: 1
---

# Navigate System Overview

Navigate is Caneka's Task/Step workflow management system, providing asynchronous operation handling and queue management.

## Core Concepts

### Task
A unit of work composed of multiple steps.

### Step
An individual operation within a task.

### Queue
Critical section management for task ordering.

### Frame
Execution context for tasks.

## Purpose

Handle asynchronous workflows with:
- Task scheduling
- Step execution
- Queue management
- Dependency handling

## Location

**Source**: `src/ext/navigate/`
**Headers**: `src/ext/include/navigate/task.h`

## Basic Usage

```c
Task *task = Task_Make();
Task_AddStep(task, my_function, data);
Task_Execute(task);
```

## See Also

- [Task System Details](task-system.md)
- [Ext Layer](../../architecture/ext-layer.md)
