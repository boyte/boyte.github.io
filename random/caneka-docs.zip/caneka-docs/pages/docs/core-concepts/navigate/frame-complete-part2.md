# Frame (Nested Iteration Context) - Complete Guide - Part 2

[← Part 1](frame-complete-part1) | **Part 2 of 2**

---

## Common Pitfalls and Solutions

### Pitfall 1: Forgetting to Pop Frames

**Problem**:
```c
// Enter nested context
Frame *frame = Frame_Make(m, idx, key, span, span);
Iter_Add(&stack, &frame->it);

// Process items
while((Iter_Next(&frame->it) & END) == 0){
    // ...
}

// Forgot to pop!
// Next iteration still thinks we're nested
```

**Result**: Stack grows unbounded, wrong context active, state corruption.

**Solution**:
```c
// Always pop after nested iteration complete
Iter_Remove(&stack);
Iter_Prev(&stack);
```

**Best Practice**: Use RAII-style patterns or ensure every push has matching pop.

### Pitfall 2: Accessing Wrong Iterator

**Problem**:
```c
Frame *outerFrame = /* ... */;
Frame *innerFrame = /* ... */;
Iter_Add(&stack, &outerFrame->it);
Iter_Add(&stack, &innerFrame->it);

// Processing inner level
while((Iter_Next(&outerFrame->it) & END) == 0){  // WRONG: using outer!
    // Should be using innerFrame->it
}
```

**Result**: Iterating wrong collection, outer frame advances incorrectly.

**Solution**:
```c
// Always use current frame (top of stack)
Iter *currentIt = (Iter *)Iter_Get(&stack);
while((Iter_Next(currentIt) & END) == 0){
    // Correct context
}
```

### Pitfall 3: Modifying Frame After Pushing

**Problem**:
```c
Frame *frame = Frame_Make(m, 0, NULL, span, span);
Iter_Add(&stack, &frame->it);

// Later: trying to modify frame
frame->originIdx = 10;  // Changes affect stack!
```

**Result**: Unexpected behavior; stack holds pointer to frame, so modifications are visible.

**Solution**: Treat frames as immutable after pushing. Create new frame if changes needed.

### Pitfall 4: Stack Index Confusion

**Problem**:
```c
Iter_Add(&stack, frame1);  // stack.idx = 0
Iter_Add(&stack, frame2);  // stack.idx = 1

Iter *current = Iter_Get(&stack);  // Gets frame2 (current)
// But stack.idx is 1, not 2!
```

**Result**: Confusion about what stack.idx represents.

**Understanding**: `stack.idx` points to *current* item (0-indexed), not count. After two pushes, idx=1 (second item, which is top of stack).

### Pitfall 5: Ignoring Origin Context

**Problem**:
```c
// Creating frame without tracking origin
Frame *frame = Frame_Make(m, 0, NULL, span, span);

// Later: need to know where this came from
// No information available!
```

**Result**: Hard to debug, lost context.

**Solution**:
```c
Frame *frame = Frame_Make(m,
    parentIt.idx,      // Where in parent?
    parentKey,         // What key led here?
    span,
    span);

// Now can trace back:
printf("Came from parent[%d] via key %p\n",
       frame->originIdx, frame->originKey);
```

### Pitfall 6: Not Handling Empty Collections

**Problem**:
```c
Frame *frame = Frame_Make(m, idx, key, emptySpan, emptySpan);
Iter_Add(&stack, &frame->it);

while((Iter_Next(&frame->it) & END) == 0){
    // Never executes if emptySpan has no items
    // But frame is still on stack!
}

// Forgot to pop even though no iterations happened
```

**Result**: Stack left in incorrect state.

**Solution**:
```c
Frame *frame = Frame_Make(m, idx, key, span, span);
Iter_Add(&stack, &frame->it);

while((Iter_Next(&frame->it) & END) == 0){
    // ...
}

// Always pop, even if loop didn't execute
Iter_Remove(&stack);
Iter_Prev(&stack);
```

### Pitfall 7: Exceeding Practical Nesting Depth

**Problem**:
```c
// Extremely deep nesting (50+ levels)
for(i32 i = 0; i < 50; i++){
    Frame *frame = Frame_Make(m, i, NULL, GetLevel(i), GetLevel(i));
    Iter_Add(&stack, &frame->it);
}

// 50 * 140 bytes = ~7KB of stack
// Plus iterator overhead
```

**Result**: While technically possible, extremely deep nesting suggests design issue.

**Solution**: Re-evaluate data structure or use flattening strategies. Most real-world use cases need < 10 levels.

### Pitfall 8: Type Confusion

**Problem**:
```c
// Pushing raw Iter instead of Frame
Iter *rawIt = MemCh_AllocOf(m, sizeof(Iter), TYPE_ITER);
Iter_Init(rawIt, span);
Iter_Add(&stack, rawIt);  // Pushing Iter, not Frame

// Later: trying to access as Frame
Frame *frame = (Frame *)Iter_Get(&stack);  // TYPE MISMATCH!
frame->originIdx;  // Accessing random memory!
```

**Result**: Type mismatch, undefined behavior.

**Solution**:
```c
// Use proper types consistently
Frame *frame = Frame_Make(m, idx, key, span, span);
Iter_Add(&stack, &frame->it);  // Pushing Iter embedded in Frame

// Access correctly:
Iter *it = (Iter *)Iter_Get(&stack);  // Get Iter, not Frame
```

**Note**: Templ pushes Iterators, not Frames directly. Frame is a conceptual wrapper used when origin tracking is needed.

### Pitfall 9: Leaking Frames

**Problem**:
```c
MemCh *m1 = MemCh_Make();
Frame *frame = Frame_Make(m1, idx, key, span, span);

MemCh *m2 = MemCh_Make();
Iter_Add(&stackInM2, &frame->it);  // Frame in m1, stack in m2

MemCh_Free(m1);  // Frees frame
// stackInM2 now has dangling pointer!
```

**Result**: Use-after-free when accessing stack.

**Solution**: Ensure frames and stacks share the same MemCh lifecycle, or manage carefully.

### Pitfall 10: Nested Iteration Without Frames

**Problem**:
```c
// Trying to nest without frames
Iter outerIt;
Iter_Init(&outerIt, outerSpan);

while((Iter_Next(&outerIt) & END) == 0){
    Span *innerSpan = (Span *)Iter_Get(&outerIt);

    Iter innerIt;
    Iter_Init(&innerIt, innerSpan);

    while((Iter_Next(&innerIt) & END) == 0){
        // This works for simple cases
        // But complex state management becomes error-prone
    }
}
```

**Why it's fragile**:
- No explicit stack (hard to inspect)
- Can't easily track where you came from
- Difficult to implement template-style jumps
- Breaks down with conditional nesting

**Solution**: Use frames for clarity and maintainability, even if simple nesting "works":
```c
Frame *frame = Frame_Make(m, outerIt.idx, key, innerSpan, innerSpan);
Iter_Add(&stack, &frame->it);
// Now state is explicit and manageable
```

---


## Cross-References

### Related Core Concepts

- **[Iter (Iterator) Complete](../memory/iter-complete.md)**: Complete iterator system that Frame wraps
- **[Span Complete](../memory/span-complete.md)**: Collections that Frame iterates
- **[Mess (Message Tree) Complete](mess-complete.md)**: Hierarchical trees that could use Frames for traversal
- **[Templ Complete](../templ-complete.md)**: **Primary user of Frames** - template engine with nested loops
- **[Type System Complete](../type-system-complete.md)**: Runtime type identification, TYPE_FRAME constant

### Template Integration

- **[Templ Complete](../templ-complete.md)**: Complete guide to template engine's use of data stack
- **[Templ Format](../../formats/templ.md)**: Template syntax that creates nested execution contexts

### Navigate System Components

- **[Task Execution Complete](task-execution-complete.md)**: Task/Step system
- **[Queue Complete](queue-complete.md)**: Queue management
- **[Relation Complete](relation-complete.md)**: Tabular data iteration

### Implementation Files

**Core Implementation**:
- [src/ext/include/navigate/frame.h](../../../../src/ext/include/navigate/frame.h) - Frame structure definition
- [src/ext/navigate/frame.c](../../../../src/ext/navigate/frame.c) - Frame_Make implementation
- [src/ext/navigate/navigate_cls.c](../../../../src/ext/navigate/navigate_cls.c) - Frame_Print display

**Template System Usage**:
- [src/inter/templ/templ_jump.c](../../../../src/inter/templ/templ_jump.c) - FOR loop frame management
- [src/inter/templ/templ.c](../../../../src/inter/templ/templ.c) - Template data stack
- [src/inter/include/templ.h](../../../../src/inter/include/templ.h) - Templ structure

**Iterator System**:
- [src/base/include/mem/iter.h](../../../../src/base/include/mem/iter.h) - Iter structure
- [src/base/mem/iter.c](../../../../src/base/mem/iter.c) - Iter operations
- [src/ext/include/navigate/iter_upper.h](../../../../src/ext/include/navigate/iter_upper.h) - High-level flags

**Related Systems**:
- [src/base/include/mem/span.h](../../../../src/base/include/mem/span.h) - Span structure
- [src/ext/include/types/range.h](../../../../src/ext/include/types/range.h) - Type constants

---


## Summary

The Frame system provides elegant nested iteration context management in Caneka:

1. **Snapshot Semantics**: Frames capture complete iterator state at nesting points

2. **Stack-Based Design**: LIFO push/pop naturally matches template nesting structure

3. **Origin Tracking**: Each frame remembers where it came from (index and key)

4. **Embedded Iterator**: Complete Iter structure provides isolation between levels

5. **Template Integration**: Primary use case is Templ engine's nested FOR loops

6. **Lightweight**: ~140 bytes per frame, O(1) operations, minimal overhead

7. **Explicit State**: Stack is inspectable, controllable, debuggable

8. **Performance**: O(1) push/pop, excellent cache locality, linear space in depth

9. **Best Practices**: Use for explicit nesting, maintain LIFO order, track origin

10. **Simplicity**: Clean abstraction over manual state management

Understanding Frames is essential for working with Caneka's template engine and any system requiring explicit nested iteration context management. The Frame system exemplifies Caneka's philosophy of making implicit state explicit and providing simple, inspectable primitives for complex operations.



---

[← Part 1](frame-complete-part1) | **Part 2 of 2**
