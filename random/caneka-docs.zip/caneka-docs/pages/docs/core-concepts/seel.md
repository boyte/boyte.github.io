---
sidebar_position: 3
---

# Seel Type System

Seel is Caneka's object property caching and class system, providing efficient type management.

## Overview

Seel provides:
- Property caching for performance
- Object lifecycle management
- Interface definitions
- Type instantiation

## Location

**Source**: `src/ext/types/`
**Headers**: `src/ext/include/types/seel.h`

## Purpose

Optimize object property access through caching while maintaining type safety.

## Benefits

- Faster property lookups
- Reduced memory access
- Type-safe operations
- Object lifecycle management

## See Also

- [Ext Layer](../architecture/ext-layer.md)
- [Base Types](../api-reference/base.md#types)
