# Doc Module: Complete Guide - Part 3

[← Part 2](doc-module-complete-part2) | **Part 3 of 3**

---

## Common Pitfalls

### Pitfall 1: Re-parsing on Every Request

**Problem**:
```c
// Inside request handler
StrVec *content = File_ToVec(m, "page.fmt");
Cursor *curs = Cursor_Make(m, content);
Roebling *rbl = FormatFmt_Make(m, curs, NULL);
Roebling_Run(rbl);  // Wasteful!
```

**Why It's Bad**: Parsing is 4-17x slower than generation. Re-parsing wastes CPU and increases latency.

**Solution**: Parse once at startup, cache Mess in route.

### Pitfall 2: Memory Leaks in Long-Running Servers

**Problem**:
```c
// Application-level MemCh never freed
MemCh *m = MemCh_Make();

while(true){
    HandleRequest(m);  // Allocations accumulate!
}
```

**Why It's Bad**: Request allocations accumulate in application MemCh, causing memory growth.

**Solution**: Use separate MemCh for each request:
```c
while(true){
    MemCh *reqM = MemCh_Make();
    HandleRequest(reqM);
    MemCh_Free(reqM);  // Clean up after request
}
```

### Pitfall 3: Forgetting HTML Entity Escaping

**Problem**:
```c
// Custom generator without escaping
ToS(ctx->bf, userContent, 0, ZERO);  // XSS vulnerable!
```

**Why It's Bad**: Allows XSS attacks via malicious content like `<script>alert('XSS')</script>`.

**Solution**: Always escape:
```c
HtmlEnt_IntoVec(m, ctx->htmlEntRbl, userContent);
ToS(ctx->bf, ctx->htmlEntRbl->dest, 0, ZERO);
```

### Pitfall 4: Assuming Thread-Safety of Mess Trees

**Problem**:
```c
// Thread 1
Fmt_ToHtml(bf1, mess);

// Thread 2 (concurrent)
mess->current = someNode;  // UNSAFE! Modifying shared Mess
```

**Why It's Bad**: Mess trees should be read-only after parsing. Modifying them during generation causes race conditions.

**Solution**: Treat Mess as immutable. Use TranspCtx for generation state, not Mess fields.

### Pitfall 5: Ignoring Parse Errors

**Problem**:
```c
Roebling_Run(rbl);
Mess *mess = (Mess *)rbl->dest;
Fmt_ToHtml(bf, mess);  // mess might be NULL or corrupt!
```

**Why It's Bad**: Corrupted Mess trees can cause crashes or garbage output.

**Solution**: Always check status:
```c
status r = Roebling_Run(rbl);
if(r & ERROR){
    return ERROR;
}
```

### Pitfall 6: Very Long Lines

**Problem**:
```pencil
This is a paragraph with an extremely long line that goes on and on and on and on and on... (5000+ characters)
```

**Why It's Bad**: Long lines cause poor cache locality and slower parsing. StrVec gap buffer operations degrade.

**Solution**: Break long lines in source documents:
```pencil
This is a paragraph with reasonable line breaks.
It flows naturally across multiple lines.
```

### Pitfall 7: Mixing Parse and Generation Memory

**Problem**:
```c
MemCh *m = MemCh_Make();
Mess *mess = ParseFmt(m, path);  // Allocates in m

// Later, try to free m while mess is still in use
MemCh_Free(m);  // Mess is now dangling!
```

**Why It's Bad**: Mess tree references freed memory.

**Solution**: Keep parse memory alive as long as Mess is needed:
```c
MemCh *appM = MemCh_Make();
Mess *mess = ParseFmt(appM, path);

// Never free appM while mess is in use
```

### Pitfall 8: Not Handling Guard Violations

**Problem**:
```c
Roebling_Run(rbl);
// Ignore guard violations
```

**Why It's Bad**: Guard violations indicate infinite loops or runaway recursion. Ignoring them allows hangs.

**Solution**: Check for guards:
```c
status r = Roebling_Run(rbl);

if(rbl->type.state & GUARD_ERROR){
    Error(m, FUNCNAME, FILENAME, LINENUMBER, "Guard violation in parser", NULL);
    return ERROR;
}
```

### Pitfall 9: Inefficient String Building

**Problem**:
```c
// Multiple tiny ToS calls
for(i32 i = 0; i < 1000; i++){
    ToS(bf, S(m, "<LI>"), 0, ZERO);
    ToS(bf, items[i], 0, ZERO);
    ToS(bf, S(m, "</LI>"), 0, ZERO);
}
```

**Why It's Bad**: Each ToS() call has overhead. Many small calls are inefficient.

**Solution**: Batch or use formatting functions:
```c
for(i32 i = 0; i < 1000; i++){
    StrVec_Appendf(bf->v, "<LI>%s</LI>", Str_Chars(items[i]));
}
```

### Pitfall 10: Assuming Mess Structure Without Validation

**Problem**:
```c
Node *heading = mess->root->child;  // Assumes specific structure
Str *title = (Str *)heading->value;  // Might crash!
```

**Why It's Bad**: Document structure varies. Assumptions about specific layouts are fragile.

**Solution**: Traverse tree safely:
```c
Iter it;
Iter_Init(&it, mess->root);

while((Iter_Next(&it) & END) == 0){
    Node *node = (Node *)Iter_Get(&it);

    if(node->captureKey == FORMATTER_INDENT){
        // Found heading
        Str *title = (Str *)node->value;
        break;
    }
}
```

### Pitfall 11: Large Mess Tree Memory Consumption

**Problem**: Caching 1000 documents × 10KB each × 30x bloat = 300MB memory.

**Why It's Bad**: Excessive memory usage for large document collections.

**Solution**: Either:
1. Accept memory usage (appropriate for small collections)
2. Implement LRU cache with limited size
3. Re-parse on demand for rarely accessed documents

### Pitfall 12: Not Testing Edge Cases

**Problem**: Only testing well-formed documents.

**Why It's Bad**: Malformed inputs can crash the parser or generator.

**Solution**: Test edge cases:
```c
// Empty file
// Files with only whitespace
// Files with very long lines
// Files with unusual Unicode
// Files with missing closing markers
```


## Cross-References

### Related Core Concepts

- **[Roebling Parser](parser/pattern-matching.md)** - Pattern matching system used by Fmt parser
- **[Mess (Message Tree)](navigate/mess-complete.md)** - Tree structure for parsed documents
- **[Node](navigate/node-complete.md)** - Tree elements within Mess
- **[StrVec](strings-complete.md)** - String vector for text content
- **[Cursor](strings-complete.md#cursor)** - Text navigation during parsing
- **[Iter](memory/iter-complete.md)** - Tree traversal during HTML generation
- **[Buff I/O](buff-io-complete.md)** - Output buffering for HTML
- **[HTTP Lifecycle](http-lifecycle-complete.md)** - Integration with web server
- **[WWW Routing](www-routing-complete.md)** - Route handler registration for .fmt files
- **[Templ](templ-complete.md)** - Template system (can embed Fmt-generated HTML)
- **[Format System](format-system-complete.md)** - Overview of all formatters including Fmt

### Source Code Files

**Inter Layer (High-level)**:
- [src/inter/include/doc/](../../../src/inter/include/doc/) - Public API headers
- [src/inter/doc/](../../../src/inter/doc/) - Document rendering interface

**Ext Layer (Implementation)**:
- [src/ext/format/fmt/fmt_roebling.c](../../../src/ext/format/fmt/fmt_roebling.c) - Pencil parser
- [src/ext/format/fmt/fmt_html.c](../../../src/ext/format/fmt/fmt_html.c) - HTML generator
- [src/ext/format/fmt/fmt_tokenize.c](../../../src/ext/format/fmt/fmt_tokenize.c) - Tokenization rules
- [src/ext/include/format/fmt/fmt.h](../../../src/ext/include/format/fmt/fmt.h) - Parser API
- [src/ext/include/format/fmt/fmt_html.h](../../../src/ext/include/format/fmt/fmt_html.h) - HTML generation API

**Programs**:
- [src/programs/clineka/main.c](../../../src/programs/clineka/main.c) - CLI tool for Fmt conversion

**Examples**:
- [docs/about.fmt](../../../docs/about.fmt) - About page (Pencil format)
- [docs/schedule.fmt](../../../docs/schedule.fmt) - Roadmap (Pencil format)
- [examples/example.fmt](../../../examples/example.fmt) - Example Pencil document

**Tests**:
- [src/programs/test/option/ext/fmt_tests.c](../../../src/programs/test/option/ext/fmt_tests.c) - Fmt parser and generator tests

### API Reference

- **[Base API](../../api-reference/base.md)** - Memory, strings, I/O primitives
- **[Ext API](../../api-reference/ext.md)** - Roebling parser, formatters
- **[Inter API](../../api-reference/inter.md)** - HTTP, WWW, document rendering

### Developer Guides

- **[Writing Parsers](../../guides/writing-parsers.md)** - Creating custom Roebling parsers
- **[Creating Web Apps](../../guides/creating-web-apps.md)** - Building web applications with Fmt/Templ
- **[Testing](../../guides/testing.md)** - Testing parsers and generators

---

This comprehensive guide covers all aspects of the Doc module (Fmt parser and HTML generator) in Caneka. For questions or contributions, see [Contributing](../../contributing.md).



---

[← Part 2](doc-module-complete-part2) | **Part 3 of 3**
