# Passport Authentication System - Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](passport-auth-complete-part2)

---

## Why Passport?

Traditional web frameworks separate authentication into scattered libraries—session management in one place, password hashing in another, user persistence somewhere else. **Caneka integrates all authentication concerns into a unified Passport system**:

- **Credential Management**: Salt-based password hashing with SHA256
- **Session Tracking**: Parity-validated sessions with User-Agent binding
- **Multi-Type Authentication**: Support for integers, IPv4/IPv6, text, and signatures
- **User Management**: File-based login persistence with property system integration
- **Type-Safe**: Full integration with Caneka's type system and memory management


## Architecture Overview

The Passport system comprises six interconnected subsystems:

```
┌─────────────────────────────────────────────────────────────┐
│                    PASSPORT SYSTEM                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐      ┌──────────────┐                   │
│  │   AuthCred   │◄─────┤  AuthTarget  │                   │
│  │  (salt+hash) │      │ (i32/IPv6/.) │                   │
│  └──────────────┘      └──────────────┘                   │
│         ▲                     ▲                             │
│         │                     │                             │
│         │              ┌──────┴──────┐                     │
│         │              │   Password  │                     │
│         │              │   (hashing) │                     │
│         │              └──────┬──────┘                     │
│         │                     │                             │
│         │              ┌──────▼──────┐                     │
│         │              │    Salt     │                     │
│         │              │  (512-byte) │                     │
│         │              └─────────────┘                     │
│         │                                                   │
│  ┌──────┴────────────────────────────────┐                │
│  │           Login Management            │                │
│  │  (User accounts with Seel properties) │                │
│  └──────┬────────────────────────────────┘                │
│         │                                                   │
│  ┌──────▼──────────────────────────────────┐              │
│  │        Session Management (SsidCtx)     │              │
│  │  (Parity-validated sessions with stash) │              │
│  └─────────────────────────────────────────┘              │
│                                                             │
│  Storage: Filesystem (sessions + login directories)        │
└─────────────────────────────────────────────────────────────┘
```

**Request Flow**:
```
1. User submits credentials → Password hashing → AuthCred created
2. Session created → Ssid_Start generates SSID with User-Agent parity
3. Login created/opened → Directory structure + property files
4. Session operations → Ssid_Open/Close validates parity, persists data
5. User persistence → Login_Persist writes properties to filesystem
```


## Core Concepts

### 1. Authentication Credentials (AuthCred)

`AuthCred` stores salted hashes or signatures for verifying user identity.

**Structure**:
```c
typedef struct auth_cred {
    Type type;                  // TYPE_AUTH_CRED
    digest salt;                // 32-byte salt
    union {
        byte hash[DIGEST_SIZE]; // 32-byte SHA256 hash (passwords)
        byte sig[SIGNATURE_SIZE]; // 96-byte signature (PKI auth)
    } val;
} AuthCred;
```

**Key Properties**:
- **Salt**: 32-byte random data stored alongside hash
- **Hash/Signature Union**: Supports both password-based and PKI authentication
- **Type-Safe**: Includes Type field for runtime verification

**Usage** (API currently incomplete):
```c
// Future API (not yet implemented)
AuthCred *cred = AuthCred_Make(m);
status result = AuthCred_Resolve(m, cred, target, authentee);
```

**Why Two Authentication Methods?**

- **Password Hash (32 bytes)**: For username/password authentication
- **Signature (96 bytes)**: For public-key infrastructure (ECDSA/EdDSA)

### 2. Authentication Targets (AuthTarget)

Authentication targets define **what** is being authenticated. Caneka supports multiple target types for flexible authentication scenarios.

**Target Types**:
```c
enum auth_flags {
    AUTH_I    = 1 << 8,  // i32 authentication (user IDs, ports)
    AUTH_U    = 1 << 9,  // util authentication (unsigned integers)
    AUTH_IP4  = 1 << 10, // IPv4 address authentication
    AUTH_IP6  = 1 << 11, // IPv6 address authentication
    AUTH_SIG  = 1 << 12, // Signature-based authentication
    AUTH_TEXT = 1 << 13, // Text/string authentication
};
```

**Structure**:
```c
typedef struct auth_target {
    Type type;                  // TYPE_AUTH_TARGET
    union {
        i32 i;                  // Signed integer
        util u;                 // Unsigned integer
        util u128[2];           // IPv6 (two 64-bit values)
        StrVec *text;           // Text vector
    } bin;
    Span *groups;               // Permission groups
} AuthTarget;
```

**Creating Targets**:
```c
// Integer target (user ID)
AuthTarget *target = AuthTarget_Make(m, AUTH_I);
target->bin.i = 12345;

// Text target (username)
AuthTarget *target = AuthTarget_Make(m, AUTH_TEXT);
target->bin.text = Sv(m, "alice", "admin");

// IPv6 target (network address)
AuthTarget *target = AuthTarget_Make(m, AUTH_IP6);
target->bin.u128[0] = high_bits;
target->bin.u128[1] = low_bits;
```

**Why Multiple Target Types?**

Different authentication scenarios require different data:
- **AUTH_I**: Authenticate API requests by user ID
- **AUTH_IP4/AUTH_IP6**: Restrict access by network address
- **AUTH_TEXT**: Traditional username/password authentication
- **AUTH_SIG**: Public-key cryptography for secure channels

### 3. Authentication Functions

Each target type has a dedicated **hashing function** that combines the target data with a global salt to generate SHA256 hashes.

#### Integer Authentication (AuthFuncI)

Authenticates 32-bit integer values (user IDs, session tokens, etc.).

**Algorithm**:
1. Validates input (rejects zero values)
2. Calculates position: `(value * 1789) % 512`
3. Constructs 512-byte buffer:
   ```
   [salt[offset..end] || i32_value || salt[0..offset]]
   ```
4. Returns SHA256 of combined buffer

**Example**:
```c
AuthTarget *target = AuthTarget_Make(m, AUTH_I);
target->bin.i = 42;

digest hash;
status result = AuthFuncI(m, target, &hash);
// hash now contains 32-byte SHA256
```

**Security**: The multiplicative offset `(value * 1789) % 512` prevents predictable salt positioning.

#### Text Authentication (AuthFuncVec)

Authenticates text strings (usernames, passwords, tokens).

**Algorithm**:
1. Validates text is non-empty
2. **Two paths**:
   - **Text > 512 bytes**: Direct SHA256 (no salt mixing)
   - **Text ≤ 512 bytes**: Mix with salt:
     ```
     [salt[text_len..512] || text || salt[0..text_len]]
     ```
3. Returns SHA256

**Example**:
```c
AuthTarget *target = AuthTarget_Make(m, AUTH_TEXT);
target->bin.text = Sv(m, "username", "alice");

digest hash;
status result = AuthFuncVec(m, target, &hash);
```

**Why Two Paths?**

Short texts benefit from salt mixing. Long texts (> 512 bytes) already have sufficient entropy and don't need additional salting.

#### IPv6 Authentication (AuthFuncIp6)

Authenticates IPv6 network addresses.

**Algorithm**:
1. Validates address is non-zero
2. IPv6 stored as two 64-bit values: `u128[0]` and `u128[1]`
3. Calculates offset: `((u128[0] + u128[1]) * 1789) % 512`
4. Constructs 512-byte buffer with interleaved salt and address
5. Returns SHA256

**Example**:
```c
AuthTarget *target = AuthTarget_Make(m, AUTH_IP6);
target->bin.u128[0] = 0x20010db8000000000000000000000001; // High
target->bin.u128[1] = 0x0000000000000000;                // Low

digest hash;
status result = AuthFuncIp6(m, target, &hash);
```

**Note**: Current implementation has a bug at line 125 (accesses `pair[2]` which is out of bounds).

### 4. Password Hashing

The password hashing system uses **salt mixing and double buffering** to create secure SHA256 hashes.

**Constants**:
```c
#define PASSWORD_UNIT_LENGTH 512  // Password processing unit size
#define DIGEST_SIZE 32            // SHA256 output size
```

**Hashing Function**:
```c
status Password_OnStr(MemCh *m, Str *dest, Str *pw, Str *salt)
```

**Parameters**:
- `m`: Memory context
- `dest`: Destination string (must have `alloc == DIGEST_SIZE`)
- `pw`: Password string (2 to 512 bytes)
- `salt`: Salt string (exactly 512 bytes)

**Returns**: SUCCESS/ERROR/NOOP

**Algorithm**:

1. **Calculate Position**:
   ```c
   i16 funny = 97 & 0x1FF;  // Obfuscation constant
   word firstTwo = *((word *)pw->bytes);  // First 4 bytes
   i16 pos = (firstTwo + funny) & 0x1FF;  // Position (0-511)
   ```

2. **Construct 512-Byte Slate**:
   - Password inserted at variable position `pos`
   - Remaining space filled with salt
   - Pattern: `[salt_end || password || salt_start]`

3. **Double Buffer**:
   ```c
   memcpy(slate + 512, slate, 512 - pos);
   // Total input: 512 + (512 - pos) bytes
   ```

4. **Hash**:
   ```c
   Str_ToSha256(m, &slate, (digest *)dest->bytes);
   // Output: 32-byte SHA256
   ```

**Example**:
```c
Str *password = S(m, "my-secret-password");
Str *salt = GetGlobalSalt(m);  // 512 bytes

Str *hash = Str_Make(m, DIGEST_SIZE);
status result = Password_OnStr(m, hash, password, salt);

// hash->bytes now contains 32-byte SHA256
Str *hex = Str_ToHex(m, hash);
// hex: "4e732bfa69b00e0dfc60ff488786b723f27d640f72598ba3b8b1adb579cfdf69"
```

**Security Features**:

- **Position Randomization**: Uses first 4 bytes of password as entropy
- **Salt Mixing**: Password interleaved with salt at variable position
- **Double Buffering**: Increases computational cost
- **Obfuscation**: Constant "funny" value (97) adds unpredictability
- **Standard Algorithm**: Industry-standard SHA256

**Why Double Buffering?**

The doubling step `memcpy(slate + 512, slate, 512 - pos)` increases the hash input size to 512-1024 bytes, making brute-force attacks more computationally expensive.

### 5. Salt Management

The system uses a **global 512-byte salt** compiled into the binary.

**Structure**:
```c
typedef struct salt {
    Type type;           // TYPE_SALT
    i32 fact;            // Multiplication factor (1789)
    i32 length;          // Salt length (512)
    byte *salt512;       // Pointer to 512-byte salt data
} Salt;
```

**Global Salt Instance**:
```c
static Salt _salt = {
    .fact = 1789,
    .length = 512,
    .salt512 = (byte *)"11234whodoweappreciate5678notthethingsthatweequate..."
};
```

**Key Properties**:
- **fact (1789)**: Multiplication factor used in offset calculations
- **length (512)**: Fixed salt size
- **salt512**: 512-byte ASCII string embedded in binary

**Obfuscation Constant**:
```c
i16 _funny = 97;  // Used in password hashing position calculation
```

**Security Consideration**: The salt is static and compiled into the binary. This means all deployments of the same Caneka binary use the same salt. For production use, consider making the salt configurable per installation.


## Session Management

Sessions track user activity across HTTP requests with **parity-validated session IDs**.

### Session ID Format

Session IDs are structured `StrVec` with the format:
```
[random_8bytes]-[timestamp_sec].[timestamp_nsec]-[parity_hex]
```

**Components**:
1. **Random (8 bytes)**: Unique identifier
2. **Timestamp**: Unix seconds + nanoseconds (creation time)
3. **Parity**: Hex-encoded half-parity of User-Agent (validation)

**Example SSID StrVec**:
```
Index 0: "a1b2c3d4"        // 8 random bytes
Index 1: "-"               // Separator
Index 2: "1705424392"      // Seconds
Index 3: "."               // Separator
Index 4: "123456789"       // Nanoseconds
Index 5: "-"               // Separator
Index 6: "deadbeef"        // Parity (hex)
```

**Why Parity Validation?**

The parity field is a hash of the User-Agent header. When the session is accessed, the system validates that the User-Agent matches. This prevents **session hijacking**—if an attacker steals a session ID, they can't use it unless they also spoof the exact User-Agent.

### Session Context (SsidCtx)

`SsidCtx` manages session storage and metrics.

**Structure**:
```c
typedef struct ssid_ctx {
    Type type;                  // TYPE_SSID_CTX
    MemCh *m;                   // Memory context
    Str *path;                  // Base path for session storage
    struct {
        i64 open;               // Count of open sessions
        i64 closed;             // Count of closed sessions
        i64 count;              // Total session count
    } metrics;
    Table *seel;                // Property lookup table (future use)
} SsidCtx;
```

**Creating Context**:
```c
Str *sessionsDir = S(m, "/var/caneka/sessions");
SsidCtx *ctx = SsidCtx_Make(m, sessionsDir);
```

### Session Functions

#### Ssid_From - Generate Session ID

Generates a new session ID **without** creating storage.

```c
StrVec *Ssid_From(SsidCtx *ctx, StrVec *ua, struct timespec *ts)
```

**Parameters**:
- `ctx`: Session context
- `ua`: User-Agent string (for parity)
- `ts`: Timestamp (seconds and nanoseconds)

**Returns**: StrVec containing session ID components

**Example**:
```c
StrVec *ua = Sv(m, "Mozilla/5.0", "(compatible;", "Caneka/1.0)");
struct timespec now;
Time_Now(&now);

StrVec *ssid = Ssid_From(ctx, ua, &now);
// ssid: ["a1b2c3d4", "-", "1705424392", ".", "123456789", "-", "deadbeef"]
```

#### Ssid_Start - Create Session

Creates a new session with filesystem storage.

```c
StrVec *Ssid_Start(SsidCtx *ctx, StrVec *ua, struct timespec *ts)
```

**Algorithm**:
1. Generate SSID via `Ssid_From`
2. Construct path: `base_path/[ssid]`
3. Check if directory already exists (collision detection)
4. Create session directory
5. Create `session.stash` file with metadata:
   - `"user-agent"`: Full User-Agent string
   - `"orig-ssid"`: Original session ID
6. Persist stash to disk
7. Return SSID

**Example**:
```c
StrVec *ssid = Ssid_Start(ctx, ua, &now);

// Filesystem:
// /var/caneka/sessions/[ssid]/
// └── session.stash  (contains user-agent and orig-ssid)
```

**Error Handling**: Returns NULL if directory already exists or stash creation fails.

#### Ssid_Open - Open Existing Session

Opens an existing session and validates User-Agent.

```c
Table *Ssid_Open(SsidCtx *ctx, StrVec *ssid, StrVec *ua)
```

**Algorithm**:
1. Extract parity from SSID (index 6)
2. Validate parity against current User-Agent
3. If validation fails, return NULL with NOOP|LAST flags
4. Construct path: `base_path/[ssid]/session.stash`
5. Deserialize stash file
6. Return Table containing session data

**Example**:
```c
Table *sessionData = Ssid_Open(ctx, ssid, ua);

if(sessionData == NULL){
    // Validation failed or session doesn't exist
}else{
    // Access session data
    StrVec *origUa = Table_Get(sessionData, K(m, "user-agent"));
}
```

**Security**: Parity validation ensures the session can only be opened by the same User-Agent that created it.

#### Ssid_Close - Persist Session Data

Closes a session and writes data to disk.

```c
status Ssid_Close(SsidCtx *ctx, StrVec *ssid, StrVec *ua, Table *stashTbl)
```

**Parameters**:
- `ctx`: Session context
- `ssid`: Session ID
- `ua`: User-Agent (for validation)
- `stashTbl`: Session data to persist

**Algorithm**:
1. Validate User-Agent parity
2. Verify session directory exists
3. Serialize `stashTbl` to stash format
4. Write to `session.stash` file
5. Return SUCCESS

**Example**:
```c
Table *sessionData = Table_Make(m);
Table_Set(sessionData, K(m, "user-id"), S(m, "alice"));
Table_Set(sessionData, K(m, "last-active"), Str_FromI64(m, time(NULL)));

status result = Ssid_Close(ctx, ssid, ua, sessionData);
// session.stash now contains user-id and last-active
```

#### Ssid_Update - Rotate Session ID

Updates (regenerates) a session ID while preserving data.

```c
StrVec *Ssid_Update(SsidCtx *ctx, StrVec *ssid, StrVec *ua, struct timespec *ts)
```

**Algorithm**:
1. Open existing session
2. Generate new SSID
3. Rename session directory: `[old_ssid]` → `[new_ssid]`
4. Return new SSID

**Example**:
```c
struct timespec now;
Time_Now(&now);

StrVec *newSsid = Ssid_Update(ctx, oldSsid, ua, &now);
// Session data preserved, directory renamed
```

**Use Case**: Periodic session rotation for security (prevents **session fixation attacks**).

#### Ssid_Destroy - Delete Session

Permanently deletes a session.

```c
status Ssid_Destroy(SsidCtx *ctx, StrVec *ssid, StrVec *ua)
```

**Algorithm**:
1. Validate User-Agent parity
2. Delete `session.stash` file
3. Delete session directory
4. Return SUCCESS

**Example**:
```c
status result = Ssid_Destroy(ctx, ssid, ua);
// Session completely removed from filesystem
```


## User Management (Login)

User accounts are managed through the **Login** system, which uses the Seel property system for flexible data storage.

### Login Type

```c
typedef Inst Login;  // Login is an alias for Inst
```

Login instances store properties via the **Seel** (property registry) system.

**Registered Properties**:

| Property | Type | Description |
|----------|------|-------------|
| `"path"` | TYPE_STR | Base directory for login data |
| `"uid"` | TYPE_STRVEC | User ID (username) |
| `"auth"` | TYPE_TABLE | Authentication credentials |
| `"errors"` | TYPE_TABLE | Error messages |
| `"email"` | TYPE_STRVEC | User email address (optional) |
| `"username"` | TYPE_STRVEC | Display username (optional) |
| `"content"` | TYPE_TABLE | Additional user metadata (optional) |

### Login Functions

#### Login_Init - Initialize Type System

Registers Login properties in the Seel system.

```c
status Login_Init(MemCh *m)
```

**Algorithm**:
1. Create Seel property table for TYPE_LOGIN
2. Register required properties: `"path"`, `"uid"`, `"auth"`, `"errors"`
3. Register optional properties: `"email"`, `"username"`, `"content"`
4. Call `Seel_Seel` to register schema
5. Return READY

**Called**: During Passport module initialization.

#### Login_Create - Create User Account

Creates a new user with directory structure.

```c
Login *Login_Create(MemCh *m, Str *path, StrVec *uid, StrVec *ssid, AuthCred *cred)
```

**Parameters**:
- `m`: Memory context
- `path`: Base path for logins (e.g., `/var/caneka/logins`)
- `uid`: User ID (username)
- `ssid`: Session ID (unused in creation, for future use)
- `cred`: Authentication credentials (can be NULL)

**Algorithm**:
1. Create Login instance: `Inst_Make(m, TYPE_LOGIN)`
2. Set properties via Seel:
   - `"path"` → base path
   - `"uid"` → user ID
   - `"auth"` → `"login"` key → cred
3. Construct login path: `path/[uid]`
4. Check if user directory exists
   - If exists: Set error `"already-exists"`, return ERROR
5. Create directories:
   - `path/[uid]/`
   - `path/[uid]/auth/`
6. Call `Login_Refresh` to initialize
7. Return Login instance

**Example**:
```c
Str *loginsDir = S(m, "/var/caneka/logins");
StrVec *uid = Sv(m, "alice");
StrVec *ssid = NULL;  // Not used during creation
AuthCred *cred = NULL;  // Set later

Login *lg = Login_Create(m, loginsDir, uid, ssid, cred);

if((lg->type.state & ERROR) == ERROR){
    // User already exists
    Table *errors = Seel_Get(lg, K(m, "errors"));
    Str *msg = Table_Get(errors, K(m, "already-exists"));
}else{
    // User created successfully
    // Filesystem:
    // /var/caneka/logins/alice/
    // └── auth/
}
```

**Directory Structure**:
```
/var/caneka/logins/
└── alice/
    └── auth/          (authentication files)
```

#### Login_Open - Open Existing User

Opens an existing user account.

```c
Login *Login_Open(MemCh *m, Str *path, StrVec *uid, StrVec *ssid, AuthCred *cred)
```

**Parameters**: Same as Login_Create

**Algorithm**:
1. Create Login instance
2. Set properties (same as Create)
3. Construct login path
4. Check if directory exists
   - If doesn't exist: Set error `"not-found"`, return ERROR
5. Return Login instance with SUCCESS

**Example**:
```c
Login *lg = Login_Open(m, loginsDir, Sv(m, "alice"), NULL, NULL);

if((lg->type.state & ERROR) == ERROR){
    // User not found
}else{
    // User opened, now load properties
    Login_Refresh(m, lg);
}
```

#### Login_Refresh - Reload User Data

Reloads user data from filesystem.

```c
status Login_Refresh(MemCh *m, Login *lg)
```

**Algorithm**:
1. Retrieve `"path"` and `"uid"` properties
2. Construct login path: `path/uid`
3. Iterate through all Seel properties for TYPE_LOGIN
4. For each string/strvec property:
   - Construct file path: `login_path/[property_name]`
   - Load file via `File_ToVec`
   - Convert to appropriate type
   - Update property via `Seel_Set`
5. Scan `login_path/auth/` for auth files (placeholder)

**Example**:
```c
Login *lg = Login_Open(m, loginsDir, Sv(m, "alice"), NULL, NULL);
Login_Refresh(m, lg);

// Properties now loaded from files:
StrVec *email = Seel_Get(lg, K(m, "email"));
StrVec *username = Seel_Get(lg, K(m, "username"));
```

**Use Case**: Synchronize in-memory login with filesystem state (reload after external changes).

#### Login_Persist - Save User Data

Writes login properties to filesystem.

```c
status Login_Persist(MemCh *m, Login *lg)
```

**Algorithm**:
1. Retrieve `"path"` and `"uid"`
2. Construct login path
3. Verify directory exists
4. Iterate through all Seel properties
5. For each property with a value:
   - Construct file path
   - Open file for writing
   - Serialize data via `ToS(bf, a, type, ZERO)`
   - Close file
6. Return SUCCESS

**Example**:
```c
Login *lg = Login_Open(m, loginsDir, Sv(m, "alice"), NULL, NULL);

// Modify properties
Seel_Set(lg, K(m, "email"), Sv(m, "alice@example.com"));
Seel_Set(lg, K(m, "username"), Sv(m, "Alice", "Wonder"));

// Persist to disk
Login_Persist(m, lg);

// Filesystem:
// /var/caneka/logins/alice/
// ├── email         (contains "alice@example.com")
// ├── username      (contains "Alice\nWonder")
// └── auth/
```

#### Login_Destroy - Delete User Account

Permanently deletes a user account.

```c
status Login_Destroy(MemCh *m, Login *lg)
```

**Algorithm**:
1. Retrieve `"path"` and `"uid"`
2. Construct login path
3. Iterate through all Seel properties
4. For each property:
   - Delete file via `File_Unlink`
5. Scan auth directory (placeholder)
6. Delete auth directory: `Dir_Rm(auth/)`
7. Delete user directory: `Dir_Rm([uid]/)`
8. Return SUCCESS

**Example**:
```c
Login *lg = Login_Open(m, loginsDir, Sv(m, "alice"), NULL, NULL);
status result = Login_Destroy(m, lg);

// User directory completely removed:
// /var/caneka/logins/alice/  ← DELETED
```

**Destructive**: This operation cannot be undone.


## Complete Example: Authentication Flow

Here's a complete example showing session creation, user authentication, and persistence.

```c
#include "caneka.h"
#include "ext.h"
#include "inter.h"
#include "passport.h"

status AuthenticationExample(MemCh *m){
    // 1. Setup paths
    StrVec *sessionsPath = IoAbsPath(m, "data/sessions/");
    StrVec *loginsPath = IoAbsPath(m, "data/logins/");

    Str *sessionsDir = StrVec_Str(m, sessionsPath);
    Str *loginsDir = StrVec_Str(m, loginsPath);

    // Create directories
    Dir_CheckCreate(m, sessionsDir);
    Dir_CheckCreate(m, loginsDir);

    // 2. Create session context
    SsidCtx *ctx = SsidCtx_Make(m, sessionsDir);

    // 3. Start a session
    StrVec *ua = Sv(m, "Mozilla/5.0", "(Caneka)", "Example/1.0");
    struct timespec now;
    Time_Now(&now);

    StrVec *ssid = Ssid_Start(ctx, ua, &now);

    if(ssid == NULL){
        printf("Failed to create session\n");
        return ERROR;
    }

    // 4. Create user account
    StrVec *uid = Sv(m, "alice");
    Login *lg = Login_Create(m, loginsDir, uid, ssid, NULL);

    if((lg->type.state & ERROR) == ERROR){
        printf("Failed to create user\n");
        return ERROR;
    }

    // 5. Set user properties
    Seel_Set(lg, K(m, "email"), Sv(m, "alice@example.com"));
    Seel_Set(lg, K(m, "username"), Sv(m, "Alice", "Wonderland"));

    Table *content = Table_Make(m);
    Table_Set(content, K(m, "bio"), S(m, "Curious explorer"));
    Table_Set(content, K(m, "joined"), Str_FromI64(m, now.tv_sec));
    Seel_Set(lg, K(m, "content"), content);

    // 6. Hash password
    Str *password = S(m, "my-secret-password");
    Str *salt = GetGlobalSalt(m);  // 512-byte global salt
    Str *hash = Str_Make(m, DIGEST_SIZE);

    status hashResult = Password_OnStr(m, hash, password, salt);

    if(hashResult == SUCCESS){
        // Store hash in auth table
        Table *auth = Seel_Get(lg, K(m, "auth"));
        Table_Set(auth, K(m, "password-hash"), hash);
    }

    // 7. Persist user data
    status persistResult = Login_Persist(m, lg);

    printf("User created: %s\n", persistResult == SUCCESS ? "yes" : "no");

    // 8. Store session data
    Table *sessionData = Table_Make(m);
    Table_Set(sessionData, K(m, "user-id"), uid);
    Table_Set(sessionData, K(m, "login-time"), Str_FromI64(m, now.tv_sec));

    status closeResult = Ssid_Close(ctx, ssid, ua, sessionData);

    // 9. Later: Open session
    Table *reopened = Ssid_Open(ctx, ssid, ua);

    if(reopened != NULL){
        StrVec *userId = Table_Get(reopened, K(m, "user-id"));
        printf("Session user: %s\n", StrVec_Cstr(m, userId));

        // Open user account
        Login *lgReopened = Login_Open(m, loginsDir, userId, ssid, NULL);
        Login_Refresh(m, lgReopened);

        StrVec *email = Seel_Get(lgReopened, K(m, "email"));
        printf("User email: %s\n", StrVec_Cstr(m, email));
    }

    // 10. Cleanup (logout)
    Login_Destroy(m, lg);
    Ssid_Destroy(ctx, ssid, ua);

    return SUCCESS;
}
```

**Output**:
```
User created: yes
Session user: alice
User email: alice@example.com
```

**Filesystem After Execution**:
```
data/
├── sessions/
│   └── [ssid]/
│       └── session.stash       (contains user-id, login-time)
└── logins/
    └── alice/
        ├── email               (contains "alice@example.com")
        ├── username            (contains "Alice\nWonderland")
        ├── content             (binary stash with bio + joined)
        └── auth/
            └── password-hash   (32-byte SHA256)
```



---

**Part 1 of 2** | [Part 2 →](passport-auth-complete-part2)
