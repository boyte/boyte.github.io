# Cryptography API - Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](cryptography-api-complete-part2)

---

## Why Dual Backends?

Caneka's crypto system abstracts the underlying cryptographic library, allowing you to switch between backends based on your needs:

- **NaCl (libsodium)**: Modern, audited, constant-time implementations (Edwards25519)
- **OpenSSL**: Industry standard, NIST-compliant algorithms (P-256/secp256r1)

The same API works with both backends—change is made at build time, not runtime.


## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                  CRYPTOGRAPHY API LAYER                     │
├─────────────────────────────────────────────────────────────┤
│  Public API: /src/api/include/crypto_api.h                 │
│                                                              │
│  Hash Functions:                                             │
│  ┌──────────────┐    ┌───────────────┐   ┌────────────┐   │
│  │ Str_ToSha256 │    │StrVec_ToSha256│   │SaltedDigest│   │
│  └──────────────┘    └───────────────┘   └────────────┘   │
│                                                              │
│  Digital Signatures (ECDSA):                                 │
│  ┌──────────────┐    ┌───────────────┐   ┌────────────┐   │
│  │SignPair_Make │    │SignPair_Sign  │   │SignPair_   │   │
│  │              │    │               │   │   Verify   │   │
│  └──────────────┘    └───────────────┘   └────────────┘   │
│                                                              │
│  PEM Serialization:                                          │
│  ┌──────────────┐    ┌───────────────┐                     │
│  │PrivateToPem  │    │PublicFromPem  │                     │
│  └──────────────┘    └───────────────┘                     │
├─────────────────────────────────────────────────────────────┤
│                    BACKEND SELECTION                        │
├──────────────────────────┬──────────────────────────────────┤
│   OpenSSL Backend        │    NaCl Backend                  │
│   (P-256 ECDSA)          │    (Edwards25519 EdDSA)          │
│                          │                                  │
│   EVP_* functions        │    crypto_sign_*                │
│   PEM_* functions        │    crypto_hash_sha256           │
│   OSSL_* encoding        │    Field arithmetic (fe25519)   │
└──────────────────────────┴──────────────────────────────────┘
```

**Key Constants**:
```c
#define DIGEST_SIZE 32      // SHA-256 produces 32-byte hashes
#define KEY_SIZE 2048       // Default key size (bits)
#define SIGNATURE_SIZE 96   // Signature size (64 bytes + metadata)
```


## Core Concepts

### Hash Functions (SHA-256)

SHA-256 is a **cryptographic hash function** that produces a 256-bit (32-byte) digest from arbitrary input data. It's one-way (can't reverse), deterministic (same input → same output), and collision-resistant.

**Use Cases**:
- Password verification (with salt)
- Data integrity checks
- Digital signature algorithms
- Key derivation functions

### Digital Signatures (ECDSA/EdDSA)

Digital signatures provide **authentication and non-repudiation**:

1. **Signing**: Use private key to create signature over data
2. **Verification**: Use public key to verify signature matches data

**Properties**:
- Only the private key holder can create valid signatures
- Anyone with the public key can verify signatures
- Signatures prove data hasn't been tampered with

**Backend Differences**:
- **OpenSSL**: P-256 (NIST secp256r1) - widely deployed, FIPS compliant
- **NaCl**: Edwards25519 - modern, constant-time, faster

### Key Pairs

Cryptographic operations use **asymmetric key pairs**:

- **Private Key (Secret)**: Must be kept secret, used for signing
- **Public Key**: Can be shared freely, used for verification

**Storage**:
- **Memory**: Private key as `EVP_PKEY` (OpenSSL) or raw bytes (NaCl)
- **Files**: PEM format (Privacy-Enhanced Mail, Base64-encoded)


## Hashing Functions

### Str_ToSha256 - Hash Single String

Computes SHA-256 hash of a single string.

```c
status Str_ToSha256(MemCh *m, Str *s, digest *hash)
```

**Parameters**:
- `m`: Memory context
- `s`: Input string
- `hash`: Output buffer (must be exactly 32 bytes)

**Returns**: `SUCCESS` on completion, `ERROR` on failure

**Example**:
```c
Str *message = S(m, "Yay test string!");
Str *hash = Str_Make(m, DIGEST_SIZE);
hash->length = DIGEST_SIZE;

status result = Str_ToSha256(m, message, (digest *)hash->bytes);

// Convert to hex for display
Str *hex = Str_ToHex(m, hash);
// Result: "8a87db5fb3a1e4491a04644396437064375c00bdaf7fea33bd4645ba138539b5"

printf("SHA-256: %s\n", hex->bytes);
```

**Performance**: O(n) where n = string length. Single-pass algorithm.

### StrVec_ToSha256 - Hash Multiple Strings

Computes SHA-256 hash of concatenated vector elements using **streaming API** (memory efficient).

```c
status StrVec_ToSha256(MemCh *m, StrVec *v, digest *hash)
```

**Parameters**:
- `m`: Memory context
- `v`: Vector of strings
- `hash`: Output digest (32 bytes)

**Returns**: `SUCCESS` after processing final element

**Algorithm**:
1. Initialize SHA-256 context
2. Update context with each element (except last)
3. Finalize with last element
4. Return 32-byte digest

**Example**:
```c
StrVec *v = StrVec_Make(m);
StrVec_Add(v, S(m, "Yay "));
StrVec_Add(v, S(m, "test "));
StrVec_Add(v, S(m, "string!"));

Str *hash = Str_Make(m, DIGEST_SIZE);
hash->length = DIGEST_SIZE;

StrVec_ToSha256(m, v, (digest *)hash->bytes);

// Produces same hash as single concatenated string
Str *hex = Str_ToHex(m, hash);
```

**Why Use StrVec Instead of Concatenating?**

Memory efficiency. If you have 10 strings totaling 1MB, `StrVec_ToSha256` processes them in-place without allocating 1MB for concatenation.

### StrVec_SaltedDigest - Hash with Salt and Nonce

Computes SHA-256 with **salt mixing** and **nonce positioning** for key derivation and password hashing.

```c
status StrVec_SaltedDigest(MemCh *m, StrVec *_v, Str *salt,
    digest *hash, util nonce)
```

**Parameters**:
- `m`: Memory context
- `_v`: Content to hash
- `salt`: Salt string (typically 512 bytes)
- `hash`: Output digest (32 bytes)
- `nonce`: Position marker (32-64 bit integer)

**Returns**: `SUCCESS` on completion

**Algorithm**:

1. **Mask Calculation**:
   - Find highest power-of-2 ≤ salt length (e.g., 512 → 512)
   - Subtract 1 to create mask (512 → 511 = 0x1FF)

2. **Position Calculation**:
   ```c
   i32 pos = nonce & mask;  // Position (0 to salt.length-1)
   ```

3. **Vector Construction**:
   ```
   [salt[pos..end] || nonce_bytes || content || salt[0..pos]]
   ```

4. **Hash**: SHA-256 of combined vector

**Example**:
```c
StrVec *content = Sv(m, "One ", "Two ", "Three ", "Four ");
Str *salt = S(m, "French fries, and potato chips...");  // 34 bytes
word nonce = 37;

Str *hash = Str_Make(m, DIGEST_SIZE);
hash->length = DIGEST_SIZE;

StrVec_SaltedDigest(m, content, salt, (digest *)hash->bytes, nonce);

Str *hex = Str_ToHex(m, hash);
// Result: "b797cc5b4d1a08c9ab7ec358e6d714152bc51de1faa51a72d2fbb88c10d937b0"
```

**Use Cases**:

- **Password Hashing**: Salt prevents rainbow table attacks, nonce adds iteration count
- **Key Derivation**: Derive keys from passphrases deterministically
- **Session Tokens**: Generate unique tokens from user ID + nonce

**Security Note**: This is a simple salting mechanism. For production password hashing, use PBKDF2, bcrypt, or Argon2 with high iteration counts.

### Str_DigestAlloc - Allocate Hash Buffer

Convenience function to create a properly-sized digest buffer.

```c
Str *Str_DigestAlloc(MemCh *m)
```

**Returns**: Str object with `alloc == DIGEST_SIZE` (32 bytes)

**Example**:
```c
Str *hash = Str_DigestAlloc(m);
hash->length = DIGEST_SIZE;
Str_ToSha256(m, message, (digest *)hash->bytes);
```

**Why Use This?**

Ensures the hash buffer is exactly the right size. If `alloc` is wrong, hashing functions may fail with `ERROR`.


## Digital Signatures

### SignPair_Make - Generate Key Pair

Generates a new ECDSA key pair for signing and verification.

```c
status SignPair_Make(MemCh *m, Single *public, Single *secret)
```

**Parameters**:
- `m`: Memory context
- `public`: Output public key (wrapped Str)
- `secret`: Output private key (wrapped EVP_PKEY)

**Returns**: `SUCCESS` on key generation, `ERROR` if crypto library fails

**Post-Conditions**:
- `secret->objType.of == TYPE_ECKEY` (private key as EVP_PKEY)
- `public->objType.of == TYPE_STR` (public key as octet string)

**Example**:
```c
Single *public = Ptr_Wrapped(m, NULL, ZERO);
Single *secret = Ptr_Wrapped(m, NULL, ZERO);

status result = SignPair_Make(m, public, secret);

if(result & SUCCESS){
    printf("Keys generated successfully\n");
    printf("Secret type: %d (TYPE_ECKEY=%d)\n",
           secret->objType.of, TYPE_ECKEY);
    printf("Public type: %d (TYPE_STR=%d)\n",
           public->objType.of, TYPE_STR);
}
```

**Backend Implementation**:

**OpenSSL**:
- Uses `EVP_EC_gen("P-256")` to generate secp256r1 curve key
- Extracts public key as octet string (65 bytes uncompressed)
- Registers external free handler for EVP_PKEY cleanup

**NaCl**:
- Uses Edwards25519 curve
- Public key: 32 bytes
- Private key: 64 bytes (seed + public key)

**Security**: Keys are cryptographically secure random. Store private keys securely (file permissions 600, encrypted storage).

### SignPair_Sign - Create Signature

Creates an ECDSA signature over message content using private key.

```c
Str *SignPair_Sign(MemCh *m, StrVec *content, Single *secret)
```

**Parameters**:
- `m`: Memory context
- `content`: Message to sign (vector of strings)
- `secret`: Private key (must have `objType.of == TYPE_ECKEY`)

**Returns**: Str containing signature bytes, or NULL on error

**Algorithm**:
1. Create EVP_MD_CTX digest context
2. Initialize with SHA-256 algorithm
3. Update digest with each StrVec element
4. Finalize with `EVP_DigestSignFinal()` to produce signature
5. Return variable-length signature in Str

**Example**:
```c
StrVec *message = Sv(m,
    "I super-master person, do hereby sign some cool, ",
    "super-fancy stuff, that totally needed to be signed...");

Str *sig = SignPair_Sign(m, message, secret);

if(sig != NULL){
    Str *sigHex = Str_ToHex(m, sig);
    printf("Signature (hex): %s\n", sigHex->bytes);
    printf("Signature length: %lld bytes\n", sig->length);
}
```

**Signature Size**:
- **OpenSSL (P-256)**: Typically 72 bytes (variable, DER-encoded)
- **NaCl (Ed25519)**: Fixed 64 bytes

**Critical**: The order of StrVec elements matters. Verification must use the exact same order.

### SignPair_Verify - Verify Signature

Verifies an ECDSA signature over message content using public key.

```c
status SignPair_Verify(MemCh *m, StrVec *content, Str *sig, Single *public)
```

**Parameters**:
- `m`: Memory context
- `content`: Original message (must match signing order)
- `sig`: Signature bytes
- `public`: Public key (must have `objType.of == TYPE_STR`)

**Returns**: `SUCCESS` if signature is valid, `NOOP` if invalid or error

**Algorithm**:
1. Reconstruct EVP_PKEY from public key octet string
2. Create EVP_MD_CTX and initialize with SHA-256
3. Update digest with each StrVec element (same order as signing)
4. Verify with `EVP_DigestVerifyFinal()`
5. Return SUCCESS only if signature matches

**Example**:
```c
// Load public key from PEM file
Single *public2 = Ptr_Wrapped(m, NULL, ZERO);
Buff *bf = Buff_Make(m, BUFF_UNBUFFERED|BUFF_CLOBBER);
File_Open(bf, S(m, "./keys/pub.pem"), O_RDONLY);
SignPair_PublicFromPem(bf, public2);

// Verify signature
status valid = SignPair_Verify(m, message, sig, public2);

if(valid & SUCCESS){
    printf("Signature is valid\n");
}else{
    printf("Signature verification failed\n");
}
```

**Security Considerations**:

- **Element Order**: StrVec elements must be in exact same order as signing
- **Message Integrity**: Even one byte change causes verification to fail
- **Public Key Trust**: You must trust the public key source (PKI, web of trust, etc.)

**Common Failure Modes**:
- Wrong public key → `NOOP`
- Message tampered with → `NOOP`
- StrVec order different → `NOOP`
- Signature corrupted → `NOOP`

### SignPair_FromPhrase - Deterministic Keys (Not Implemented)

Generate key pair deterministically from passphrase.

```c
status SignPair_FromPhrase(MemCh *m, Single *public, Single *secret,
    StrVec *phrase)
```

**Status**: NOT IMPLEMENTED in OpenSSL backend (returns ERROR)

**Intended Use**: Derive keys from memorable passphrase (12-word mnemonic, etc.)

**Security Risk**: If implemented, requires strong KDF (PBKDF2, Argon2) to prevent brute-force attacks on weak passphrases.


## PEM Serialization

PEM (Privacy-Enhanced Mail) is a **Base64-encoded format** for storing cryptographic keys and certificates.

**Example PEM Public Key**:
```
-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEVvXk6jvOGdPZn7PbNfpQhGp7WL4K
...
-----END PUBLIC KEY-----
```

### SignPair_PrivateToPem - Export Private Key

Writes private key to PEM file.

```c
status SignPair_PrivateToPem(Buff *bf, Single *secret)
```

**Parameters**:
- `bf`: Output buffer (file-backed)
- `secret`: Private key (must have `objType.of == TYPE_ECKEY`)

**Returns**: `SUCCESS` on write, `ERROR` on failure

**Example**:
```c
// Create directory
Dir_CheckCreate(m, S(m, "./keys"));

// Open file for writing
Buff *bf = Buff_Make(m, BUFF_UNBUFFERED|BUFF_CLOBBER);
File_Open(bf, S(m, "./keys/private.pem"), O_CREAT|O_TRUNC|O_WRONLY);

// Write PEM
status result = SignPair_PrivateToPem(bf, secret);

if(result & SUCCESS){
    printf("Private key written to ./keys/private.pem\n");
}

File_Close(bf);
```

**Security Warning**: Private keys in PEM format are **unencrypted**. Set file permissions to 600 (owner read/write only):

```bash
chmod 600 ./keys/private.pem
```

**File Contents** (example):
```
-----BEGIN PRIVATE KEY-----
MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQg...
-----END PRIVATE KEY-----
```

### SignPair_PublicToPem - Export Public Key

Writes public key to PEM file.

```c
status SignPair_PublicToPem(Buff *bf, Single *public)
```

**Parameters**:
- `bf`: Output buffer (file)
- `public`: Public key (must have `objType.of == TYPE_STR`)

**Returns**: `SUCCESS` on write, `ERROR` on failure

**Example**:
```c
Buff *bf = Buff_Make(m, BUFF_UNBUFFERED|BUFF_CLOBBER);
File_Open(bf, S(m, "./keys/public.pem"), O_CREAT|O_TRUNC|O_WRONLY);

status result = SignPair_PublicToPem(bf, public);

if(result & SUCCESS){
    printf("Public key written to ./keys/public.pem\n");
}
```

**Public Key Distribution**: Public keys can be freely distributed. Common methods:
- Store in version control (safe!)
- Embed in TLS certificates
- Publish on key servers
- Share via email/chat

### SignPair_PublicFromPem - Import Public Key

Reads public key from PEM file.

```c
status SignPair_PublicFromPem(Buff *bf, Single *public)
```

**Parameters**:
- `bf`: Input buffer (file-backed, opened for reading)
- `public`: Output public key wrapper

**Returns**: `SUCCESS` on read, `ERROR` on failure

**Post-Condition**: `public->objType.of == TYPE_STR` with octet string

**Example**:
```c
Single *public = Ptr_Wrapped(m, NULL, ZERO);

Buff *bf = Buff_Make(m, BUFF_UNBUFFERED|BUFF_CLOBBER);
File_Open(bf, S(m, "./keys/public.pem"), O_RDONLY);

status result = SignPair_PublicFromPem(bf, public);

if(result & SUCCESS){
    printf("Public key loaded\n");
    Str *pubKey = (Str *)public->val.ptr;
    printf("Public key length: %lld bytes\n", pubKey->length);
}
```

**Use Case**: Load public key to verify signatures created by another party.

### SignPair_PrivateFromPem - Import Private Key (Not Implemented)

Reads private key from PEM file.

```c
status SignPair_PrivateFromPem(Buff *bf, Single *secret)
```

**Status**: NOT IMPLEMENTED in OpenSSL backend (returns ERROR)

**Workaround**: Generate new keys or implement PEM import using OpenSSL's `PEM_read_PrivateKey()`.


## Complete Example: Sign and Verify

Here's a complete workflow demonstrating key generation, signing, PEM export/import, and verification.

```c
#include "caneka.h"
#include "ext.h"
#include "crypto_api.h"

status SignatureWorkflow(MemCh *m){
    DebugStack_Push(NULL, 0);

    // 1. Generate key pair
    Single *public = Ptr_Wrapped(m, NULL, ZERO);
    Single *secret = Ptr_Wrapped(m, NULL, ZERO);

    status result = SignPair_Make(m, public, secret);
    if(!(result & SUCCESS)){
        printf("Failed to generate keys\n");
        return ERROR;
    }

    printf("✓ Keys generated\n");

    // 2. Create message to sign
    StrVec *message = Sv(m,
        "This is a legally binding contract to deliver ",
        "one million dollars in unmarked bills to the ",
        "undersigned party within 30 days of signature.");

    // 3. Sign the message
    Str *sig = SignPair_Sign(m, message, secret);
    if(sig == NULL){
        printf("Failed to sign message\n");
        return ERROR;
    }

    Str *sigHex = Str_ToHex(m, sig);
    printf("✓ Signature created: %s\n", sigHex->bytes);

    // 4. Export keys to PEM files
    Dir_CheckCreate(m, S(m, "./keys"));

    Buff *bf = Buff_Make(m, BUFF_UNBUFFERED|BUFF_CLOBBER);
    File_Open(bf, S(m, "./keys/private.pem"), O_CREAT|O_TRUNC|O_WRONLY);
    result = SignPair_PrivateToPem(bf, secret);
    File_Close(bf);

    if(!(result & SUCCESS)){
        printf("Failed to export private key\n");
        return ERROR;
    }

    printf("✓ Private key exported to ./keys/private.pem\n");

    bf = Buff_Make(m, BUFF_UNBUFFERED|BUFF_CLOBBER);
    File_Open(bf, S(m, "./keys/public.pem"), O_CREAT|O_TRUNC|O_WRONLY);
    result = SignPair_PublicToPem(bf, public);
    File_Close(bf);

    if(!(result & SUCCESS)){
        printf("Failed to export public key\n");
        return ERROR;
    }

    printf("✓ Public key exported to ./keys/public.pem\n");

    // 5. Simulate receiving message + signature + public key from another party
    // Load public key from PEM file
    Single *public2 = Ptr_Wrapped(m, NULL, ZERO);
    bf = Buff_Make(m, BUFF_UNBUFFERED|BUFF_CLOBBER);
    File_Open(bf, S(m, "./keys/public.pem"), O_RDONLY);
    result = SignPair_PublicFromPem(bf, public2);
    File_Close(bf);

    if(!(result & SUCCESS)){
        printf("Failed to import public key\n");
        return ERROR;
    }

    printf("✓ Public key imported from PEM\n");

    // 6. Verify signature
    status valid = SignPair_Verify(m, message, sig, public2);

    if(valid & SUCCESS){
        printf("✓ Signature is VALID\n");
        printf("  Message is authentic and unmodified\n");
    }else{
        printf("✗ Signature is INVALID\n");
        printf("  Message may be tampered or wrong public key\n");
    }

    // 7. Test with modified message (should fail)
    StrVec *tampered = Sv(m,
        "This is a legally binding contract to deliver ",
        "TWO million dollars in unmarked bills to the ",  // Changed!
        "undersigned party within 30 days of signature.");

    valid = SignPair_Verify(m, tampered, sig, public2);

    if(valid & SUCCESS){
        printf("✗ ERROR: Tampered message verified (shouldn't happen!)\n");
    }else{
        printf("✓ Tampered message rejected (expected)\n");
    }

    DebugStack_Pop();
    return SUCCESS;
}

int main(int argc, char **argv){
    Caneka_Init();

    MemCh *m = MemCh_Make();
    status result = SignatureWorkflow(m);

    MemCh_Free(m);

    return (result & SUCCESS) ? 0 : 1;
}
```

**Output**:
```
✓ Keys generated
✓ Signature created: 3045022100a1b2c3d4e5f6...
✓ Private key exported to ./keys/private.pem
✓ Public key exported to ./keys/public.pem
✓ Public key imported from PEM
✓ Signature is VALID
  Message is authentic and unmodified
✓ Tampered message rejected (expected)
```


## Encryption (BoxPair - Not Implemented)

The BoxPair functions provide **authenticated encryption** using NaCl's crypto_box (Curve25519 + Salsa20 + Poly1305).

### BoxPair_Make - Generate Encryption Keys

```c
status BoxPair_Make(MemCh *m, Str *public, Str *secret, StrVec *phrase)
```

**Status**: NOT IMPLEMENTED (returns ERROR)

**Intended Use**: Generate Curve25519 key pair for encryption

### BoxPair_Enc - Encrypt

```c
status BoxPair_Enc(MemCh *m, Str *secret, StrVec *content)
```

**Status**: NOT IMPLEMENTED (returns ERROR)

**Intended Use**: Encrypt content with authenticated encryption

### BoxPair_Dec - Decrypt

```c
status BoxPair_Dec(MemCh *m, Str *public, StrVec *content)
```

**Status**: NOT IMPLEMENTED (returns ERROR)

**Intended Use**: Decrypt and verify authenticated ciphertext


## HMAC (Not Implemented)

HMAC (Hash-based Message Authentication Code) provides **message authentication** with a shared secret key.

### Str_HmacEnc - Compute HMAC

```c
status Str_HmacEnc(MemCh *m, Str *s, Str *hmac)
```

**Status**: NOT IMPLEMENTED (returns NOOP)

### Str_HmacDec - Verify HMAC

```c
status Str_HmacDec(MemCh *m, Str *s, Str *hmac)
```

**Status**: NOT IMPLEMENTED (returns NOOP)


## Initialization

### Crypto_Init - Initialize Crypto System

```c
status Crypto_Init(MemCh *m)
```

**Purpose**: Initialize cryptography subsystem and register cleanup handlers

**Parameters**: `m` - Memory context

**Returns**: `SUCCESS` on initialization

**When to Call**: During application startup, before using any crypto functions

**Example**:
```c
int main(int argc, char **argv){
    Caneka_Init();

    MemCh *m = MemCh_Make();
    Crypto_Init(m);  // Initialize crypto

    // Now safe to use crypto functions

    MemCh_Free(m);
    return 0;
}
```

**Backend Implementation**:

**OpenSSL**:
- Calls `OpenSsl_ExtFreeInit(m)` to register cleanup handlers
- Sets up TYPE_ECKEY and TYPE_ECKEY_PUB cleanup via `OPENSSL_free()`

**NaCl**:
- Returns SUCCESS immediately (no initialization needed)


## Backend Details

### OpenSSL Backend

**Location**: [src/third/openssl/](src/third/openssl/)

**Key Functions Used**:

| Function Category | OpenSSL Functions |
|-------------------|-------------------|
| Hashing | `EVP_DigestInit_ex()`, `EVP_DigestUpdate()`, `EVP_DigestFinal()` |
| Key Generation | `EVP_EC_gen("P-256")` |
| Signing | `EVP_DigestSignInit()`, `EVP_DigestSignUpdate()`, `EVP_DigestSignFinal()` |
| Verification | `EVP_DigestVerifyInit()`, `EVP_DigestVerifyUpdate()`, `EVP_DigestVerifyFinal()` |
| PEM Export | `OSSL_ENCODER_CTX_new_for_pkey()`, `OSSL_ENCODER_to_fp()` |
| PEM Import | `PEM_read_PUBKEY()` |
| Error Handling | `ERR_get_error()`, `ERR_error_string_n()` |

**Elliptic Curve**: P-256 (secp256r1)
- NIST standardized
- 256-bit field
- Public key: ~65 bytes (uncompressed point)
- Signature: Variable length, typically 72 bytes (DER-encoded)

**Dependencies**:
```
include=/usr/include/openssl/
link=openssl@crypto
```

**Linked Library**: `libcrypto` (OpenSSL crypto library)

### NaCl/libsodium Backend

**Location**: [src/third/nacl.experimental/](src/third/nacl.experimental/)

**Key Functions**:

| Function Category | NaCl Functions |
|-------------------|----------------|
| Hashing | `sha256_start()`, `sha256_update()`, `sha256_finalize()` |
| Signing | `sign_keypair_sha256()`, `crypto_sign()` |
| Verification | `crypto_sign_open()` |
| Encryption | `crypto_box()` (not implemented) |

**Elliptic Curve**: Edwards25519
- Modern, audited, constant-time
- Public key: 32 bytes
- Signature: Fixed 64 bytes

**Field Arithmetic Types**:
```c
typedef struct {
    crypto_uint32 v[32];  // 32 x 32-bit integers = 128 bytes
} fe25519;  // Field element

typedef struct {
    fe25519 x, y, z, t;  // Projective coordinates
} ge25519;  // Group element

typedef struct {
    crypto_uint32 v[32];
} sc25519;  // Scalar
```

**SHA-256 Context**:
```c
typedef struct sha256_ctx {
    int type;
    unsigned long long total;
    unsigned char h[32];  // Hash state
} Sha256Ctx;
```

**Initial Vector (IV)** (SHA-256):
```
6a09e667 bb67ae85 3c6eef72 a54ff53a
510e527f 9b05688c 1f83d9ab 5be0cd19
```

**Dependencies**:
```
static=libnacl@/usr/local/lib/libnacl.a
include=/usr/local/include/nacl/
```

**Static Library**: `libnacl.a` (libsodium compiled as static)


## Integration with Caneka Types

### Memory Management (MemCh)

All crypto functions accept `MemCh *m` for allocation:

```c
// Allocate hash buffer
Str *hash = Str_Make(m, DIGEST_SIZE);

// Allocate key wrappers
Single *public = Ptr_Wrapped(m, NULL, ZERO);
Single *secret = Ptr_Wrapped(m, NULL, ZERO);
```

**External Free Handlers**: OpenSSL allocations (EVP_PKEY) are registered with `MemCh_AddExtFree()` for automatic cleanup when MemCh is freed.

### String Types (Str)

```c
typedef struct {
    byte *bytes;       // Raw byte data
    i64 length;       // Current length
    i64 alloc;        // Allocated capacity
    StrType type;     // Type flags
} Str;
```

**Usage**:
- Hash input/output
- Signature bytes
- Public key octets
- PEM data (after Base64 decode)

**Hex Conversion**:
```c
Str *hash = Str_Make(m, DIGEST_SIZE);
Str_ToSha256(m, message, (digest *)hash->bytes);
Str *hex = Str_ToHex(m, hash);  // Binary → Hex string
```

### String Vectors (StrVec)

```c
typedef struct {
    Page *p;          // Underlying storage
    i64 total;       // Number of elements
    // ...
} StrVec;
```

**Usage**:
- Multi-part messages: `StrVec_ToSha256()`
- Signing fragmented content: `SignPair_Sign()`
- Verifying multi-part data: `SignPair_Verify()`

**Iteration**: Uses `Iter` protocol for traversing elements.

### Pointer Wrappers (Single)

```c
typedef struct {
    void *ptr;        // Actual pointer
    union {
        util word;   // Type identifier
        ObjType of;  // Object type (TYPE_ECKEY, TYPE_STR, etc.)
    } objType;
} Single;
```

**Usage in Crypto**:

| Type | Field | Contents |
|------|-------|----------|
| Private Key | `objType.of = TYPE_ECKEY` | EVP_PKEY pointer |
| Public Key | `objType.of = TYPE_STR` | Str with octet bytes |

**Creation**:
```c
Single *wrapper = Ptr_Wrapped(m, NULL, ZERO);
// Initially: ptr = NULL, objType.word = 0
```

### Buffers (Buff)

```c
typedef struct {
    int fd;           // File descriptor
    MemCh *m;        // Memory context
    // ...
} Buff;
```

**Usage**:
- PEM file I/O
- Buffered signature/hash writing

**Example**:
```c
Buff *bf = Buff_Make(m, BUFF_UNBUFFERED|BUFF_CLOBBER);
File_Open(bf, S(m, "./keys/private.pem"), O_CREAT|O_TRUNC|O_WRONLY);
SignPair_PrivateToPem(bf, secret);
File_Close(bf);
```


## Security Considerations

### Hash Functions

**Strengths**:
- SHA-256 produces 256-bit (32-byte) digests
- Suitable for signature algorithms, KDFs
- Collision-resistant

**Limitations**:
- **NOT for password hashing**: Use bcrypt, scrypt, or Argon2
- Rainbow table attacks: Always use salt for passwords
- Length extension attacks: Use HMAC for authentication

### Digital Signatures

**Strengths**:
- P-256 (OpenSSL) and Ed25519 (NaCl) are both secure
- Provides authentication and non-repudiation
- Signatures verifiable by anyone with public key

**Best Practices**:
- Protect private keys (file permissions 600, encrypted storage)
- Verify public key authenticity (PKI, fingerprints)
- Use same StrVec element order for signing and verification

### Key Management

**Private Keys**:
- ⚠️ **Never commit private keys to version control**
- ⚠️ **Encrypt PEM files** (not yet implemented in Caneka)
- ⚠️ **Restrict file permissions**: `chmod 600 private.pem`
- ⚠️ **Rotate keys** periodically

**Public Keys**:
- ✅ Safe to distribute freely
- ✅ Can be stored in version control
- ✅ Verify fingerprints before trusting

### Memory Security

**Limitations**:
- ⚠️ **No secure memory zeroing**: Sensitive data (keys, hashes) not explicitly wiped
- ⚠️ **Memory allocated via MemCh**: May remain in memory until context freed
- ⚠️ **Swap/hibernation risk**: Memory may be written to disk

**Mitigations**:
- Use short-lived MemCh for crypto operations
- Disable swap for sensitive applications
- Implement secure zeroing for production use

### Algorithm Choices

**NaCl**:
- ✅ Conservative, audited, constant-time
- ✅ Faster than OpenSSL for Ed25519
- ⚠️ Not FIPS compliant

**OpenSSL**:
- ✅ Widely deployed, NIST standardized
- ✅ FIPS compliant (with FIPS module)
- ⚠️ Timing attack risks in some configurations



---

**Part 1 of 2** | [Part 2 →](cryptography-api-complete-part2)
