# TCP Server System Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](tcp-server-complete-part2)

---

## Overview

The TCP Server System in Caneka provides **non-blocking, poll-based network serving** that integrates with the Navigate Task/Queue system for concurrent connection handling. Unlike traditional threaded servers, Caneka's TCP server uses **single-threaded event-driven architecture** where each connection is a child Task managed by a Queue with file descriptor criteria.

The server supports **protocol-agnostic handling** through callback functions, making it suitable for HTTP, WebSocket, or any TCP-based protocol. The system emphasizes **zero-copy buffer operations**, **predictable memory management**, and **transparent connection lifecycle**.


## Core Philosophy

### Event-Driven Architecture

The TCP server follows an **event-driven** model where:

1. **Main Server Task**: Polls for new connections using `poll(2)`
2. **Child Tasks**: Each connection becomes a separate Task
3. **Queue Management**: Queue handles task scheduling with FD-based criteria
4. **Step Chains**: Request handling via composable Step functions

This eliminates threading complexity while maintaining high concurrency through efficient polling.

### Protocol Abstraction

The server separates **transport (TCP)** from **protocol (HTTP/etc.)** via callback functions:

```c
typedef struct tcp_ctx {
    // Transport configuration
    i32 port;
    Str *inet4;
    Str *inet6;

    // Protocol integration
    TaskPopulate populate;    // Create child task for new connection
    StepFunc finalize;        // Cleanup after connection completes
    SourceFunc defaultData;   // Initialize protocol-specific data

    // Application data
    Inst *pages;             // Route tree
    Inst *inc;               // Include templates
    NodeObj *nav;            // Navigation config
} TcpCtx;
```

The **populate** function creates protocol-specific handling (HTTP, WebSocket, etc.) for each connection.

### Non-Blocking I/O

All socket operations use **O_NONBLOCK** mode:

- **Accept**: Returns immediately if no connections available
- **Read**: Returns available data without blocking
- **Write**: Writes what fits in send buffer, returns immediately

This allows the single-threaded server to handle thousands of concurrent connections by only operating on ready file descriptors.

### Memory Chapter Per Connection

Each connection gets its own **MemCh** memory chapter:

```c
MemCh *tm = MemCh_Make();             // New chapter for connection
Task *child = Task_Make(Span_Make(tm), tsk);
child->timeout.tv_sec = TCP_TIMEOUT;
tm->owner = child;                    // Chapter owned by task
```

When the connection completes, the entire chapter is freed in one operation:

```c
if(child->type.state & (SUCCESS|ERROR)){
    Queue_Remove(q, child->idx);
    ctx->finalize(NULL, child);
    MemCh_Free(child->m);  // Free entire connection memory
}
```

This provides **predictable memory management** - no per-request allocations leaking into global memory.


## Structure

### TcpCtx: Server Context

**Definition** [tcp_ctx.h:1-19](../../../src/ext/include/serve/tcp_ctx.h#L1-L19):

```c
typedef struct tcp_ctx {
    Type type;               // TYPE_TCP_CTX
    i32 port;               // Server port (e.g., 8080)
    Str *inet4;             // IPv4 address (future use)
    Str *inet6;             // IPv6 address (future use)

    // Protocol callbacks
    TaskPopulate populate;   // Function to initialize connection task
    StepFunc finalize;       // Function to cleanup connection
    SourceFunc defaultData;  // Function to create default data (future)

    // Application data
    StrVec *path;           // Base path for routes
    Inst *pages;            // Route tree for public pages
    Inst *inc;              // Route tree for includes (header/footer)
    NodeObj *nav;           // Navigation configuration

    // Metrics
    struct {
        struct timespec start;  // Server start time
        i64 open;              // Connections opened
        i64 error;             // Connections with errors
        i64 served;            // Connections successfully served
    } metrics;
} TcpCtx;
```

**Callback Type Definitions:**

```c
// Initialize child task for new connection
typedef status (*TaskPopulate)(MemCh *m, Task *tsk, void *arg, void *source);

// Cleanup after connection completes
typedef status (*StepFunc)(Step *st, Task *tsk);

// Create default data for task (future use)
typedef void *(*SourceFunc)(MemCh *m, Abstract *source);
```

**Creation** [tcp_ctx.c:4-9](../../../src/ext/serve/tcp_ctx.c#L4-L9):

```c
TcpCtx *TcpCtx_Make(MemCh *m){
    TcpCtx *ctx = (TcpCtx *)MemCh_AllocOf(m, sizeof(TcpCtx), TYPE_TCP_CTX);
    ctx->type.of = TYPE_TCP_CTX;
    Time_Now(&ctx->metrics.start);  // Record start time
    return ctx;
}
```

### ProtoCtx: Protocol Context

**Definition** [proto_ctx.h:1-8](../../../src/ext/include/serve/proto_ctx.h#L1-L8):

```c
typedef struct proto {
    Type type;          // TYPE_PROTO_CTX
    util u;            // Utility field (unused currently)
    Buff *in;          // Input buffer (reading from socket)
    Span *outSpan;     // Output buffers (multiple for piping)
    Buff *out;         // Final output buffer (writing to socket)
    void *ctx;         // Protocol-specific context (HttpCtx, etc.)
} ProtoCtx;
```

**Purpose**: ProtoCtx acts as a **transport-protocol bridge**:
- **in**: Receives data from TCP socket
- **outSpan**: Collects response buffers from handlers
- **out**: Final aggregated output written to TCP socket
- **ctx**: Protocol state (HTTP headers, query params, etc.)

**Creation** [proto_ctx.c:4-9](../../../src/ext/serve/proto_ctx.c#L4-L9):

```c
ProtoCtx *ProtoCtx_Make(MemCh *m){
    ProtoCtx *ctx = (ProtoCtx *)MemCh_AllocOf(m, sizeof(ProtoCtx), TYPE_PROTO_CTX);
    ctx->type.of = TYPE_PROTO_CTX;
    ctx->outSpan = Span_Make(m);  // Initialize output buffer span
    return ctx;
}
```

### Task Structure for TCP

**Server Task**: Main server task with STEP_LOOP for continuous polling

```c
Task *tsk = Task_Make(NULL, ctx);
tsk->stepGuardMax = -1;             // Infinite steps (server never ends)
Task_AddStep(tsk, ServeTcp_AcceptPoll, ctx, NULL, STEP_LOOP);
Task_AddStep(tsk, ServeTcp_OpenTcp, ctx, NULL, ZERO);
Task_AddStep(tsk, ServeTcp_SetupQueue, ctx, NULL, ZERO);
```

**Connection Task**: Child task for each connection

```c
MemCh *tm = MemCh_Make();
Task *child = Task_Make(Span_Make(tm), tsk);
child->type.of = TYPE_TCP_TASK;
child->type.state |= TASK_CHILD;
child->timeout.tv_sec = TCP_TIMEOUT;  // 6 second timeout
child->parent = tsk;
child->stepGuardMax = TCP_STEP_MAX;   // 16,000 max steps per connection
tm->owner = child;
```

**pollfd Storage**: Each task stores its `struct pollfd` in the utility field:

```c
#define TcpTask_GetPollFd(tsk) ((struct pollfd *)&(tsk)->u)

struct pollfd *pfd = TcpTask_GetPollFd(tsk);
pfd->fd = socket_fd;
pfd->events = POLLIN;
pfd->revents = 0;
```

This clever **space optimization** avoids separate allocation for poll structures.

### Queue with File Descriptor Criteria

The server uses a Queue with **FD-based criteria** for efficient polling:

```c
Queue *q = Queue_Make(tsk->m);

// Create FD criteria handler
QueueCrit *crit = QueueCrit_Make(tsk->m, QueueCrit_Fds, ZERO);
Queue_AddHandler(q, crit);

tsk->data = (Abstract *)q;
tsk->type.state |= TASK_QUEUE;
```

**Criteria System**: Queue maintains a criteria array (pollfd array) for bulk polling:

```c
// Add connection to queue
child->idx = Queue_Add(q, child);

// Update poll criteria
if(child->type.state & TASK_UPDATE_CRIT){
    struct pollfd *pfd = (struct pollfd *)&child->u;
    Queue_SetCriteria(q, 0, child->idx, &child->u);
    child->type.state &= ~TASK_UPDATE_CRIT;
}
```

The queue criteria array is passed directly to `poll(2)`, making polling O(1) for task lookup.


## Implementation Details

### Server Initialization

Server creation via `ServeTcp_Make` [serve_tcp.c:191-198](../../../src/ext/serve/serve_tcp.c#L191-L198):

```c
Task *ServeTcp_Make(TcpCtx *ctx){
    Task *tsk = Task_Make(NULL, ctx);
    tsk->stepGuardMax = -1;  // Infinite loop

    // Steps run in reverse order (backward iteration)
    Task_AddStep(tsk, ServeTcp_AcceptPoll, ctx, NULL, STEP_LOOP);
    Task_AddStep(tsk, ServeTcp_OpenTcp, ctx, NULL, ZERO);
    Task_AddStep(tsk, ServeTcp_SetupQueue, ctx, NULL, ZERO);

    return tsk;
}
```

**Step Execution Order:**
1. `ServeTcp_SetupQueue`: Create Queue with FD criteria
2. `ServeTcp_OpenTcp`: Open TCP socket and bind to port
3. `ServeTcp_AcceptPoll`: Loop forever accepting connections (STEP_LOOP)

### Opening TCP Socket

`ServeTcp_OpenTcp` [serve_tcp.c:48-70](../../../src/ext/serve/serve_tcp.c#L48-L70):

```c
static status ServeTcp_OpenTcp(Step *st, Task *tsk){
    TcpCtx *ctx = (TcpCtx *)as(tsk->source, TYPE_TCP_CTX);

    // Open socket, bind, and listen
    i32 fd = openPortToFd(ctx->port);

    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    if(fd > 0){
        pfd->fd = fd;
        pfd->events = POLLIN;     // Wait for incoming connections
        pfd->revents = 0;
        st->type.state |= SUCCESS;
    } else {
        st->type.state |= ERROR;
    }

    return st->type.state;
}
```

**openPortToFd Implementation** [serve_tcp.c:4-46](../../../src/ext/serve/serve_tcp.c#L4-L46):

```c
static i32 openPortToFd(i32 port){
    i32 fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in serv_addr;
    memset(&serv_addr, '0', sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);  // Bind to all interfaces
    serv_addr.sin_port = htons(port);

    // Set non-blocking mode
    if (fcntl(fd, F_SETFL, O_NONBLOCK) == -1) {
        Error(ErrStream->m, FUNCNAME, FILENAME, LINENUMBER,
            "openPortToFd setting nonblock", NULL);
        return -1;
    }

    // Enable address reuse (important for quick restart)
    i32 one = 1;
    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(i32)) < 0) {
        Error(ErrStream->m, FUNCNAME, FILENAME, LINENUMBER,
            "openPortToFd setting reuse addr", NULL);
        return -1;
    }
    if (setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &one, sizeof(i32)) < 0) {
        Error(ErrStream->m, FUNCNAME, FILENAME, LINENUMBER,
            "openPortToFd setting reuse port", NULL);
        return -1;
    }

    // Bind to address
    if(bind(fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) != 0){
        Error(ErrStream->m, FUNCNAME, FILENAME, LINENUMBER,
            "openPortToFd binding", NULL);
        return -1;
    }

    // Start listening (backlog of 128 connections)
    if(listen(fd, TCP_LISTEN_BACKLOG) != 0){
        Error(ErrStream->m, FUNCNAME, FILENAME, LINENUMBER,
            "openPortToFd listening", NULL);
        return -1;
    }

    return fd;
}
```

**Configuration Constants** [serve_tcp.h:1-9](../../../src/ext/include/serve/serve_tcp.h#L1-L9):

```c
#define TCP_STEP_MAX 16000         // Max steps per connection
#define SERV_READ_SIZE 1024        // Bytes to read per recv
#define SERV_SEND_SIZE 1024        // Bytes to write per send (unused)
#define TCP_POLL_DELAY 10          // Poll timeout (milliseconds)
#define ACCEPT_AT_ONEC_MAX 192     // Max connections per accept loop (unused)
#define TCP_TIMEOUT 6              // Connection timeout (seconds)
#define TCP_LISTEN_BACKLOG 128     // Socket listen backlog
#define TCP_ZERO_REQ_DELAY 6000    // Poll timeout when no requests (microseconds)
```

### Accept and Poll Loop

`ServeTcp_AcceptPoll` [serve_tcp.c:72-176](../../../src/ext/serve/serve_tcp.c#L72-L176) is the core server loop:

**Phase 1: Poll for Connections**

```c
static status ServeTcp_AcceptPoll(Step *st, Task *tsk){
    TcpCtx *ctx = (TcpCtx *)as(tsk->source, TYPE_TCP_CTX);
    Queue *q = (Queue *)as(tsk->data, TYPE_QUEUE);
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);

    // Dynamic timeout: wait longer if no active requests
    i64 timeout = 0;
    if(q->it.p->nvalues == 0){
        timeout = TCP_ZERO_REQ_DELAY;  // 6000 microseconds
    }

    // Poll for new connections
    i32 available = poll(pfd, 1, timeout);
    if(available == -1){
        // Handle error
        st->type.state |= ERROR;
        return st->type.state;
    }
```

**Phase 2: Accept Connections**

```c
    i32 accepted = 0;
    while(available-- > 0){
        // Accept new connection
        i32 new_fd = accept(pfd->fd, (struct sockaddr*)NULL, NULL);

        if(new_fd > 0){
            ctx->metrics.open++;

            // Set non-blocking
            fcntl(new_fd, F_SETFL, O_NONBLOCK);

            // Create memory chapter for connection
            MemCh *tm = MemCh_Make();

            // Create child task
            Task *child = Task_Make(Span_Make(tm), tsk);
            child->type.of = TYPE_TCP_TASK;
            child->type.state |= TASK_CHILD;
            child->timeout.tv_sec = TCP_TIMEOUT;
            child->parent = tsk;
            child->stepGuardMax = TCP_STEP_MAX;
            tm->owner = child;

            // Call populate callback to initialize protocol handling
            ctx->populate(tm, child, I32_Wrapped(tm, new_fd), tsk->source);

            // Add child to queue
            child->idx = Queue_Add(q, child);

            // Update poll criteria
            if(child->type.state & TASK_UPDATE_CRIT){
                struct pollfd *pfd = (struct pollfd *)&child->u;
                Queue_SetCriteria(q, 0, child->idx, &child->u);
                child->type.state &= ~TASK_UPDATE_CRIT;
            }

            accepted++;
        } else {
            break;  // No more connections available
        }
    }
```

**Phase 3: Process Existing Connections**

```c
    // Process all active connections
    tsk->type.state |= (NOOP|PROCESSING);
    while((Queue_Next(q) & END) == 0){
        tsk->type.state &= ~(NOOP|PROCESSING);

        // Get next ready connection from queue
        Task *child = (Task *)Queue_Get(q);

        // Execute connection task
        child->parent = tsk;
        Task_Tumble(child);

        // If connection complete, cleanup
        if(child->type.state & (SUCCESS|ERROR)){
            Queue_Remove(q, child->idx);
            ctx->finalize(NULL, child);    // Call finalize callback
            MemCh_Free(child->m);          // Free connection memory
        }
    }

    return st->type.state;
}
```

**Key Algorithm Details:**

1. **Dynamic Timeout**: Longer poll timeout when idle (6000μs) to save CPU
2. **Accept Loop**: Accept multiple connections per poll event
3. **Non-Blocking Accept**: Break when no more connections ready
4. **Memory Chapter Per Connection**: Each connection isolated in own chapter
5. **Populate Callback**: Protocol-agnostic connection initialization
6. **Queue Processing**: Poll-based ready detection via FD criteria
7. **Cleanup**: Finalize callback + chapter free for completed connections

### Connection Task Lifecycle

**1. Task Creation** [serve_tcp.c:105-112](../../../src/ext/serve/serve_tcp.c#L105-L112):

```c
MemCh *tm = MemCh_Make();
Task *child = Task_Make(Span_Make(tm), tsk);
child->type.of = TYPE_TCP_TASK;
child->type.state |= TASK_CHILD;
child->timeout.tv_sec = TCP_TIMEOUT;  // 6 seconds
child->parent = tsk;
child->stepGuardMax = TCP_STEP_MAX;   // 16,000 steps max
tm->owner = child;
```

**2. Populate Callback** [serve_tcp.c:113](../../../src/ext/serve/serve_tcp.c#L113):

```c
ctx->populate(tm, child, I32_Wrapped(tm, new_fd), tsk->source);
```

**Example Populate for HTTP** [webserver.c:72-84](../../../src/inter/www/webserver.c#L72-L84):

```c
static status WebServer_populate(MemCh *m, Task *tsk,
                                void *arg, void *source){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    Single *fdw = (Single *)as(arg, TYPE_WRAPPED_I32);
    pfd->fd = fdw->val.i;  // Store socket FD

    // Initialize HTTP handling
    HttpTask_InitResponse(tsk, NULL, source);
    Task_AddStep(tsk, WebServer_GatherPage, NULL, NULL, ZERO);
    HttpTask_AddRecieve(tsk, NULL, NULL);

    return SUCCESS;
}
```

**3. Queue Addition** [serve_tcp.c:122-137](../../../src/ext/serve/serve_tcp.c#L122-L137):

```c
child->idx = Queue_Add(q, child);

// Update poll criteria for monitoring
if(child->type.state & TASK_UPDATE_CRIT){
    struct pollfd *pfd = (struct pollfd *)&child->u;
    Queue_SetCriteria(q, 0, child->idx, &child->u);
    child->type.state &= ~TASK_UPDATE_CRIT;
}
```

**4. Task Execution** [serve_tcp.c:146-166](../../../src/ext/serve/serve_tcp.c#L146-L166):

```c
while((Queue_Next(q) & END) == 0){
    Task *child = (Task *)Queue_Get(q);
    child->parent = tsk;
    Task_Tumble(child);  // Execute child task steps

    if(child->type.state & (SUCCESS|ERROR)){
        Queue_Remove(q, child->idx);
        ctx->finalize(NULL, child);
        MemCh_Free(child->m);
    }
}
```

**5. Finalize Callback** [webserver.c:8-39](../../../src/inter/www/webserver.c#L8-L39):

```c
static status WebServer_logAndClose(Step *_st, Task *tsk){
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Log request
    MemBookStats st;
    MemBook_GetStats(tsk->m, &st);

    if(ctx->type.state & ERROR){
        Out("^r.Error method/code path time memory^0\n", args);
    } else if(ctx->code == 200){
        Out("^g.Served method/code path time memory^0\n", args);
    } else {
        Out("^c.Responded method/code path time memory^0\n", args);
    }

    // Close socket
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    close(pfd->fd);

    return SUCCESS;
}
```

### Reading from Socket

`TcpTask_ReadToRbl` [tcp_task.c:4-27](../../../src/ext/serve/tcp_task.c#L4-L27):

```c
status TcpTask_ReadToRbl(Step *st, Task *tsk){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    Roebling *rbl = (Roebling *)as(st->arg, TYPE_ROEBLING);

    // Set socket FD on input buffer
    Buff_SetSocket(proto->in, pfd->fd);

    // Read from socket (1024 bytes)
    if((Buff_ReadAmount(proto->in, SERV_READ_SIZE) & NOOP) == 0){
        // Parse incoming data with Roebling
        Roebling_Run(rbl);
    }

    // Propagate parser state to step/task
    st->type.state |= rbl->type.state & (SUCCESS|ERROR);
    tsk->type.state |= rbl->type.state & ERROR;

    return st->type.state;
}
```

**Read Process:**
1. **Buff_SetSocket**: Associate buffer with socket FD
2. **Buff_ReadAmount**: Read up to 1024 bytes (non-blocking)
3. **Roebling_Run**: Parse incoming data (HTTP headers, etc.)
4. **State Propagation**: SUCCESS/ERROR from parser to step/task

### Writing to Socket

`TcpTask_WriteStep` [tcp_task.c:29-62](../../../src/ext/serve/tcp_task.c#L29-L62):

```c
status TcpTask_WriteStep(Step *st, Task *tsk){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);

    // Set socket FD on output buffer
    Buff_SetFd(proto->out, pfd->fd);

    // Pipe all output buffers to socket
    Iter it;
    Iter_Init(&it, proto->outSpan);
    while((Iter_Next(&it) & END) == 0){
        Buff *bf = Iter_Get(&it);

        // Pipe buffer to output (zero-copy reference)
        Buff_Pipe(proto->out, bf);

        // Close file if buffer is streaming from file
        if(bf->type.state & (BUFF_SOCKET|BUFF_FD)){
            close(bf->fd);
            Buff_UnsetFd(bf);
        }

        // Check for errors
        if((bf->type.state & ERROR) ||
           (bf->type.state & (SUCCESS|END)) == 0){
            st->type.state |= ERROR;
            tsk->type.state |= ERROR;
            break;
        }
    }

    if((st->type.state & ERROR) == 0){
        st->type.state |= SUCCESS;
    }

    return st->type.state;
}
```

**Write Process:**
1. **Buff_SetFd**: Associate output buffer with socket FD
2. **Iterate Output Buffers**: Process all collected response buffers
3. **Buff_Pipe**: Zero-copy piping to output (references, not copies)
4. **File Cleanup**: Close file descriptors for streamed static assets
5. **Error Handling**: Abort on any buffer errors

### Poll Event Management

**Expect Receive** [tcp_task.c:64-69](../../../src/ext/serve/tcp_task.c#L64-L69):

```c
status TcpTask_ExpectRecv(Step *st, Task *tsk){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    pfd->events = POLLIN|POLLNVAL|POLLHUP|POLLERR;
    tsk->type.state |= TASK_UPDATE_CRIT;  // Signal queue to update criteria
    return tsk->type.state;
}
```

**Expect Send** [tcp_task.c:71-76](../../../src/ext/serve/tcp_task.c#L71-L76):

```c
status TcpTask_ExpectSend(Step *st, Task *tsk){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    pfd->events = POLLOUT|POLLNVAL|POLLHUP|POLLERR;
    tsk->type.state |= TASK_UPDATE_CRIT;  // Signal queue to update criteria
    return tsk->type.state;
}
```

**TASK_UPDATE_CRIT Flag**: Signals the queue that poll criteria changed and need updating via `Queue_SetCriteria`.


## Code Examples

### Example 1: Creating HTTP Server

Complete HTTP server setup:

```c
// Create TCP context
TcpCtx *tcp = TcpCtx_Make(m);
tcp->port = 8080;
tcp->populate = WebServer_populate;       // HTTP-specific initialization
tcp->finalize = WebServer_logAndClose;    // HTTP-specific cleanup

// Load routes
tcp->pages = Route_Make(m);
Route_CollectConfig(tcp->pages, Sv(m, "/"), publicPath, configAtts);

tcp->inc = Route_Make(m);
Route_CollectConfig(tcp->inc, Sv(m, "/"), incPath, configAtts);

// Create server task
Task *server = ServeTcp_Make(tcp);

// Run server
Task_Tumble(server);  // Runs forever (stepGuardMax = -1)
```

### Example 2: WebServer Populate Function

Initialize HTTP handling for new connection:

```c
static status WebServer_populate(MemCh *m, Task *tsk,
                                void *arg, void *source){
    // Extract socket FD
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    Single *fdw = (Single *)as(arg, TYPE_WRAPPED_I32);
    pfd->fd = fdw->val.i;

    // Create HTTP protocol context
    HttpTask_InitResponse(tsk, NULL, source);

    // Add HTTP request handling steps
    Task_AddStep(tsk, WebServer_GatherPage, NULL, NULL, ZERO);
    HttpTask_AddRecieve(tsk, NULL, NULL);

    return SUCCESS;
}
```

**HttpTask_InitResponse creates:**
- ProtoCtx with input/output buffers
- HttpCtx with headers, query params, etc.
- Roebling HTTP parser for reading request

### Example 3: WebServer Finalize Function

Cleanup and logging after connection completes:

```c
static status WebServer_logAndClose(Step *_st, Task *tsk){
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Get memory statistics
    MemBookStats st;
    MemBook_GetStats(tsk->m, &st);

    // Build log arguments
    void *args[9];
    args[0] = Lookup_Get(HttpMethods, ctx->method);  // GET, POST, etc.
    args[1] = I32_Wrapped(tsk->m, ctx->code);        // 200, 404, etc.
    args[2] = ctx->path;                             // /path/to/resource
    args[3] = Time_Wrapped(tsk->m, &tsk->metrics.consumed);  // Request time
    args[4] = Str_MemCount(tsk->m, st.total * PAGE_SIZE);    // Memory used
    args[5] = I64_Wrapped(tsk->m, st.total);         // Pages allocated
    args[6] = I64_Wrapped(tsk->m, st.pageIdx);       // Current page index
    args[7] = NULL;  // Error messages (if any)
    args[8] = NULL;

    // Color-coded logging
    if(ctx->type.state & ERROR){
        args[7] = ctx->errors;
        Out("^r.Error method/code path time memory^0\n", args);
    } else if(ctx->code == 200){
        Out("^g.Served method/code path time memory^0\n", args);
    } else {
        Out("^c.Responded method/code path time memory^0\n", args);
    }

    // Close socket
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    close(pfd->fd);

    return SUCCESS;
}
```

**Example Log Output:**

```
^g.Served GET/200 /stats time-used:2.5ms 16k 4 / 4 ^{TIME.human}^0
^g.Served GET/200 /static/style.css time-used:0.8ms 12k 3 / 3 ^{TIME.human}^0
^c.Responded GET/404 /missing time-used:1.2ms 8k 2 / 2 ^{TIME.human}^0
^r.Error POST/500 /api/users time-used:15.7ms 32k 8 / 8 [error details]^0
```

### Example 4: Custom Protocol Server

Creating a simple echo server with custom protocol:

```c
// Protocol context for echo
typedef struct {
    Type type;
    Buff *in;
    Buff *out;
} EchoCtx;

// Populate function for echo protocol
static status Echo_populate(MemCh *m, Task *tsk,
                            void *arg, void *source){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    Single *fdw = (Single *)as(arg, TYPE_WRAPPED_I32);
    pfd->fd = fdw->val.i;

    // Create echo context
    EchoCtx *ctx = MemCh_AllocOf(m, sizeof(EchoCtx), TYPE_ECHO_CTX);
    ctx->in = Buff_Make(m, ZERO);
    ctx->out = Buff_Make(m, ZERO);
    tsk->data = (Abstract *)ctx;

    // Add echo steps
    Task_AddStep(tsk, Echo_WriteResponse, NULL, NULL, ZERO);
    Task_AddStep(tsk, Echo_ReadRequest, NULL, NULL, ZERO);

    // Expect data
    TcpTask_ExpectRecv(NULL, tsk);

    return SUCCESS;
}

// Read request
static status Echo_ReadRequest(Step *st, Task *tsk){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    EchoCtx *ctx = (EchoCtx *)tsk->data;

    // Read from socket
    Buff_SetSocket(ctx->in, pfd->fd);
    status r = Buff_ReadAmount(ctx->in, 1024);

    if(r & SUCCESS){
        st->type.state |= SUCCESS;
    }

    return st->type.state;
}

// Write response (echo back)
static status Echo_WriteResponse(Step *st, Task *tsk){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    EchoCtx *ctx = (EchoCtx *)tsk->data;

    // Echo input back to output
    Buff_AddVec(ctx->out, ctx->in->v);

    // Write to socket
    Buff_SetFd(ctx->out, pfd->fd);
    status r = Buff_Write(ctx->out);

    if(r & SUCCESS){
        st->type.state |= SUCCESS;
    }

    return st->type.state;
}

// Cleanup
static status Echo_finalize(Step *st, Task *tsk){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    close(pfd->fd);
    return SUCCESS;
}

// Create echo server
TcpCtx *tcp = TcpCtx_Make(m);
tcp->port = 7777;
tcp->populate = Echo_populate;
tcp->finalize = Echo_finalize;

Task *server = ServeTcp_Make(tcp);
Task_Tumble(server);
```

### Example 5: Accessing Server Metrics

Monitoring server health:

```c
void printServerMetrics(TcpCtx *tcp){
    void *args[6];

    // Calculate uptime
    struct timespec now;
    Time_Now(&now);
    i64 uptime_sec = now.tv_sec - tcp->metrics.start.tv_sec;

    // Build arguments
    args[0] = I64_Wrapped(OutStream->m, tcp->metrics.open);
    args[1] = I64_Wrapped(OutStream->m, tcp->metrics.served);
    args[2] = I64_Wrapped(OutStream->m, tcp->metrics.error);
    args[3] = I64_Wrapped(OutStream->m, uptime_sec);
    args[4] = NULL;

    Out("Server Metrics:\n", NULL);
    Out("  Connections opened: $\n", args);
    Out("  Successfully served: $\n", args + 1);
    Out("  Errors: $\n", args + 2);
    Out("  Uptime: $ seconds\n", args + 3);
}
```

### Example 6: Queue Inspection

Checking active connections:

```c
void inspectQueue(Queue *q){
    void *args[4];

    args[0] = I64_Wrapped(OutStream->m, q->it.p->nvalues);
    args[1] = NULL;
    Out("Active connections: $\n", args);

    // Iterate active tasks
    Iter it;
    Iter_Init(&it, q->it.p);
    while((Iter_Next(&it) & END) == 0){
        Task *child = Iter_Get(&it);
        struct pollfd *pfd = TcpTask_GetPollFd(child);

        args[0] = child;
        args[1] = I32_Wrapped(OutStream->m, pfd->fd);
        args[2] = I32_Wrapped(OutStream->m, pfd->events);
        args[3] = NULL;

        Out("  Task @ fd=$ events=$\n", args);
    }
}
```


## Performance Characteristics

### Connection Handling

**Accept Performance:**
- Poll timeout: 0ms (active) or 6000μs (idle)
- Accept loop: Multiple connections per poll event
- Non-blocking: No waiting on unavailable connections

**Throughput:**
- Theoretical: Limited by kernel and hardware
- Practical: 10,000+ req/sec for simple responses
- Bottleneck: Usually application logic, not TCP layer

### Memory Usage Per Connection

**Fixed Overhead:**
- Task structure: ~200 bytes
- pollfd structure: 8 bytes (embedded in task.u)
- Queue entry: ~50 bytes
- Total: ~250 bytes per connection

**Variable Overhead:**
- ProtoCtx: ~100 bytes
- Protocol context (HttpCtx): ~500 bytes
- Input buffer: ~4KB (depends on request size)
- Output buffers: ~4KB+ (depends on response size)

**Total Typical**: ~8-10KB per active HTTP connection

**Cleanup**: All freed together via `MemCh_Free(child->m)` when connection closes.

### Concurrency Limits

**Theoretical Limits:**
- FD limit: `ulimit -n` (typically 1024-65536)
- Memory: Depends on available RAM (10KB/conn → 100,000 connections per GB)
- Poll performance: O(n) where n = active connections

**Practical Limits:**
- Tested: 10,000 concurrent connections
- Recommended: 1,000-5,000 for typical workloads
- Bottleneck: Application processing time, not TCP layer

### Timeout Handling

**Connection Timeout:**
- Configured: `TCP_TIMEOUT` (6 seconds)
- Applied per-connection via `child->timeout.tv_sec`
- Checked by: Queue during task iteration

**Timeout Behavior:**
- Task exceeds timeout → ERROR state
- Queue removes task → finalize called → memory freed

**Impact:**
- Prevents hung connections from consuming resources
- Enables "slow loris" attack mitigation

### Step Guard

**Purpose**: Prevent infinite loops in connection handling

**Configuration:**
- Global default: Configurable per system
- Connection default: `TCP_STEP_MAX` (16,000 steps)
- Server: Unlimited (`stepGuardMax = -1`)

**Behavior:**
- Task exceeds step limit → ERROR state
- Useful for detecting runaway request processing



---

**Part 1 of 2** | [Part 2 →](tcp-server-complete-part2)
