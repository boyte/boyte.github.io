# Error Handling: Complete Guide - Part 2

[← Part 1](error-handling-complete-part1) | **Part 2 of 2**

---

## Best Practices

### Always Use Macros for Location

**GOOD**:
```c
Error(m, FUNCNAME, FILENAME, LINENUMBER, "error message", args);
```

**BAD**:
```c
Error(m, "MyFunction", "file.c", 123, "error message", args);
// Hardcoded values get stale if code moves
```

### NULL-Terminate Arguments Array

**GOOD**:
```c
void *args[] = {
    I32_Wrapped(m, value),
    str,
    NULL  // Required sentinel
};
Error(m, FUNCNAME, FILENAME, LINENUMBER, "format $, @", args);
```

**BAD**:
```c
void *args[] = {
    I32_Wrapped(m, value),
    str
    // Missing NULL - undefined behavior
};
Error(m, ...);
```

### Match Placeholders to Arguments

**GOOD**:
```c
void *args[] = {
    I32_Wrapped(m, count),  // First $
    str,                     // First @
    NULL
};
Error(m, FUNCNAME, FILENAME, LINENUMBER, "Count: $, Name: @", args);
```

**BAD**:
```c
void *args[] = {
    I32_Wrapped(m, count),
    NULL  // Missing second argument!
};
Error(m, FUNCNAME, FILENAME, LINENUMBER, "Count: $, Name: @", args);
// Crashes or garbage output
```

### Propagate ERROR State

**GOOD**:
```c
status result = SubOperation();
if(result & ERROR){
    // Add context, then propagate
    Error(m, FUNCNAME, FILENAME, LINENUMBER,
        "Sub-operation failed during initialization", NULL);
    return ERROR;
}
```

**ACCEPTABLE** (when error already has context):
```c
status result = SubOperation();
if(result & ERROR){
    return ERROR;  // Just propagate, error already reported
}
```

### Set Object Error State

**GOOD**:
```c
if(operation_failed){
    Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
        "Operation failed", NULL);
    bf->type.state |= ERROR;  // Update object state
    return ERROR;
}
```

**BAD**:
```c
if(operation_failed){
    Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
        "Operation failed", NULL);
    return ERROR;  // Object state not updated
}
```

### Register Error Handlers During Init

**GOOD**:
```c
status MyType_Init(MemCh *m){
    status r = READY;

    // Register error handler
    r |= Lookup_Add(m, ErrorHandlers, TYPE_MY_TYPE,
        (void *)MyType_ErrorHandler);

    return r;
}
```

### Attach Owners to MemCh

**GOOD**:
```c
MemCh *m = MemCh_Make();
CliArgs *cli = Args_Make(m, argc, argv);
m->owner = cli;  // Errors will invoke Args_ErrorFunc

// Later errors automatically handled by Args error handler
```


## Common Pitfalls and Solutions

### Pitfall 1: Missing NULL Terminator

**Problem**:
```c
void *args[] = {
    I32_Wrapped(m, 42),
    str
    // Missing NULL!
};
Error(m, FUNCNAME, FILENAME, LINENUMBER, "Value: $, Str: @", args);
// Undefined behavior - reads past array end
```

**Solution**:
```c
void *args[] = {
    I32_Wrapped(m, 42),
    str,
    NULL  // Always terminate with NULL
};
```

### Pitfall 2: Placeholder Mismatch

**Problem**:
```c
void *args[] = {
    I32_Wrapped(m, 42),
    NULL
};
// Format has 2 placeholders but only 1 argument
Error(m, FUNCNAME, FILENAME, LINENUMBER, "Value: $, Missing: $", args);
```

**Solution**:
```c
void *args[] = {
    I32_Wrapped(m, 42),
    I32_Wrapped(m, 0),  // Provide second argument
    NULL
};
Error(m, FUNCNAME, FILENAME, LINENUMBER, "Value: $, Missing: $", args);
```

### Pitfall 3: Using errno After Other Calls

**Problem**:
```c
i32 fd = open("file.txt", O_RDONLY);
if(fd < 0){
    // Other operations that may change errno
    Str *path = S(m, "file.txt");

    // errno may have changed!
    ErrNoError(ErrStream);
}
```

**Solution**:
```c
i32 fd = open("file.txt", O_RDONLY);
if(fd < 0){
    i32 saved_errno = errno;  // Save immediately

    // Other operations
    Str *path = S(m, "file.txt");

    errno = saved_errno;  // Restore before ErrNoError
    ErrNoError(ErrStream);
}
```

### Pitfall 4: Returning ERROR Without Calling Error()

**Problem**:
```c
if(invalid_state){
    return ERROR;  // Silent failure - no diagnostic output
}
```

**Solution**:
```c
if(invalid_state){
    Error(m, FUNCNAME, FILENAME, LINENUMBER,
        "Invalid state detected", NULL);
    return ERROR;
}
```

### Pitfall 5: Recursive Error() Calls

**Problem**:
```c
status MyFunc_ErrorHandler(MemCh *m, void *obj, void *msg){
    // Calls operation that might error
    Operation_That_Errors(m);  // Could call Error() again!

    return ERROR;
}
```

**Solution**: The `_error` global flag prevents this, but handlers should avoid operations that might error.

```c
status MyFunc_ErrorHandler(MemCh *m, void *obj, void *msg){
    // Only output and formatting - no risky operations
    Fmt(ErrStream, "Custom error message\n", NULL);
    return ERROR | NOOP;
}
```

### Pitfall 6: Forgetting to Propagate ERROR

**Problem**:
```c
status ProcessData(){
    status result = SubOperation();

    if(result & ERROR){
        // Error detected but not propagated
        Out("Error occurred\n", NULL);
        // Continues execution!
    }

    return SUCCESS;  // Wrong! Should return ERROR
}
```

**Solution**:
```c
status ProcessData(){
    status result = SubOperation();

    if(result & ERROR){
        return ERROR;  // Propagate error
    }

    return SUCCESS;
}
```

### Pitfall 7: Wrong Argument Type

**Problem**:
```c
i32 value = 42;
void *args[] = {
    &value,  // Wrong! Should wrap in Single
    NULL
};
Error(m, FUNCNAME, FILENAME, LINENUMBER, "Value: $", args);
// Crashes or garbage output
```

**Solution**:
```c
i32 value = 42;
void *args[] = {
    I32_Wrapped(m, value),  // Properly wrapped
    NULL
};
Error(m, FUNCNAME, FILENAME, LINENUMBER, "Value: $", args);
```

### Pitfall 8: Handler Doesn't Return NOOP

**Problem**:
```c
status MyErrorHandler(MemCh *m, void *obj, void *msg){
    Fmt(ErrStream, "Custom error output\n", NULL);
    return ERROR;  // Missing NOOP - will Fatal!
}
```

**Solution**:
```c
status MyErrorHandler(MemCh *m, void *obj, void *msg){
    Fmt(ErrStream, "Custom error output\n", NULL);
    return ERROR | NOOP;  // Signal: handled, don't Fatal
}
```

### Pitfall 9: Not Setting Object State

**Problem**:
```c
status Operation(Buff *bf){
    if(failure){
        Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
            "Operation failed", NULL);
        return ERROR;
        // bf->type.state not updated - caller may not know
    }
}
```

**Solution**:
```c
status Operation(Buff *bf){
    if(failure){
        Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
            "Operation failed", NULL);
        bf->type.state |= ERROR;  // Update state
        return ERROR;
    }
}
```

### Pitfall 10: Using Error() in Signal Handler

**Problem**:
```c
void my_signal_handler(int sig){
    Error(m, FUNCNAME, FILENAME, LINENUMBER,
        "Signal received", NULL);
    // Error() is not async-signal-safe!
}
```

**Solution**: Caneka's built-in signal handlers use safe operations:

```c
static void sigI(i32 sig, siginfo_t *info, void *ptr){
    if(_fuse){
        _fuse = FALSE;

        // Safe: direct write() syscall
        if(ErrStream->fd > 0){
            write(ErrStream->fd, "Signal\n", 7);
        }
    }
    exit(1);
}
```


## Cross-References

### Related Core Concepts

- **[Guard Mechanism Complete](guard-mechanism-complete.md)**: Infinite loop detection uses Error() for reporting
- **[MemCh Complete](memory/memchapter.md)**: Memory contexts and owner chains
- **[Type System Complete](type-system-complete.md)**: Type-specific error handlers via ErrorHandlers lookup
- **[Buff I/O Complete](buff-io-complete.md)**: Error reporting in I/O operations

### Integration Points

- **[Format System Complete](format-system-complete.md)**: Fmt() function used for error message formatting
- **[CLI Args](../guides/cli.md)**: Args_ErrorHandler shows help text on errors
- **[Task Execution Complete](navigate/task-execution-complete.md)**: Task-specific error handlers
- **[HTTP Lifecycle Complete](http-lifecycle-complete.md)**: HTTP error responses

### Implementation Files

- **Headers**:
  - [src/base/include/types/error.h](../../../src/base/include/types/error.h) - Error declarations
  - [src/base/include/types/error_msg.h](../../../src/base/include/types/error_msg.h) - ErrorMsg structure
- **Implementation**:
  - [src/base/types/error.c](../../../src/base/types/error.c) - Core error handling
  - [src/base/types/error_msg.c](../../../src/base/types/error_msg.c) - ErrorMsg creation
  - [src/base/core/init.c](../../../src/base/core/init.c) - Stream initialization
- **Examples**:
  - [src/base/termio/args.c](../../../src/base/termio/args.c) - Args error handler
  - [src/ext/navigate/task.c](../../../src/ext/navigate/task.c) - Task error handling
  - [src/base/io/file.c](../../../src/base/io/file.c) - File I/O errors

---

*This documentation provides a comprehensive guide to Caneka's error handling system. For specific use cases or custom error handler patterns, refer to the examples throughout the codebase.*



---

[← Part 1](error-handling-complete-part1) | **Part 2 of 2**
