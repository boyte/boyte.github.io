# HTTP Lifecycle: Complete Guide - Part 2

[← Part 1](http-lifecycle-complete-part1) | **Part 2 of 3** | [Part 3 →](http-lifecycle-complete-part3)

---

## HTTP Request Parsing State Machine

The Roebling-based HTTP parser is a finite state machine with 8 states, each corresponding to a part of the HTTP request format.

### State Diagram

```
START
  ↓
HTTP_METHOD (GET or POST)
  ↓
HTTP_PATH (URI path, e.g., /api/users)
  ↓
HTTP_VERSION (HTTP/1.1) OR HTTP_QUERY_START (if '?' detected)
  ↓
HTTP_QUERY (parse key=value pairs) → HTTP_QUERY_END
  ↓
HTTP_HEADERS (parse Header-Name: value lines)
  ↓
HTTP_BODY (if Content-Length present)
  ↓
END
```

### State Transitions in Detail

Each state has one or more patterns that trigger transitions to the next state.

#### State: HTTP_METHOD

**Purpose**: Match the HTTP method verb.

**Patterns**:
```c
// GET pattern
{PAT_TERM,'G'},{PAT_TERM,'E'},{PAT_TERM,'T'},
{PAT_TERM|PAT_MANY|PAT_CONSUME,' '}  // Consume spaces after GET

// POST pattern
{PAT_TERM,'P'},{PAT_TERM,'O'},{PAT_TERM,'S'},{PAT_TERM,'T'},
{PAT_TERM|PAT_MANY|PAT_CONSUME,' '}  // Consume spaces after POST
```

**Transitions**:
- Match "GET" → `ctx->method = HTTP_METHOD_GET`, advance to HTTP_PATH
- Match "POST" → `ctx->method = HTTP_METHOD_POST`, advance to HTTP_PATH
- No match → ERROR

**Example input**: `GET /index.html HTTP/1.1`
- Cursor at position 0
- Pattern matches "GET "
- Method stored, cursor now at position 4

#### State: HTTP_PATH

**Purpose**: Capture the request URI path up to '?' (query start) or ' ' (end of path).

**Pattern**:
```c
{PAT_KO|PAT_INVERT_CAPTURE, '?', '?'},  // Stop if '?' (query)
{PAT_KO|PAT_KO_TERM, ' ', ' '},          // Stop if ' ' (version)
patText                                  // Capture everything else
```

**Transitions**:
- Match until '?' → Store path, advance to HTTP_QUERY_START
- Match until ' ' → Store path, advance to HTTP_VERSION
- No match → ERROR

**Capture function**: The matched text becomes `ctx->path` (as a StrVec).

**Example 1**: `GET /api/users HTTP/1.1`
- Pattern matches "/api/users" (stops at space)
- `ctx->path = Sv(m, "/api/users")`
- Next state: HTTP_VERSION

**Example 2**: `GET /search?q=test HTTP/1.1`
- Pattern matches "/search" (stops at '?')
- `ctx->path = Sv(m, "/search")`
- Next state: HTTP_QUERY_START

#### State: HTTP_VERSION or HTTP_QUERY_START

**Purpose**: Distinguish between requests with and without query parameters.

**Patterns**:

**If HTTP_VERSION**:
```c
{PAT_TERM,'H'},{PAT_TERM,'T'},{PAT_TERM,'T'},{PAT_TERM,'P'},
{PAT_TERM,'/'},{PAT_TERM,'1'},{PAT_TERM,'.'},{PAT_TERM,'1','2'}
```

**If HTTP_QUERY_START**:
```c
{PAT_TERM, '?', '?'}  // Just match the '?'
```

**Transitions**:
- Match "HTTP/1.1" or "HTTP/1.0" → Store version, advance to HTTP_HEADERS
- Match '?' → Advance to HTTP_QUERY
- No match → ERROR

**Example**: `HTTP/1.1`
- Pattern matches "HTTP/1.1"
- `ctx->httpVersion = Sv(m, "HTTP/1.1")`
- Next state: HTTP_HEADERS

#### State: HTTP_QUERY

**Purpose**: Parse `key=value&key=value` query parameters, handling URL encoding.

**Pattern sequence**:
1. Match query key (up to '=')
2. Match '='
3. Match query value (up to '&' or ' ')
4. Match '&' → repeat from step 1
5. Match ' ' → end of query, advance to HTTP_VERSION

**URL encoding handling**:
```c
// Matches %XX where XX is a hex byte
{PAT_SINGLE|PAT_TERM, '%'},
{PAT_SINGLE, 'A', 'F'},{PAT_SINGLE, 'a', 'f'},{PAT_SINGLE|PAT_TERM, '0', '9'},
{PAT_SINGLE, 'A', 'F'},{PAT_SINGLE, 'a', 'f'},{PAT_SINGLE|PAT_TERM, '0', '9'}
```

**Capture functions**: Each key-value pair is stored in a Table at `queryIt.p`.

**Example**: `?name=Alice&age=30&city=New%20York HTTP/1.1`

**Parsing steps**:
1. Match "name" → Store key
2. Match '=' → Expect value
3. Match "Alice" → Store value, `Table_Set(queryIt.p, "name", "Alice")`
4. Match '&' → Continue
5. Match "age" → Store key
6. Match '=' → Expect value
7. Match "30" → Store value, `Table_Set(queryIt.p, "age", "30")`
8. Match '&' → Continue
9. Match "city" → Store key
10. Match '=' → Expect value
11. Match "New", then "%20", then "York" → Decode to "New York"
12. Store value, `Table_Set(queryIt.p, "city", "New York")`
13. Match ' ' → End of query

**Result**:
```c
ctx->queryIt.p = {
    "name" → StrVec("Alice"),
    "age" → StrVec("30"),      // Note: string, not integer
    "city" → StrVec("New York")
}
```

#### State: HTTP_HEADERS

**Purpose**: Parse `Header-Name: value\r\n` lines until empty line (`\r\n\r\n`).

**Pattern for header name**:
```c
{PAT_SINGLE, 'A', 'Z'},{PAT_SINGLE|PAT_TERM, 'a', 'z'},  // First char
{PAT_KO|PAT_KO_TERM, ':', ':'},                          // Stop at ':'
{PAT_MANY, 'A', 'Z'},{PAT_MANY, 'a', 'z'},{PAT_MANY, '0', '9'},
{PAT_MANY|PAT_TERM, '-', '-'}                            // Allow hyphens
```

**Pattern for header value**:
```c
{PAT_KO|PAT_KO_TERM, '\r', '\r'},{PAT_KO|PAT_KO_TERM, '\n', '\n'},
{PAT_MANY|PAT_INVERT_CAPTURE, ' ', ' '},  // Skip leading spaces
patText                                    // Capture value
```

**Line ending**:
```c
{PAT_TERM, '\r'},{PAT_TERM, '\n'}  // CRLF
```

**Capture function**: Each header is stored in `headersIt.p` table.

**Special header handling**:

**Content-Length** (integer value):
```c
{PAT_MANY|PAT_TERM|PAT_REQUIRE_KO, '0', '9'}  // Only digits
```
Capture function converts to integer and stores in `ctx->contentLength`.

**Header continuation** (folded headers):
```c
{PAT_MANY|PAT_INVERT_CAPTURE, '\t', '\t'},
{PAT_MANY|PAT_INVERT_CAPTURE, ' ', ' '},
```
If a line starts with whitespace, it's appended to the previous header value.

**Example headers**:
```
Content-Type: application/json\r\n
Content-Length: 123\r\n
Accept: text/html\r\n
If-None-Match: "a3f2c1b0-1704067200"\r\n
\r\n
```

**Parsed result**:
```c
ctx->headersIt.p = {
    "Content-Type" → StrVec("application/json"),
    "Accept" → StrVec("text/html"),
    "If-None-Match" → StrVec("\"a3f2c1b0-1704067200\"")
}
ctx->contentLength = 123;
```

**Empty line detection**: When `\r\n\r\n` is matched (header ending), advance to:
- HTTP_BODY if `Content-Length > 0`
- END if no body expected

#### State: HTTP_BODY

**Purpose**: The body is not parsed by the HTTP Roebling instance—it's left as raw bytes in the Cursor. A separate parser handles it.

**Transition**: After headers, if `Content-Length` is present:
1. Advance cursor by `Content-Length` bytes
2. Extract body substring as `Cursor_Sub`
3. Call `HttpCtx_ParseBody` with body Cursor

This separation allows the body parser to be swapped (JSON, XML, form data, etc.) without changing the HTTP parser.

### Complete Example: Parsing a POST Request

**Raw request**:
```
POST /api/users HTTP/1.1\r\n
Content-Type: application/json\r\n
Content-Length: 27\r\n
\r\n
{"name":"Bob","age":25}
```

**Parsing trace**:

1. **HTTP_METHOD**: Match "POST ", `method = HTTP_METHOD_POST`, cursor at 5
2. **HTTP_PATH**: Match "/api/users", `path = "/api/users"`, cursor at 15
3. **HTTP_VERSION**: Match " HTTP/1.1", `httpVersion = "HTTP/1.1"`, cursor at 24
4. **HTTP_HEADERS**:
   - Match "Content-Type: application/json\r\n", store header
   - Match "Content-Length: 27\r\n", store header, `contentLength = 27`
   - Match "\r\n" (empty line), end headers
5. **HTTP_BODY**: Extract 27 bytes starting at cursor position:
   - Body substring: `{"name":"Bob","age":25}`
   - Call `HttpCtx_ParseBody` with this substring
6. **JSON Parsing** (inside `HttpCtx_ParseBody`):
   - Create JsonParser Roebling instance
   - Parse JSON into Table
   - Result: `ctx->body = Table{"name" → "Bob", "age" → 25}`

**Final HttpCtx state**:
```c
HttpCtx {
    method = HTTP_METHOD_POST,
    code = 200,  // Default, will be set by handler
    path = StrVec("/api/users"),
    body = Table {
        "name" → StrVec("Bob"),
        "age" → Single(25)
    },
    headersIt.p = Table {
        "Content-Type" → StrVec("application/json"),
        "Content-Length" → StrVec("27")
    },
    contentLength = 27
}
```


## Routing & Handler Dispatch

### Route Tree Structure

Routes are organized as a tree of Inst objects that mirror the URL path hierarchy. Each Route is a Seel-backed Inst with properties:

**Route properties**:
```c
enum route_prop_idx {
    ROUTE_PROPIDX_PATH = 0,       // StrVec of path segment (e.g., "api")
    ROUTE_PROPIDX_DATA = 1,       // Table of route-specific data
    ROUTE_PROPIDX_CHILDREN = 2,   // Span of child Routes
    ROUTE_ROUTE_GENS = 3          // Generation count (for config reloading)
};
```

**Route flags** (stored in `type.state`):
```c
ROUTE_STATIC = 1 << 8     // Serve static file
ROUTE_DYNAMIC = 1 << 9    // Render template
ROUTE_FMT = 1 << 10       // Convert Pencil format to HTML
ROUTE_INDEX = 1 << 13     // Directory index (index.html)
ROUTE_BINSEG = 1 << 11    // BinSeg database endpoint
ROUTE_ACTION = 1 << 14    // Custom action handler
ROUTE_FORBIDDEN = 1 << 15 // Return 403
```

**Example tree for a typical web application**:

```
Root Route "/"
│
├─ [ROUTE_STATIC] "index.html"
│   action: "/var/www/index.html"
│   mime: "text/html"
│
├─ [ROUTE_STATIC] "style.css"
│   action: "/var/www/style.css"
│   mime: "text/css"
│
├─ Route "api/"
│   │
│   ├─ [ROUTE_BINSEG] "users"
│   │   action: BinSegCtx (database)
│   │   mime: "application/json"
│   │
│   └─ [ROUTE_BINSEG] "posts"
│       action: BinSegCtx (database)
│
├─ [ROUTE_FMT] "about"
│   action: Mess (parsed Pencil document)
│   mime: "text/html"
│
└─ Route "blog/"
    │
    ├─ [ROUTE_DYNAMIC] "index.templ"
    │   templ: Templ (prepared template)
    │   data: Table (config data)
    │
    └─ [ROUTE_DYNAMIC] "post.templ"
        templ: Templ (prepared template)
```

### Route Building: From Filesystem to Tree

Routes are typically built by scanning the web root directory and creating Route Insts for each file and subdirectory.

**Route creation from directory**:

```c
Route *Route_From(MemCh *m, StrVec *dir){
    Route *rt = Route_Make(m);

    // Set path property
    Seel_Set(rt, K(m, "path"), dir);

    // Initialize children span
    Span *children = Span_Make(m, 4);
    Seel_Set(rt, K(m, "children"), children);

    // Scan directory
    DIR *d = opendir(StrVec_Cstr(m, dir));
    struct dirent *entry;
    while((entry = readdir(d)) != NULL){
        if(entry->d_type == DT_DIR && strcmp(entry->d_name, ".") != 0
                && strcmp(entry->d_name, "..") != 0){
            // Subdirectory → recursive Route_From
            StrVec *subdir = StrVec_Copy(m, dir);
            StrVec_AddCstr(subdir, "/");
            StrVec_AddCstr(subdir, entry->d_name);

            Route *child = Route_From(m, subdir);
            Span_Add(children, child);
        }else if(entry->d_type == DT_REG){
            // Regular file → create leaf route
            Route *fileRoute = Route_Make(m);

            // Determine file type and set handler
            Str *filename = Str_FromCstr(m, entry->d_name, ZERO);
            Route_SetTargetFile(fileRoute, filename, dir);

            Span_Add(children, fileRoute);
        }
    }
    closedir(d);

    return rt;
}
```

**File type detection and handler assignment**:

```c
status Route_SetTargetFile(Route *rt, Str *ext, Str *absPath){
    MemCh *m = rt->m;

    // Get file extension
    Str *extension = Str_GetExtension(ext);

    if(Str_Equals(extension, K(m, "html")) || Str_Equals(extension, K(m, "css"))
            || Str_Equals(extension, K(m, "js"))){
        // Static file
        rt->type.state |= ROUTE_STATIC;
        Seel_Set(rt, K(m, "action"), absPath);

        // Set MIME type
        Single *mimeFunc = Route_MimeFunc(extension);
        Str *mime = ((Str *(*)(MemCh *))mimeFunc->val.func)(m);
        Seel_Set(rt, K(m, "mime"), mime);

    }else if(Str_Equals(extension, K(m, "templ"))){
        // Template file
        rt->type.state |= ROUTE_DYNAMIC;

        // Prepare template (parse and compile)
        Templ *templ = prepareTempl(rt, absPath);
        Seel_Set(rt, K(m, "templ"), templ);
        Seel_Set(rt, K(m, "mime"), Sv(m, "text/html"));

    }else if(Str_Equals(extension, K(m, "fmt"))){
        // Pencil format file
        rt->type.state |= ROUTE_FMT;

        // Parse Pencil document into Mess structure
        Mess *mess = Fmt_FromFile(m, absPath);
        Seel_Set(rt, K(m, "action"), mess);
        Seel_Set(rt, K(m, "mime"), Sv(m, "text/html"));

    }else if(Str_Equals(extension, K(m, "binseg"))){
        // Database endpoint
        rt->type.state |= ROUTE_BINSEG;

        // Create BinSegCtx for this database
        BinSegCtx *bsCtx = BinSegCtx_Make(m, absPath);
        Seel_Set(rt, K(m, "action"), bsCtx);
        Seel_Set(rt, K(m, "mime"), Sv(m, "application/json"));
    }

    return READY;
}
```

**Template preparation** (happens at server startup, not per-request):

```c
static Templ *prepareTempl(Route *rt, StrVec *path){
    MemCh *m = rt->m;

    // Read template file
    StrVec *content = File_ToVec(m, StrVec_Str(m, path));
    if(content == NULL || content->total == 0){
        // Error handling
        return NULL;
    }

    // Parse template
    Cursor *curs = Cursor_Make(m, content);
    Templ *templ = Templ_Make(m);
    Templ_Parse(templ, curs);

    // Prepare template (analyze jumps, build data stack)
    Templ_Prepare(templ);

    return templ;
}
```

This preparation is costly (parsing, analyzing) but happens once at startup. Each request just calls `Templ_Reset()` and `Templ_ToS()`.

### Route Lookup Algorithm

When an HTTP request arrives with path `/api/users`, the route tree is traversed to find a matching handler.

**Algorithm**: `Route_Get(Route *rt, StrVec *path)`

```c
Route *Route_Get(Route *rt, StrVec *path){
    MemCh *m = rt->m;

    // Tokenize path by '/'
    Span *tokens = StrVec_Split(m, path, K(m, "/"));

    Route *current = rt;  // Start at root

    // Traverse tree
    Iter it;
    Iter_Init(&it, tokens);
    while((Iter_Next(&it) & END) == 0){
        StrVec *token = Iter_Get(&it);
        if(token == NULL || token->total == 0){
            continue;  // Skip empty tokens (e.g., leading '/')
        }

        // Get children of current route
        Span *children = Seel_Get(current, K(m, "children"));
        if(children == NULL){
            return NULL;  // Dead end, no match
        }

        // Find child matching this token
        Route *match = NULL;
        Iter childIt;
        Iter_Init(&childIt, children);
        while((Iter_Next(&childIt) & END) == 0){
            Route *child = Iter_Get(&childIt);
            StrVec *childPath = Seel_Get(child, K(m, "path"));

            if(Equals(childPath, token)){
                match = child;
                break;
            }
        }

        if(match == NULL){
            return NULL;  // No child matches this segment
        }

        current = match;  // Descend to child
    }

    return current;  // Final route
}
```

**Example traversal** for `/blog/post.templ`:

1. Tokenize: `["blog", "post.templ"]`
2. Start at root route
3. Token "blog":
   - Get root's children
   - Find child with `path = "blog"`
   - Descend to blog route
4. Token "post.templ":
   - Get blog's children
   - Find child with `path = "post.templ"`
   - Descend to post.templ route
5. Return post.templ route

**Route matching in WebServer_GatherPage**:

```c
status WebServer_GatherPage(Step *st, Task *tsk){
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Global root route (initialized at startup)
    extern Route *WebServerRoot;

    // Match route
    Route *rt = Route_Get(WebServerRoot, ctx->path);

    if(rt == NULL){
        // 404 Not Found
        ctx->code = 404;
        ctx->type.state |= ERROR;
        return ERROR;
    }

    // Store matched route
    ctx->route = rt;

    // Dispatch to handler (next section)
    ...
}
```

### Handler Dispatch

Once a route is matched, its handler function is called based on the route's flags.

**Handler function table**:

```c
// Global table mapping route flags to handler functions
Span *RouteFuncTable = NULL;

status Route_Init(MemCh *m){
    RouteFuncTable = Span_Make(m, 8);

    Span_Set(RouteFuncTable, ROUTE_STATIC, Func_Wrapped(m, routeFuncStatic));
    Span_Set(RouteFuncTable, ROUTE_DYNAMIC, Func_Wrapped(m, routeFuncTempl));
    Span_Set(RouteFuncTable, ROUTE_FMT, Func_Wrapped(m, routeFuncFmt));
    Span_Set(RouteFuncTable, ROUTE_BINSEG, Func_Wrapped(m, routeFuncFileDb));

    return READY;
}
```

**Handler retrieval and invocation**:

```c
// In WebServer_GatherPage (continued from above)
Route *rt = ctx->route;

// Get handler function based on route flags
RouteFunc handler = NULL;
if(rt->type.state & ROUTE_STATIC){
    handler = Span_Get(RouteFuncTable, ROUTE_STATIC);
}else if(rt->type.state & ROUTE_DYNAMIC){
    handler = Span_Get(RouteFuncTable, ROUTE_DYNAMIC);
}else if(rt->type.state & ROUTE_FMT){
    handler = Span_Get(RouteFuncTable, ROUTE_FMT);
}else if(rt->type.state & ROUTE_BINSEG){
    handler = Span_Get(RouteFuncTable, ROUTE_BINSEG);
}

if(handler == NULL){
    ctx->code = 500;
    ctx->type.state |= ERROR;
    return ERROR;
}

// Invoke handler
status r = handler(proto->out, rt, ctx->data, ctx);

if(r & ERROR){
    ctx->code = 500;
    ctx->type.state |= ERROR;
}else{
    ctx->code = 200;
    ctx->contentLength = proto->out->v->total;
}

return r;
```

### Handler Implementations Detailed

#### Static File Handler

**Purpose**: Serve file content directly without modification.

**Implementation**:

```c
static status routeFuncStatic(Buff *bf, Route *rt, Table *_data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get absolute file path from route
    Str *pathS = StrVec_Str(bf->m,
        (StrVec *)as(Seel_Get(rt, K(m, "action")), TYPE_STRVEC));

    // Check if file exists and is readable
    struct stat st;
    if(stat((char *)pathS->bytes, &st) != 0){
        ctx->code = 404;
        ctx->type.state |= ERROR;
        return ERROR;
    }

    // Set MIME type
    ctx->mime = Seel_Get(rt, K(m, "mime"));

    // Set unbuffered mode for efficient streaming
    bf->type.state |= BUFF_UNBUFFERED;

    // Open file and attach to buffer
    status r = File_Open(bf, pathS, O_RDONLY);

    if(r & ERROR){
        ctx->code = 500;
        ctx->type.state |= ERROR;
    }

    return r;
}
```

**Key optimization**: `BUFF_UNBUFFERED` mode means the buffer's file descriptor becomes the opened file. When `Buff_Send` is called, it uses `sendfile(2)` or equivalent zero-copy transmission. The file content never enters user space.

**Example request/response**:

Request:
```
GET /style.css HTTP/1.1
```

Response:
```
HTTP/1.1 200 OK
Content-Type: text/css
Content-Length: 4521

/* CSS content streamed directly from disk */
body { margin: 0; }
...
```

#### Template Handler

**Purpose**: Render a prepared Templ template with request-specific data.

**Implementation**:

```c
static status routeFuncTempl(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get prepared template
    Templ *templ = (Templ *)as(Seel_Get(rt, K(m, "templ")), TYPE_TEMPL);

    if(templ == NULL){
        ctx->code = 500;
        ctx->type.state |= ERROR;
        return ERROR;
    }

    // Reset template (clears previous render state)
    Templ_Reset(templ);

    // Set MIME type
    ctx->mime = Sv(m, "text/html");

    // Render template with data context
    status r = Templ_ToS(templ, bf, data, NULL);

    if(r & ERROR){
        ctx->code = 500;
        ctx->type.state |= ERROR;
    }

    return r;
}
```

**Data context**: The `data` table contains:
- **Session data**: Injected by TcpCtx's `defaultData` function
- **Query parameters**: `ctx->queryIt.p` table
- **POST body**: `ctx->body` (if JSON parsed)
- **Route-specific config**: Loaded from `.config` files in route directory

**Example template** (blog/post.templ):
```html
<!DOCTYPE html>
<html>
<head><title>{post.title}</title></head>
<body>
    <h1>{post.title}</h1>
    <p>By {post.author} on {post.date}</p>
    <div>{post.content}</div>

    <h2>Comments</h2>
    <ul>
    {#comments}
        <li><strong>{name}</strong>: {text}</li>
    {/comments}
    </ul>
</body>
</html>
```

**Data table for this template**:
```c
data = {
    "post" → Table {
        "title" → StrVec("My First Post"),
        "author" → StrVec("Alice"),
        "date" → StrVec("2026-01-17"),
        "content" → StrVec("<p>This is the post content.</p>")
    },
    "comments" → Span [
        Table {"name" → "Bob", "text" → "Great post!"},
        Table {"name" → "Carol", "text" → "Very helpful."}
    ]
}
```

**Rendered output**:
```html
<!DOCTYPE html>
<html>
<head><title>My First Post</title></head>
<body>
    <h1>My First Post</h1>
    <p>By Alice on 2026-01-17</p>
    <div><p>This is the post content.</p></div>

    <h2>Comments</h2>
    <ul>
        <li><strong>Bob</strong>: Great post!</li>
        <li><strong>Carol</strong>: Very helpful.</li>
    </ul>
</body>
</html>
```

The template rendering is zero-copy when possible—Templ writes directly to the Buff's StrVec without intermediate allocations.

#### Pencil Format Handler

**Purpose**: Convert Pencil (.fmt) documents to HTML on the fly.

**Implementation**:

```c
static status routeFuncFmt(Buff *bf, Route *rt, Table *_data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get parsed Mess structure
    Mess *mess = (Mess *)as(Seel_Get(rt, K(m, "action")), TYPE_MESS);

    if(mess == NULL){
        ctx->code = 500;
        ctx->type.state |= ERROR;
        return ERROR;
    }

    // Set MIME type
    ctx->mime = Sv(m, "text/html");

    // Convert Mess to HTML
    status r = Fmt_ToHtml(bf, mess);

    if(r & ERROR){
        ctx->code = 500;
        ctx->type.state |= ERROR;
    }

    return r;
}
```

**Mess structure**: Pencil documents are parsed into a tree of Mess nodes representing headings, paragraphs, lists, links, etc. `Fmt_ToHtml` traverses this tree and writes HTML tags.

**Example Pencil document** (about.fmt):
```
# About Caneka

Caneka is a *full-stack web framework* written from scratch in C.


## Features

- Memory management with MemBook/MemChapter
- Roebling parser for DSLs
- Templ template engine
```

**Generated HTML**:
```html
<h1>About Caneka</h1>
<p>Caneka is a <em>full-stack web framework</em> written from scratch in C.</p>
<h2>Features</h2>
<ul>
    <li>Memory management with MemBook/MemChapter</li>
    <li>Roebling parser for DSLs</li>
    <li>Templ template engine</li>
</ul>
```

This handler is used for serving documentation—the `/docs` folder in the webserver is often filled with `.fmt` files that render as HTML.

#### BinSeg Database Handler

**Purpose**: Provide RESTful CRUD operations on BinSeg (binary segment) databases.

**Implementation**:

```c
static status routeFuncFileDb(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get BinSeg context
    BinSegCtx *bsCtx = (BinSegCtx *)as(Seel_Get(rt, K(m, "action")), TYPE_BINSEG_CTX);

    // Get action from query parameter (?action=add)
    Abstract *action = Table_Get(ctx->queryIt.p, K(m, "action"));

    if(action == NULL){
        ctx->code = 403;
        ctx->type.state |= ERROR;
        return ERROR;
    }

    status r = READY;

    // Dispatch based on action
    if(Equals(action, K(m, "add"))){
        // Add record (POST body should contain data)
        if(ctx->body == NULL){
            ctx->code = 400;  // Bad Request
            ctx->type.state |= ERROR;
            return ERROR;
        }

        // Validate body type
        if(ctx->body->type.of != TYPE_TABLE &&
           ctx->body->type.of != TYPE_SPAN &&
           !(ctx->body->type.of & TYPE_INSTANCE)){
            ctx->code = 400;
            ctx->type.state |= ERROR;
            return ERROR;
        }

        // Insert into BinSeg database
        r = BinSegCtx_Send(bsCtx, ctx->body);

    }else if(Equals(action, K(m, "modify"))){
        // Update existing record
        // TODO: Implement modify logic

    }else if(Equals(action, K(m, "read"))){
        // Query records
        // TODO: Implement read logic

    }else{
        ctx->code = 403;
        ctx->type.state |= ERROR;
        return ERROR;
    }

    // Determine response format based on Accept header
    StrVec *acceptHeader = Table_Get(ctx->headersIt.p, K(m, "Accept"));

    if(acceptHeader != NULL && Equals(acceptHeader, K(m, "text/html"))){
        // HTML response: render template with form data
        Table_Set(data, K(m, "form"), ctx->body);
        return routeFuncTempl(bf, rt, data, ctx);
    }else{
        // JSON response
        ctx->mime = Sv(m, "application/json");

        // Serialize result to JSON
        // TODO: Implement JSON serialization

        return r;
    }
}
```

**Usage example**: POST to `/api/users?action=add` with JSON body:

Request:
```
POST /api/users?action=add HTTP/1.1
Content-Type: application/json
Content-Length: 35

{"name":"Bob","email":"bob@ex.com"}
```

Processing:
1. Route matches `/api/users` (ROUTE_BINSEG)
2. Query parameter `action=add` detected
3. Body parsed into Table: `{"name" → "Bob", "email" → "bob@ex.com"}`
4. `BinSegCtx_Send(bsCtx, body)` inserts record
5. Response depends on Accept header

Response (Accept: application/json):
```
HTTP/1.1 200 OK
Content-Type: application/json

{"status":"success","id":42}
```

Response (Accept: text/html):
```
HTTP/1.1 200 OK
Content-Type: text/html

<html>
<body>
    <p>User Bob added successfully!</p>
    <a href="/api/users">View all users</a>
</body>
</html>
```

The HTML response is generated by calling `routeFuncTempl` with the form data, allowing a single endpoint to serve both API and web UI.


## ETag Support & Caching

ETags (Entity Tags) provide cache validation, allowing browsers to skip downloading unchanged resources.

### ETag Generation

**Algorithm**: Hash the file path + modification timestamp to create a unique identifier.

**Implementation from http_ctx.c:6**:

```c
StrVec *HttpCtx_MakeEtag(MemCh *m, Str *path, struct timespec *mod){
    StrVec *v = StrVec_Make(m);

    // Compute parity hash of file path
    quad hpar = HalfParity_From(path);

    // Convert hash to hex string
    Str s = {
        .type = {TYPE_STR, STRING_BINARY|STRING_CONST},
        .length = sizeof(quad),
        .alloc = sizeof(quad),
        .bytes = (byte *)&hpar
    };
    StrVec_Add(v, Str_ToHex(m, &s));

    // Append separator
    StrVec_Add(v, Str_Ref(m, (byte *)"-", 1, 1, STRING_COPY|MORE));

    // Append modification timestamp
    StrVec_Add(v, Str_FromI64(m, mod->tv_sec));

    return v;  // Result: "a3f2c1b0-1704067200"
}
```

**Why this format?**
- **Hash**: Identifies the file (different files → different hashes)
- **Timestamp**: Identifies file version (file modified → timestamp changes)
- **Combined**: Unique identifier for this specific version of this file

**Example**:
- File: `/var/www/style.css`
- Modified: Unix timestamp 1704067200
- Hash: `a3f2c1b0` (from `HalfParity_From("/var/www/style.css")`)
- ETag: `"a3f2c1b0-1704067200"`

### ETag Validation Flow

**First request** (no cache):

Client request:
```
GET /style.css HTTP/1.1
```

Server response:
```
HTTP/1.1 200 OK
Content-Type: text/css
Content-Length: 4521
ETag: "a3f2c1b0-1704067200"

/* CSS content */
body { margin: 0; }
...
```

Browser stores the file and ETag in cache.

**Second request** (with cache):

Client request:
```
GET /style.css HTTP/1.1
If-None-Match: "a3f2c1b0-1704067200"
```

Server processing:
1. Parse `If-None-Match` header
2. Match route to `/style.css`
3. Get file modification time
4. Generate ETag for current file
5. Compare ETags

If match (file unchanged):
```
HTTP/1.1 304 Not Modified
ETag: "a3f2c1b0-1704067200"

```
(No body sent, browser uses cached version)

If no match (file modified):
```
HTTP/1.1 200 OK
Content-Type: text/css
Content-Length: 4821
ETag: "b2e1d3c4-1704153600"

/* Updated CSS content */
body { margin: 0; padding: 0; }
...
```

### ETag Checking Implementation

**In static file handler**:

```c
static status routeFuncStatic(Buff *bf, Route *rt, Table *_data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get file path
    Str *pathS = StrVec_Str(bf->m,
        (StrVec *)as(Seel_Get(rt, K(m, "action")), TYPE_STRVEC));

    // Stat file to get modification time
    struct stat st;
    if(stat((char *)pathS->bytes, &st) != 0){
        ctx->code = 404;
        return ERROR;
    }

    // Generate ETag
    StrVec *etag = HttpCtx_MakeEtag(m, pathS, &st.st_mtim);

    // Check If-None-Match header
    StrVec *ifNoneMatch = Table_Get(ctx->headersIt.p, K(m, "If-None-Match"));

    if(ifNoneMatch != NULL && Equals(ifNoneMatch, etag)){
        // ETag matches, return 304
        ctx->code = 304;
        Table_Set(ctx->headersOut, K(m, "ETag"), etag);

        // No body needed for 304
        return READY;
    }

    // ETag doesn't match or not present, send full file
    ctx->code = 200;
    ctx->mime = Seel_Get(rt, K(m, "mime"));
    Table_Set(ctx->headersOut, K(m, "ETag"), etag);

    bf->type.state |= BUFF_UNBUFFERED;
    return File_Open(bf, pathS, O_RDONLY);
}
```

**Key optimization**: The 304 response skips the `File_Open` call entirely—no file I/O happens, making cache hits extremely fast.

### Performance Impact

**Without ETags**:
- Every request: Read file from disk, transmit over network
- 4 KB CSS file: ~0.5ms disk I/O + network latency
- 100 requests/sec: 50ms of I/O, full bandwidth usage

**With ETags** (80% cache hit rate):
- 80 requests: 304 response, ~0.05ms (no I/O), minimal bandwidth
- 20 requests: 200 response, ~0.5ms I/O + full transmission
- Total: 14ms I/O, 20% bandwidth

ETags reduce both server load and network traffic significantly for static assets.



---

[← Part 1](http-lifecycle-complete-part1) | **Part 2 of 3** | [Part 3 →](http-lifecycle-complete-part3)
