---
sidebar_position: 3
---

# Roebling Pattern Matching - Complete Guide

The Roebling parser uses a sophisticated **pattern matching system** to parse text streams character-by-character. This guide explains how patterns work, how matches are tracked, and how to create custom parsers.

## Core Concept

Roebling maintains multiple concurrent **Match** objects, each attempting to match a different pattern against the input stream. When a Match succeeds, a capture function is called with the matched content.

### Architecture

```
Input Stream → Roebling → [Match 1, Match 2, ..., Match N] → Captures
```

**Key Insight**: Unlike regex engines that try one pattern at a time, Roebling feeds each byte to **all active patterns simultaneously**, allowing overlapping matches and complex state machines.

## Pattern Character Definitions

Patterns are arrays of **PatCharDef** structures that define what characters are acceptable at each position:

```c
typedef struct pat_char_def {
    byte kind;          // Pattern type (PAT_TERM, PAT_MANY, etc.)
    byte ch;            // Character to match (or class)
    word count;         // Count for PAT_COUNT
    PatCharDef *ko;     // Knockout pattern (alternative if this fails)
} PatCharDef;
```

### Pattern Types

#### PAT_TERM - Terminal Marker

Marks the end of a matching term (sub-pattern).

```c
{ PAT_TERM, 0, 0, NULL }
```

**Purpose**: Signals that a portion of the pattern has matched, allowing intermediate captures.

**Example Pattern**: `"hello" TERM " " "world"`
- Captures "hello" when TERM is reached
- Continues matching " world"

#### PAT_MANY - Zero or More

Matches 0 or more characters of a specific class.

```c
{ PAT_MANY, 'a', 0, NULL }  // Match aaa*, aa*, a*, or even empty
```

**Character Classes:**
- `'a'` - Alphabetic characters
- `'n'` - Numeric characters
- `'w'` - Whitespace
- `' '` - Literal space
- Any literal character

**Example**: Email username pattern
```c
PatCharDef email_user[] = {
    { PAT_MANY, 'a', 0, NULL },  // letters*
    { PAT_MANY, 'n', 0, NULL },  // numbers*
    { PAT_TERM, 0, 0, NULL }
};
```

#### PAT_OPTIONAL - Zero or One

Matches 0 or 1 occurrence of a character.

```c
{ PAT_OPTIONAL, 's', 0, NULL }  // Match 's' or empty
```

**Example**: Optional 's' for plurals
```c
PatCharDef plural[] = {
    { PAT_MANY, 'a', 0, NULL },  // word
    { PAT_OPTIONAL, 's', 0, NULL },  // optional 's'
    { PAT_TERM, 0, 0, NULL }
};
// Matches: "cat", "cats", "dog", "dogs"
```

#### PAT_ANY - Match Anything

Matches any single character.

```c
{ PAT_ANY, 0, 0, NULL }
```

**Example**: Wildcard pattern
```c
PatCharDef wildcard[] = {
    { 0, 'a', 0, NULL },         // 'a'
    { PAT_ANY, 0, 0, NULL },     // any char
    { 0, 'z', 0, NULL },         // 'z'
    { PAT_TERM, 0, 0, NULL }
};
// Matches: "abz", "a5z", "a!z", etc.
```

#### PAT_INVERT - Negate Class

Inverts the character class (match anything EXCEPT).

```c
{ PAT_INVERT | PAT_MANY, 'w', 0, NULL }  // Match non-whitespace*
```

**Example**: Parse until whitespace
```c
PatCharDef until_space[] = {
    { PAT_INVERT | PAT_MANY, 'w', 0, NULL },  // anything but whitespace
    { PAT_TERM, 0, 0, NULL }
};
// Matches: "word", "file.txt", "192.168.1.1"
// Stops at first space
```

#### PAT_COUNT - Counted Repetition

Matches exactly N occurrences.

```c
{ PAT_COUNT, 'n', 4, NULL }  // Match exactly 4 digits
```

**Example**: Year pattern (YYYY)
```c
PatCharDef year[] = {
    { PAT_COUNT, 'n', 4, NULL },  // 4 digits
    { PAT_TERM, 0, 0, NULL }
};
// Matches: "2025", "1999", "2000"
// Rejects: "25", "99999"
```

#### PAT_LEAVE - Stop Consuming

Stops consuming input after matching, useful for lookahead.

```c
{ PAT_LEAVE, 'x', 0, NULL }
```

**Example**: Match word before colon
```c
PatCharDef key[] = {
    { PAT_MANY, 'a', 0, NULL },   // word
    { PAT_LEAVE, ':', 0, NULL },  // followed by ':' but don't consume it
    { PAT_TERM, 0, 0, NULL }
};
// Input: "name:value"
// Matches: "name" (leaves ':' in stream)
```

#### PAT_KO - Knockout Pattern

Provides an alternative pattern if the main one fails.

```c
PatCharDef *ko_pattern = /* alternative definition */;
{ 0, 'x', 0, ko_pattern }
```

**Example**: Try quoted string, fallback to bare word
```c
PatCharDef *bare_word = /* pattern for unquoted word */;
PatCharDef quoted_or_bare[] = {
    { 0, '"', 0, bare_word },      // Try quote, fallback to bare_word
    { PAT_MANY, 'a', 0, NULL },    // word content
    { 0, '"', 0, NULL },           // closing quote
    { PAT_TERM, 0, 0, NULL }
};
```

## Match Structure

Each **Match** tracks the state of attempting to match a pattern:

```c
typedef struct match {
    PatCharDef *startDef;      // Beginning of pattern
    PatCharDef *curDef;        // Current position in pattern
    PatCharDef *lastTermDef;   // Last TERM marker seen
    Snip snip;                 // Tracks matched content
    Span *backlog;             // Collected match data
    word captureKey;           // ID for this match
} Match;
```

### Match Lifecycle

1. **Initialize**: `Match_Make()` creates Match from pattern
   - `curDef` = `startDef`
   - `snip` = empty
   - `backlog` = empty Span

2. **Feed Bytes**: `Match_Feed(byte)` advances state
   - Check if byte matches `curDef`
   - If yes, advance `curDef`, add byte to snip
   - If no, fail match or try KO pattern
   - If PAT_TERM reached, create Snip in backlog

3. **Complete**: When full pattern matches
   - `curDef` points past last PatCharDef
   - All snips collected in backlog
   - Ready for capture dispatch

4. **Dispatch**: `Roebling_Dispatch()` calls capture function
   - Passes matched content as StrVec
   - Capture function processes result

## Snips - Sub-Matches

A **Snip** represents a portion of matched content (between TERM markers):

```c
typedef struct snip {
    SnipState state;    // SNIP_GAP, SNIP_CONTENT, SNIP_NOTAIL
    i32 start;          // Start position in input
    i32 len;            // Length of matched content
} Snip;
```

### Snip States

- **SNIP_GAP**: No content (zero-width match)
- **SNIP_CONTENT**: Normal matched content
- **SNIP_NOTAIL**: Content without trailing character

### Example with Multiple Terms

```c
PatCharDef http_line[] = {
    { PAT_MANY, 'a', 0, NULL },  // method
    { PAT_TERM, 0, 0, NULL },    // TERM 1
    { 0, ' ', 0, NULL },         // space
    { PAT_MANY, 'a', 0, NULL },  // path
    { PAT_TERM, 0, 0, NULL },    // TERM 2
    { 0, ' ', 0, NULL },         // space
    { PAT_MANY, 'a', 0, NULL },  // version
    { PAT_TERM, 0, 0, NULL }     // TERM 3
};
```

**Input**: `"GET /index.html HTTP/1.1"`

**Snips created**:
1. Snip 0: "GET" (TERM 1)
2. Snip 1: "/index.html" (TERM 2)
3. Snip 2: "HTTP/1.1" (TERM 3)

**Backlog**: Span with 3 Snips

**Dispatch**: Capture function receives StrVec with ["GET", "/index.html", "HTTP/1.1"]

## Capture Functions

Capture functions are callbacks invoked when a pattern fully matches:

```c
typedef status (*RblCaptureFunc)(
    Roebling *rbl,
    word captureKey,
    StrVec *matched
);
```

### Parameters

- `rbl`: Roebling parser instance (for context)
- `captureKey`: ID identifying which pattern matched
- `matched`: StrVec containing matched snips

### Example Capture Function

```c
status ParseHttpLine(Roebling *rbl, word captureKey, StrVec *matched) {
    // matched[0] = method ("GET")
    // matched[1] = path ("/index.html")
    // matched[2] = version ("HTTP/1.1")

    HttpRequest *req = rbl->context;  // Stored in Roebling
    req->method = StrVec_GetStr(matched, 0);
    req->path = StrVec_GetStr(matched, 1);
    req->version = StrVec_GetStr(matched, 2);

    return SUCCESS;
}

// Register pattern
Roebling_SetPattern(rbl, http_line, CAPTURE_HTTP_LINE, ParseHttpLine);
```

## Complete Example: Simple INI Parser

Let's build a parser for INI files:

```ini
[section]
key=value
another_key = another value
```

### Pattern Definitions

```c
// Pattern 1: Section header [section]
PatCharDef section_pattern[] = {
    { 0, '[', 0, NULL },             // literal '['
    { PAT_MANY, 'a', 0, NULL },      // section name
    { PAT_TERM, 0, 0, NULL },        // TERM - capture section name
    { 0, ']', 0, NULL },             // literal ']'
    { PAT_TERM, 0, 0, NULL }         // TERM - done
};

// Pattern 2: Key-value pair key=value
PatCharDef keyvalue_pattern[] = {
    { PAT_INVERT | PAT_MANY, '=', 0, NULL },  // key (anything but '=')
    { PAT_TERM, 0, 0, NULL },        // TERM - capture key
    { 0, '=', 0, NULL },             // literal '='
    { PAT_MANY | PAT_OPTIONAL, 'w', 0, NULL },  // optional whitespace
    { PAT_MANY, 'a', 0, NULL },      // value
    { PAT_TERM, 0, 0, NULL }         // TERM - capture value
};
```

### Capture Functions

```c
status CaptureSection(Roebling *rbl, word key, StrVec *matched) {
    IniConfig *cfg = rbl->context;
    cfg->current_section = StrVec_GetStr(matched, 0);  // Section name
    return SUCCESS;
}

status CaptureKeyValue(Roebling *rbl, word key, StrVec *matched) {
    IniConfig *cfg = rbl->context;
    Str *key_str = StrVec_GetStr(matched, 0);
    Str *value_str = StrVec_GetStr(matched, 1);

    // Store in current section
    Table_Set(cfg->sections, cfg->current_section,
        Table_Make(m, key_str, value_str));

    return SUCCESS;
}
```

### Parser Setup

```c
IniConfig *ParseIni(MemCh *m, const char *filename) {
    // Load file into cursor
    Str *content = File_ToStr(m, filename);
    Cursor *curs = Cursor_Make(m, content);

    // Create parser
    Roebling *rbl = Roebling_Make(m);
    IniConfig *cfg = MemCh_AllocOf(m, sizeof(IniConfig), TYPE_CONFIG);
    rbl->context = cfg;

    // Register patterns
    Roebling_SetPattern(rbl, section_pattern, KEY_SECTION, CaptureSection);
    Roebling_SetPattern(rbl, keyvalue_pattern, KEY_KEYVALUE, CaptureKeyValue);

    // Parse
    Roebling_Start(rbl, curs);
    while (!Cursor_AtEnd(curs)) {
        status result = Roebling_RunMatches(rbl);
        if (result & ERROR) break;
    }

    return cfg;
}
```

## Best Practices

1. **Use TERM markers strategically** - Place them where you want to capture sub-matches
2. **Leverage character classes** - Use 'a', 'n', 'w' instead of enumerating characters
3. **Use PAT_INVERT for exclusion** - "Match until X" patterns
4. **Provide KO patterns** for alternatives - Try quoted, fallback to unquoted
5. **Keep patterns focused** - One pattern per construct (section, keyvalue, etc.)
6. **Store context in Roebling** - Use `rbl->context` for parser state

## Common Pitfalls

### Pitfall 1: Forgetting TERM Markers

```c
// WRONG - No TERM, nothing captured
PatCharDef wrong[] = {
    { PAT_MANY, 'a', 0, NULL }
};

// RIGHT - TERM triggers capture
PatCharDef right[] = {
    { PAT_MANY, 'a', 0, NULL },
    { PAT_TERM, 0, 0, NULL }
};
```

### Pitfall 2: Greedy Matching

```c
// WRONG - PAT_MANY is greedy, consumes everything
PatCharDef greedy[] = {
    { PAT_MANY, 'a', 0, NULL },  // Matches entire input
    { 0, ' ', 0, NULL }          // Never reached
};

// RIGHT - Use PAT_INVERT to stop at delimiter
PatCharDef correct[] = {
    { PAT_INVERT | PAT_MANY, 'w', 0, NULL },  // Stop at whitespace
    { PAT_TERM, 0, 0, NULL }
};
```

### Pitfall 3: Not Handling Multiple Matches

Multiple patterns can match the same input. Roebling dispatches ALL matches.

```c
// Both patterns might match "hello123"
// - Pattern 1: "hello" (letters only)
// - Pattern 2: "hello123" (letters + numbers)
// Both captures will be called!
```

**Solution**: Make patterns mutually exclusive or handle duplicates in capture functions.

## See Also

- [Parser Overview](overview.md) - Roebling architecture
- [Creating DSLs](creating-dsls.md) - Building custom languages
- [Cursor](../../memory/cursor.md) - Input stream navigation
