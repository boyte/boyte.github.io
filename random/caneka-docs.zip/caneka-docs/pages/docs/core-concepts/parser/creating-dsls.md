---
sidebar_position: 2
---

# Creating DSLs with Roebling

The Roebling parser enables creation of Domain Specific Languages (DSLs) for your application needs.

## What is a DSL?

A Domain Specific Language is a specialized programming language designed for a particular domain or problem space.

Examples:
- SQL for databases
- HTML for markup
- CSS for styling
- **Custom formats for your application**

## Creating a Simple DSL

1. Define your syntax patterns
2. Create a Roebling parser
3. Add pattern rules
4. Parse input

## Example: Configuration Format

```c
Roebling *parser = Roebling_Make();
// Define patterns for your config syntax
Roebling_AddPattern(parser, "key = value");
// Parse configuration
RoeblingMatch *match = Roebling_Parse(parser, input);
```

## Benefits

- **Flexibility**: Syntax adapts to your domain
- **Clarity**: Express concepts in domain terms
- **Maintainability**: Changes to syntax don't require recompiling
- **Power**: Full parsing capabilities without writing a parser from scratch

## See Also

- [Parser Overview](overview.md)
- [Pencil Format Example](../../formats/pencil-fmt.md)
