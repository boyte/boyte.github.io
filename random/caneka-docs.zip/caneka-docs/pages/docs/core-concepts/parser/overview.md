---
sidebar_position: 1
---

# Roebling Parser Overview

The Roebling parser is Caneka's pattern matching engine - think of it as "a regular expression engine that can generate and run data structures."

## Purpose

Enable syntax-agnostic parsing and DSL creation without hardcoded grammar rules.

## Key Capabilities

- Pattern-based tokenization
- String splitting and matching
- DSL generation
- Syntax-agnostic design

## Philosophy

Traditional parsers have fixed syntax. Roebling allows you to define your own:

```
"hello " then word then "!"
```

This pattern matches: "hello world!", "hello there!", etc.

## Use Cases

- Creating custom configuration formats
- Parsing domain-specific languages
- Tokenizing custom file formats
- Building protocol parsers

## Location

**Source**: `src/ext/parser/`
**Headers**: `src/ext/include/parser/roebling.h`

## See Also

- [Creating DSLs](creating-dsls.md)
- [Ext Layer Architecture](../../architecture/ext-layer.md)
