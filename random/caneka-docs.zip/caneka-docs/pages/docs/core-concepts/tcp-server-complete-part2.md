# TCP Server System Complete Guide - Part 2

[← Part 1](tcp-server-complete-part1) | **Part 2 of 2**

---

## Best Practices

### 1. Keep Populate Function Lightweight

**Good:**

```c
static status WebServer_populate(MemCh *m, Task *tsk,
                                void *arg, void *source){
    // Quick setup only
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    Single *fdw = (Single *)as(arg, TYPE_WRAPPED_I32);
    pfd->fd = fdw->val.i;

    // Initialize protocol
    HttpTask_InitResponse(tsk, NULL, source);
    Task_AddStep(tsk, WebServer_GatherPage, NULL, NULL, ZERO);
    HttpTask_AddRecieve(tsk, NULL, NULL);

    return SUCCESS;
}
```

**Bad:**

```c
static status WebServer_populateBad(MemCh *m, Task *tsk,
                                   void *arg, void *source){
    // DON'T do expensive work here!
    // This blocks accept loop!

    // Reading files
    StrVec *config = File_ToVec(m, configPath);  // SLOW!

    // Database queries
    DbResult *result = Db_Query(db, "SELECT ...");  // SLOW!

    // Complex initialization
    for(i64 i = 0; i < 10000; i++){
        // Heavy processing
    }

    // ... setup ...
}
```

**Reason**: Populate runs in accept loop. Slow populate → slow accepts → connection backlog.

### 2. Use MemCh Per Connection

**Good:**

```c
// Connection setup (in accept loop)
MemCh *tm = MemCh_Make();
Task *child = Task_Make(Span_Make(tm), tsk);
tm->owner = child;

// All allocations use connection MemCh
ProtoCtx *proto = ProtoCtx_Make(tm);
HttpCtx *ctx = HttpCtx_Make(tm);
Buff *bf = Buff_Make(tm, ZERO);

// Cleanup (when connection completes)
MemCh_Free(child->m);  // Everything freed together
```

**Bad:**

```c
// Using global memory
MemCh *globalM = GetGlobalMemCh();
ProtoCtx *proto = ProtoCtx_Make(globalM);  // LEAK!
```

**Reason**: Connection allocations must be freed together. Using global memory causes leaks.

### 3. Set Appropriate Timeouts

**Timeout Configuration:**

```c
// Short timeout for API endpoints
child->timeout.tv_sec = 2;  // 2 seconds

// Standard timeout for web pages
child->timeout.tv_sec = 6;  // 6 seconds

// Long timeout for file uploads
child->timeout.tv_sec = 30;  // 30 seconds

// No timeout for streaming connections
child->timeout.tv_sec = 0;  // Disabled
```

**Considerations:**
- Too short: Legitimate slow clients timeout
- Too long: Resources held by hung connections
- Balance: Network latency + processing time + safety margin

### 4. Handle Errors in Finalize

**Good:**

```c
static status WebServer_logAndClose(Step *st, Task *tsk){
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Log errors for debugging
    if(ctx->type.state & ERROR){
        void *args[] = {ctx->errors, NULL};
        Out("^r.Error in request: @^0\n", args);
    }

    // Always close socket
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    if(pfd->fd > 0){
        close(pfd->fd);
    }

    return SUCCESS;
}
```

**Bad:**

```c
static status WebServer_finalizeBad(Step *st, Task *tsk){
    // Assuming everything succeeded
    HttpCtx *ctx = /* ... */;
    Out("^g.Success: @ served^0\n", ctx->path);  // Might be NULL!

    // Missing error handling
    // Missing socket close

    return SUCCESS;
}
```

**Reason**: Finalize called for both SUCCESS and ERROR states. Must handle both cases.

### 5. Update Poll Events Correctly

**Pattern:**

```c
// After adding read step
TcpTask_ExpectRecv(NULL, tsk);

// After adding write step
TcpTask_ExpectSend(NULL, tsk);
```

**Implementation:**

```c
status TcpTask_ExpectRecv(Step *st, Task *tsk){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    pfd->events = POLLIN|POLLNVAL|POLLHUP|POLLERR;
    tsk->type.state |= TASK_UPDATE_CRIT;  // CRITICAL!
    return tsk->type.state;
}
```

**Reason**: Queue needs to know when poll events change. Missing `TASK_UPDATE_CRIT` → task never wakes up.

### 6. Zero-Copy Buffer Operations

**Good:**

```c
// Zero-copy piping
Buff *header = Buff_Make(m, ZERO);
Route_Handle(headerRoute, header, data, ctx);

Buff *content = Buff_Make(m, ZERO);
Route_Handle(contentRoute, content, data, ctx);

// Add to output span (references, not copies)
Span_Add(proto->outSpan, header);
Span_Add(proto->outSpan, content);
```

**Bad:**

```c
// Copying data between buffers
Buff *header = Buff_Make(m, ZERO);
Route_Handle(headerRoute, header, data, ctx);

Buff *combined = Buff_Make(m, ZERO);
Buff_AddVec(combined, header->v);  // COPY!

Buff *content = Buff_Make(m, ZERO);
Route_Handle(contentRoute, content, data, ctx);
Buff_AddVec(combined, content->v);  // COPY!
```

**Reason**: Piping uses StrVec references. Copying wastes CPU and memory.


## Common Pitfalls

### Pitfall 1: Blocking Operations in Populate

**Problem:** Slow populate blocks accept loop, causing connection backlog.

```c
// BAD: File I/O in populate
static status WebServer_populateBad(MemCh *m, Task *tsk,
                                   void *arg, void *source){
    // This blocks ALL accepts!
    StrVec *config = File_ToVec(m, S(m, "config.txt"));  // SLOW!

    // Setup with config...
}
```

**Symptom:** Server stops accepting connections, clients timeout.

**Fix:** Move heavy operations to task steps:

```c
// GOOD: Lightweight populate
static status WebServer_populate(MemCh *m, Task *tsk,
                                void *arg, void *source){
    // Fast setup only
    HttpTask_InitResponse(tsk, NULL, source);
    Task_AddStep(tsk, WebServer_LoadConfig, NULL, NULL, ZERO);
    Task_AddStep(tsk, WebServer_GatherPage, NULL, NULL, ZERO);
    HttpTask_AddRecieve(tsk, NULL, NULL);
    return SUCCESS;
}

// Load config in task step (doesn't block accepts)
static status WebServer_LoadConfig(Step *st, Task *tsk){
    StrVec *config = File_ToVec(tsk->m, S(tsk->m, "config.txt"));
    // Use config...
    return SUCCESS;
}
```

### Pitfall 2: Forgetting TASK_UPDATE_CRIT

**Problem:** Poll events changed but queue not notified.

```c
// BAD: Missing update flag
status TcpTask_ExpectRecvBad(Step *st, Task *tsk){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    pfd->events = POLLIN;
    // Missing: tsk->type.state |= TASK_UPDATE_CRIT;
    return tsk->type.state;
}
```

**Symptom:** Task never wakes up for I/O, connection hangs.

**Fix:** Always set TASK_UPDATE_CRIT when changing poll events:

```c
// GOOD: Update flag set
status TcpTask_ExpectRecv(Step *st, Task *tsk){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    pfd->events = POLLIN|POLLNVAL|POLLHUP|POLLERR;
    tsk->type.state |= TASK_UPDATE_CRIT;  // Critical!
    return tsk->type.state;
}
```

### Pitfall 3: Memory Leaks from Global MemCh

**Problem:** Using global memory in connection handler.

```c
// BAD: Global memory for connection data
static MemCh *globalM = NULL;

static status WebServer_handleBad(Step *st, Task *tsk){
    // This leaks!
    Buff *bf = Buff_Make(globalM, ZERO);  // NOT FREED!
    // Process request...
}
```

**Symptom:** Memory usage grows with each request, eventually OOM.

**Fix:** Always use connection MemCh:

```c
// GOOD: Connection memory
static status WebServer_handle(Step *st, Task *tsk){
    MemCh *m = tsk->m;  // Connection memory
    Buff *bf = Buff_Make(m, ZERO);  // Freed with connection
    // Process request...
}
```

### Pitfall 4: Not Closing Socket in Finalize

**Problem:** Socket FD leak when finalize doesn't close.

```c
// BAD: Socket not closed
static status WebServer_finalizeBad(Step *st, Task *tsk){
    // Log something...
    Out("Connection completed\n", NULL);
    // Missing: close(pfd->fd);
    return SUCCESS;
}
```

**Symptom:** FD exhaustion, server stops accepting connections after ~1024 requests.

**Fix:** Always close socket in finalize:

```c
// GOOD: Socket closed
static status WebServer_finalize(Step *st, Task *tsk){
    Out("Connection completed\n", NULL);

    // Always close socket
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    close(pfd->fd);

    return SUCCESS;
}
```

### Pitfall 5: Infinite Step Loops

**Problem:** Task step chain loops infinitely.

```c
// BAD: Circular step dependencies
static status Step_A(Step *st, Task *tsk){
    Task_AddStep(tsk, Step_B, NULL, NULL, ZERO);
    return SUCCESS;
}

static status Step_B(Step *st, Task *tsk){
    Task_AddStep(tsk, Step_A, NULL, NULL, ZERO);  // LOOP!
    return SUCCESS;
}
```

**Symptom:** Connection hits step guard (16,000 steps), errors out.

**Fix:** Design acyclic step chains:

```c
// GOOD: Linear step flow
static status Step_A(Step *st, Task *tsk){
    // Do work...
    Task_AddStep(tsk, Step_B, NULL, NULL, ZERO);
    return SUCCESS;
}

static status Step_B(Step *st, Task *tsk){
    // Do work...
    // No more steps, task completes
    return SUCCESS;
}
```

### Pitfall 6: Timeout Too Short

**Problem:** Legitimate slow clients timeout.

```c
// BAD: 1 second timeout for web pages
child->timeout.tv_sec = 1;
```

**Symptom:** Slow clients (mobile, high latency) get timeout errors.

**Fix:** Set timeout appropriate for workload:

```c
// GOOD: Reasonable timeout
child->timeout.tv_sec = 6;  // Standard web pages
// or
child->timeout.tv_sec = 30;  // File uploads
```

### Pitfall 7: Mixing Blocking and Non-Blocking

**Problem:** Blocking operation in non-blocking server.

```c
// BAD: Blocking file read
static status WebServer_serveBad(Step *st, Task *tsk){
    Buff *bf = Buff_Make(tsk->m, ZERO);

    // This can block!
    status r = File_Open(bf, path, O_RDONLY);  // Blocking read!

    return r;
}
```

**Symptom:** One slow file read blocks all connections.

**Fix:** Use unbuffered I/O for static files:

```c
// GOOD: Non-blocking file streaming
static status routeFuncStatic(Buff *bf, Route *rt,
                              Table *data, HttpCtx *ctx){
    Str *pathS = /* get path */;
    bf->type.state |= BUFF_UNBUFFERED;  // Stream directly
    return File_Open(bf, pathS, O_RDONLY);
}
```

### Pitfall 8: Queue Exhaustion

**Problem:** Not removing completed tasks from queue.

```c
// BAD: Tasks never removed
while((Queue_Next(q) & END) == 0){
    Task *child = Queue_Get(q);
    Task_Tumble(child);

    // Missing: Queue_Remove(q, child->idx);
    // Missing: MemCh_Free(child->m);
}
```

**Symptom:** Queue grows unbounded, memory exhaustion.

**Fix:** Always remove completed tasks:

```c
// GOOD: Cleanup after completion
while((Queue_Next(q) & END) == 0){
    Task *child = Queue_Get(q);
    Task_Tumble(child);

    if(child->type.state & (SUCCESS|ERROR)){
        Queue_Remove(q, child->idx);     // Remove from queue
        ctx->finalize(NULL, child);       // Cleanup callback
        MemCh_Free(child->m);            // Free memory
    }
}
```

### Pitfall 9: Race Condition on Server Restart

**Problem:** `bind()` fails immediately after server shutdown.

```c
// Restart server quickly
close(server_fd);
// Immediately:
i32 new_fd = openPortToFd(port);  // ERROR: Address already in use
```

**Symptom:** "Address already in use" error on quick restart.

**Fix:** Set SO_REUSEADDR and SO_REUSEPORT:

```c
i32 one = 1;
setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(i32));
setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &one, sizeof(i32));
```

This allows immediate rebind after shutdown (already done in Caneka).

### Pitfall 10: Buffer Reuse Without Reset

**Problem:** Reusing buffer from previous request.

```c
// BAD: Buffer not cleared
static Buff *globalBuff = NULL;

static status WebServer_handleBad(Step *st, Task *tsk){
    if(globalBuff == NULL){
        globalBuff = Buff_Make(tsk->m, ZERO);
    }

    // Contains data from previous request!
    Route_Handle(route, globalBuff, data, ctx);

    return SUCCESS;
}
```

**Symptom:** Response contains data from previous requests.

**Fix:** Always use fresh buffers:

```c
// GOOD: Fresh buffer per request
static status WebServer_handle(Step *st, Task *tsk){
    Buff *bf = Buff_Make(tsk->m, ZERO);  // New buffer
    Route_Handle(route, bf, data, ctx);
    return SUCCESS;
}
```


## Integration with HTTP Lifecycle

The TCP server integrates with HTTP at several points:

### 1. Server Creation

HTTP server wraps TCP server [webserver.c:300-312](../../../src/inter/www/webserver.c#L300-L312):

```c
Task *WebServer_Make(i32 port, quad ip4, util *ip6){
    // Create TCP server task
    Task *tsk = ServeTcp_Make(NULL);

    // Configure for HTTP
    tsk->source = (Abstract *)tcpCtx_Make(tsk->m, port, ip4, ip6);

    return tsk;
}

static TcpCtx *tcpCtx_Make(MemCh *m, i32 port, quad ip4, util ip6[2]){
    TcpCtx *ctx = TcpCtx_Make(m);
    ctx->port = port;
    ctx->populate = WebServer_populate;     // HTTP populate
    ctx->finalize = WebServer_logAndClose;  // HTTP finalize
    return ctx;
}
```

### 2. Connection Initialization

TCP calls populate → HTTP initializes [webserver.c:72-84](../../../src/inter/www/webserver.c#L72-L84):

```c
static status WebServer_populate(MemCh *m, Task *tsk,
                                void *arg, void *source){
    // Store socket FD
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    Single *fdw = (Single *)as(arg, TYPE_WRAPPED_I32);
    pfd->fd = fdw->val.i;

    // Initialize HTTP protocol handling
    HttpTask_InitResponse(tsk, NULL, source);           // Create ProtoCtx + HttpCtx
    Task_AddStep(tsk, WebServer_GatherPage, NULL, NULL, ZERO);  // Route matching
    HttpTask_AddRecieve(tsk, NULL, NULL);              // HTTP parsing

    return SUCCESS;
}
```

### 3. Request Reading

TCP read → HTTP parse [http_task.c:25-33](../../../src/inter/http/http_task.c#L25-L33):

```c
status HttpTask_AddRecieve(Task *tsk, void *arg, void *source){
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);

    // Create HTTP parser
    Cursor *curs = Cursor_Make(tsk->m, proto->in->v);
    Roebling *rbl = HttpRbl_Make(tsk->m, curs, proto);

    // Add TCP read step with HTTP parser
    status r = Task_AddStep(tsk, TcpTask_ReadToRbl, rbl, source, STEP_IO_IN);

    // Wait for data
    TcpTask_ExpectRecv(NULL, tsk);

    return r;
}
```

### 4. Response Writing

HTTP response → TCP write [http_proto.c:20](../../../src/inter/http/http_proto.c#L20):

```c
// Add buffers to output span
HttpProto_AddBuff(proto, headerBuff);
HttpProto_AddBuff(proto, contentBuff);

// Prepare response headers
HttpProto_PrepareResponse(proto, tsk);

// Add TCP write step
Task_AddDataStep(tsk, TcpTask_WriteStep, NULL, NULL, NULL, ZERO);

// Wait for socket ready
TcpTask_ExpectSend(NULL, tsk);
```

### 5. Connection Cleanup

TCP finalize → HTTP logging [webserver.c:8-39](../../../src/inter/www/webserver.c#L8-L39):

```c
static status WebServer_logAndClose(Step *_st, Task *tsk){
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Log HTTP request details
    MemBookStats st;
    MemBook_GetStats(tsk->m, &st);

    void *args[] = {
        Lookup_Get(HttpMethods, ctx->method),
        I32_Wrapped(tsk->m, ctx->code),
        ctx->path,
        Time_Wrapped(tsk->m, &tsk->metrics.consumed),
        Str_MemCount(tsk->m, st.total * PAGE_SIZE),
        // ...
    };

    if(ctx->type.state & ERROR){
        Out("^r.Error method/code path time memory^0\n", args);
    } else if(ctx->code == 200){
        Out("^g.Served method/code path time memory^0\n", args);
    }

    // Close TCP socket
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    close(pfd->fd);

    return SUCCESS;
}
```

### Request Flow Diagram

```
Client → TCP Socket
    ↓
[ServeTcp_AcceptPoll] Accept connection
    ↓
[WebServer_populate] Initialize HTTP handling
    ├─ Create ProtoCtx
    ├─ Create HttpCtx
    ├─ Add TcpTask_ReadToRbl (read request)
    └─ Add WebServer_GatherPage (route matching)
    ↓
[TcpTask_ReadToRbl] Read from socket
    ├─ Buff_ReadAmount (1024 bytes)
    └─ Roebling_Run (parse HTTP headers)
    ↓
[WebServer_GatherPage] Match route
    ├─ Route_Get(path)
    └─ Add WebServer_ServePage
    ↓
[WebServer_ServePage] Generate response
    ├─ Route_Handle (header)
    ├─ Route_Handle (content)
    ├─ Route_Handle (footer)
    └─ HttpProto_PrepareResponse
    ↓
[TcpTask_WriteStep] Write to socket
    ├─ Buff_Pipe (collect buffers)
    └─ Write to FD
    ↓
[WebServer_logAndClose] Cleanup
    ├─ Log request
    ├─ close(fd)
    └─ MemCh_Free(child->m)
```


## Cross-References

### Related Documentation

- **[HTTP Lifecycle Complete](http-lifecycle-complete.md)**: HTTP protocol handling built on TCP server, request/response flow
- **[WWW Routing Complete](www-routing-complete.md)**: Route matching and handler dispatch called from HTTP handling
- **[Navigate Queue Complete](navigate/queue-complete.md)**: Queue system used for connection management, criteria-based polling
- **[Navigate Task Execution Complete](navigate/task-execution-complete.md)**: Task execution model for server and connection tasks
- **[Buff I/O Complete](buff-io-complete.md)**: Buffered I/O for socket reading/writing, piping, zero-copy operations
- **[Type System Complete](type-system-complete.md)**: Runtime types for TcpCtx, ProtoCtx, Task identification

### Key Source Files

- [src/ext/include/serve/tcp_ctx.h](../../../src/ext/include/serve/tcp_ctx.h): TcpCtx structure definition
- [src/ext/include/serve/proto_ctx.h](../../../src/ext/include/serve/proto_ctx.h): ProtoCtx structure definition
- [src/ext/include/serve/serve_tcp.h](../../../src/ext/include/serve/serve_tcp.h): Server configuration constants
- [src/ext/include/serve/tcp_task.h](../../../src/ext/include/serve/tcp_task.h): Task helper functions
- [src/ext/serve/serve_tcp.c](../../../src/ext/serve/serve_tcp.c): Main server implementation
- [src/ext/serve/tcp_task.c](../../../src/ext/serve/tcp_task.c): Socket I/O operations
- [src/ext/serve/tcp_ctx.c](../../../src/ext/serve/tcp_ctx.c): Context creation
- [src/ext/serve/proto_ctx.c](../../../src/ext/serve/proto_ctx.c): Protocol context creation
- [src/inter/www/webserver.c](../../../src/inter/www/webserver.c): HTTP server using TCP layer

### Related APIs

**Server Creation:**
- `ServeTcp_Make(ctx)`: Create TCP server task
- `TcpCtx_Make(m)`: Create server context
- `ProtoCtx_Make(m)`: Create protocol context

**Socket Operations:**
- `TcpTask_GetPollFd(tsk)`: Get pollfd from task
- `TcpTask_ReadToRbl(st, tsk)`: Read from socket to Roebling parser
- `TcpTask_WriteStep(st, tsk)`: Write output buffers to socket
- `TcpTask_ExpectRecv(st, tsk)`: Set poll events for receiving
- `TcpTask_ExpectSend(st, tsk)`: Set poll events for sending

**Queue Integration:**
- `Queue_Add(q, task)`: Add connection task to queue
- `Queue_SetCriteria(q, idx, task, criteria)`: Update poll criteria
- `Queue_Next(q)`: Get next ready connection
- `Queue_Remove(q, idx)`: Remove completed connection

**Buffer Operations:**
- `Buff_SetSocket(bf, fd)`: Associate buffer with socket
- `Buff_ReadAmount(bf, size)`: Read from socket (non-blocking)
- `Buff_Write(bf)`: Write to socket (non-blocking)
- `Buff_Pipe(dest, src)`: Zero-copy buffer composition


## Summary

The TCP Server System provides **event-driven, non-blocking network serving** that integrates seamlessly with Caneka's Task/Queue architecture. By using **single-threaded polling** with per-connection memory chapters, the server achieves **high concurrency without threading complexity**.

Key architectural decisions:

- **Event-driven**: Poll-based I/O, no blocking operations
- **Protocol-agnostic**: Callbacks separate transport from protocol
- **Memory per-connection**: MemCh per connection for predictable cleanup
- **Zero-copy**: Buffer piping without intermediate copies
- **Queue-managed**: FD-based criteria for efficient polling
- **Timeout protection**: Per-connection timeouts prevent hung connections
- **Step guards**: Prevent infinite loops in connection handling

The system handles thousands of concurrent connections efficiently, with typical memory overhead of ~8-10KB per active connection. Integration with HTTP, routing, and templating systems creates a complete web serving stack without external dependencies.



---

[← Part 1](tcp-server-complete-part1) | **Part 2 of 2**
