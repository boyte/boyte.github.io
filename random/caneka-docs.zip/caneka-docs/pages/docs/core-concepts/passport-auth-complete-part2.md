# Passport Authentication System - Complete Guide - Part 2

[← Part 1](passport-auth-complete-part1) | **Part 2 of 2**

---

## HTTP Integration (Future)

The Passport system is designed for integration with Caneka's HTTP server. Here's how authentication would work in a web context:

### Login Handler (Conceptual)

```c
status Handle_Login(Buff *bf, Route *rt, Inst *data, HttpCtx *ctx) {
    MemCh *m = ctx->m;

    // 1. Extract User-Agent from HTTP headers
    StrVec *ua = HttpCtx_GetHeader(ctx, "User-Agent");

    // 2. Parse POST data (username + password)
    Table *body = ctx->body;  // Parsed form data
    StrVec *uid = Table_Get(body, K(m, "username"));
    Str *password = Table_Get(body, K(m, "password"));

    // 3. Open user account
    SsidCtx *sessCtx = /* retrieve from server config */;
    Login *lg = Login_Open(m, loginsDir, uid, NULL, NULL);

    if((lg->type.state & ERROR) == ERROR){
        ctx->code = HTTP_STATUS_UNAUTHORIZED;
        Buff_Print(bf, "User not found");
        return ERROR;
    }

    // 4. Verify password
    Login_Refresh(m, lg);
    Table *auth = Seel_Get(lg, K(m, "auth"));
    Str *storedHash = Table_Get(auth, K(m, "password-hash"));

    Str *salt = GetGlobalSalt(m);
    Str *computedHash = Str_Make(m, DIGEST_SIZE);
    Password_OnStr(m, computedHash, password, salt);

    if(!Str_Equals(storedHash, computedHash)){
        ctx->code = HTTP_STATUS_UNAUTHORIZED;
        Buff_Print(bf, "Invalid password");
        return ERROR;
    }

    // 5. Create session
    struct timespec now;
    Time_Now(&now);
    StrVec *ssid = Ssid_Start(sessCtx, ua, &now);

    // 6. Store user ID in session
    Table *sessionData = Table_Make(m);
    Table_Set(sessionData, K(m, "user-id"), uid);
    Ssid_Close(sessCtx, ssid, ua, sessionData);

    // 7. Set cookie in HTTP response
    Str *cookie = Str_Make(m, 512);
    Str_Print(cookie, "SSID=%s; HttpOnly; Secure; Path=/",
              StrVec_Cstr(m, ssid));
    HttpCtx_SetHeader(ctx, "Set-Cookie", cookie);

    // 8. Response
    ctx->code = HTTP_STATUS_OK;
    Buff_Print(bf, "Login successful");

    return SUCCESS;
}
```

### Session Validation Middleware (Conceptual)

```c
status Middleware_ValidateSession(HttpCtx *ctx) {
    MemCh *m = ctx->m;

    // 1. Extract SSID from cookie
    Str *cookieHeader = HttpCtx_GetHeader(ctx, "Cookie");
    StrVec *ssid = ExtractCookie(m, cookieHeader, "SSID");

    if(ssid == NULL){
        ctx->code = HTTP_STATUS_UNAUTHORIZED;
        return ERROR;
    }

    // 2. Extract User-Agent
    StrVec *ua = HttpCtx_GetHeader(ctx, "User-Agent");

    // 3. Open session
    SsidCtx *sessCtx = /* retrieve from server config */;
    Table *sessionData = Ssid_Open(sessCtx, ssid, ua);

    if(sessionData == NULL){
        // Parity validation failed or session doesn't exist
        ctx->code = HTTP_STATUS_UNAUTHORIZED;
        return ERROR;
    }

    // 4. Store session data in request context
    ctx->session = sessionData;

    return SUCCESS;
}
```


## Storage and Persistence

The Passport system uses **file-based storage** with a structured directory layout.

### Directory Structure

```
base_path/
├── sessions/
│   └── [ssid]/
│       └── session.stash          (binary stash file)
└── logins/
    └── [uid]/
        ├── email                  (plain text StrVec)
        ├── username               (plain text StrVec)
        ├── content                (binary stash Table)
        └── auth/
            └── password-hash      (32-byte binary)
```

### File Formats

**Session Stash (session.stash)**:
- Binary stash format (BinSeg serialization)
- Contains Table with metadata:
  - `"user-agent"`: Original User-Agent string
  - `"orig-ssid"`: Original session ID
  - Custom key-value pairs from application

**Login Files**:
- **String/StrVec properties**: Plain text serialization (UTF-8)
- **Table properties**: Binary stash format
- **Auth files**: 32-byte binary hashes

**Serialization Functions**:
- `Stash_FlushFree(Buff *bf, MemCh *m)`: Write stash to buffer
- `Stash_FromStream(Buff *bf)`: Read stash from buffer
- `ToS(Buff *bf, Abstract *a, Type type, status flags)`: Generic serialization
- `File_ToVec(MemCh *m, Str *path)`: Load file to StrVec

### Backup and Migration

Since Passport uses filesystem storage, backup and migration are straightforward:

**Backup Sessions**:
```bash
cp -r /var/caneka/sessions /backup/sessions-2026-01-17
```

**Migrate Users**:
```bash
rsync -av /var/caneka/logins/ newserver:/var/caneka/logins/
```

**Restore Session**:
```bash
cp -r /backup/sessions-2026-01-17/[ssid] /var/caneka/sessions/
```


## Security Considerations

### Password Security

**Strengths**:
- ✅ SHA256 hashing (industry standard)
- ✅ Salt mixing with variable positioning
- ✅ Double buffering increases computational cost
- ✅ Position randomization based on password content
- ✅ Zero-value rejection prevents trivial attacks

**Limitations**:
- ⚠️ **Global static salt**: All deployments use the same compiled salt
- ⚠️ **No iteration count**: Simple SHA256 without PBKDF2 or bcrypt
- ⚠️ **No per-user salt**: All users share the same salt
- ⚠️ **Password length limit**: Maximum 512 bytes

**Recommendation**: For production use, consider:
1. Per-user salts stored alongside hashes
2. PBKDF2 or bcrypt with iteration count (10,000+)
3. Configurable salt per installation

### Session Security

**Strengths**:
- ✅ **Parity validation**: User-Agent binding prevents cross-client hijacking
- ✅ **Random 8-byte ID**: Collision-resistant
- ✅ **Timestamp**: Prevents replay attacks
- ✅ **Filesystem isolation**: Each session has its own directory

**Limitations**:
- ⚠️ **No encryption at rest**: Session files stored as plaintext
- ⚠️ **Filesystem security**: Depends on OS-level permissions
- ⚠️ **No session timeout**: Sessions persist indefinitely unless explicitly destroyed

**Recommendation**:
1. Implement session expiration (delete old sessions)
2. Encrypt session.stash files with application key
3. Set restrictive filesystem permissions (chmod 700)

### Authentication Target Security

**Strengths**:
- ✅ Cryptographic binding with global salt
- ✅ Zero-value rejection
- ✅ Type-safe with runtime checks

**Issues**:
- ⚠️ **IPv6 bounds error**: Line 125 accesses `pair[2]` (out of bounds)
- ⚠️ **No text length validation**: Large texts processed without limits

### Type System Security

**Strengths**:
- ✅ Type checking via `as()` macro
- ✅ MemCh memory isolation
- ✅ Type information in all structures


## Performance Characteristics

### Password Hashing

- **Time Complexity**: O(1) - fixed 512-1024 byte hash input
- **Space Complexity**: O(1) - 512-byte slate buffer
- **Computational Cost**: Single SHA256 operation (~1-5 microseconds on modern CPUs)

**Note**: Single-iteration SHA256 is fast but potentially vulnerable to brute force. Production systems typically use PBKDF2 with 10,000+ iterations.

### Session Operations

| Operation | Time Complexity | Filesystem I/O |
|-----------|----------------|----------------|
| Ssid_From | O(1) | None |
| Ssid_Start | O(1) | Directory create + stash write |
| Ssid_Open | O(1) | Stash read |
| Ssid_Close | O(1) | Stash write |
| Ssid_Update | O(1) | Directory rename |
| Ssid_Destroy | O(1) | File + directory delete |

**Parity Validation**: O(n) where n = User-Agent length (typically < 200 bytes)

### Login Operations

| Operation | Time Complexity | Filesystem I/O |
|-----------|----------------|----------------|
| Login_Create | O(p) | Directory creates + p property writes |
| Login_Open | O(1) | None |
| Login_Refresh | O(p) | p property reads |
| Login_Persist | O(p) | p property writes |
| Login_Destroy | O(p) | p file deletes + directory delete |

Where **p** = number of properties (typically 4-7).

### Scaling Considerations

**Session Limits**:
- Filesystem-based storage scales to **millions of sessions**
- Consider using hierarchical directories for > 100,000 sessions:
  ```
  sessions/
  ├── a1/
  │   └── a1b2c3d4.../
  ├── a2/
  │   └── a2345678.../
  ```

**User Limits**:
- Same filesystem scaling applies to logins
- Property system adds minimal overhead


## Common Patterns

### Pattern 1: User Registration

```c
status RegisterUser(MemCh *m, Str *loginsDir, StrVec *username, Str *password) {
    // Hash password
    Str *salt = GetGlobalSalt(m);
    Str *hash = Str_Make(m, DIGEST_SIZE);
    Password_OnStr(m, hash, password, salt);

    // Create user
    Login *lg = Login_Create(m, loginsDir, username, NULL, NULL);

    if((lg->type.state & ERROR) == ERROR){
        return ERROR;  // User already exists
    }

    // Store password hash
    Table *auth = Seel_Get(lg, K(m, "auth"));
    Table_Set(auth, K(m, "password-hash"), hash);

    // Persist
    Login_Persist(m, lg);

    return SUCCESS;
}
```

### Pattern 2: User Login with Session

```c
StrVec *LoginUser(MemCh *m, SsidCtx *sessCtx, Str *loginsDir,
                  StrVec *username, Str *password, StrVec *ua) {
    // Open user
    Login *lg = Login_Open(m, loginsDir, username, NULL, NULL);
    if((lg->type.state & ERROR) == ERROR) return NULL;

    Login_Refresh(m, lg);

    // Verify password
    Table *auth = Seel_Get(lg, K(m, "auth"));
    Str *storedHash = Table_Get(auth, K(m, "password-hash"));

    Str *salt = GetGlobalSalt(m);
    Str *computedHash = Str_Make(m, DIGEST_SIZE);
    Password_OnStr(m, computedHash, password, salt);

    if(!Str_Equals(storedHash, computedHash)){
        return NULL;  // Invalid password
    }

    // Create session
    struct timespec now;
    Time_Now(&now);
    StrVec *ssid = Ssid_Start(sessCtx, ua, &now);

    // Store user ID in session
    Table *sessionData = Table_Make(m);
    Table_Set(sessionData, K(m, "user-id"), username);
    Ssid_Close(sessCtx, ssid, ua, sessionData);

    return ssid;  // Return session ID
}
```

### Pattern 3: Session Validation

```c
StrVec *ValidateSession(MemCh *m, SsidCtx *sessCtx, StrVec *ssid, StrVec *ua) {
    // Open session
    Table *sessionData = Ssid_Open(sessCtx, ssid, ua);

    if(sessionData == NULL){
        return NULL;  // Invalid session or User-Agent mismatch
    }

    // Extract user ID
    StrVec *userId = Table_Get(sessionData, K(m, "user-id"));

    return userId;
}
```

### Pattern 4: Change Password

```c
status ChangePassword(MemCh *m, Login *lg, Str *newPassword) {
    // Hash new password
    Str *salt = GetGlobalSalt(m);
    Str *hash = Str_Make(m, DIGEST_SIZE);
    Password_OnStr(m, hash, newPassword, salt);

    // Update auth table
    Table *auth = Seel_Get(lg, K(m, "auth"));
    Table_Set(auth, K(m, "password-hash"), hash);

    // Persist
    Login_Persist(m, lg);

    return SUCCESS;
}
```

### Pattern 5: Session Rotation (Security)

```c
StrVec *RotateSession(MemCh *m, SsidCtx *sessCtx, StrVec *oldSsid, StrVec *ua) {
    struct timespec now;
    Time_Now(&now);

    // Generate new session ID, preserve data
    StrVec *newSsid = Ssid_Update(sessCtx, oldSsid, ua, &now);

    return newSsid;
}
```


## Best Practices

### 1. Always Validate User-Agent

```c
// ✅ GOOD: Validate User-Agent on every session operation
Table *sessionData = Ssid_Open(ctx, ssid, ua);
if(sessionData == NULL){
    // Reject request - User-Agent mismatch or session invalid
    return ERROR;
}

// ❌ BAD: Skip User-Agent validation
// This defeats the parity security mechanism
```

### 2. Destroy Sessions on Logout

```c
// ✅ GOOD: Explicitly destroy session
status Logout(SsidCtx *ctx, StrVec *ssid, StrVec *ua) {
    return Ssid_Destroy(ctx, ssid, ua);
}

// ❌ BAD: Leave sessions indefinitely
// Sessions accumulate and consume storage
```

### 3. Use Ssid_Update for Long-Lived Sessions

```c
// ✅ GOOD: Rotate session ID periodically
if(TimeSinceLogin > ONE_HOUR){
    StrVec *newSsid = Ssid_Update(ctx, ssid, ua, &now);
    // Update client cookie with newSsid
}

// ❌ BAD: Use same session ID for days/weeks
// Increases session fixation attack risk
```

### 4. Set Filesystem Permissions

```bash
# ✅ GOOD: Restrict access to session/login directories
chmod 700 /var/caneka/sessions
chmod 700 /var/caneka/logins

# ❌ BAD: World-readable directories
chmod 755 /var/caneka/sessions  # Anyone can read session data!
```

### 5. Handle Password Length Limits

```c
// ✅ GOOD: Validate password length
if(password->length < 2 || password->length > 512){
    return ERROR;
}
Str *hash = Str_Make(m, DIGEST_SIZE);
Password_OnStr(m, hash, password, salt);

// ❌ BAD: Hash passwords > 512 bytes
// Password_OnStr will return ERROR
```

### 6. Clean Up Old Sessions

```c
// ✅ GOOD: Implement session cleanup
status CleanupOldSessions(MemCh *m, SsidCtx *ctx, i64 maxAge) {
    // Iterate sessions directory
    // Delete sessions older than maxAge seconds
}

// ❌ BAD: Never delete sessions
// Filesystem fills up over time
```


## Common Pitfalls

### Pitfall 1: Forgetting Login_Refresh

```c
// ❌ BAD: Properties are not loaded
Login *lg = Login_Open(m, loginsDir, uid, NULL, NULL);
StrVec *email = Seel_Get(lg, K(m, "email"));  // NULL! Properties not loaded

// ✅ GOOD: Refresh after opening
Login *lg = Login_Open(m, loginsDir, uid, NULL, NULL);
Login_Refresh(m, lg);
StrVec *email = Seel_Get(lg, K(m, "email"));  // Now loaded from file
```

### Pitfall 2: Not Checking Error States

```c
// ❌ BAD: Ignoring error states
Login *lg = Login_Create(m, loginsDir, uid, NULL, NULL);
Login_Persist(m, lg);  // May fail if user already exists!

// ✅ GOOD: Check state flags
Login *lg = Login_Create(m, loginsDir, uid, NULL, NULL);
if((lg->type.state & ERROR) == ERROR){
    Table *errors = Seel_Get(lg, K(m, "errors"));
    // Handle error
}else{
    Login_Persist(m, lg);
}
```

### Pitfall 3: Wrong User-Agent

```c
// ❌ BAD: Using different User-Agent for session operations
StrVec *ssid = Ssid_Start(ctx, ua1, &now);
Table *data = Ssid_Open(ctx, ssid, ua2);  // NULL! Parity mismatch

// ✅ GOOD: Use same User-Agent
StrVec *ssid = Ssid_Start(ctx, ua, &now);
Table *data = Ssid_Open(ctx, ssid, ua);  // Success
```

### Pitfall 4: Password Hash Destination Size

```c
// ❌ BAD: Wrong destination size
Str *hash = Str_Make(m, 64);  // Too large!
Password_OnStr(m, hash, password, salt);  // Returns ERROR

// ✅ GOOD: Exactly DIGEST_SIZE (32 bytes)
Str *hash = Str_Make(m, DIGEST_SIZE);
Password_OnStr(m, hash, password, salt);  // Success
```

### Pitfall 5: Assuming AuthCred Works

```c
// ❌ BAD: AuthCred functions are incomplete
AuthCred *cred = AuthCred_Make(m);  // Returns stub
status result = AuthCred_Resolve(m, cred, target, authentee);  // ZERO (not implemented)

// ✅ GOOD: Use Password_OnStr and direct hash comparison instead
```


## Function Reference

### AuthCred Functions

| Function | Status | Purpose |
|----------|--------|---------|
| `AuthCred_Make(m)` | Stub | Create credential (incomplete) |
| `AuthCred_Resolve(m, cred, target, authentee)` | Stub | Verify credential (incomplete) |

### AuthTarget Functions

| Function | Status | Purpose |
|----------|--------|---------|
| `AuthTarget_Make(m, flags)` | Complete | Create auth target |
| `AuthFuncI(m, target, hash)` | Complete | Hash i32 value |
| `AuthFuncU(m, target, hash)` | Complete | Hash util value |
| `AuthFuncVec(m, target, hash)` | Complete | Hash text vector |
| `AuthFuncIp6(m, target, hash)` | Bug | Hash IPv6 (bounds error) |
| `AuthTarget_Init(m)` | Stub | Initialize targets (incomplete) |

### Password Functions

| Function | Status | Purpose |
|----------|--------|---------|
| `Password_OnStr(m, dest, pw, salt)` | Complete | Hash password with salt |
| `Password_Set(bf, pw, salt)` | Stub | Store password (incomplete) |
| `Password_Check(bf, pw, salt)` | Stub | Verify password (incomplete) |

### Salt Functions

| Function | Status | Purpose |
|----------|--------|---------|
| `Salt_FromBuff(bf, dest)` | Stub | Load salt (incomplete) |
| `Salt_ToBuff(bf, dest, path)` | Stub | Save salt (incomplete) |

### Session Functions

| Function | Status | Purpose |
|----------|--------|---------|
| `SsidCtx_Make(m, path)` | Complete | Create session context |
| `Ssid_From(ctx, ua, ts)` | Complete | Generate session ID |
| `Ssid_Start(ctx, ua, ts)` | Complete | Create session with storage |
| `Ssid_Open(ctx, ssid, ua)` | Complete | Open and validate session |
| `Ssid_Update(ctx, ssid, ua, ts)` | Complete | Rotate session ID |
| `Ssid_Close(ctx, ssid, ua, stashTbl)` | Complete | Persist session data |
| `Ssid_Destroy(ctx, ssid, ua)` | Complete | Delete session |

### Login Functions

| Function | Status | Purpose |
|----------|--------|---------|
| `Login_Init(m)` | Complete | Initialize type system |
| `Login_Create(m, path, uid, ssid, cred)` | Complete | Create user account |
| `Login_Open(m, path, uid, ssid, cred)` | Complete | Open existing user |
| `Login_AddAuth(m, lg, a)` | Stub | Add credential (incomplete) |
| `Login_Refresh(m, lg)` | Partial | Reload user properties |
| `Login_Persist(m, lg)` | Complete | Save user properties |
| `Login_Destroy(m, lg)` | Complete | Delete user account |


## Known Issues and Limitations

### Critical Issues

1. **IPv6 Out-of-Bounds Access**: `AuthFuncIp6` at line 125 accesses `pair[2]` which doesn't exist. Should be `pair[0] + pair[1]`.

### Incomplete Features

1. **AuthCred_Make/Resolve**: No implementation
2. **AuthTarget_Init**: No implementation
3. **Password_Set/Check**: Buffer interface incomplete
4. **Salt_FromBuff/ToBuff**: Persistence incomplete
5. **Login_AddAuth**: Not implemented
6. **Auth file handling**: Login_Refresh/Destroy have placeholders for auth files but no implementation
7. **HTTP integration**: Not yet connected to HTTP layer

### Design Limitations

1. **Static Global Salt**: Compiled into binary, not configurable per installation
2. **No PBKDF2**: Simple single-iteration SHA256
3. **File-Based Only**: No database backend option
4. **No Encryption at Rest**: Session and login files stored as plaintext
5. **No Session Expiration**: Sessions persist indefinitely unless explicitly destroyed
6. **Filesystem Dependency**: Security relies on OS-level permissions


## Integration with Other Systems

### Seel Property System

Login uses Seel for flexible property storage:

```c
// Register property
Seel_Seel(m, TYPE_LOGIN, "email", TYPE_STRVEC, ZERO);

// Set property
Seel_Set(lg, K(m, "email"), Sv(m, "alice@example.com"));

// Get property
StrVec *email = Seel_Get(lg, K(m, "email"));

// Nested property (key-value in table)
Seel_SetKv(lg, K(m, "auth"), S(m, "password-hash"), hash);
```

### Stash Serialization

Session data uses BinSeg stash format:

```c
// Serialize
Table *data = Table_Make(m);
Stash_FlushFree(bf, m);  // Writes to buffer

// Deserialize
Abstract *restored = Stash_FromStream(bf);
Table *data = (Table *)restored;
```

### Cryptography API

Password hashing uses the Crypto API:

```c
#include "crypto_api.h"

Str_ToSha256(m, &str, digest);  // SHA256 hashing
```


## Summary

The Caneka Passport system provides a **comprehensive authentication foundation** with:

**Strengths**:
- Flexible authentication targets (integers, IPv6, text, signatures)
- Cryptographically sound password hashing with salt mixing
- Parity-based session validation prevents hijacking
- Clean separation of concerns
- Full integration with Caneka's type and property systems

**Gaps**:
- Some stub implementations (AuthCred, Password_Set/Check)
- No HTTP integration yet
- Static global salt limits deployment flexibility
- File-based storage may not scale to millions of concurrent users

**Best suited for**:
- Web applications with moderate user counts (< 100,000 active users)
- Applications requiring secure session management
- Systems with filesystem-based storage requirements
- Prototypes and internal tools

**Future enhancements**:
- Complete AuthCred implementation
- HTTP middleware integration
- Database backend option
- Per-user salts
- PBKDF2 or bcrypt support
- Session expiration and cleanup
- Encryption at rest

The system is **well-architected for gradual completion**, with clear extension points for additional authentication methods, storage backends, and HTTP integration.



---

[← Part 1](passport-auth-complete-part1) | **Part 2 of 2**
