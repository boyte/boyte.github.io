# HTTP Lifecycle: Complete Guide - Part 1

**Part 1 of 3** | [Part 2 →](http-lifecycle-complete-part2)

---

## Core Philosophy

Caneka's HTTP implementation embodies the framework's glass-bottom-boat philosophy—every aspect of HTTP request processing is transparent, from the moment a socket receives bytes to the final response transmission. Unlike frameworks that hide complexity behind middleware stacks and magic routing, Caneka exposes the complete HTTP lifecycle through its Navigate Task system integrated with Roebling parsing.

**The fundamental insight**: HTTP request handling is a state machine that transforms buffered socket data through a series of explicit, observable steps. Each phase—parsing, routing, content generation, response writing—is a discrete Task step that can be inspected, debugged, and extended without diving into framework internals.

This transparency serves practical purposes:
- **Debugging**: See exactly where request processing stalls or fails
- **Performance**: Profile each phase independently
- **Extension**: Insert custom behavior at any lifecycle point
- **Understanding**: Learn how HTTP actually works, not just how to use an abstraction

The HTTP system sits in the Inter layer because it orchestrates multiple Base and Ext components: Buff I/O for socket operations, Roebling for parsing, Navigate for task management, Templ for dynamic content, and Route trees for dispatch.


## Structure & Components

### Core Data Structures

The HTTP implementation uses four interconnected structures that work together throughout the request/response lifecycle:

#### HttpCtx - Request Context

```c
typedef struct {
    Type type;
    MemCh *m;              // Memory context
    i32 method;            // HTTP_METHOD_GET, HTTP_METHOD_POST
    i32 code;              // HTTP status code (200, 404, etc.)
    i64 contentLength;     // Response body length
    Str *mime;             // Content-Type for response
    StrVec *httpVersion;   // "HTTP/1.1"
    StrVec *path;          // Request path as StrVec
    Abstract *body;        // Parsed request body (JSON, form data)
    Inst *route;           // Matched route instance
    Table *data;           // Request-specific data for templates
    Span *errors;          // Error collection
    Table *headersOut;     // Response headers to send
    Iter queryIt;          // Iterator over query parameters
    Iter headersIt;        // Iterator over request headers
} HttpCtx;
```

**Key relationships**:
- `queryIt.p` points to a Table of parsed query parameters (`?key=value&...`)
- `headersIt.p` points to a Table of request headers
- `data` accumulates context for template rendering (session, form data, etc.)
- `route` links to the Route instance that will handle this request
- `body` contains parsed JSON or form data when `Content-Type` is appropriate

#### ProtoCtx - Protocol Buffer Context

```c
typedef struct {
    Type type;
    MemCh *m;
    Buff *in;              // Input buffer (receives socket data)
    Buff *out;             // Output buffer (accumulates response)
    Abstract *ctx;         // Points to HttpCtx
} ProtoCtx;
```

The ProtoCtx bridges the socket layer and HTTP layer:
- `in` accumulates incoming bytes from the socket until a complete request is received
- `out` buffers the response (headers + body) before transmission
- `ctx` provides access to the HTTP-specific request context

#### TcpCtx - TCP Server Context

```c
typedef struct {
    Type type;
    MemCh *m;
    i32 port;              // Server port (e.g., 8080)
    void *defaultData;     // Default data injector function
    status (*populate)(MemCh *m, Task *tsk, void *arg, void *source);
    status (*finalize)(Step *st, Task *tsk);
} TcpCtx;
```

The TcpCtx defines server-level behavior:
- `populate` is called when a new connection is accepted (creates HttpCtx/ProtoCtx)
- `finalize` is called when the request completes (logs and closes the socket)
- `defaultData` can inject session management or other cross-request state

#### Route - URL Handler

```c
typedef Inst Route;  // Route is an Inst with specific properties

enum route_flags {
    ROUTE_STATIC = 1 << 8,    // Serve file directly
    ROUTE_DYNAMIC = 1 << 9,   // Template rendering
    ROUTE_FMT = 1 << 10,      // Pencil format to HTML
    ROUTE_INDEX = 1 << 13,    // Directory index
    ROUTE_BINSEG = 1 << 11,   // BinSeg database endpoint
    ROUTE_ACTION = 1 << 14,   // Custom action
    ROUTE_FORBIDDEN = 1 << 15
};
```

Routes are organized in a tree structure matching URL paths:
- Each Route Inst represents a path segment
- Children are stored in the `ROUTE_PROPIDX_CHILDREN` property (a Span of child Routes)
- The tree is traversed by tokenizing the request path and following child links
- Each Route has a handler function pointer based on its type (static, template, etc.)

### Handler Function Signature

All route handlers follow this signature:

```c
typedef status (*RouteFunc)(Buff *bf, Route *rt, Inst *data, HttpCtx *ctx);
```

- `bf`: Output buffer where the response body is written
- `rt`: The matched Route instance (contains properties like file path, template, etc.)
- `data`: Additional data table for the request
- `ctx`: The HttpCtx with request details

Handlers write their output to `bf` and return a status. The framework handles headers and finalization.


## The Complete HTTP Lifecycle

The HTTP request/response cycle flows through 11 distinct phases, each implemented as Navigate Task steps:

### Phase 1: Socket Acceptance

**What happens**: The TCP server's `accept(2)` call returns a new file descriptor for an incoming connection.

**Code location**: [src/ext/serve/tcp_task.c](../../../src/ext/serve/tcp_task.c)

**Key actions**:
- Server task waits on `poll()` with `POLLIN` for listening socket
- `accept()` returns new socket FD
- New Task created for this connection
- TcpCtx's `populate` function called

**Example from webserver.c:72**:
```c
static status WebServer_populate(MemCh *m, Task *tsk, void *arg, void *source){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    Single *fdw = (Single *)as(arg, TYPE_WRAPPED_I32);
    pfd->fd = fdw->val.i;  // Store the new socket FD

    HttpTask_InitResponse(tsk, NULL, source);
    Task_AddStep(tsk, WebServer_GatherPage, NULL, NULL, ZERO);
    HttpTask_AddRecieve(tsk, NULL, NULL);

    return SUCCESS;
}
```

The `populate` function:
1. Stores the socket FD in the task's pollfd
2. Creates ProtoCtx with input/output buffers
3. Adds a step to gather the page content
4. Adds a step to receive data from the socket

### Phase 2: Buffer Receive

**What happens**: The task waits for socket data and accumulates it in `ProtoCtx->in` buffer.

**Code location**: [src/inter/http/http_task.c:25](../../../src/inter/http/http_task.c)

**Key actions**:
- Task step has `STEP_IO_IN` flag (marks it as waiting for input)
- Navigate Queue's `poll()` loop monitors this socket FD
- Data arrives → `TcpTask_ReadToRbl` executes
- Bytes appended to `ProtoCtx->in` Buff

**Example from http_task.c:25**:
```c
status HttpTask_AddRecieve(Task *tsk, void *arg, void *source){
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    Cursor *curs = Cursor_Make(tsk->m, proto->in->v);
    Roebling *rbl = HttpRbl_Make(tsk->m, curs, proto);
    status r = Task_AddStep(tsk, TcpTask_ReadToRbl, rbl, source, STEP_IO_IN);

    TcpTask_ExpectRecv(NULL, tsk);
    return r;
}
```

This creates a Cursor over the input buffer's StrVec and sets up a Roebling parser. The `STEP_IO_IN` flag tells the Queue to wait for socket readability before executing the step.

### Phase 3: HTTP Request Parsing (Roebling State Machine)

**What happens**: Roebling parser transforms buffered bytes into structured HttpCtx fields.

**Code location**: [src/inter/http/http_roebling.c](../../../src/inter/http/http_roebling.c)

**State transitions**:
1. `HTTP_METHOD` → Match "GET" or "POST"
2. `HTTP_PATH` → Capture URI path (up to '?' or ' ')
3. `HTTP_VERSION` → Match "HTTP/1.1" or detect query start '?'
4. `HTTP_QUERY` → Parse `key=value&key=value` pairs
5. `HTTP_HEADERS` → Parse `Header-Name: value\r\n` lines
6. `HTTP_BODY` → Transition to body (if Content-Length present)

**Pattern examples from http_roebling.c**:

```c
// GET method pattern
static PatCharDef getDef[] = {
    {PAT_TERM,'G' ,'G'},
    {PAT_TERM,'E' ,'E'},
    {PAT_TERM,'T' ,'T'},
    {PAT_TERM|PAT_MANY|PAT_INVERT_CAPTURE|PAT_CONSUME,' ' ,' '},
    {PAT_END, 0, 0}
};

// URI path pattern (stop at '?' or ' ')
static PatCharDef uriDef[] = {
    {PAT_KO|PAT_INVERT_CAPTURE, '?', '?'},
    {PAT_KO|PAT_KO_TERM, ' ', ' '},
    patText,
    {PAT_END, 0, 0}
};

// Header name pattern (e.g., "Content-Type")
static PatCharDef headerNameDef[] = {
    {PAT_SINGLE, 'A', 'Z'},{PAT_SINGLE|PAT_TERM, 'a', 'z'},
    {PAT_KO|PAT_KO_TERM, ':', ':'},
    {PAT_MANY, 'A', 'Z'},{PAT_MANY, 'a', 'z'},{PAT_MANY, '0', '9'},
    {PAT_MANY|PAT_TERM, '-', '-'},
    {PAT_END, 0, 0}
};
```

**Capture functions**: Each pattern has an associated capture function that stores the matched text in HttpCtx:

```c
static status uri(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);
    return Roebling_SetPattern(rbl, uriDef, HTTP_PATH, HTTP_VERSION);
}
```

When the `uriDef` pattern matches, the captured text becomes `HttpCtx->path`.

**Query parameter parsing**: The state machine handles URL-encoded parameters:

```c
// Query key-value parsing
static PatCharDef queryKeySegDef[] = {
    {PAT_KO|PAT_INVERT_CAPTURE, ' ', ' '},
    {PAT_KO|PAT_INVERT_CAPTURE, '%', '%'},
    {PAT_KO|PAT_INVERT_CAPTURE, '=', '='},
    {PAT_KO|PAT_KO_TERM|PAT_INVERT_CAPTURE, '&', '&'},
    patText,
    {PAT_END, 0, 0}
};

// Handles %XX URL encoding
static PatCharDef queryEscapedDef[] = {
    {PAT_SINGLE|PAT_TERM, '%', '%'},
    {PAT_SINGLE, 'A', 'F'},{PAT_SINGLE, 'a', 'f'},{PAT_SINGLE|PAT_TERM, '0', '9'},
    {PAT_SINGLE, 'A', 'F'},{PAT_SINGLE, 'a', 'f'},{PAT_SINGLE|PAT_TERM, '0', '9'},
    {PAT_END, 0, 0}
};
```

The parser builds a Table accessible via `HttpCtx->queryIt`, where each query parameter is a key-value pair.

### Phase 4: Body Parsing (JSON/Form Data)

**What happens**: If `Content-Type: application/json` is present, parse the body into an Abstract structure.

**Code location**: [src/inter/http/http_ctx.c:21](../../../src/inter/http/http_ctx.c)

**Key logic from http_ctx.c:21**:

```c
status HttpCtx_ParseBody(HttpCtx *ctx, NodeObj *config, Cursor *curs){
    MemCh *m = ctx->m;

    // Check for Content-Length header
    Single *sg = Table_Get(ctx->headersIt.p, K(m, "Content-Length"));
    if(sg != NULL){
        // Check for JSON content type
        StrVec *contentType = Table_Get(ctx->headersIt.p, K(m, "Content-Type"));
        if(contentType != NULL && Equals(contentType, K(m, "application/json"))){
            // Verify body length matches Content-Length
            if(curs->v->total - (Cursor_Pos(curs)+1) != sg->val.value){
                ctx->type.state |= ERROR;
                return ctx->type.state;
            }

            // Determine target Seel type from config
            NodeObj *binseg = Inst_ByPath(config, Sv(m, "binseg"), NULL, SPAN_OP_GET, NULL);
            StrVec *seelName = NULL;
            cls instTypeOf = TYPE_TABLE;
            if(binseg != NULL && (seelName = (StrVec *)Inst_Att(binseg, K(m, "seel"))) != NULL){
                instTypeOf = Seel_TypeByName(seelName);
            }

            // Parse JSON with Roebling
            Roebling *rbl = JsonParser_Make(m, curs, instTypeOf);
            Roebling_Run(rbl);

            if((rbl->type.state & ERROR) == 0){
                ctx->body = (Abstract *)JsonParser_GetRoot(rbl);
            }else{
                // Log error and set ERROR state
                void *args[] = {rbl, NULL};
                Error(m, FUNCNAME, FILENAME, LINENUMBER, "Error Parsing Roebling @", args);
                ctx->type.state |= ERROR;
            }
        }
    }

    return ctx->type.state;
}
```

**What this accomplishes**:
- Validates Content-Length matches actual body size
- Uses JsonParser (another Roebling instance) to parse JSON
- Can type the result based on Seel schema from config
- Stores parsed body in `ctx->body` as a Table or typed Inst
- Sets ERROR state if parsing fails

**Example**: A POST with body `{"name": "Alice", "age": 30}` results in:
```c
ctx->body = (Abstract *){
    .type.of = TYPE_TABLE,
    .table_contents = {
        "name" → StrVec("Alice"),
        "age" → Single(30)
    }
}
```

### Phase 5: Route Lookup

**What happens**: The request path is tokenized and traversed through the Route tree to find a handler.

**Code location**: [src/inter/www/route.c](../../../src/inter/www/route.c)

**Route tree structure**: Routes are organized as a tree of Inst objects:
```
/
├── index.html (ROUTE_STATIC)
├── api/
│   ├── users (ROUTE_BINSEG)
│   └── posts (ROUTE_BINSEG)
├── about/ (ROUTE_FMT)
└── blog/
    └── post.templ (ROUTE_DYNAMIC)
```

**Traversal algorithm**: `Route_Get(Route *rt, StrVec *path)`
1. Tokenize path by '/' separator
2. Start at root Route
3. For each token:
   - Get children Span from `ROUTE_PROPIDX_CHILDREN`
   - Find child whose `path` property matches token
   - Descend to that child
4. Return final Route or NULL if no match

**Example path lookup** for `/blog/post.templ`:
```c
Route *root = ...; // Root route
StrVec *path = Sv(m, "/blog/post.templ");

Route *current = root;
// Token 1: "blog"
Span *children = Seel_Get(current, K(m, "children"));
current = Span_Find(children, K(m, "blog"));

// Token 2: "post.templ"
children = Seel_Get(current, K(m, "children"));
current = Span_Find(children, K(m, "post.templ"));

// current now points to the Route for post.templ
ctx->route = current;
```

**File extension dispatch**: Routes have associated handler functions based on file type:

```c
// From route.c - Handler function table
Span *RouteFuncTable = NULL;  // Maps route flags to functions
Span *RouteMimeTable = NULL;  // Maps extensions to MIME types

// Static file handler
static status routeFuncStatic(Buff *bf, Route *rt, Table *_data, HttpCtx *ctx){
    MemCh *m = bf->m;
    Str *pathS = StrVec_Str(bf->m,
        (StrVec *)as(Seel_Get(rt, K(m, "action")), TYPE_STRVEC));
    bf->type.state |= BUFF_UNBUFFERED;
    return File_Open(bf, pathS, O_RDONLY);
}

// Template handler
static status routeFuncTempl(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;
    Templ *templ = (Templ *)as(Seel_Get(rt, K(m, "templ")), TYPE_TEMPL);

    Templ_Reset(templ);
    templ->type.state |= bf->type.state;
    Templ_ToS(templ, bf, data, NULL);
    return templ->type.state;
}

// Pencil format (.fmt) handler
static status routeFuncFmt(Buff *bf, Route *rt, Table *_data, HttpCtx *ctx){
    MemCh *m = bf->m;
    return Fmt_ToHtml(bf,
        (Mess *)as(Seel_Get(rt, K(m, "action")), TYPE_MESS));
}
```

**Handler selection**: When a Route is matched, its flags determine which handler function is called:
- `ROUTE_STATIC` → `routeFuncStatic` (serve file directly)
- `ROUTE_DYNAMIC` → `routeFuncTempl` (render template)
- `ROUTE_FMT` → `routeFuncFmt` (convert Pencil to HTML)
- `ROUTE_BINSEG` → `routeFuncFileDb` (database CRUD operations)

### Phase 6: ETag Generation

**What happens**: If the route points to a static resource, generate an ETag for cache validation.

**Code location**: [src/inter/http/http_ctx.c:6](../../../src/inter/http/http_ctx.c)

**ETag format**: `{hash}-{timestamp}`

**Implementation from http_ctx.c:6**:

```c
StrVec *HttpCtx_MakeEtag(MemCh *m, Str *path, struct timespec *mod){
    StrVec *v = StrVec_Make(m);

    // Compute parity hash of file path
    quad hpar = HalfParity_From(path);
    Str s = {
        .type = {TYPE_STR, STRING_BINARY|STRING_CONST},
        .length = sizeof(quad),
        .alloc = sizeof(quad),
        .bytes = (byte *)&hpar
    };

    // ETag = hex(hash) + "-" + timestamp
    StrVec_Add(v, Str_ToHex(m, &s));
    StrVec_Add(v, Str_Ref(m, (byte *)"-", 1, 1, STRING_COPY|MORE));
    StrVec_Add(v, Str_FromI64(m, mod->tv_sec));

    return v;
}
```

**Example ETags**:
- File `index.html` modified at Unix time 1704067200:
  - Hash: `a3f2c1b0` (from parity hash)
  - ETag: `"a3f2c1b0-1704067200"`

**Cache validation**: If the request includes `If-None-Match: "a3f2c1b0-1704067200"`, the server:
1. Regenerates ETag for current file
2. Compares with request ETag
3. If match → return 304 Not Modified (no body)
4. If no match → return 200 OK with full body

**Code from route.c** (not shown in files above, but referenced in exploration):
```c
status Route_CheckEtag(Route *rt, StrVec *etag){
    // Get file modification time
    struct timespec mod = ...;
    StrVec *path = Seel_Get(rt, K(m, "path"));

    // Regenerate ETag
    StrVec *currentEtag = HttpCtx_MakeEtag(m, path, &mod);

    // Compare
    if(Equals(currentEtag, etag)){
        return HTTP_STATUS_NOT_MODIFIED;  // 304
    }
    return HTTP_STATUS_OK;  // 200
}
```

### Phase 7: Handler Execution

**What happens**: The matched route's handler function executes, writing output to `ProtoCtx->out`.

**Handler execution point**: [src/inter/www/webserver.c:100](../../../src/inter/www/webserver.c) (WebServer_GatherPage)

**The dispatch pattern**:

```c
status WebServer_GatherPage(Step *st, Task *tsk){
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Route already matched and stored in ctx->route
    Route *route = ctx->route;

    // Call the handler function
    RouteFunc handler = Route_GetHandler(route);  // Based on route flags
    status r = handler(proto->out, route, ctx->data, ctx);

    if(r & ERROR){
        ctx->code = 500;
        ctx->type.state |= ERROR;
    }else{
        ctx->code = 200;
        ctx->contentLength = proto->out->v->total;
    }

    return r;
}
```

**Handler examples in detail**:

**Static file serving**:
```c
static status routeFuncStatic(Buff *bf, Route *rt, Table *_data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get absolute file path from route
    Str *pathS = StrVec_Str(bf->m,
        (StrVec *)as(Seel_Get(rt, K(m, "action")), TYPE_STRVEC));

    // Set unbuffered mode for efficient streaming
    bf->type.state |= BUFF_UNBUFFERED;

    // Open file and attach to buffer (file content becomes buffer content)
    return File_Open(bf, pathS, O_RDONLY);
}
```

When `BUFF_UNBUFFERED` is set, the Buff writes directly from the file descriptor without copying into memory. This is optimal for large static assets.

**Template rendering**:
```c
static status routeFuncTempl(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get prepared template from route
    Templ *templ = (Templ *)as(Seel_Get(rt, K(m, "templ")), TYPE_TEMPL);

    // Reset template state (clears previous render)
    Templ_Reset(templ);

    // Render template with data context
    Templ_ToS(templ, bf, data, NULL);

    return templ->type.state;
}
```

The `data` Table contains:
- Session information (if any)
- Query parameters
- Parsed body (for POST requests)
- Route-specific data from config files

**BinSeg database endpoint**:
```c
static status routeFuncFileDb(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;
    BinSegCtx *bsCtx = (BinSegCtx *)as(Seel_Get(rt, K(m, "action")), TYPE_BINSEG_CTX);

    // Get action from query parameter (?action=add)
    Abstract *action = Table_Get(ctx->queryIt.p, K(m, "action"));

    if(action == NULL){
        ctx->code = 403;
        ctx->type.state |= ERROR;
        return ctx->type.state;
    }

    // Handle different CRUD operations
    if(Equals(action, K(m, "add")) && ctx->body != NULL){
        BinSegCtx_Send(bsCtx, ctx->body);  // Insert parsed JSON
    }else if(Equals(action, K(m, "modify"))){
        // Update existing record
    }else if(Equals(action, K(m, "read"))){
        // Query records
    }else{
        ctx->code = 403;
        ctx->type.state |= ERROR;
    }

    // Respond with HTML or JSON based on Accept header
    StrVec *acceptHeader = Table_Get(ctx->headersIt.p, K(m, "Accept"));
    if(acceptHeader != NULL && Equals(acceptHeader, K(m, "text/html"))){
        Table_Set(data, K(m, "form"), ctx->body);
        return routeFuncTempl(bf, rt, data, ctx);  // Render template with result
    }else{
        // Return JSON response
    }

    return NOOP;
}
```

This demonstrates how POST body parsing integrates with database operations—the parsed JSON is directly inserted into BinSeg storage.

### Phase 8: Response Header Writing

**What happens**: HTTP status line and headers are written to the output buffer before the body.

**Code location**: [src/inter/http/http_ctx.c:59](../../../src/inter/http/http_ctx.c)

**Header writing implementation**:

```c
status HttpCtx_WriteHeaders(Buff *bf, HttpCtx *ctx){
    status r = READY;
    void *args[6];

    // Get status code string ("200 OK", "404 Not Found", etc.)
    Str *status = Lookup_Get(statusCodeStrings, ctx->code);
    if(status == NULL){
        status = Lookup_Get(statusCodeStrings, 500);
        r |= ERROR;
    }

    // Get current timestamp for Date header
    struct timespec now;
    Time_Now(&now);

    // Write status line and standard headers
    args[0] = status;
    args[1] = Time_ToRStr(bf->m, &now);
    args[2] = ctx->mime;
    args[3] = NULL;
    r |= Fmt(bf,
        "HTTP/1.1 $\r\n"
        "Date: $\r\n"
        "Server: caneka/0.1\r\n"
        "Content-Type: $\r\n",
        args);

    // Write custom response headers from headersOut table
    Iter it;
    Iter_Init(&it, ctx->headersOut);
    while((Iter_Next(&it) & END) == 0){
        Hashed *h = Iter_Get(&it);
        if(h != NULL){
            ToS(bf, h->key, 0, ZERO);
            Buff_AddBytes(bf, (byte *)": ", 2);
            ToS(bf, h->value, 0, ZERO);
            Buff_AddBytes(bf, (byte *)"\r\n", 2);
        }
    }

    // Special case: 304 Not Modified has no body
    if(ctx->code == 304){
        r |= Buff_AddBytes(bf, (byte *)"\r\n", 2);
        return r;
    }

    // Write Content-Length and final header separator
    args[0] = I64_Wrapped(bf->m, ctx->contentLength);
    args[1] = NULL;
    r |= Fmt(bf, "Content-Length: $\r\n\r\n", args);

    return r;
}
```

**Example output** for a 200 OK response:
```
HTTP/1.1 200 OK
Date: Fri, 17 Jan 2026 14:23:45 GMT
Server: caneka/0.1
Content-Type: text/html
ETag: "a3f2c1b0-1704067200"
Content-Length: 4521

<!DOCTYPE html>...
```

**Example output** for a 304 Not Modified:
```
HTTP/1.1 304 Not Modified
Date: Fri, 17 Jan 2026 14:23:45 GMT
Server: caneka/0.1
Content-Type: text/html
ETag: "a3f2c1b0-1704067200"

```
(No body, connection can close immediately)

**Custom headers**: The `ctx->headersOut` table allows handlers to add custom headers:

```c
// In a handler function
Table_Set(ctx->headersOut, K(m, "Cache-Control"), Sv(m, "max-age=3600"));
Table_Set(ctx->headersOut, K(m, "X-Custom-Header"), Sv(m, "custom-value"));
```

These headers are automatically written by `HttpCtx_WriteHeaders`.

### Phase 9: Response Transmission

**What happens**: The complete response (headers + body) in `ProtoCtx->out` is sent over the socket.

**Code location**: [src/ext/serve/tcp_task.c](../../../src/ext/serve/tcp_task.c) (TcpTask_Send)

**The transmission step**:

```c
status TcpTask_Send(Step *st, Task *tsk){
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    Buff *out = proto->out;
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);

    // Use Buff_Send to transmit data
    status r = Buff_Send(out, pfd->fd);

    if(r & IO_WOULD_BLOCK){
        // Socket buffer full, wait for POLLOUT
        st->flags |= STEP_IO_OUT;
        return r;
    }

    if(out->unsent.total == 0){
        // All data sent successfully
        return SUCCESS;
    }

    return r;
}
```

**Buffered I/O integration**: `Buff_Send` uses the `unsent` pointer system:
- `unsent.idx` and `unsent.offset` track position in StrVec
- Each call to `send(2)` advances `unsent` forward
- If `send()` returns EAGAIN, the step is marked `STEP_IO_OUT` and waits for socket writability
- Navigate Queue's `poll()` monitors `POLLOUT` on this FD
- When writable, the step executes again and resumes transmission

**Partial send handling**: For large responses (e.g., 10 MB static file):
```
Attempt 1: send() → 65536 bytes sent, EAGAIN
           unsent advances by 65536, wait for POLLOUT
Attempt 2: send() → 131072 bytes sent, EAGAIN
           unsent advances by 131072, wait for POLLOUT
...
Attempt N: send() → 45123 bytes sent, total complete
           unsent.total == 0, return SUCCESS
```

This non-blocking I/O ensures the server can handle multiple concurrent connections without threads.

### Phase 10: Logging

**What happens**: Request details are logged to stdout with timing and memory metrics.

**Code location**: [src/inter/www/webserver.c:8](../../../src/inter/www/webserver.c)

**Logging implementation**:

```c
static status WebServer_logAndClose(Step *_st, Task *tsk){
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Get memory statistics
    MemBookStats st;
    MemBook_GetStats(tsk->m, &st);

    void *args[9];
    args[0] = Lookup_Get(HttpMethods, ctx->method);
    args[1] = I32_Wrapped(tsk->m, ctx->code);
    args[2] = ctx->path;
    args[3] = Time_Wrapped(tsk->m, &tsk->metrics.consumed);
    args[4] = Str_MemCount(tsk->m, st.total * PAGE_SIZE);
    args[5] = I64_Wrapped(tsk->m, st.total);
    args[6] = I64_Wrapped(tsk->m, st.pageIdx);
    args[7] = NULL;
    args[8] = NULL;

    if(ctx->type.state & ERROR){
        args[7] = ctx->errors;
        Out("^r.Error $/$ @ time-used:$ $ @ $ $/$ ^{TIME.human}^0\n", args);
    }else if(ctx->code == 200){
        Out("^g.Served $/$ @ time-used:$ $ $/$ ^{TIME.human}^0\n", args);
    }else{
        Out("^c.Responded $/$ @ time-used:$ $ $/$ ^{TIME.human}^0\n", args);
    }

    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    close(pfd->fd);

    return SUCCESS;
}
```

**Example log output**:
```
Served GET/200 /index.html @ time-used:2.3ms 8KB @ 2 pages/3 pageIdx
Served GET/200 /api/users @ time-used:15.7ms 24KB @ 6 pages/8 pageIdx
Responded GET/304 /style.css @ time-used:0.8ms 4KB @ 1 pages/2 pageIdx
Error POST/500 /api/broken @ time-used:5.2ms 12KB @ 3 pages/4 pageIdx [error details]
```

**Color coding**:
- `^g.` = green for successful 200 responses
- `^c.` = cyan for other successful codes (304, 301, etc.)
- `^r.` = red for errors

**Metrics tracked**:
- HTTP method and status code
- Request path
- Processing time (`tsk->metrics.consumed`)
- Memory usage in human-readable format
- Page count and index (memory fragmentation indicator)

### Phase 11: Connection Close

**What happens**: Socket file descriptor is closed, task memory is freed.

**Code location**: Same as Phase 10 (webserver.c:8)

**Cleanup sequence**:
1. `close(pfd->fd)` closes the socket
2. Task returns SUCCESS, signaling completion
3. Navigate Queue removes task from active list
4. Task's MemChapter is freed (all request memory released)

**Memory lifecycle**: Each HTTP request has its own MemChapter:
- Created in Phase 1 when task spawns
- Accumulates all allocations (HttpCtx, buffers, parsed data, route data)
- Freed atomically when task completes
- No manual memory management needed in handlers

**Connection keep-alive**: Currently not implemented—each request closes the connection. The framework is designed to support HTTP/1.1 persistent connections by:
- Checking `Connection: keep-alive` header
- Skipping `close()` in finalize step
- Reusing the task for next request on same FD



---

**Part 1 of 3** | [Part 2 →](http-lifecycle-complete-part2)
