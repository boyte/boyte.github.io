# Config Format: Complete Guide - Part 1

**Part 1 of 2** | [Part 2 ->](config-format-complete-part2)

---

## Status and Scope

### Verified (implementation)
- Parser: `src/ext/format/config/config_roebling.c`
- API: `src/ext/format/config/config.c`
- Output type: `Inst` (`TYPE_NODEOBJ`) with `name`, `atts`, `children` in `src/ext/include/types/inst.h`
- Syntax forms: sections with `{}`; key/value with `:`; list items with `-`; digits-only numbers

### Inferred / Not Implemented
- No string quoting or escaping
- No `=` assignment syntax
- No comment syntax
- Token character set is not formally specified; examples include `/`, `-`, `_`

## Parsing Pipeline (Verified)

```
.config text
  -> Cursor
  -> Roebling state machine (FormatConfig_Make)
  -> Inst tree (NodeObj)
```

Entry points:

- `Config_FromPath` loads a file, parses it, and returns the root `Inst`.
- `Config_FromVec` parses a `StrVec` directly.

## Syntax Summary (Verified)

| Form | Example | Capture / Result | Notes |
| --- | --- | --- | --- |
| Section start | `routes {` | `CONFIG_INDENT` | Starts a new `Inst` child |
| Section end | `}` | `CONFIG_OUTDENT` | Closes current section |
| Key/value | `title: Caneka Demo` | `CONFIG_KEY` + value | Value is rest of line |
| List item | `- one` | `CONFIG_ITEM` | Adds to a `Span` list |
| Digits-only | `start: 3` | `CONFIG_NUMBER` | Stored as wrapped integer |
| Blank line | (empty) | `CONFIG_NL` | Ends current value scope |

Whitespace:
- Leading spaces are ignored for structure.
- Values preserve internal spaces (line-based capture).

## Whitespace, Comments, Escapes, Errors (Verified)

| Topic | Behavior |
| --- | --- |
| Whitespace | Leading spaces are ignored; values keep internal spaces |
| Comments | Not implemented |
| Escapes / quoting | Not implemented |
| Errors | Roebling sets `ERROR` when no patterns match; no line/col reporting |

## Data Model (Verified)

The parser builds an `Inst` (`TYPE_NODEOBJ`) with three properties:

- `name` (index 0): section name (`StrVec`)
- `atts` (index 1): attributes (`Table`)
- `children` (index 2): child sections or lists (`Table` or `Span`)

Helpers:

- `Inst_Att(node, key)` -> attribute value
- `Inst_GetChild(node, key)` -> child section
- `Inst_ByPath(root, path, ...)` -> nested lookup using a `StrVec` path

## Walkthrough: `examples/object.config` (Verified)

Input:

```config
doc {
    alpha: apple
    start: 3

    list:
        - one
        - two
}
```

Parsed structure (as validated in `src/programs/test/option/ext/config_tests.c`):

- `doc` is a child node under the root.
- `doc.atts["alpha"] == "apple"`
- `doc.atts["start"] == 3` (wrapped integer)
- `doc.children["list"]` is a `Span` with `["one", "two"]`

Access (from tests, simplified):

```c
StrVec *docKey = StrVec_From(m, Str_FromCstr(m, "doc", ZERO));
Path_DotAnnotate(m, docKey);
Inst *doc = Inst_GetByPath(root, docKey);
Str *alpha = Inst_Att(doc, Str_FromCstr(m, "alpha", ZERO));
```

## Known Limitations (Verified)

- No comments.
- No quoting or escape syntax.
- Only `:` is supported for key/value pairs.
- Numbers must be digits-only to be parsed as integers.
