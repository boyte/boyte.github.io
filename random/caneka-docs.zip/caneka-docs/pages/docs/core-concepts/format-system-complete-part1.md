# Format System Complete Guide - Part 1

**Part 1 of 2** | [Part 2 ->](format-system-complete-part2)

---

## Overview (Verified)

The format system is a set of parsers and generators built on the Roebling
state-machine engine. In current code, the implemented formatters are:

- Config parser (`src/ext/format/config/`)
- Fmt/Pencil parser + HTML generator (`src/ext/format/fmt/`)
- JSON parser (`src/ext/format/json/`)
- HTML entity escaper (`src/ext/format/html/`)
- XML tag output helper (`src/ext/format/xml/tag.c`)

There is **no bidirectional conversion** layer (e.g., HTML -> Fmt).

## Shared Infrastructure (Verified)

All parsers use:

- `Cursor` to read a `StrVec` (`src/base/bytes/cursor.c`)
- `Roebling` to match patterns (`src/ext/parser/roebling.c`)
- `Match`/`Snip` to capture spans (`src/ext/parser/match.c`, `snip.c`)

## Runtime Data Models and Layer Connections (Verified)

| Layer | Type | Purpose | Used By |
| --- | --- | --- | --- |
| Base | `Str`, `StrVec`, `Span` | Text storage and sequences | All formatters |
| Ext | `Roebling`, `Match`, `Snip` | Pattern engine | All parsers |
| Ext | `Mess`, `Node`, `Tokenize` | Fmt document tree | Fmt -> HTML |
| Ext | `Inst` / NodeObj | Config tree | Web server config |
| Ext | `Fetcher`, `FetchTarget` | Path resolution | Templ engine |
| Inter | `Templ` | Template rendering | Web server routes |

This connection is why config values and route data (Ext) can be read directly
inside templates (Inter).

## Formatter Summaries (Verified)

### Config

- Entry: `FormatConfig_Make`, `Config_FromPath`
- Files: `src/ext/format/config/config_roebling.c`, `config.c`
- Output: `Inst` (`TYPE_NODEOBJ`) with `name`, `atts`, `children`

See: `config-format-complete-part1.md`

### Fmt (Pencil)

- Entry: `FormatFmt_Make`
- Files: `src/ext/format/fmt/fmt_roebling.c`, `fmt_tokenize.c`, `fmt_html.c`
- Output: `Mess` tree, rendered with `Fmt_ToHtml`

See: `formats/pencil-fmt.md`

### JSON

- Entry: `JsonParser_Make`
- Files: `src/ext/format/json/json_roebling.c`
- Output: `Table`, `Span`, or typed `Inst` depending on call site

### HTML Entity Escaper

- Entry: `HtmlEntRbl_Make`, `HtmlEnt_IntoVec`
- File: `src/ext/format/html/html_escape_roebling.c`
- Output: escaped `StrVec`

### XML Tag Output

- Entry: `Tag_Out`
- File: `src/ext/format/xml/tag.c`
- Output: tag strings written to `Buff`

## Spec vs Implementation (Verified/Inferred)

| Format | Verified | Inferred / Not Implemented |
| --- | --- | --- |
| Config | `:` keys, `{}` sections, `-` lists | Comments, quoting, `=` keys |
| Fmt | headings, paragraphs, lists, tags | Code blocks, inline comments |
| JSON | objects, arrays, strings, numbers | Relaxed JSON extensions |
| HTML escape | `&`, `<`, `>`, `"`, `'` | Custom entity tables |

## Known Edge Cases (Verified)

- `Fmt_ToHtml` ignores class tokens in output (parsed but not rendered).
- `HtmlEnt_IntoVec` currently maps `<` to `&gt;` (see `html_escape_roebling.c`).
