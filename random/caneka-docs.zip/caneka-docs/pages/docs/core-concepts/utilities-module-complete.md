# Utilities Module - Complete Guide

The Caneka Utilities Module provides **essential helper functions** for common programming tasks: integer conversion, time manipulation, and type-safe value wrapping. These utilities are foundational building blocks used throughout the Caneka codebase.

## Why Utilities?

Every application needs common operations:

- **Integer ↔ String Conversion**: Parse command-line arguments, format numbers for display
- **Time Operations**: Timestamps, delays, throttling, time calculations
- **Value Wrapping**: Type-safe boxing of primitives and pointers for generic containers

**Caneka's Utilities consolidate these operations** into consistent, memory-managed APIs.

## Architecture Overview

```
┌──────────────────────────────────────────────────────────────┐
│                    UTILITIES MODULE                          │
├──────────────────────────────────────────────────────────────┤
│  Location: src/base/util/                                    │
│                                                               │
│  ┌────────────────┐    ┌──────────────┐   ┌──────────────┐ │
│  │  Integer Conv  │    │  Time Utils  │   │  Single Wrap │ │
│  │  util/int.h    │    │  util/time.h │   │  util/single │ │
│  └────────────────┘    └──────────────┘   └──────────────┘ │
│         │                      │                   │         │
│         │                      │                   │         │
│         ▼                      ▼                   ▼         │
│  String ↔ i64           struct timespec       Generic void* │
│  Random strings         Approximate time       Type wrappers│
│                         Delays/throttle                      │
│                                                               │
│  Integration: Used by CLI args, HTTP, testing, logging       │
└──────────────────────────────────────────────────────────────┘
```

## Module Components

### 1. Integer Conversion

**Location**: `src/base/util/int.h`

Convert between strings and integers with error handling.

#### Int_FromStr - Parse i32 from String

```c
i32 Int_FromStr(Str *s)
```

**Purpose**: Convert string to 32-bit signed integer

**Parameters**:
- `s`: String containing integer (base 10)

**Returns**: Parsed i32 value, or 0 if parsing fails

**Example**:
```c
Str *num = S(m, "42");
i32 value = Int_FromStr(num);
// value: 42

Str *neg = S(m, "-123");
i32 negative = Int_FromStr(neg);
// negative: -123

Str *invalid = S(m, "not a number");
i32 bad = Int_FromStr(invalid);
// bad: 0 (parse error)
```

**Parsing Rules**:
- Leading whitespace ignored
- Accepts negative sign (`-`)
- Stops at first non-digit character
- Returns 0 on error (ambiguous with actual zero!)

**Limitations**:
- No error indication (0 may be valid or error)
- No overflow detection

#### I64_FromStr - Parse i64 from String

```c
i64 I64_FromStr(Str *s)
```

**Purpose**: Convert string to 64-bit signed integer

**Parameters**:
- `s`: String containing integer

**Returns**: Parsed i64 value, or 0 if parsing fails

**Example**:
```c
Str *big = S(m, "9223372036854775807");  // i64 max
i64 value = I64_FromStr(big);
// value: 9223372036854775807

Str *timestamp = S(m, "1705432800");  // Unix timestamp
i64 ts = I64_FromStr(timestamp);
// ts: 1705432800
```

**Use Case**: Parsing timestamps, file sizes, large counters

#### Str_FromI64 - Convert i64 to String

```c
Str *Str_FromI64(MemCh *m, i64 value)
```

**Purpose**: Convert 64-bit integer to string

**Parameters**:
- `m`: Memory context
- `value`: Integer to convert

**Returns**: Str containing decimal representation

**Example**:
```c
i64 count = 123456;
Str *text = Str_FromI64(m, count);
// text->bytes: "123456"

i64 negative = -789;
Str *neg = Str_FromI64(m, negative);
// neg->bytes: "-789"

i64 zero = 0;
Str *z = Str_FromI64(m, zero);
// z->bytes: "0"
```

**Use Cases**:
- Formatting integers for display
- Converting counters for logging
- Building HTTP response headers (`Content-Length: 1234`)

#### Str_FromI64Pad - Convert with Zero Padding

```c
Str *Str_FromI64Pad(MemCh *m, i64 value, i32 minWidth)
```

**Purpose**: Convert integer to string with zero padding

**Parameters**:
- `m`: Memory context
- `value`: Integer to convert
- `minWidth`: Minimum string width (padded with leading zeros)

**Returns**: Str with zero-padded decimal representation

**Example**:
```c
i64 day = 5;
Str *padded = Str_FromI64Pad(m, day, 2);
// padded->bytes: "05"

i64 year = 2026;
Str *y = Str_FromI64Pad(m, year, 4);
// y->bytes: "2026" (no padding needed)

i64 milliseconds = 7;
Str *ms = Str_FromI64Pad(m, milliseconds, 3);
// ms->bytes: "007"
```

**Use Cases**:
- Date/time formatting: `2026-01-05` instead of `2026-1-5`
- File numbering: `file_001.txt`, `file_002.txt`
- Timestamp milliseconds: `12345.007`

#### Str_UniRandom - Generate Random String

```c
Str *Str_UniRandom(MemCh *m, i32 length)
```

**Purpose**: Generate random alphanumeric string

**Parameters**:
- `m`: Memory context
- `length`: Desired string length

**Returns**: Str with random digits (0-9)

**Example**:
```c
Str *sessionId = Str_UniRandom(m, 8);
// sessionId->bytes: "47829103" (random digits)

Str *token = Str_UniRandom(m, 16);
// token->bytes: "9284756301928374" (random)
```

**Character Set**: Digits only (0-9)

**Randomness**: Uses `rand()` (not cryptographically secure!)

**Use Cases**:
- Session ID generation (combine with timestamp)
- Temporary file names
- Non-security-critical unique identifiers

**Security Warning**: NOT suitable for passwords, tokens, or cryptographic keys. Use `/dev/urandom` or crypto library for security-sensitive randomness.

### 2. Time Utilities

**Location**: `src/base/util/time.h`

Time manipulation, delays, and approximate time intervals.

**Core Structure**:
```c
struct timespec {
    time_t tv_sec;       // Seconds since epoch
    long tv_nsec;        // Nanoseconds (0-999,999,999)
};
```

**Approximate Time**:
```c
typedef struct {
    i32 millisec;   // 0-999
    i32 sec;        // 0-59
    i32 min;        // 0-59
    i32 hour;       // 0-23
    i32 day;        // Days (unbounded)
} ApproxTime;
```

#### Time_Now - Get Current Time

```c
status Time_Now(struct timespec *ts)
```

**Purpose**: Get current wall-clock time

**Parameters**:
- `ts`: Output timespec structure

**Returns**: SUCCESS on completion

**Example**:
```c
struct timespec now;
Time_Now(&now);

printf("Seconds: %ld\n", now.tv_sec);
printf("Nanoseconds: %ld\n", now.tv_nsec);

// Example output:
// Seconds: 1705432800
// Nanoseconds: 123456789
```

**Use Cases**:
- Timestamps for logging
- Session ID generation
- Performance profiling

#### Time_Sub - Subtract Times

```c
struct timespec Time_Sub(struct timespec a, struct timespec b)
```

**Purpose**: Calculate time difference (a - b)

**Parameters**:
- `a`: First time (later)
- `b`: Second time (earlier)

**Returns**: timespec representing duration (a - b)

**Example**:
```c
struct timespec start, end;
Time_Now(&start);

// Do some work
for(i32 i = 0; i < 1000000; i++){
    // computation
}

Time_Now(&end);

struct timespec elapsed = Time_Sub(end, start);
printf("Elapsed: %ld.%09ld seconds\n",
       elapsed.tv_sec, elapsed.tv_nsec);

// Example output: Elapsed: 0.042356789 seconds
```

**Nanosecond Handling**: Automatically handles nanosecond borrowing when `end.tv_nsec < start.tv_nsec`

#### Time_Add - Add Times

```c
struct timespec Time_Add(struct timespec a, struct timespec b)
```

**Purpose**: Add two time values (a + b)

**Parameters**:
- `a`: First time value
- `b`: Second time value

**Returns**: timespec representing sum

**Example**:
```c
struct timespec now;
Time_Now(&now);

// Add 5 seconds
struct timespec delay = {5, 0};  // 5 seconds, 0 nanoseconds
struct timespec future = Time_Add(now, delay);

printf("Future timestamp: %ld\n", future.tv_sec);
```

**Use Case**: Calculate deadline times (now + timeout)

#### Time_Delay - Sleep for Duration

```c
status Time_Delay(struct timespec delay)
```

**Purpose**: Sleep for specified duration

**Parameters**:
- `delay`: Duration to sleep

**Returns**: SUCCESS after sleeping

**Example**:
```c
// Sleep for 1.5 seconds
struct timespec delay = {1, 500000000};  // 1 sec + 500 millisec
Time_Delay(delay);

// Sleep for 100 milliseconds
struct timespec ms100 = {0, 100000000};
Time_Delay(ms100);
```

**Implementation**: Uses `nanosleep()` system call

#### Time_Throttle - Rate Limiting

```c
status Time_Throttle(struct timespec *last, struct timespec interval)
```

**Purpose**: Enforce minimum time between events

**Parameters**:
- `last`: Pointer to last event time (updated on success)
- `interval`: Minimum time between events

**Returns**: SUCCESS if enough time elapsed, NOOP otherwise

**Example**:
```c
struct timespec lastPrint = {0, 0};
struct timespec minInterval = {0, 100000000};  // 100ms

for(i32 i = 0; i < 1000; i++){
    if(Time_Throttle(&lastPrint, minInterval) & SUCCESS){
        printf("Progress: %d\n", i);
        // Only prints every 100ms
    }
}
```

**Use Cases**:
- Rate-limiting log messages
- Throttling status updates
- Preventing UI flicker

**Behavior**: Updates `last` to current time on SUCCESS, leaves unchanged on NOOP

#### Time_Greater - Compare Times

```c
bool Time_Greater(struct timespec a, struct timespec b)
```

**Purpose**: Check if a > b

**Returns**: `true` if a is later than b, `false` otherwise

**Example**:
```c
struct timespec now, future;
Time_Now(&now);

struct timespec delay = {5, 0};
future = Time_Add(now, delay);

if(Time_Greater(future, now)){
    printf("Future is later than now\n");  // Printed
}
```

#### Time_Beyond - Check if Past Deadline

```c
bool Time_Beyond(struct timespec now, struct timespec deadline)
```

**Purpose**: Check if current time has passed deadline

**Returns**: `true` if now >= deadline, `false` otherwise

**Example**:
```c
struct timespec start;
Time_Now(&start);

struct timespec timeout = {10, 0};  // 10 seconds
struct timespec deadline = Time_Add(start, timeout);

while(true){
    struct timespec now;
    Time_Now(&now);

    if(Time_Beyond(now, deadline)){
        printf("Timeout!\n");
        break;
    }

    // Do work
}
```

**Use Case**: Timeout detection for operations

#### Time_ToStr - Format Time as String

```c
Str *Time_ToStr(MemCh *m, struct timespec ts)
```

**Purpose**: Convert timespec to ISO 8601 string

**Parameters**:
- `m`: Memory context
- `ts`: Time to format

**Returns**: Str with formatted time (ISO 8601)

**Example**:
```c
struct timespec now;
Time_Now(&now);

Str *formatted = Time_ToStr(m, now);
// formatted->bytes: "2026-01-17T15:30:45"
```

**Format**: `YYYY-MM-DDTHH:MM:SS` (ISO 8601)

#### Time_Today - Get Today's Date

```c
struct timespec Time_Today()
```

**Purpose**: Get midnight of current day

**Returns**: timespec for today at 00:00:00

**Example**:
```c
struct timespec today = Time_Today();
Str *date = Time_ToStr(m, today);
// date->bytes: "2026-01-17T00:00:00"
```

**Use Case**: Date comparisons, daily log rotation

#### Time_ToDayStr - Format Today as String

```c
Str *Time_ToDayStr(MemCh *m)
```

**Purpose**: Get today's date as formatted string

**Returns**: Str with today's date (YYYY-MM-DD)

**Example**:
```c
Str *today = Time_ToDayStr(m);
// today->bytes: "2026-01-17"
```

**Use Case**: Log file names (`log-2026-01-17.txt`)

#### ApproxTime_Set - Set Approximate Time

```c
void ApproxTime_Set(ApproxTime *at, struct timespec ts)
```

**Purpose**: Convert timespec to approximate time components

**Parameters**:
- `at`: Output ApproxTime structure
- `ts`: Time to convert

**Example**:
```c
struct timespec ts = {90061, 500000000};  // 1 day + 1 hour + 1 min + 1 sec + 500ms

ApproxTime at;
ApproxTime_Set(&at, ts);

printf("Days: %d\n", at.day);           // 1
printf("Hours: %d\n", at.hour);         // 1
printf("Minutes: %d\n", at.min);        // 1
printf("Seconds: %d\n", at.sec);        // 1
printf("Milliseconds: %d\n", at.millisec); // 500
```

**Conversion**:
- 1 day = 86400 seconds
- 1 hour = 3600 seconds
- 1 minute = 60 seconds
- 1 millisecond = 1,000,000 nanoseconds

#### ApproxTime_Beyond - Check Approximate Timeout

```c
bool ApproxTime_Beyond(struct timespec now, struct timespec start,
                       ApproxTime interval)
```

**Purpose**: Check if interval has elapsed since start

**Returns**: `true` if now >= start + interval, `false` otherwise

**Example**:
```c
struct timespec start;
Time_Now(&start);

ApproxTime timeout = {0, 30, 0, 0, 0};  // 30 seconds

// Later...
struct timespec now;
Time_Now(&now);

if(ApproxTime_Beyond(now, start, timeout)){
    printf("30 seconds have elapsed\n");
}
```

**Use Case**: Human-readable timeout specifications

### 3. Single Value Wrapper

**Location**: `src/base/util/single.h`

Type-safe wrapping of primitives and pointers for generic containers.

**Structure**:
```c
typedef struct {
    union {
        void *ptr;       // Pointer value
        i32 i;           // 32-bit integer
        i64 i64;         // 64-bit integer
        util word;       // Unsigned integer (64-bit)
        bool boolean;    // Boolean value
        ObjType of;      // Type identifier
        FuncPtr func;    // Function pointer
    } val;

    union {
        util word;       // Type tag
        ObjType of;      // Type (from enum)
    } objType;
} Single;
```

**Key Insight**: `Single` allows storing **any value** (pointer, integer, boolean, function) in a uniform wrapper with a type tag for runtime validation.

#### Ptr_Wrapped - Wrap Pointer

```c
Single *Ptr_Wrapped(MemCh *m, void *ptr, word type)
```

**Purpose**: Wrap pointer with type information

**Parameters**:
- `m`: Memory context
- `ptr`: Pointer to wrap (can be NULL)
- `type`: Type tag (usually ZERO or specific type constant)

**Returns**: Single wrapper containing pointer

**Example**:
```c
Str *message = S(m, "Hello");
Single *wrapped = Ptr_Wrapped(m, message, TYPE_STR);

// Later: Extract and validate
void *raw = wrapped->val.ptr;
if(wrapped->objType.of == TYPE_STR){
    Str *str = (Str *)raw;
    printf("%s\n", str->bytes);
}
```

**Use Cases**:
- Storing pointers in generic containers (Table, Span)
- Type-safe downcasting
- Crypto API (public/private keys)

#### I32_Wrapped - Wrap 32-bit Integer

```c
Single *I32_Wrapped(MemCh *m, i32 value)
```

**Purpose**: Wrap i32 value

**Example**:
```c
i32 count = 42;
Single *wrapped = I32_Wrapped(m, count);

// Later: Extract
i32 retrieved = wrapped->val.i;
printf("Count: %d\n", retrieved);
```

#### I64_Wrapped - Wrap 64-bit Integer

```c
Single *I64_Wrapped(MemCh *m, i64 value)
```

**Purpose**: Wrap i64 value

**Example**:
```c
i64 timestamp = 1705432800;
Single *wrapped = I64_Wrapped(m, timestamp);

// Later: Extract
i64 ts = wrapped->val.i64;
```

#### Bool_Wrapped - Wrap Boolean

```c
Single *Bool_Wrapped(MemCh *m, bool value)
```

**Purpose**: Wrap boolean value

**Example**:
```c
bool isValid = true;
Single *wrapped = Bool_Wrapped(m, isValid);

// Later: Extract
if(wrapped->val.boolean){
    printf("Valid!\n");
}
```

#### Func_Wrapped - Wrap Function Pointer

```c
Single *Func_Wrapped(MemCh *m, FuncPtr func)
```

**Purpose**: Wrap function pointer

**Example**:
```c
typedef void (*CallbackFunc)(int);

void MyCallback(int value){
    printf("Callback: %d\n", value);
}

Single *wrapped = Func_Wrapped(m, (FuncPtr)MyCallback);

// Later: Call
CallbackFunc callback = (CallbackFunc)wrapped->val.func;
callback(123);
```

**Use Case**: Storing callbacks in generic containers

#### Single_Equals - Compare Singles

```c
bool Single_Equals(Single *a, Single *b)
```

**Purpose**: Compare two Single wrappers

**Returns**: `true` if types and values match, `false` otherwise

**Comparison Rules**:
1. Type tags must match (`objType.of`)
2. For pointers: pointer values compared
3. For integers: integer values compared

**Example**:
```c
Single *a = I32_Wrapped(m, 42);
Single *b = I32_Wrapped(m, 42);
Single *c = I32_Wrapped(m, 99);

if(Single_Equals(a, b)){
    printf("a == b\n");  // Printed
}

if(!Single_Equals(a, c)){
    printf("a != c\n");  // Printed
}
```

#### Single_Clone - Deep Copy Single

```c
Single *Single_Clone(MemCh *m, Single *src)
```

**Purpose**: Create deep copy of Single wrapper

**Parameters**:
- `m`: Memory context for allocation
- `src`: Source Single to copy

**Returns**: New Single with copied value

**Example**:
```c
Single *original = I64_Wrapped(m, 123456);
Single *clone = Single_Clone(m, original);

// Independent copies
clone->val.i64 = 999;
printf("Original: %lld\n", original->val.i64);  // 123456
printf("Clone: %lld\n", clone->val.i64);        // 999
```

#### Single_ToUtil - Extract Unsigned Integer

```c
util Single_ToUtil(Single *s)
```

**Purpose**: Extract unsigned integer from Single

**Returns**: Unsigned integer value

**Example**:
```c
Single *wrapped = I64_Wrapped(m, 12345);
util value = Single_ToUtil(wrapped);
// value: 12345
```

**Use Case**: Converting wrapped values to unsigned for calculations

## Complete Examples

### Example 1: Timestamp Formatting

```c
#include "caneka.h"
#include "util.h"

void PrintTimestamp(MemCh *m){
    struct timespec now;
    Time_Now(&now);

    // ISO 8601 format
    Str *iso = Time_ToStr(m, now);
    printf("ISO 8601: %s\n", iso->bytes);

    // Date only
    Str *date = Time_ToDayStr(m);
    printf("Today: %s\n", date->bytes);

    // Unix timestamp
    printf("Unix timestamp: %ld\n", now.tv_sec);
}
```

**Output**:
```
ISO 8601: 2026-01-17T15:30:45
Today: 2026-01-17
Unix timestamp: 1705432245
```

### Example 2: Performance Measurement

```c
#include "caneka.h"
#include "util.h"

void MeasurePerformance(MemCh *m){
    struct timespec start, end;

    Time_Now(&start);

    // Simulate work
    for(i32 i = 0; i < 10000000; i++){
        // Computation
    }

    Time_Now(&end);

    struct timespec elapsed = Time_Sub(end, start);

    printf("Elapsed time: %ld.%09ld seconds\n",
           elapsed.tv_sec, elapsed.tv_nsec);

    // Convert to milliseconds
    i64 ms = elapsed.tv_sec * 1000 + elapsed.tv_nsec / 1000000;
    printf("Elapsed: %lld ms\n", ms);
}
```

**Output**:
```
Elapsed time: 0.042356789 seconds
Elapsed: 42 ms
```

### Example 3: Timeout Detection

```c
#include "caneka.h"
#include "util.h"

status WaitWithTimeout(MemCh *m, i32 timeoutSec){
    struct timespec start;
    Time_Now(&start);

    struct timespec timeout = {timeoutSec, 0};
    struct timespec deadline = Time_Add(start, timeout);

    while(true){
        struct timespec now;
        Time_Now(&now);

        if(Time_Beyond(now, deadline)){
            printf("Timeout after %d seconds\n", timeoutSec);
            return ERROR;
        }

        // Check for completion
        if(/* work done */ false){
            printf("Completed successfully\n");
            return SUCCESS;
        }

        // Sleep briefly to avoid busy-wait
        struct timespec sleep = {0, 100000000};  // 100ms
        Time_Delay(sleep);
    }
}
```

### Example 4: Rate-Limited Logging

```c
#include "caneka.h"
#include "util.h"

void RateLimitedLoop(MemCh *m){
    struct timespec lastLog = {0, 0};
    struct timespec logInterval = {1, 0};  // 1 second

    for(i32 i = 0; i < 10000; i++){
        // Do work every iteration
        // ...

        // Log at most once per second
        if(Time_Throttle(&lastLog, logInterval) & SUCCESS){
            printf("Progress: %d items processed\n", i);
        }
    }
}
```

**Output** (time-spaced):
```
Progress: 0 items processed
Progress: 2341 items processed   (1 second later)
Progress: 4682 items processed   (2 seconds later)
Progress: 7023 items processed   (3 seconds later)
Progress: 9364 items processed   (4 seconds later)
```

### Example 5: Generic Container with Singles

```c
#include "caneka.h"
#include "util.h"

void GenericContainer(MemCh *m){
    // Create heterogeneous span
    Span *mixed = Span_Make(m);

    // Add different types
    Span_Add(mixed, I32_Wrapped(m, 42));
    Span_Add(mixed, I64_Wrapped(m, 123456789));
    Span_Add(mixed, Bool_Wrapped(m, true));
    Span_Add(mixed, Ptr_Wrapped(m, S(m, "Hello"), TYPE_STR));

    // Iterate and extract
    Iter *it = Iter_Make(m, mixed);
    while(Iter_Next(it)){
        Single *item = (Single *)Iter_Value(it);

        switch(item->objType.of){
            case TYPE_I32:
                printf("i32: %d\n", item->val.i);
                break;
            case TYPE_I64:
                printf("i64: %lld\n", item->val.i64);
                break;
            case TYPE_BOOL:
                printf("bool: %s\n", item->val.boolean ? "true" : "false");
                break;
            case TYPE_STR:
                printf("Str: %s\n", ((Str *)item->val.ptr)->bytes);
                break;
        }
    }
}
```

**Output**:
```
i32: 42
i64: 123456789
bool: true
Str: Hello
```

### Example 6: Parsing CLI Integer Argument

```c
#include "caneka.h"
#include "util.h"

i32 ParsePortArg(MemCh *m, const char *arg){
    Str *portStr = Str_CstrRef(m, arg);
    i32 port = Int_FromStr(portStr);

    if(port <= 0 || port > 65535){
        printf("Error: Invalid port number: %s\n", arg);
        return -1;
    }

    return port;
}

int main(int argc, char **argv){
    MemCh *m = MemCh_Make();

    if(argc < 2){
        printf("Usage: %s <port>\n", argv[0]);
        return 1;
    }

    i32 port = ParsePortArg(m, argv[1]);
    if(port < 0) return 1;

    printf("Starting server on port %d\n", port);

    MemCh_Free(m);
    return 0;
}
```

**Usage**:
```bash
./server 8080
# Output: Starting server on port 8080

./server 999999
# Output: Error: Invalid port number: 999999
```

## Best Practices

### 1. Check Integer Conversion Errors

```c
// ✅ GOOD: Validate after parsing
Str *input = S(m, "abc");
i32 value = Int_FromStr(input);

if(value == 0 && !Str_Equals(input, S(m, "0"))){
    printf("Parse error\n");
}

// ⚠️ LIMITATION: Can't distinguish 0 from error
// Consider using I64_FromStr with range check for validation
```

### 2. Use Time_Delay for Short Sleeps

```c
// ✅ GOOD: Use Time_Delay for precise timing
struct timespec ms100 = {0, 100000000};
Time_Delay(ms100);

// ❌ BAD: Use sleep() for sub-second delays
sleep(0);  // No delay!
usleep(100000);  // Deprecated POSIX function
```

### 3. Always Set Type Tags in Single

```c
// ✅ GOOD: Set type tag
Str *msg = S(m, "Hello");
Single *wrapped = Ptr_Wrapped(m, msg, TYPE_STR);

if(wrapped->objType.of == TYPE_STR){
    // Type-safe access
}

// ❌ BAD: Skip type tag
Single *wrapped = Ptr_Wrapped(m, msg, ZERO);
// No type information for validation
```

### 4. Use Time_ToStr for Logging

```c
// ✅ GOOD: ISO 8601 format
struct timespec now;
Time_Now(&now);
Str *timestamp = Time_ToStr(m, now);
printf("[%s] Event occurred\n", timestamp->bytes);

// ❌ BAD: Raw timestamp
printf("[%ld] Event occurred\n", now.tv_sec);
// Hard to read: [1705432245] Event occurred
```

### 5. Throttle High-Frequency Updates

```c
// ✅ GOOD: Throttle status updates
struct timespec lastUpdate = {0, 0};
struct timespec updateInterval = {0, 100000000};  // 100ms

for(i32 i = 0; i < 1000000; i++){
    // Work

    if(Time_Throttle(&lastUpdate, updateInterval) & SUCCESS){
        printf("Progress: %d\n", i);
    }
}

// ❌ BAD: Update every iteration
// Prints 1 million times, floods terminal
```

## Common Pitfalls

### Pitfall 1: Zero Ambiguity in Int_FromStr

```c
// ❌ PROBLEM: Can't tell if "0" or error
Str *zero = S(m, "0");
i32 val1 = Int_FromStr(zero);  // Returns 0 (valid)

Str *invalid = S(m, "xyz");
i32 val2 = Int_FromStr(invalid);  // Returns 0 (error)

// val1 == val2, but different meanings!

// ✅ SOLUTION: Validate input first or use range check
if(val2 == 0 && input->length > 0 && input->bytes[0] != '0'){
    // Likely parse error
}
```

### Pitfall 2: Nanosecond Overflow

```c
// ❌ BAD: Nanoseconds > 999,999,999
struct timespec bad = {0, 1500000000};  // 1.5 billion ns

// ✅ GOOD: Keep nanoseconds in range
struct timespec good = {1, 500000000};  // 1 sec + 500 million ns
```

### Pitfall 3: Wrong Single Type Tag

```c
// ❌ BAD: Wrong type tag
Str *msg = S(m, "Hello");
Single *wrapped = Ptr_Wrapped(m, msg, TYPE_I32);  // Wrong type!

if(wrapped->objType.of == TYPE_I32){
    i32 value = wrapped->val.i;  // Garbage! msg is not an i32
}

// ✅ GOOD: Correct type tag
Single *wrapped = Ptr_Wrapped(m, msg, TYPE_STR);
```

### Pitfall 4: Forgetting to Update lastTime in Throttle

```c
// ❌ BAD: lastTime never updated
struct timespec lastLog = {0, 0};
struct timespec interval = {1, 0};

for(i32 i = 0; i < 100; i++){
    struct timespec now;
    Time_Now(&now);

    if(Time_Greater(Time_Sub(now, lastLog), interval)){
        printf("Log\n");
        // FORGOT: lastLog = now;
    }
}
// Prints 100 times immediately!

// ✅ GOOD: Use Time_Throttle (auto-updates)
for(i32 i = 0; i < 100; i++){
    if(Time_Throttle(&lastLog, interval) & SUCCESS){
        printf("Log\n");  // Prints at 1-second intervals
    }
}
```

## Function Reference

| Function | Purpose |
|----------|---------|
| **Integer Conversion** | |
| `Int_FromStr(s)` | Parse i32 from string |
| `I64_FromStr(s)` | Parse i64 from string |
| `Str_FromI64(m, value)` | Convert i64 to string |
| `Str_FromI64Pad(m, value, width)` | Convert i64 with zero padding |
| `Str_UniRandom(m, length)` | Generate random digit string |
| **Time Utilities** | |
| `Time_Now(ts)` | Get current time |
| `Time_Sub(a, b)` | Subtract times (a - b) |
| `Time_Add(a, b)` | Add times (a + b) |
| `Time_Delay(delay)` | Sleep for duration |
| `Time_Throttle(last, interval)` | Rate limiting |
| `Time_Greater(a, b)` | Compare times (a > b) |
| `Time_Beyond(now, deadline)` | Check if past deadline |
| `Time_ToStr(m, ts)` | Format time as ISO 8601 |
| `Time_Today()` | Get today at midnight |
| `Time_ToDayStr(m)` | Get today as string |
| `ApproxTime_Set(at, ts)` | Convert to approximate time |
| `ApproxTime_Beyond(now, start, interval)` | Check approximate timeout |
| **Single Wrapper** | |
| `Ptr_Wrapped(m, ptr, type)` | Wrap pointer |
| `I32_Wrapped(m, value)` | Wrap i32 |
| `I64_Wrapped(m, value)` | Wrap i64 |
| `Bool_Wrapped(m, value)` | Wrap boolean |
| `Func_Wrapped(m, func)` | Wrap function pointer |
| `Single_Equals(a, b)` | Compare Singles |
| `Single_Clone(m, src)` | Deep copy Single |
| `Single_ToUtil(s)` | Extract unsigned integer |

## Summary

The Utilities Module provides **foundational helper functions** with:

**Strengths**:
- ✅ Simple integer ↔ string conversion
- ✅ Comprehensive time manipulation
- ✅ Type-safe value wrapping
- ✅ Integration with MemCh memory management
- ✅ Used throughout Caneka codebase

**Use Cases**:
- Parsing command-line arguments
- Formatting log timestamps
- Performance measurement
- Rate-limiting operations
- Generic containers with mixed types

**Limitations**:
- Integer parsing returns 0 on error (ambiguous)
- Str_UniRandom uses `rand()` (not crypto-secure)
- No overflow detection in integer conversion
- Single wrapper requires manual type tag management

**Best For**:
- Applications requiring time operations
- CLI tools with integer arguments
- Generic data structures
- Logging and debugging
- Performance profiling

The module is **production-ready** and provides essential utilities for everyday programming tasks in Caneka.
