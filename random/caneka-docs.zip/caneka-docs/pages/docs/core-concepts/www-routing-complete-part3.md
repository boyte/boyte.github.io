# WWW Routing System Complete Guide - Part 3

[← Part 2](www-routing-complete-part2) | **Part 3 of 3**

---

## Cross-References

### Related Documentation

- **[HTTP Lifecycle Complete](http-lifecycle-complete.md)**: Request/response flow, protocol handling, how routing integrates with HTTP phases
- **[Seel/Inst Property System Complete](seel-inst-complete.md)**: Type system underlying Route objects, property access patterns, hierarchical navigation
- **[Templ Complete](templ-complete.md)**: Template engine used by `routeFuncTempl` handler, preparation and rendering phases
- **[BinSeg Complete](binseg-complete.md)**: Binary database format served by `routeFuncFileDb` handler, serialization/deserialization
- **[Type System Complete](type-system-complete.md)**: Runtime type identification, wrapper types for handler functions
- **[Buff I/O Complete](buff-io-complete.md)**: Buffered I/O system used for content generation and piping
- **[Table/Lookup Complete](table-lookup-complete.md)**: Hash tables for handler registration and route data storage

### Key Source Files

- [src/inter/include/www/route.h](../../../src/inter/include/www/route.h): Route type definition, flags, handler signature
- [src/inter/www/route.c](../../../src/inter/www/route.c): Route building, preparation, handler dispatch
- [src/inter/www/webserver.c](../../../src/inter/www/webserver.c): Request handling, page serving, composition
- [src/inter/www/page.c](../../../src/inter/www/page.c): WwwPage schema definition
- [src/ext/format/config/config.c](../../../src/ext/format/config/config.c): Configuration file loading
- [src/programs/test/option/inter/route_tests.c](../../../src/programs/test/option/inter/route_tests.c): Comprehensive routing tests

### Related APIs

**Route Management:**
- `Route_Make(m)`: Create new route instance
- `Route_From(m, dir)`: Build routes from directory
- `Route_BuildRoute(root, name, path, configAtts)`: Build single route
- `Route_CollectConfig(root, name, path, configAtts)`: Scan and build routes
- `Route_Prepare(rt)`: Prepare route content (templates, formats, etc.)
- `Route_Get(root, path)`: Look up route by path
- `Route_Handle(rt, dest, data, ctx)`: Dispatch to handler

**Handler Registration:**
- `Route_Init(m)`: Initialize routing system and default handlers
- `Route_MimeFunc(path)`: Get handler by file extension
- `Func_Wrapped(m, func)`: Wrap handler function pointer

**Configuration:**
- `Config_FromPath(m, path)`: Load .config file
- `Config_Sequence(m, v)`: Parse space-separated list

**ETag Management:**
- `Route_CheckEtag(rt, etag)`: Check if ETag matches
- `Route_SetEtag(rt, path, mod)`: Generate and store ETag
- `HttpCtx_MakeEtag(m, path, mod)`: Generate ETag from file

### Navigation Patterns

**Creating Routes:**

```c
// Method 1: Automatic from directory
Route *pages = Route_Make(m);
Route_CollectConfig(pages, Sv(m, "/"), publicPath, configAtts);

// Method 2: Manual construction
Route *root = Route_Make(m);
Route *stats = Inst_Make(m, TYPE_WWW_ROUTE);
Inst_ByPath(root, IoPath(m, "/stats"), stats, SPAN_OP_SET, NULL);
```

**Accessing Route Properties:**

```c
// Get prepared content
Templ *templ = (Templ *)Seel_Get(route, K(m, "templ"));
Str *mime = (Str *)Seel_Get(route, K(m, "mime"));
Table *data = (Table *)Seel_Get(route, K(m, "data"));

// Get handler function
Single *funcW = (Single *)Seel_Get(route, K(m, "func"));
RouteFunc func = (RouteFunc)funcW->val.ptr;
```

**Hierarchical Traversal:**

```c
// Walk route tree
Route *root = tcp->pages;
Route *api = Inst_ByPath(root, IoPath(m, "/api"), NULL, SPAN_OP_GET, NULL);
Route *users = Inst_ByPath(api, IoPath(m, "users"), NULL, SPAN_OP_GET, NULL);

// Or direct path
Route *users = Inst_ByPath(root, IoPath(m, "/api/users"),
                           NULL, SPAN_OP_GET, NULL);
```


## Summary

The WWW Routing System provides **filesystem-driven, transparent URL-to-handler mapping** for Caneka's web server. By mirroring the filesystem structure and using file extensions to determine content types, routing becomes **discoverable and predictable**. Routes are Inst objects integrated with Caneka's type system, enabling hierarchical navigation and typed property access.

The system follows a **prepare-once, serve-many model**: templates, formats, and database contexts are parsed at startup and reused across requests. This moves expensive parsing work out of the request path, resulting in **extremely fast request handling** (microseconds for most operations).

Key architectural decisions:
- **Routes are Inst objects**: Unified with type system, hierarchical navigation
- **Extension-based dispatching**: Predictable handler mapping
- **Preparation phase**: Parse once at startup, serve fast
- **ETag caching**: Conditional responses for static assets
- **Configuration inheritance**: Cascading .config files
- **Zero-copy composition**: Buffer piping without intermediate copying

The routing system integrates seamlessly with the HTTP lifecycle, Templ engine, BinSeg databases, and other Caneka subsystems to provide a complete web serving solution.



---

[← Part 2](www-routing-complete-part2) | **Part 3 of 3**
