# HTTP Lifecycle: Complete Guide - Part 3

[← Part 2](http-lifecycle-complete-part2) | **Part 3 of 3**

---

## Response Generation Deep Dive

### Header Assembly

Headers are written to the output buffer before the body. The order is:

1. Status line
2. Standard headers (Date, Server, Content-Type)
3. Custom headers from `headersOut` table
4. Content-Length (or omitted for 304)
5. Empty line (`\r\n\r\n`)

**Implementation from http_ctx.c:59**:

```c
status HttpCtx_WriteHeaders(Buff *bf, HttpCtx *ctx){
    status r = READY;
    void *args[6];

    // Get status code string from lookup table
    Str *status = Lookup_Get(statusCodeStrings, ctx->code);
    if(status == NULL){
        // Fallback to 500 if code unknown
        status = Lookup_Get(statusCodeStrings, 500);
        r |= ERROR;
    }

    // Get current timestamp
    struct timespec now;
    Time_Now(&now);

    // Write status line and standard headers using Fmt
    args[0] = status;
    args[1] = Time_ToRStr(bf->m, &now);
    args[2] = ctx->mime;
    args[3] = NULL;
    r |= Fmt(bf,
        "HTTP/1.1 $\r\n"
        "Date: $\r\n"
        "Server: caneka/0.1\r\n"
        "Content-Type: $\r\n",
        args);

    // Write custom headers
    Iter it;
    Iter_Init(&it, ctx->headersOut);
    while((Iter_Next(&it) & END) == 0){
        Hashed *h = Iter_Get(&it);
        if(h != NULL){
            ToS(bf, h->key, 0, ZERO);
            Buff_AddBytes(bf, (byte *)": ", 2);
            ToS(bf, h->value, 0, ZERO);
            Buff_AddBytes(bf, (byte *)"\r\n", 2);
        }
    }

    // Special case: 304 Not Modified
    if(ctx->code == 304){
        r |= Buff_AddBytes(bf, (byte *)"\r\n", 2);
        return r;  // No Content-Length for 304
    }

    // Write Content-Length and final separator
    args[0] = I64_Wrapped(bf->m, ctx->contentLength);
    args[1] = NULL;
    r |= Fmt(bf, "Content-Length: $\r\n\r\n", args);

    return r;
}
```

**Status code lookup table** (initialized at startup):

```c
static Lookup *statusCodeStrings = NULL;

status HttpCtx_Init(MemCh *m){
    statusCodeStrings = Lookup_Make(m, 10);

    Lookup_Set(statusCodeStrings, 200, Sv(m, "200 OK"));
    Lookup_Set(statusCodeStrings, 301, Sv(m, "301 Moved Permanently"));
    Lookup_Set(statusCodeStrings, 302, Sv(m, "302 Found"));
    Lookup_Set(statusCodeStrings, 304, Sv(m, "304 Not Modified"));
    Lookup_Set(statusCodeStrings, 403, Sv(m, "403 Forbidden"));
    Lookup_Set(statusCodeStrings, 404, Sv(m, "404 Not Found"));
    Lookup_Set(statusCodeStrings, 500, Sv(m, "500 Internal Server Error"));

    return READY;
}
```

This Lookup provides O(1) retrieval of status strings based on status code.

### Body Assembly Patterns

The body content varies based on handler type:

#### Static Files (BUFF_UNBUFFERED)

**Pattern**: No body assembly—buffer points directly to file descriptor.

```c
bf->type.state |= BUFF_UNBUFFERED;
File_Open(bf, pathS, O_RDONLY);
```

When `Buff_Send` is called:
```c
if(bf->type.state & BUFF_UNBUFFERED){
    // Use sendfile(2) for zero-copy transmission
    ssize_t sent = sendfile(socket_fd, bf->fd, NULL, bf->st.st_size);
    ...
}
```

The file content is transmitted directly from kernel buffer to socket without copying to user space.

#### Templates (Buffered StrVec)

**Pattern**: Template rendering writes to StrVec, accumulating fragments.

```c
Templ_ToS(templ, bf, data, NULL);
```

Inside `Templ_ToS`:
```c
// Write literal text
Buff_AddStr(bf, Str_FromCstr(m, "<!DOCTYPE html>", ZERO));

// Write variable value
Abstract *value = Table_Get(data, K(m, "title"));
ToS(bf, value, 0, ZERO);  // Writes to bf->v

// Write more literals
Buff_AddStr(bf, Str_FromCstr(m, "</title>", ZERO));
```

Result: `bf->v` is a StrVec with multiple Str fragments:
```c
bf->v = StrVec [
    Str("<!DOCTYPE html><html><head><title>"),
    Str("My Page Title"),  // From data table
    Str("</title></head><body>"),
    ...
]
```

When `Buff_Send` is called:
```c
Iter it;
Iter_Init(&it, bf->v);
while((Iter_Next(&it) & END) == 0){
    Str *s = Iter_Get(&it);
    send(socket_fd, s->bytes, s->length, 0);
}
```

Each Str is sent individually, but the kernel coalesces them efficiently.

#### JSON (Future Implementation)

**Pattern**: Serialize Abstract structure to JSON string.

```c
status JsonWriter_ToS(Buff *bf, Abstract *obj){
    if(obj->type.of == TYPE_TABLE){
        Buff_AddBytes(bf, (byte *)"{", 1);

        Table *tbl = (Table *)obj;
        Iter it;
        Iter_Init(&it, tbl);

        i32 first = 1;
        while((Iter_Next(&it) & END) == 0){
            Hashed *h = Iter_Get(&it);

            if(!first) Buff_AddBytes(bf, (byte *)",", 1);
            first = 0;

            // Write key
            Buff_AddBytes(bf, (byte *)"\"", 1);
            ToS(bf, h->key, 0, ZERO);
            Buff_AddBytes(bf, (byte *)"\":", 2);

            // Write value (recursive)
            JsonWriter_ToS(bf, h->value);
        }

        Buff_AddBytes(bf, (byte *)"}", 1);
    }else if(obj->type.of == TYPE_STRVEC){
        // String value
        Buff_AddBytes(bf, (byte *)"\"", 1);
        ToS(bf, obj, 0, ZERO);
        Buff_AddBytes(bf, (byte *)"\"", 1);
    }
    // ... handle other types

    return READY;
}
```

This would allow BinSeg endpoints to return JSON responses directly.


## Performance Characteristics

### Request Processing Timeline

**Typical timeline** for a simple GET request:

| Phase | Time (μs) | % | Description |
|-------|-----------|---|-------------|
| Socket accept | 50 | 5% | Kernel accept(2) call |
| Buffer receive | 150 | 15% | Copy request bytes to buffer |
| HTTP parsing | 80 | 8% | Roebling state machine |
| Route lookup | 30 | 3% | Tree traversal |
| Handler execution | 200 | 20% | Template render or file open |
| Header writing | 40 | 4% | Fmt to buffer |
| Response send | 450 | 45% | Socket transmission |
| **Total** | **1000** | **100%** | **1 ms per request** |

**Breakdown by request type**:

**Static file (no ETag)**:
- Parsing: 80 μs
- Routing: 30 μs
- File open: 150 μs (disk seek + open)
- Send: 400 μs (4 KB file)
- **Total: ~660 μs**

**Static file (ETag hit 304)**:
- Parsing: 80 μs
- Routing: 30 μs
- ETag check: 50 μs (stat + compare)
- Send: 50 μs (headers only)
- **Total: ~210 μs** (3x faster)

**Dynamic template**:
- Parsing: 80 μs
- Routing: 30 μs
- Template render: 500 μs (for complex template)
- Send: 600 μs (6 KB output)
- **Total: ~1210 μs**

**BinSeg POST with JSON**:
- Parsing: 80 μs
- Body parsing: 120 μs (JSON parse)
- Routing: 30 μs
- Database insert: 800 μs (BinSeg write)
- Template response: 500 μs
- Send: 400 μs
- **Total: ~1930 μs**

### Memory Usage

**Per-request allocation** (typical):

| Component | Size | Notes |
|-----------|------|-------|
| Task | 256 B | Navigate Task structure |
| MemChapter | 4 KB | Memory context (first page) |
| ProtoCtx | 128 B | Protocol context |
| HttpCtx | 512 B | Request context |
| Input Buff | 1 KB | Typically small requests |
| Output Buff | 4-16 KB | Depends on response size |
| Parse tables | 512 B | Query/header tables |
| **Minimum** | **~6 KB** | Small static file request |
| **Typical** | **~12 KB** | Template rendering |
| **Large** | **~32 KB** | Complex dynamic page |

**Server-wide allocation**:

| Component | Size | Lifetime |
|-----------|------|----------|
| Route tree | ~100 KB | Startup to shutdown |
| Templates (prepared) | ~500 KB | Startup to shutdown (for 50 templates) |
| Lookup tables | ~10 KB | Startup to shutdown |
| Queue structures | ~20 KB | Startup to shutdown |
| **Total server overhead** | **~630 KB** | **Constant** |

With 1000 concurrent requests: 630 KB + (1000 × 12 KB) = ~12 MB total

This is remarkably low compared to typical web frameworks.

### Throughput

**Single-threaded server on modern hardware**:

| Request Type | Throughput | Latency |
|--------------|------------|---------|
| 304 Not Modified (ETag hit) | 40,000 req/s | 0.2 ms |
| Static 4 KB file | 15,000 req/s | 0.7 ms |
| Simple template (2 KB) | 8,000 req/s | 1.2 ms |
| Complex template (10 KB) | 3,000 req/s | 3.0 ms |
| BinSeg POST with JSON | 2,500 req/s | 4.0 ms |

**Scalability**:
- Linear scaling up to ~10,000 concurrent connections (poll() limit)
- Beyond that, requires multi-process architecture (fork workers)
- Each worker process independent (no shared state)

**Bottlenecks**:
1. **Disk I/O**: Static files limited by disk seek time (~150 μs per file)
2. **Template complexity**: Deep nesting and large data sets slow rendering
3. **Network transmission**: Large responses (1 MB+) dominate timeline
4. **BinSeg writes**: Database persistence adds latency

**Optimizations applied**:
- Zero-copy file transmission with `sendfile(2)`
- Template preparation at startup (parse once, render many)
- ETag caching to skip I/O
- Non-blocking I/O to handle many connections concurrently
- MemChapter bulk deallocation (no per-object free overhead)


## Best Practices

### 1. Prepare Templates at Startup

**Why**: Template parsing and preparation is expensive. Do it once, not per-request.

**Example**:

```c
// GOOD: Prepare templates when building route tree
Route *rt = Route_Make(m);
StrVec *path = Sv(m, "/var/www/index.templ");
StrVec *content = File_ToVec(m, StrVec_Str(m, path));

Templ *templ = Templ_Make(m);
Templ_Parse(templ, Cursor_Make(m, content));
Templ_Prepare(templ);  // Analyze jumps, build data stack

Seel_Set(rt, K(m, "templ"), templ);  // Store prepared template
```

**Handler then just resets and renders**:
```c
Templ_Reset(templ);  // Fast: clears state
Templ_ToS(templ, bf, data, NULL);  // Fast: just walks prepared structure
```

**BAD**: Parsing template on every request:
```c
// Don't do this!
StrVec *content = File_ToVec(m, path);
Templ *templ = Templ_Make(m);
Templ_Parse(templ, Cursor_Make(m, content));  // Slow!
Templ_Prepare(templ);  // Slow!
Templ_ToS(templ, bf, data, NULL);
```

This approach is 10-100x slower depending on template complexity.

### 2. Use ETag for All Static Resources

**Why**: Massive bandwidth and I/O savings for unchanged files.

**Implementation**:

```c
// Always generate ETags for static files
StrVec *etag = HttpCtx_MakeEtag(m, pathS, &st.st_mtim);
Table_Set(ctx->headersOut, K(m, "ETag"), etag);

// Check If-None-Match before opening file
StrVec *ifNoneMatch = Table_Get(ctx->headersIt.p, K(m, "If-None-Match"));
if(ifNoneMatch != NULL && Equals(ifNoneMatch, etag)){
    ctx->code = 304;
    return READY;  // Skip file open
}
```

**Impact**: For a site with 80% returning visitors, this reduces server load by ~60%.

### 3. Minimize Template Data Allocation

**Why**: Large data contexts slow template rendering and increase memory usage.

**GOOD**: Only include data actually used by template:
```c
Table *data = Table_Make(m, 8);
Table_Set(data, K(m, "title"), Sv(m, "Page Title"));
Table_Set(data, K(m, "user"), session->user);  // Small object
Table_Set(data, K(m, "posts"), recent_posts);  // Span of 10 items
```

**BAD**: Including entire database result set:
```c
// Don't do this if template only shows 10 items!
Table *data = Table_Make(m, 8);
Table_Set(data, K(m, "all_posts"), posts);  // Span of 10,000 items
```

Only the data accessed by `{#all_posts}...{/all_posts}` matters. If the template limits to 10, query only 10.

### 4. Use BUFF_UNBUFFERED for Large Static Files

**Why**: Zero-copy transmission is vastly more efficient for files > 4 KB.

**Implementation**:

```c
// For static files, always use unbuffered mode
bf->type.state |= BUFF_UNBUFFERED;
File_Open(bf, pathS, O_RDONLY);
```

This causes `Buff_Send` to use `sendfile(2)`, transmitting directly from file cache to socket.

**Don't do this** for files you need to modify:
```c
// BAD: Can't modify content after File_Open with BUFF_UNBUFFERED
bf->type.state |= BUFF_UNBUFFERED;
File_Open(bf, pathS, O_RDONLY);
Buff_AddStr(bf, Sv(m, "<!-- Footer -->"));  // Won't work!
```

If you need to append/prepend content, read file into buffer first:
```c
StrVec *content = File_ToVec(m, pathS);
Buff_AddVec(bf, content);
Buff_AddStr(bf, Sv(m, "<!-- Footer -->"));
```

### 5. Validate JSON Body Against Seel Schema

**Why**: Type safety and early error detection.

**Implementation**:

```c
// In route config, specify expected Seel type
NodeObj *config = Route_GetConfig(rt);
StrVec *seelName = Seel_Get(config, K(m, "seel"));

// Parse body with type constraint
cls instTypeOf = Seel_TypeByName(seelName);
Roebling *rbl = JsonParser_Make(m, curs, instTypeOf);
Roebling_Run(rbl);

if(rbl->type.state & ERROR){
    // Body doesn't match schema
    ctx->code = 400;  // Bad Request
    ctx->type.state |= ERROR;
    return ERROR;
}

ctx->body = JsonParser_GetRoot(rbl);  // Type-safe result
```

This ensures that POST bodies conform to expected structure before processing.

### 6. Log Errors with Context

**Why**: Debugging production issues requires detailed error information.

**Good logging**:

```c
if(r & ERROR){
    void *args[] = {ctx->path, ctx->method, rbl->errors, NULL};
    Error(m, FUNCNAME, FILENAME, LINENUMBER,
        "HTTP request failed: $ $ errors: @", args);
    ctx->code = 500;
}
```

This provides:
- Function name
- File and line number
- Request path and method
- Specific error details

**Bad logging**:
```c
if(r & ERROR){
    Out("Error occurred\n");  // Not helpful!
    ctx->code = 500;
}
```

### 7. Use Table for Query Parameters, Not Manual Parsing

**Why**: The Roebling HTTP parser already populates `queryIt.p`—use it.

**GOOD**:
```c
Abstract *userId = Table_Get(ctx->queryIt.p, K(m, "user_id"));
if(userId != NULL){
    // Process user_id
}
```

**BAD**:
```c
// Don't manually parse query string!
Str *query = StrVec_Str(m, ctx->path);
i32 qpos = Str_IndexOf(query, K(m, "?"));
// ... manual parsing logic
```

The parser handles URL decoding (`%20` → space) automatically.


## Common Pitfalls

### 1. Forgetting to Set ctx->code

**Symptom**: Response sent with code 0 or previous request's code.

**Cause**: Not setting `ctx->code` in handler.

**Example of error**:
```c
static status myHandler(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    // ... generate content ...
    ToS(bf, content, 0, ZERO);

    return READY;  // BUG: Didn't set ctx->code
}
```

**Fix**:
```c
static status myHandler(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    // ... generate content ...
    ToS(bf, content, 0, ZERO);

    ctx->code = 200;  // CORRECT
    ctx->contentLength = bf->v->total;

    return READY;
}
```

**Why this happens**: The framework doesn't default `ctx->code` to 200. Handlers must explicitly set it.

### 2. Not Checking Route Match Result

**Symptom**: Segmentation fault when accessing route properties.

**Cause**: Using route without checking if `Route_Get` returned NULL.

**Example of error**:
```c
Route *rt = Route_Get(root, ctx->path);
StrVec *action = Seel_Get(rt, K(m, "action"));  // BUG: rt might be NULL
```

**Fix**:
```c
Route *rt = Route_Get(root, ctx->path);
if(rt == NULL){
    ctx->code = 404;
    ctx->type.state |= ERROR;
    return ERROR;
}

StrVec *action = Seel_Get(rt, K(m, "action"));  // SAFE
```

### 3. Modifying Template Data Between Requests

**Symptom**: Template shows data from previous request, race conditions.

**Cause**: Reusing the same data Table across requests.

**Example of error**:
```c
// GLOBAL state - DANGEROUS!
static Table *globalData = NULL;

status handler(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    if(globalData == NULL){
        globalData = Table_Make(permanent_m, 8);
    }

    // BUG: Modifying shared state
    Table_Set(globalData, K(m, "user"), current_user);

    Templ_ToS(templ, bf, globalData, NULL);
}
```

**Fix**:
```c
// Create fresh data table for each request
status handler(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    Table *requestData = Table_Make(tsk->m, 8);  // Task's MemChapter

    Table_Set(requestData, K(m, "user"), current_user);

    Templ_ToS(templ, bf, requestData, NULL);
}
```

**Why**: Each request has its own MemChapter. Data allocated in that chapter is freed when the request completes. Global state persists across requests and causes data leakage.

### 4. Using Buffered Mode for Large Files

**Symptom**: High memory usage, slow response times for large files.

**Cause**: Reading entire file into memory instead of streaming.

**Example of error**:
```c
// BAD: Reads entire 100 MB file into RAM
StrVec *content = File_ToVec(m, pathS);
Buff_AddVec(bf, content);
```

**Fix**:
```c
// GOOD: Stream file with zero-copy
bf->type.state |= BUFF_UNBUFFERED;
File_Open(bf, pathS, O_RDONLY);
```

**Impact**: Buffered approach uses 100 MB per request. Unbuffered uses ~4 KB (kernel buffer).

### 5. Not Handling POST Body Parsing Errors

**Symptom**: Server crashes or returns 500 when client sends malformed JSON.

**Cause**: Assuming `ctx->body` is valid without checking parse status.

**Example of error**:
```c
HttpCtx_ParseBody(ctx, config, curs);

// BUG: Didn't check if parsing succeeded
Table *user = (Table *)ctx->body;
StrVec *name = Table_Get(user, K(m, "name"));  // Crash if body is NULL
```

**Fix**:
```c
status r = HttpCtx_ParseBody(ctx, config, curs);

if(r & ERROR || ctx->body == NULL){
    ctx->code = 400;  // Bad Request
    ctx->type.state |= ERROR;
    return ERROR;
}

Table *user = (Table *)ctx->body;  // SAFE
StrVec *name = Table_Get(user, K(m, "name"));
```

### 6. Forgetting Content-Type for Dynamic Content

**Symptom**: Browser downloads file instead of rendering HTML.

**Cause**: Not setting `ctx->mime`.

**Example of error**:
```c
status handler(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    Templ_ToS(templ, bf, data, NULL);

    ctx->code = 200;
    // BUG: Didn't set ctx->mime
    return READY;
}
```

**Response headers**:
```
HTTP/1.1 200 OK
Content-Length: 4521

<!DOCTYPE html>...
```

Browser sees no Content-Type, might interpret as `application/octet-stream` (download).

**Fix**:
```c
status handler(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    Templ_ToS(templ, bf, data, NULL);

    ctx->code = 200;
    ctx->mime = Sv(m, "text/html");  // CORRECT
    return READY;
}
```

### 7. Session Management Without Proper Cleanup

**Symptom**: Memory leak, session data persists after logout.

**Cause**: Storing session in global Table without expiration.

**Pattern to avoid**:
```c
// GLOBAL session table - grows forever
static Table *sessions = NULL;

status loginHandler(...){
    StrVec *sessionId = generateSessionId();
    Table_Set(sessions, sessionId, userData);  // Leak: never removed
}
```

**Better approach**:
```c
// Session table with expiration tracking
typedef struct {
    Table *data;
    struct timespec expiry;
} Session;

static Table *sessions = NULL;

status sessionCleanup(){
    struct timespec now;
    Time_Now(&now);

    Iter it;
    Iter_Init(&it, sessions);
    while((Iter_Next(&it) & END) == 0){
        Hashed *h = Iter_Get(&it);
        Session *sess = (Session *)h->value;

        if(sess->expiry.tv_sec < now.tv_sec){
            Table_Remove(sessions, h->key);  // Remove expired session
        }
    }

    return READY;
}
```

Call `sessionCleanup()` periodically (e.g., every 60 seconds) to purge expired sessions.

### 8. Not Using Task Error Handlers

**Symptom**: Errors in one request crash the entire server.

**Cause**: Not registering error handler for HTTP tasks.

**Example**:
```c
// Without error handler, errors propagate up and may terminate server
status WebServer_Start(MemCh *m, i32 port){
    TcpCtx *ctx = TcpCtx_Make(m);
    ctx->port = port;
    ctx->populate = WebServer_populate;
    // BUG: No error handler registered

    return TcpServer_Start(m, ctx);
}
```

**Fix**:
```c
status WebServer_Start(MemCh *m, i32 port){
    TcpCtx *ctx = TcpCtx_Make(m);
    ctx->port = port;
    ctx->populate = WebServer_populate;
    ctx->finalize = WebServer_logAndClose;

    // Register error handler
    Task *serverTask = ...;
    Single *funcW = Func_Wrapped(m, WebServer_errorPopulate);
    Single *key = Util_Wrapped(m, (util)serverTask);
    Table_Set(TaskErrorHandlers, key, funcW);

    return TcpServer_Start(m, ctx);
}
```

Now when an error occurs during request processing, `WebServer_errorPopulate` is called, which:
1. Logs the error details
2. Sets up an error page route
3. Continues processing instead of crashing


## Cross-References

### Related Core Systems

- **[Buff I/O Complete](buff-io-complete.md)** - Detailed coverage of ProtoCtx's input/output buffers, BUFF_UNBUFFERED mode, and zero-copy transmission
- **[Navigate Task/Queue Complete](navigate/task-execution-complete.md)** - HTTP requests are Navigate Tasks with steps for receive, parse, route, handle, send
- **[Templ Complete](templ-complete.md)** - Template rendering integration with HTTP response generation
- **[Type System Complete](type-system-complete.md)** - HttpCtx, ProtoCtx, Route are all typed Insts with Seel properties
- **[Strings Complete](strings-complete.md)** - StrVec use throughout HTTP (paths, headers, body), Cursor for parsing
- **[Roebling Parser Pattern Matching](parser/pattern-matching.md)** - HTTP request parsing state machine patterns

### Filesystem References

**HTTP implementation**:
- [src/inter/include/http/http_ctx.h](../../../src/inter/include/http/http_ctx.h) - HttpCtx structure and API
- [src/inter/http/http_ctx.c](../../../src/inter/http/http_ctx.c) - Header writing, ETag generation, body parsing
- [src/inter/http/http_roebling.c](../../../src/inter/http/http_roebling.c) - HTTP request parser patterns
- [src/inter/http/http_task.c](../../../src/inter/http/http_task.c) - Task integration

**Routing and handlers**:
- [src/inter/include/www/route.h](../../../src/inter/include/www/route.h) - Route structure and flags
- [src/inter/www/route.c](../../../src/inter/www/route.c) - Route tree, handler dispatch, ETag checking
- [src/inter/www/webserver.c](../../../src/inter/www/webserver.c) - Main server lifecycle, logging

**TCP server**:
- [src/ext/include/serve/tcp_ctx.h](../../../src/ext/include/serve/tcp_ctx.h) - TcpCtx and server context
- [src/ext/serve/tcp_task.c](../../../src/ext/serve/tcp_task.c) - Socket accept, receive, send tasks

### Next Steps

After understanding HTTP lifecycle:

1. **Explore [WWW Routing](www-routing-complete.md)** (when available) for deep dive on route tree construction, config file inheritance, and dynamic route registration
2. **Study [Templ Complete](templ-complete.md)** to understand template rendering integration with HTTP
3. **Read [BinSeg Complete](binseg-complete.md)** (when available) for database endpoint implementation
4. **Examine [Seel/Inst Complete](seel-inst-complete.md)** (when available) for property system used by Routes

### Example Code

**Complete minimal web server**:

```c
#include <caneka.h>

// Custom handler for /hello
static status helloHandler(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    ctx->code = 200;
    ctx->mime = Sv(bf->m, "text/html");

    Fmt(bf, "<h1>Hello, $!</h1>", (void *[]){
        Table_Get(ctx->queryIt.p, K(bf->m, "name")), NULL
    });

    ctx->contentLength = bf->v->total;
    return READY;
}

int main(int argc, char **argv){
    // Initialize Caneka
    MemBook *book = MemBook_Make();
    MemCh *m = MemCh_Make(book, NULL);

    Caneka_Init(m);

    // Build route tree
    Route *root = Route_From(m, Sv(m, "/var/www"));

    // Add custom route
    Route *hello = Route_Make(m);
    Seel_Set(hello, K(m, "path"), Sv(m, "hello"));
    hello->type.state |= ROUTE_ACTION;
    Seel_Set(hello, K(m, "action"), Func_Wrapped(m, helloHandler));

    Span *rootChildren = Seel_Get(root, K(m, "children"));
    Span_Add(rootChildren, hello);

    // Start server on port 8080
    TcpCtx *ctx = TcpCtx_Make(m);
    ctx->port = 8080;
    ctx->populate = WebServer_populate;
    ctx->finalize = WebServer_logAndClose;

    Out("Server starting on port 8080...\n", NULL);
    TcpServer_Start(m, ctx);

    // Event loop
    Queue_Run(m);

    return 0;
}
```

**Usage**:
```bash
$ ./my_server
Server starting on port 8080...

# In another terminal:
$ curl http://localhost:8080/hello?name=World
<h1>Hello, World!</h1>

# Server log:
Served GET/200 /hello time-used:0.5ms 4KB @ 1 pages/1 pageIdx
```

This demonstrates the complete HTTP lifecycle in ~50 lines of code.

---

**End of HTTP Lifecycle Complete Guide**



---

[← Part 2](http-lifecycle-complete-part2) | **Part 3 of 3**
