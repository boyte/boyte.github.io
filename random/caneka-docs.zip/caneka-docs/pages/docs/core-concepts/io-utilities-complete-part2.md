# I/O Utilities: Complete Guide - Part 2

[← Part 1](io-utilities-complete-part1) | **Part 2 of 2**

---

## Socket Utilities

### IPv4 Conversion

#### Ip4_ToStr() - Convert IPv4 to String

**Signature:**
```c
Str *Ip4_ToStr(MemCh *m, u32 ip4);
```

Converts a 32-bit IPv4 address (in host byte order) to dotted-decimal string format.

**Example:**
```c
u32 localhost = 0x7F000001;  // 127.0.0.1
Str *ipStr = Ip4_ToStr(m, localhost);
printf("IP: %s\n", Str_Chars(ipStr));
// Output: IP: 127.0.0.1
```

**Byte Order:** Expects host byte order (0x7F000001), not network byte order.

#### Str_ToIp4() - Parse IPv4 String

**Signature:**
```c
u32 Str_ToIp4(Str *ipStr);
```

Parses dotted-decimal IPv4 string to 32-bit integer.

**Example:**
```c
Str *ip = S(m, "192.168.1.100");
u32 addr = Str_ToIp4(ip);
// addr = 0xC0A80164
```

**Error Handling:** Returns 0 on parse failure.

#### Quad_ToIp4() - Build from Octets

**Signature:**
```c
u32 Quad_ToIp4(u8 a, u8 b, u8 c, u8 d);
```

Constructs IPv4 address from four octets.

**Example:**
```c
u32 google_dns = Quad_ToIp4(8, 8, 8, 8);
// google_dns = 0x08080808
```

**Use Case:** Programmatically constructing IP addresses.

### Network Connection

#### Sock_InetConnect() - Connect to TCP Socket

**Signature:**
```c
status Sock_InetConnect(
    MemCh *m,
    Buff *bf,
    u32 ipv4,
    i32 port,
    u32 ipv6  // Currently unused
);
```

Creates TCP connection to specified IPv4 address and port, attaching socket to Buff object.

**Example: HTTP Request**
```c
// Connect to example.com:80
u32 exampleIp = Str_ToIp4(S(m, "93.184.216.34"));
Buff *conn = Buff_Make(m, 0);

if(Sock_InetConnect(m, conn, exampleIp, 80, 0) == SUCCESS){
    // Send HTTP request
    Buff_Add(conn, S(m, "GET / HTTP/1.1\r\n"));
    Buff_Add(conn, S(m, "Host: example.com\r\n"));
    Buff_Add(conn, S(m, "\r\n"));
    Buff_Flush(conn);

    // Read response
    Str *response = Buff_GetStr(m, conn);
    printf("%s\n", Str_Chars(response));
}
```

**Key Behaviors:**
- Sets socket to blocking mode by default (use `BUFF_ASYNC` for non-blocking)
- Attaches socket to Buff with `BUFF_SOCKET` flag
- Socket closed when Buff destroyed
- Returns ERROR on connection failure

---


## Common Patterns

### Pattern 1: Build System File Discovery

**Problem:** Find all C source files, convert to object file paths.

**Solution:**
```c
// Gather all .c files
Span *sources = Dir_GatherByExt(m, IoPath(m, "src"), S(m, "c"));

// Convert to .o paths in obj/ directory
Span *objects = Span_Make(m, TYPE_STRVEC);

Iter *it = Iter_Make(m, sources);
while(Iter_Avail(it)){
    StrVec *src = Iter_Deref(it);

    // Get filename
    Str *fname = IoUtil_FnameStr(src);

    // Build object path
    StrVec *obj = IoPath(m, "obj");
    IoUtil_AddVec(obj, IoPath_FromStr(m, fname));
    IoUtil_SwapExt(obj, S(m, "o"));

    Span_Push(objects, obj);
    Iter_Next(it);
}

// Now have parallel arrays: sources[i] -> objects[i]
```

### Pattern 2: Incremental Build Check

**Problem:** Only recompile source files newer than object files.

**Solution:**
```c
typedef struct {
    StrVec *source;
    StrVec *object;
} BuildPair;

void BuildIfNeeded(MemCh *m, BuildPair *pair){
    // Check if object exists
    if(IoUtil_Exists(pair->object) == ERROR){
        CompileFile(m, pair->source, pair->object);
        return;
    }

    // Check if source is newer
    if(IoUtil_CmpUpdated(pair->source, pair->object) == SUCCESS){
        CompileFile(m, pair->source, pair->object);
    }
}
```

### Pattern 3: Safe Path Validation

**Problem:** Ensure user-provided paths stay within allowed directory (prevent directory traversal attacks).

**Solution:**
```c
status ValidateWebPath(MemCh *m, Str *requestPath, StrVec *webroot){
    // Convert to absolute path
    StrVec *abs = IoUtil_GetAbsVec(m, requestPath);

    // Check if descendant of webroot
    if(IoPath_Descendent(abs, webroot) == ERROR){
        Error(m, "Path outside webroot: $", abs);
        return ERROR;
    }

    // Additional check: no hidden files
    Iter *it = Iter_Make(m, abs);
    while(Iter_Avail(it)){
        Str *component = Iter_Deref(it);
        const char *comp = Str_Chars(component);

        if(comp[0] == '.'){
            Error(m, "Hidden files not allowed: $", abs);
            return ERROR;
        }

        Iter_Next(it);
    }

    return SUCCESS;
}
```

### Pattern 4: Process Pipeline

**Problem:** Chain multiple commands with pipes (like shell `cmd1 | cmd2 | cmd3`).

**Solution:**
```c
// Stage 1: Generate data
ProcDets pd1;
ProcDets_Init(m, &pd1);
pd1.flags = PROCDETS_PIPES;
pd1.args = Span_Make(m, TYPE_STRVEC);
Span_Push(pd1.args, Sv(m, "cat"));
Span_Push(pd1.args, Sv(m, "data.txt"));
SubCall(m, &pd1);
close(pd1.inFd);  // No input needed

// Stage 2: Process data
ProcDets pd2;
ProcDets_Init(m, &pd2);
pd2.flags = PROCDETS_PIPES;
pd2.args = Span_Make(m, TYPE_STRVEC);
Span_Push(pd2.args, Sv(m, "grep"));
Span_Push(pd2.args, Sv(m, "error"));
SubCall(m, &pd2);

// Pipe stage1 stdout to stage2 stdin
char buf[4096];
i32 n;
while((n = read(pd1.outFd, buf, sizeof(buf))) > 0){
    write(pd2.inFd, buf, n);
}
close(pd1.outFd);
close(pd2.inFd);  // Signal EOF

// Read final output
Buff *result = Buff_Make(m, 0);
Buff_SetFd(result, pd2.outFd);
Str *output = Buff_GetStr(m, result);

// Wait for both
SubStatus(m, &pd1);
SubStatus(m, &pd2);

printf("Pipeline result:\n%s", Str_Chars(output));
```

### Pattern 5: Directory Mirroring

**Problem:** Copy directory structure to different location.

**Solution:**
```c
typedef struct {
    StrVec *srcRoot;
    StrVec *dstRoot;
} MirrorCtx;

status MirrorDir(void *ctx, StrVec *srcDir){
    MirrorCtx *mc = (MirrorCtx*)ctx;

    // Calculate relative path
    i32 rootLen = StrVec_Len(mc->srcRoot);
    StrVec *rel = StrVec_Cpy(mc->m, srcDir);
    StrVec_RemoveFirst(rel, rootLen);

    // Build destination path
    StrVec *dst = StrVec_Cpy(mc->m, mc->dstRoot);
    IoUtil_AddVec(dst, rel);

    // Create directory
    Dir_Mk(mc->m, dst);

    return SUCCESS;
}

status MirrorFile(void *ctx, StrVec *srcFile){
    MirrorCtx *mc = (MirrorCtx*)ctx;

    // Calculate destination
    i32 rootLen = StrVec_Len(mc->srcRoot);
    StrVec *rel = StrVec_Cpy(mc->m, srcFile);
    StrVec_RemoveFirst(rel, rootLen);

    StrVec *dst = StrVec_Cpy(mc->m, mc->dstRoot);
    IoUtil_AddVec(dst, rel);

    // Copy file content
    Buff *src = Buff_Make(mc->m, BUFF_SLURP);
    File_Open(mc->m, src, srcFile, O_RDONLY, 0);

    Buff *dstBuf = Buff_Make(mc->m, BUFF_CLOBBER);
    File_Open(mc->m, dstBuf, dst, O_WRONLY | O_CREAT | O_TRUNC, 0);

    Buff_Pipe(src, dstBuf);
    Buff_Flush(dstBuf);

    return SUCCESS;
}

// Usage
MirrorCtx ctx = {
    .m = m,
    .srcRoot = IoPath(m, "/source"),
    .dstRoot = IoPath(m, "/backup")
};

Dir_Climb(m, ctx.srcRoot, &ctx, MirrorDir, MirrorFile);
```

---


## Performance Characteristics

### Path Operations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| `IoPath()` | O(n) | Linear scan for separators |
| `IoUtil_IsAbs()` | O(1) | Check first component |
| `IoUtil_AddVec()` | O(m) | m = components added |
| `IoUtil_GetExt()` | O(1) | Extension is last component |
| `IoUtil_SwapExt()` | O(1) | Pop + push operations |
| `IoPath_Descendent()` | O(min(n,m)) | Component-wise comparison |

**Optimization:** Path operations are very cheap due to StrVec representation. Avoid converting to C strings until necessary.

### Directory Operations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| `Dir_Exists()` | O(1) syscall | Single stat() |
| `Dir_Mk()` | O(1) syscall | Single mkdir() |
| `Dir_Gather()` | O(n) | n = directory entries |
| `Dir_Climb()` | O(n) | n = total files/dirs |
| `Dir_GatherSel()` | O(n × f) | f = filter cost |
| `Dir_Destroy()` | O(n) | n = total entries |

**Scalability:** `Dir_Climb()` suitable for <10,000 files. For larger trees, consider batching or external tools.

### Subprocess Operations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| `SubProcess()` | O(exec time) | Blocking until child exits |
| `SubCall()` | O(1) | Fork overhead only |
| `SubStatus()` | O(1) syscall | wait() or WNOHANG |
| `SubProcToBuff()` | O(output size) | Reads all output |

**Memory:** `SubProcToBuff()` stores entire output in memory. For >1MB output, use file redirection.

### Caching and Stat Calls

**Important:** Many I/O operations invoke `stat()` syscalls which are relatively expensive:

```c
// Poor: 3 stat calls
if(IoUtil_Exists(path) == SUCCESS){
    if(Dir_Exists(path) == SUCCESS){
        struct stat st;
        stat(StrVec_Chars(path), &st);  // Third stat!
    }
}

// Better: 1 stat call
struct stat st;
if(stat(StrVec_Chars(path), &st) == 0){
    if(S_ISDIR(st.st_mode)){
        // Use st directly
    }
}
```

**Buff Stat Caching:** Buff objects cache stat results:

```c
Buff *bf = Buff_Make(m, 0);
File_Open(m, bf, path, O_RDONLY, 0);

Buff_Stat(bf);  // First call: does stat()
struct stat *s1 = &bf->st;

Buff_Stat(bf);  // Subsequent calls: cached
struct stat *s2 = &bf->st;  // Same data, no syscall
```

---


## Best Practices

### 1. Always Use Absolute Paths for Storage

Relative paths become invalid if CWD changes. Convert to absolute before storing in configuration or databases.

```c
// Bad: Store relative path
StrVec *config = IoPath(m, "../config.ini");
SaveToDatabase(config);  // Breaks if CWD changes

// Good: Store absolute path
StrVec *config = IoAbsPath(m, "../config.ini");
SaveToDatabase(config);  // Always valid
```

### 2. Validate User-Provided Paths

Always check paths stay within allowed directories to prevent security vulnerabilities.

```c
status ValidatePath(StrVec *userPath, StrVec *allowedRoot){
    StrVec *abs = IoUtil_AbsVec(m, userPath);

    if(IoPath_Descendent(abs, allowedRoot) == ERROR){
        Error(m, "Invalid path: outside allowed directory");
        return ERROR;
    }

    return SUCCESS;
}
```

### 3. Close Pipe File Descriptors

Forgetting to close pipe FDs causes child processes to hang waiting for EOF.

```c
// Bad: Child hangs waiting for stdin
SubCall(m, &pd);
write(pd.inFd, data, len);
// Missing: close(pd.inFd)
SubStatus(m, &pd);  // Blocks forever

// Good: Explicit close signals EOF
SubCall(m, &pd);
write(pd.inFd, data, len);
close(pd.inFd);  // Child receives EOF
SubStatus(m, &pd);  // Completes
```

### 4. Use BUFF_CLOBBER for Safe Overwrites

Prevent accidental file truncation by requiring explicit BUFF_CLOBBER flag.

```c
// Bad: Accidentally truncates existing file
Buff *bf = Buff_Make(m, 0);
File_Open(m, bf, path, O_WRONLY | O_TRUNC, 0);  // ERROR: needs BUFF_CLOBBER

// Good: Explicit intent to overwrite
Buff *bf = Buff_Make(m, BUFF_CLOBBER);
File_Open(m, bf, path, O_WRONLY | O_TRUNC, 0);  // OK
```

### 5. Throttle Async Process Loops

Avoid busy-waiting in process monitoring loops.

```c
// Bad: 100% CPU usage
while(SubStatus(m, &pd) == SUCCESS){
    // Tight loop
}

// Good: Throttled checking
while(SubStatus(m, &pd) == SUCCESS){
    usleep(100000);  // 100ms delay
}
```

### 6. Free Large Buffers After Subprocess Output

`SubProcToBuff()` accumulates output in memory. Free promptly for long-running programs.

```c
Buff *out = Buff_Make(m, 0);
Buff *err = Buff_Make(m, 0);

SubProcToBuff(m, &pd, out, err);

// Process output immediately
ProcessOutput(out);

// Free large buffer if done with it
// (Alternatively, use temporary MemCh for subprocess scope)
```

---


## Common Pitfalls

### Pitfall 1: Forgetting to Convert Relative Paths

**Problem:** Relative paths break when CWD changes.

```c
// Setup code runs in /home/user
StrVec *logPath = IoPath(m, "logs/server.log");

// Later: daemon changes to /
chdir("/");

// Now logPath refers to /logs/server.log (wrong!)
File_Open(m, bf, logPath, O_WRONLY, 0);  // ERROR: /logs doesn't exist
```

**Solution:** Use `IoAbsPath()` or `IoUtil_AbsVec()` before CWD changes.

```c
StrVec *logPath = IoAbsPath(m, "logs/server.log");
// Now: /home/user/logs/server.log (always valid)
```

### Pitfall 2: Stat Call Accumulation

**Problem:** Redundant stat() calls in loops.

```c
// Bad: N stat calls
for(i32 i = 0; i < N; i++){
    if(IoUtil_Exists(paths[i]) == SUCCESS){  // stat()
        struct stat st;
        stat(StrVec_Chars(paths[i]), &st);   // stat() again!
        ProcessFile(paths[i], &st);
    }
}

// Good: 1 stat call per file
for(i32 i = 0; i < N; i++){
    struct stat st;
    if(stat(StrVec_Chars(paths[i]), &st) == 0){
        ProcessFile(paths[i], &st);
    }
}
```

### Pitfall 3: Directory Iteration with Modification

**Problem:** Modifying directory contents while iterating can cause undefined behavior.

```c
// Bad: Deleting files during traversal
status DeleteAllFiles(void *ctx, StrVec *path){
    File_Unlink(path);  // May corrupt directory iterator
    return SUCCESS;
}

Dir_Climb(m, rootDir, NULL, NULL, DeleteAllFiles);
```

**Solution:** Gather first, then modify.

```c
// Good: Two-phase approach
Span *files = Dir_GatherSel(m, selector);

Iter *it = Iter_Make(m, files);
while(Iter_Avail(it)){
    StrVec *path = Iter_Deref(it);
    File_Unlink(path);
    Iter_Next(it);
}
```

### Pitfall 4: Zombie Processes

**Problem:** Not calling `SubStatus()` after `SubCall()` creates zombie processes.

```c
// Bad: Zombie created
SubCall(m, &pd);
// Missing: SubStatus(m, &pd)

// Process finishes but remains in process table
```

**Solution:** Always wait for child processes.

```c
// Good: Proper cleanup
SubCall(m, &pd);

// Do other work...

SubStatus(m, &pd);  // Reaps zombie
```

For async processes, use signal handler:

```c
void sigchld_handler(int sig){
    while(waitpid(-1, NULL, WNOHANG) > 0);
}

signal(SIGCHLD, sigchld_handler);
```

### Pitfall 5: Path Separator Assumptions

**Problem:** Hardcoding `/` separators prevents future portability.

```c
// Bad: Hardcoded separator
char *path = "/usr/local/bin";

// Good: Use path functions
StrVec *path = IoPath(m, "/usr/local/bin");
const char *sep = IoUtil_PathSep();  // Future: Windows support
```

### Pitfall 6: Hidden File Filtering

**Problem:** `Dir_Climb()` silently skips hidden files (starting with `.`), which may be unexpected.

```c
// This will NOT find .gitignore, .config, etc.
Dir_Climb(m, rootDir, NULL, NULL, ProcessFile);
```

**Solution:** If hidden files needed, use manual directory iteration or `Dir_Gather()` with custom filter.

### Pitfall 7: Extension-less Files

**Problem:** Assuming all files have extensions.

```c
// Bad: Crashes on extension-less files
Str *ext = IoUtil_GetExt(path);
if(Str_Eq(ext, S_CONST("c"))){  // NULL pointer dereference if no extension
    CompileFile(path);
}

// Good: Check for NULL
Str *ext = IoUtil_GetExt(path);
if(ext != NULL && Str_Eq(ext, S_CONST("c"))){
    CompileFile(path);
}
```

---


## Related Documentation

- **[Buff I/O Complete](buff-io-complete.md)** - Complete buffer I/O guide
- **[File Operations Complete](io/file-operations-complete.md)** - File handling details
- **[Stash Complete](io/stash-complete.md)** - Memory persistence
- **[MemCh](memory/memchapter.md)** - Memory context integration
- **[Strings Complete](strings-complete.md)** - Str/StrVec foundations
- **[Error Handling Complete](error-handling-complete.md)** - Error patterns

---


## Summary

The I/O Utilities system provides comprehensive path handling, directory operations, and subprocess management with several key advantages:

**Path Handling Strengths:**
- StrVec representation eliminates buffer overflows
- Component-level manipulation (extensions, directories)
- Absolute/relative path conversion
- Path ancestry checking for security

**Directory Operations Strengths:**
- Recursive traversal with callbacks
- Advanced filtering with DirSelector
- Modification time tracking
- Safe recursive deletion

**Subprocess Management Strengths:**
- Full pipe control (stdin/stdout/stderr)
- Async and sync execution modes
- Output capture to memory or files
- Process monitoring and timeout support

**Integration Points:**
- MemCh for automatic cleanup
- Buff for unified I/O
- Str/StrVec for safe string handling
- Error for consistent error reporting

These utilities form the foundation for build systems (buildeka), web servers (www), and any application requiring robust file system and process interaction. The zero-dependency POSIX implementation ensures portability while the StrVec path representation provides safety guarantees impossible in traditional C path handling.



---

[← Part 1](io-utilities-complete-part1) | **Part 2 of 2**
