# File Operations: Complete Guide - Part 2

[← Part 1](file-operations-complete-part1) | **Part 2 of 3** | [Part 3 →](file-operations-complete-part3)

---

## Implementation Details

### File Operations API

#### Opening Files

```c
status File_Open(Buff *bf, void *_fpath, word ioFlags);
```

**Polymorphic Path Argument**: Accepts either `Str*` or `StrVec*` via type dispatch:

```c
status File_Open(Buff *bf, void *_fpath, word ioFlags){
    Abstract *fpath = (Abstract *)_fpath;

    // Type dispatch for path conversion
    Str *sp = NULL;
    if(fpath->type.of == TYPE_STR){
        sp = (Str *)fpath;
    }else if(fpath->type.of == TYPE_STRVEC){
        sp = StrVec_ToStr(bf->m, (StrVec *)fpath);
    }else{
        Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
            "File_Open requires Str or StrVec path", NULL);
        return ERROR;
    }

    char *cstr = Str_Cstr(bf->m, sp);

    // Safety check for existing files
    i32 ri = stat(cstr, &bf->st);
    if(ri != -1 && (ioFlags & O_TRUNC) && (bf->type.state & BUFF_CLOBBER) == 0){
        Abstract *args[] = {fpath, NULL};
        Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
            "File exists and Buff CLOBBER flag is unset for @", args);
        bf->type.state |= ERROR;
        return bf->type.state;
    }

    // Open with appropriate flags
    i32 fd = 0;
    if(ioFlags & O_CREAT){
        fd = open(cstr, ioFlags, 0644);  // Create with rw-r--r--
    }else{
        fd = open(cstr, ioFlags);
    }

    if(fd <= 0){
        if((bf->type.state & NOOP) == 0){
            Abstract *args[] = {fpath, Str_CstrRef(bf->m, strerror(errno)), NULL};
            Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
                "Error opening file @: $", args);
        }
        bf->type.state |= ERROR;
        return bf->type.state;
    }

    Buff_SetFd(bf, fd);

    // Handle SLURP mode
    if(bf->type.state & BUFF_SLURP){
        Buff_Read(bf);
    }

    return bf->type.state;
}
```

**Key Features**:

1. **Pre-check Protection**: Uses `stat()` before opening to prevent accidental overwrites
2. **CLOBBER Flag Required**: Must explicitly set to allow `O_TRUNC` on existing files
3. **Error Context**: Reports both filename and errno message on failure
4. **Auto-Read**: `BUFF_SLURP` flag triggers immediate read of entire file
5. **Permission Handling**: Creates files with 0644 (rw-r--r--) permissions

**Setting File Descriptor**:

```c
status Buff_SetFd(Buff *bf, i32 fd){
    bf->fd = fd;
    bf->type.state |= BUFF_FD;

    // Configure non-blocking if async
    if(bf->type.state & BUFF_ASYNC){
        if (fcntl(fd, F_SETFL, O_NONBLOCK) == -1) {
            Abstract *args[] = {Str_CstrRef(bf->m, strerror(errno)), NULL};
            Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
                "Buff setting nonblock: $", args);
            return ERROR;
        }
    }
    return SUCCESS;
}
```

#### Closing Files

```c
status File_Close(Buff *bf);
```

**Implementation**:

```c
status File_Close(Buff *bf){
    if((bf->type.state & (BUFF_FD|BUFF_SOCKET)) == 0){
        Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
            "Buff_Close called on Buff without FD or SOCKET", NULL);
        return ERROR;
    }

    // Sync data to disk if requested
    if(bf->type.state & BUFF_DATASYNC){
        if(fdatasync(bf->fd) == -1){
            Abstract *args[] = {Str_CstrRef(bf->m, strerror(errno)), NULL};
            Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
                "fdatasync failed: $", args);
        }
    }

    close(bf->fd);
    bf->type.state &= ~(BUFF_FD|BUFF_SOCKET);
    bf->fd = -1;

    return SUCCESS;
}
```

**Features**:

- **Optional Sync**: `BUFF_DATASYNC` ensures data reaches disk before close
- **Flag Cleanup**: Clears BUFF_FD/BUFF_SOCKET flags
- **Validation**: Errors if Buff not associated with file descriptor

#### File Metadata Operations

```c
boolean File_Exists(Buff *bf, Str *path);
boolean File_PathExists(MemCh *m, Str *path);
status File_Stat(MemCh *m, Str *path, struct stat *st);
void File_ModTime(MemCh *m, Str *path, struct timespec *tm);
```

**File Existence Check**:

```c
boolean File_Exists(Buff *bf, Str *path){
    char *path_cstr = Str_Cstr(bf->m, path);
    struct stat st;
    if(stat(path_cstr, &st)){
        bf->type.state |= NOOP;
        return FALSE;
    }
    return TRUE;
}

boolean File_PathExists(MemCh *m, Str *path){
    struct stat st;
    return (stat(Str_Cstr(m, path), &st) == 0);
}
```

**File Statistics**:

```c
status File_Stat(MemCh *m, Str *path, struct stat *st){
    if(stat(Str_Cstr(m, path), st) == 0){
        return SUCCESS;
    }
    return ERROR;
}
```

**Modification Time**:

```c
void File_ModTime(MemCh *m, Str *path, struct timespec *ts){
    struct stat st;
    if(stat(Str_Cstr(m, path), &st) == 0){
        ts->tv_sec = st.st_mtime;
        ts->tv_nsec = 0;
    }
}
```

#### File Modification Operations

```c
status File_Unlink(MemCh *m, Str *path);
status File_Rename(MemCh *m, Str *to, Str *from);
```

**Delete File**:

```c
status File_Unlink(MemCh *m, Str *path){
    return unlink(Str_Cstr(m, path)) == 0 ? SUCCESS : ERROR;
}
```

**Rename/Move File**:

```c
status File_Rename(MemCh *m, Str *to, Str *from){
    return rename(Str_Cstr(m, to), Str_Cstr(m, from)) == 0 ? SUCCESS : ERROR;
}
```

#### High-Level File Reading

```c
StrVec *File_ToVec(MemCh *m, Str *path);
```

**Complete "Slurp" Implementation**:

```c
StrVec *File_ToVec(MemCh *m, Str *path){
    Buff *bf = Buff_Make(m, BUFF_SLURP);

    if(!File_Exists(bf, path)){
        return NULL;
    }

    File_Open(bf, path, O_RDONLY);
    Buff_Read(bf);
    File_Close(bf);

    return bf->v;  // Return StrVec with file contents
}
```

**Use Case**: Reading entire file into memory with single function call. The StrVec can be iterated as a sequence of strings (lines or blocks).

### Buff I/O Operations

#### Buff Creation

```c
Buff *Buff_Make(MemCh *m, word flags);
Buff *Buff_From(MemCh *m, StrVec *v);
```

**Make (New Buffer)**:

```c
Buff *Buff_Make(MemCh *m, word flags){
    Buff *bf = Buff_From(m, StrVec_Make(m));
    bf->type.state = flags;
    return bf;
}
```

**From (Existing StrVec)**:

```c
Buff *Buff_From(MemCh *m, StrVec *v){
    Buff *bf = (Buff *)MemCh_AllocOf(m, sizeof(Buff), TYPE_BUFF);
    bf->type.of = TYPE_BUFF;
    bf->m = m;
    bf->fd = -1;
    bf->v = v;
    bf->tail.idx = -1;
    bf->unsent.idx = 0;
    bf->unsent.s = Span_Get(v->p, bf->unsent.idx);
    bf->unsent.total = v->total;
    return bf;
}
```

**Key Initialization**:

- **fd = -1**: Indicates no file descriptor attached (memory-only mode)
- **tail.idx = -1**: No tail allocated yet
- **unsent tracking**: Points to first Str in StrVec for reading

#### Write Operations

```c
status Buff_AddBytes(Buff *bf, byte *bytes, i64 length);
status Buff_Add(Buff *bf, Str *s);
status Buff_AddVec(Buff *bf, StrVec *v);
```

**Add Bytes Implementation**:

```c
status Buff_AddBytes(Buff *bf, byte *bytes, i64 length){
    status r = SUCCESS;
    i16 guard = 0;

    if(length == 0){
        return NOOP;
    }

    // Initialize tail if needed
    if(bf->tail.idx == -1){
        Buff_addTail(bf);
    }

    // Add bytes to tail, creating new tails as needed
    while(length > 0){
        Guard_Incr(bf->m, &guard, BUFF_CYCLE_MAX, FUNCNAME, FILENAME, LINENUMBER);

        word remaining = bf->tail.s->alloc - bf->tail.s->length;

        if(remaining == 0){
            Buff_addTail(bf);  // Current tail full, create new
        }else if(length <= remaining){
            // Fits in current tail
            Str_Add(bf->tail.s, bytes, length);
            bf->unsent.total += length;
            bf->v->total += length;
            length = 0;
        }else{
            // Partial fill
            Str_Add(bf->tail.s, bytes, remaining);
            bf->unsent.total += remaining;
            bf->v->total += remaining;
            bytes += remaining;
            length -= remaining;
            Buff_addTail(bf);  // Create new tail for overflow
        }
    }

    return r;
}
```

**Internal: Add Tail**:

```c
static status Buff_addTail(Buff *bf){
    if(bf->tail.idx == -1){
        bf->tail.idx = 0;
        bf->tail.s = Span_Get(bf->v->p, bf->tail.idx);
        if(bf->tail.s == NULL){
            bf->tail.s = Str_Make(bf->m, STR_DEFAULT);
            Span_Add(bf->v->p, bf->tail.s);
        }
    }else{
        bf->tail.idx++;
        bf->tail.s = Str_Make(bf->m, STR_DEFAULT);
        Span_Add(bf->v->p, bf->tail.s);
    }
    return SUCCESS;
}
```

**Key Algorithm**:

1. **Lazy Tail Creation**: Only allocates tail when first byte added
2. **Fill Strategy**: Fills current tail to capacity before creating new
3. **Total Tracking**: Updates both `unsent.total` and `v->total`
4. **Guard Protection**: Prevents infinite loops with `BUFF_CYCLE_MAX` limit

#### Flush/Send Operations

```c
status Buff_Flush(Buff *bf);
```

**Flush to File Descriptor**:

```c
status Buff_Flush(Buff *bf){
    if(bf->type.state & (BUFF_SOCKET|BUFF_FD)){
        while((Buff_sendToFd(bf, bf->fd) & (SUCCESS|ERROR|NOOP|END)) == 0){
            // Keep sending until complete or error
        }
    }
    return bf->type.state;
}
```

**Internal: Send to FD**:

```c
static status Buff_sendToFd(Buff *bf, i32 fd){
    if(bf->unsent.total == 0){
        return SUCCESS;
    }

    if(bf->unsent.s == NULL){
        return END;
    }

    // Send current unsent string
    i64 offset = bf->unsent.offset;
    status r = Buff_bytesToFd(bf, fd, bf->unsent.s->bytes + offset,
                               bf->unsent.s->length - offset, &offset);

    if(r & SUCCESS){
        // Entire string sent, move to next
        bf->unsent.idx++;
        bf->unsent.offset = 0;
        bf->unsent.s = Span_Get(bf->v->p, bf->unsent.idx);
    }else if(r & MORE){
        // Partial send
        bf->unsent.offset = offset;
    }

    return r;
}
```

**Internal: Bytes to FD**:

```c
static status Buff_bytesToFd(Buff *bf, i32 fd, byte *bytes, i64 length, i64 *offset){
    ssize_t sent = 0;

    if(bf->type.state & BUFF_SOCKET){
        sent = send(fd, bytes, min(length, IO_BLOCK_SIZE), 0);
    }else{
        sent = write(fd, bytes, min(length, IO_BLOCK_SIZE));
    }

    if(sent == -1){
        if(errno == EAGAIN || errno == EWOULDBLOCK){
            return MORE;  // Non-blocking would block
        }
        Abstract *args[] = {Str_CstrRef(bf->m, strerror(errno)), NULL};
        Error(bf->m, FUNCNAME, FILENAME, LINENUMBER, "Send failed: $", args);
        bf->type.state |= ERROR;
        return ERROR;
    }else if(sent == 0){
        bf->type.state |= END;
        return END;
    }else{
        *offset += sent;
        bf->unsent.total -= sent;

        if(sent < length){
            return MORE;  // Partial send
        }
        return SUCCESS;  // Complete send
    }
}
```

**Key Features**:

- **Block Size Limit**: Sends max `IO_BLOCK_SIZE` (4096) bytes per call
- **Partial Send Handling**: Tracks offset for incomplete sends
- **Non-blocking Support**: Returns `MORE` for EAGAIN/EWOULDBLOCK
- **Type Dispatch**: Uses `send()` for sockets, `write()` for files

#### Read Operations

```c
status Buff_Read(Buff *bf);
status Buff_ReadAmount(Buff *bf, i64 amount);
status Buff_ReadToStr(Buff *bf, Str *s);
status Buff_GetStr(Buff *bf, Str *s);
```

**Read All Available**:

```c
status Buff_Read(Buff *bf){
    return Buff_ReadAmount(bf, IO_SEND_MAX);
}
```

**Read Specific Amount**:

```c
status Buff_ReadAmount(Buff *bf, i64 amount){
    if((bf->type.state & (BUFF_FD|BUFF_SOCKET)) == 0){
        return NOOP;
    }

    i16 guard = 0;
    status r = SUCCESS;

    while(amount > 0){
        Guard_Incr(bf->m, &guard, BUFF_CYCLE_MAX, FUNCNAME, FILENAME, LINENUMBER);

        ssize_t received = 0;
        Str *s = Str_Make(bf->m, min(amount, IO_BLOCK_SIZE));

        if(bf->type.state & BUFF_SOCKET){
            received = recv(bf->fd, s->bytes, s->alloc, 0);
        }else if(bf->type.state & BUFF_FD){
            received = read(bf->fd, s->bytes, s->alloc);
        }

        if(received == -1){
            if(errno == EAGAIN || errno == EWOULDBLOCK){
                r |= MORE;
                break;
            }
            Abstract *args[] = {Str_CstrRef(bf->m, strerror(errno)), NULL};
            Error(bf->m, FUNCNAME, FILENAME, LINENUMBER, "Read failed: $", args);
            bf->type.state |= ERROR;
            return ERROR;
        }else if(received == 0){
            bf->type.state |= END;
            break;
        }else{
            s->length = received;
            Span_Add(bf->v->p, s);
            bf->v->total += received;
            amount -= received;

            if(received < IO_BLOCK_SIZE){
                // Partial read indicates EOF or no more data
                break;
            }
        }
    }

    return r | bf->type.state;
}
```

**Key Features**:

- **Chunked Reading**: Allocates new Str for each `IO_BLOCK_SIZE` chunk
- **StrVec Accumulation**: Appends each chunk to Buff's StrVec
- **Non-blocking**: Returns `MORE` for EAGAIN/EWOULDBLOCK
- **EOF Detection**: Sets `END` flag when read returns 0

#### Seeking Operations

```c
status Buff_PosAbs(Buff *bf, i64 position);
status Buff_Pos(Buff *bf, i64 position);
status Buff_PosEnd(Buff *bf);
```

**Absolute Seek**:

```c
status Buff_PosAbs(Buff *bf, i64 position){
    return Buff_posFrom(bf, position, SEEK_SET);
}
```

**Relative Seek**:

```c
status Buff_Pos(Buff *bf, i64 position){
    return Buff_posFrom(bf, position, SEEK_CUR);
}
```

**Seek to End**:

```c
status Buff_PosEnd(Buff *bf){
    return Buff_posFrom(bf, 0, SEEK_END);
}
```

**Internal: Position From**:

```c
static status Buff_posFrom(Buff *bf, i64 offset, i64 whence){
    bf->type.state &= ~PROCESSING;

    if((bf->type.state & (BUFF_FD|BUFF_SOCKET)) == 0){
        return Buff_vecPosFrom(bf, offset, whence);  // Memory-only seeking
    }

    i64 pos = lseek(bf->fd, offset, whence);

    if(pos < 0){
        Buff_Stat(bf);
        bf->type.state |= (ERROR|END);
        return bf->type.state;
    }else if(pos > 0){
        bf->type.state |= PROCESSING;
    }

    return bf->type.state;
}
```

**Memory-Only Seeking** (when no fd):

```c
static status Buff_vecPosFrom(Buff *bf, i64 offset, i64 whence){
    if(whence == SEEK_SET){
        bf->unsent.offset = offset;
    }else if(whence == SEEK_CUR){
        bf->unsent.offset += offset;
    }else if(whence == SEEK_END){
        bf->unsent.offset = bf->v->total + offset;
    }

    // Adjust unsent.idx and offset to correct Str
    i64 accum = 0;
    Iter it;
    Iter_Init(&it, bf->v->p);

    while((Iter_Next(&it) & END) == 0){
        Str *s = (Str *)Iter_Get(&it);
        if(accum + s->length >= bf->unsent.offset){
            bf->unsent.idx = it.idx;
            bf->unsent.offset = bf->unsent.offset - accum;
            bf->unsent.s = s;
            break;
        }
        accum += s->length;
    }

    return SUCCESS;
}
```

#### Buffer Statistics

```c
status Buff_Stat(Buff *bf);
boolean Buff_IsEmpty(Buff *bf);
```

**File Statistics**:

```c
status Buff_Stat(Buff *bf){
    memset(&bf->st, 0, sizeof(struct stat));

    if(bf->type.state & (BUFF_FD|BUFF_SOCKET)){
        if(fstat(bf->fd, &bf->st)){
            bf->type.state |= ERROR;
        }else if(lseek(bf->fd, 0, SEEK_CUR) == bf->st.st_size){
            bf->type.state |= END;  // At EOF
        }
    }else{
        bf->st.st_size = bf->v->total;  // Memory-only size
    }

    return bf->type.state;
}
```

**Empty Check**:

```c
boolean Buff_IsEmpty(Buff *bf){
    return (bf->v->total == 0);
}
```

#### Data Piping

```c
status Buff_Pipe(Buff *to, Buff *from);
```

**Pipe Between Buffers**:

```c
status Buff_Pipe(Buff *to, Buff *from){
    Iter it;
    Iter_Init(&it, from->v->p);

    while((Iter_Next(&it) & END) == 0){
        Str *s = (Str *)Iter_Get(&it);
        Buff_Add(to, s);
    }

    if(to->type.state & BUFF_FLUSH){
        Buff_Flush(to);
    }

    return to->type.state;
}
```

**Use Case**: Copying data from one buffer to another, potentially across different destinations (memory → file, file → socket, etc.).

### Directory Operations

#### Directory Traversal

```c
status Dir_Climb(MemCh *m, Str *path, DirFunc dir, FileFunc file, void *source);
```

**Function Pointer Types**:

```c
typedef status (*DirFunc)(MemCh *m, StrVec *path, void *source);
typedef status (*FileFunc)(MemCh *m, StrVec *dir, Str *file, void *source);
```

**Recursive Directory Traversal**:

```c
status Dir_Climb(MemCh *m, Str *path, DirFunc dir, FileFunc file, void *source){
    struct dirent *ent;
    DIR *d = opendir((char *)path->bytes);

    if(d == NULL){
        Abstract *args[] = {path, Str_CstrRef(m, strerror(errno)), NULL};
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
            "Failed to open directory @: $", args);
        return ERROR;
    }

    status r = SUCCESS;

    while((ent = readdir(d)) != NULL){
        // Skip . and ..
        if(ent->d_name[0] == '.' &&
           (ent->d_name[1] == '\0' ||
            (ent->d_name[1] == '.' && ent->d_name[2] == '\0'))){
            continue;
        }

        i64 len = strlen(ent->d_name);
        Str *e = Str_Ref(m, (byte *)ent->d_name, len, len+1, STRING_COPY);

        StrVec *v = StrVec_Clone(m, (StrVec *)path);
        StrVec_Add(v, e);
        Str *s = StrVec_ToStr(m, v);

        if(ent->d_type == DT_DIR){
            // Directory callback
            if(dir != NULL){
                r |= dir(m, v, source);
                if((r & NOOP) == 0){
                    // Recurse if callback didn't return NOOP
                    r |= Dir_Climb(m, s, dir, file, source);
                }
            }
        }else{
            // File callback
            if(file != NULL){
                r |= file(m, (StrVec *)path, e, source);
            }
        }
    }

    closedir(d);
    return r;
}
```

**Callback Pattern**:

- **dir callback**: Invoked for each directory, return NOOP to skip recursion
- **file callback**: Invoked for each file
- **source pointer**: Arbitrary data passed through to callbacks

#### Directory Management

```c
status Dir_Exists(MemCh *m, Str *path);
status Dir_Mk(MemCh *m, Str *path);
status Dir_CheckCreate(MemCh *m, Str *path);
status Dir_Destroy(MemCh *m, Str *path);
```

**Check Existence**:

```c
status Dir_Exists(MemCh *m, Str *path){
    char *path_cstr = Str_Cstr(m, path);
    DIR* dir = opendir(path_cstr);

    if(dir){
        closedir(dir);
        return SUCCESS;
    }else if(ENOENT == errno){
        return NOOP;  // Doesn't exist
    }
    return ERROR;  // Other error
}
```

**Create Directory**:

```c
status Dir_Mk(MemCh *m, Str *path){
    if(mkdir(Str_Cstr(m, path), 0766) == 0){
        return SUCCESS;
    }else{
        return ERROR;
    }
}
```

**Create If Not Exists**:

```c
status Dir_CheckCreate(MemCh *m, Str *path){
    status s = Dir_Exists(m, path);
    if(s == NOOP){
        return Dir_Mk(m, path);
    }
    return s;
}
```

**Recursive Delete**:

```c
status Dir_Destroy(MemCh *m, Str *path){
    // Uses Dir_Climb with delete callbacks, then rmdir on parent
    Dir_Climb(m, path, Dir_destroyDir, File_destroyFile, NULL);
    return (rmdir(Str_Cstr(m, path)) == 0) ? SUCCESS : ERROR;
}

static status Dir_destroyDir(MemCh *m, StrVec *path, void *source){
    Str *s = StrVec_ToStr(m, path);
    return (rmdir(Str_Cstr(m, s)) == 0) ? SUCCESS : ERROR;
}

static status File_destroyFile(MemCh *m, StrVec *dir, Str *file, void *source){
    StrVec *v = StrVec_Clone(m, dir);
    StrVec_Add(v, file);
    Str *path = StrVec_ToStr(m, v);
    return File_Unlink(m, path);
}
```

#### Directory Gathering

```c
status Dir_Gather(MemCh *m, Str *path, Span *sp);
status Dir_GatherSel(MemCh *m, Str *path, DirSelector *sel);
DirSelector *Dir_GatherByExt(MemCh *m, Str *path, Span *sp, Span *exts);
```

**Simple Gather**:

```c
status Dir_Gather(MemCh *m, Str *path, Span *sp){
    DirSelector *sel = DirSelector_Make(m, NULL, sp, ZERO);
    return Dir_GatherSel(m, path, sel);
}
```

**Gather by Extension**:

```c
DirSelector *Dir_GatherByExt(MemCh *m, Str *path, Span *sp, Span *exts){
    DirSelector *sel = DirSelector_Make(m, NULL, sp, ZERO);
    sel->meta = exts;  // Extensions stored in meta
    Dir_GatherSel(m, path, sel);
    return sel;
}
```

**Selector-Based Gather**:

```c
status Dir_GatherSel(MemCh *m, Str *path, DirSelector *sel){
    return Dir_Climb(m, path, DirSel_dirFunc, DirSel_fileFunc, sel);
}

static status DirSel_fileFunc(MemCh *m, StrVec *dir, Str *file, void *source){
    DirSelector *sel = (DirSelector *)source;

    // Extension filtering
    if(sel->meta != NULL){
        StrVec *ext = IoUtil_GetExt(m, (StrVec *)file);
        Str *extStr = StrVec_ToStr(m, ext);

        boolean found = FALSE;
        Iter it;
        Iter_Init(&it, sel->meta);
        while((Iter_Next(&it) & END) == 0){
            Str *allowed = (Str *)Iter_Get(&it);
            if(Str_Cmp(extStr, allowed) == 0){
                found = TRUE;
                break;
            }
        }

        if(!found){
            return NOOP;  // Skip file
        }
    }

    // Custom filter function
    if((sel->type.state & DIR_SELECTOR_FILTER) && sel->func != NULL){
        boolean include = sel->func(m, dir, file, sel->source);
        if(sel->type.state & DIR_SELECTOR_INVERT){
            include = !include;
        }
        if(!include){
            return NOOP;
        }
    }

    // Add to results
    StrVec *v = StrVec_Clone(m, dir);
    StrVec_Add(v, file);
    Span_Add(sel->dest, v);

    // Track modification time if requested
    if(sel->type.state & (DIR_SELECTOR_MTIME_ALL|DIR_SELECTOR_MTIME_LOWEST)){
        struct timespec ts;
        File_ModTime(m, StrVec_ToStr(m, v), &ts);
        // ... accumulate or compare times ...
    }

    return SUCCESS;
}
```

### Path Handling

#### Path Parsing

```c
StrVec *IoPath(MemCh *m, char *cstr);
StrVec *IoPath_From(MemCh *m, Str *s);
StrVec *IoPath_FromStr(MemCh *m, Str *s);
StrVec *IoPath_FromVec(MemCh *m, StrVec *v);
```

**Parse C String to Path**:

```c
StrVec *IoPath(MemCh *m, char *cstr){
    return IoPath_FromStr(m, Str_CstrRef(m, cstr));
}
```

**Parse Str to Path**:

```c
StrVec *IoPath_FromStr(MemCh *m, Str *s){
    StrVec *v = StrVec_Make(m);
    Cursor *c = Cursor_Make(m, s);

    // Split on '/'
    while(Cursor_HasMore(c)){
        Str *component = Cursor_NextUntil(c, '/');
        if(component->length > 0){
            StrVec_Add(v, component);
        }
    }

    v->type.state |= STRVEC_PATH;
    return v;
}
```

#### Absolute Path Resolution

```c
Str *IoUtil_GetAbsPath(MemCh *m, Str *path);
Str *IoUtil_GetCwdPath(MemCh *m, Str *path);
StrVec *IoUtil_AbsVec(MemCh *m, StrVec *v);
StrVec *IoAbsPath(MemCh *m, char *cstr);
```

**Get Absolute Path**:

```c
Str *IoUtil_GetAbsPath(MemCh *m, Str *path){
    if(path != NULL && path->bytes[0] != '/'){
        // Relative path - prepend cwd
        if(path->length >= 2 && path->bytes[0] == '.' && path->bytes[1] == '/'){
            Str_Incr(path, 2);  // Skip ./
        }
        return IoUtil_GetCwdPath(m, path);
    }

    // Already absolute
    if(path->alloc != STR_DEFAULT){
        return Str_CloneAlloc(m, path, STR_DEFAULT);
    }
    return path;
}
```

**Get Current Working Directory Path**:

```c
Str *IoUtil_GetCwdPath(MemCh *m, Str *path){
    Str *s = Str_Make(m, STR_DEFAULT);
    char *cstr = getcwd((char *)s->bytes, STR_DEFAULT_MAX);

    if(cstr == NULL){
        Abstract *args[] = {Str_CstrRef(m, strerror(errno)), NULL};
        Error(m, FUNCNAME, FILENAME, LINENUMBER, "getcwd failed: $", args);
        s->type.state |= ERROR;
        return NULL;
    }

    i64 len = strlen(cstr);
    s->length = len;

    Str_AddCstr(s, "/");

    if(path != NULL){
        Str_Add(s, path->bytes, path->length);
        if((s->type.state & ERROR) == 0){
            return s;
        }else{
            return NULL;
        }
    }

    return s;
}
```

#### Path Component Operations

```c
status IoUtil_SwapExt(MemCh *m, StrVec *path, Str *ext);
status IoUtil_AddExt(MemCh *m, StrVec *path, Str *ext);
StrVec *IoUtil_GetExt(MemCh *m, StrVec *path);
StrVec *IoUtil_BasePath(MemCh *m, StrVec *path);
```

**Swap Extension**:

```c
status IoUtil_SwapExt(MemCh *m, StrVec *path, Str *ext){
    // Find last component (filename)
    Str *last = Span_GetLast(path->p);

    // Find extension separator
    i64 dotIdx = Str_LastIndexOf(last, '.');
    if(dotIdx >= 0){
        // Truncate at dot
        last->length = dotIdx;
    }

    // Add new extension
    Str_AddCstr(last, ".");
    Str_Add(last, ext->bytes, ext->length);

    return SUCCESS;
}
```

**Get Extension**:

```c
StrVec *IoUtil_GetExt(MemCh *m, StrVec *path){
    Str *last = Span_GetLast(path->p);
    i64 dotIdx = Str_LastIndexOf(last, '.');

    if(dotIdx >= 0){
        StrVec *v = StrVec_Make(m);
        Str *ext = Str_Slice(m, last, dotIdx + 1, last->length);
        StrVec_Add(v, ext);
        return v;
    }

    return NULL;  // No extension
}
```

**Get Base Path** (directory without filename):

```c
StrVec *IoUtil_BasePath(MemCh *m, StrVec *path){
    StrVec *v = StrVec_Clone(m, path);

    if(v->p->max_idx >= 0){
        Span_RemoveLast(v->p);  // Remove last component (filename)
    }

    return v;
}
```

#### Path Comparison

```c
boolean IoUtil_IsAbs(StrVec *v);
boolean IoUtil_IsStrAbs(Str *s);
status IoPath_Descendent(StrVec *orig, StrVec *compare);
boolean IoUtil_CmpUpdated(MemCh *m, Str *a, Str *b);
```

**Is Absolute Path**:

```c
boolean IoUtil_IsAbs(StrVec *v){
    Str *first = Span_Get(v->p, 0);
    return (first != NULL && first->bytes[0] == '/');
}

boolean IoUtil_IsStrAbs(Str *s){
    return (s != NULL && s->length > 0 && s->bytes[0] == '/');
}
```

**Is Descendent Path**:

```c
status IoPath_Descendent(StrVec *orig, StrVec *compare){
    if(compare->p->max_idx < orig->p->max_idx){
        return NOOP;  // compare is shorter, can't be descendent
    }

    // Check if all components of orig match compare's prefix
    Iter it1, it2;
    Iter_Init(&it1, orig->p);
    Iter_Init(&it2, compare->p);

    while((Iter_Next(&it1) & END) == 0){
        if((Iter_Next(&it2) & END)){
            return NOOP;
        }

        Str *s1 = (Str *)Iter_Get(&it1);
        Str *s2 = (Str *)Iter_Get(&it2);

        if(Str_Cmp(s1, s2) != 0){
            return NOOP;  // Component mismatch
        }
    }

    return SUCCESS;  // All components match
}
```

**Compare Modification Times**:

```c
boolean IoUtil_CmpUpdated(MemCh *m, Str *a, Str *b){
    struct stat source_stat;
    struct stat build_stat;

    char *path_cstr = Str_Cstr(m, a);
    if(stat(path_cstr, &source_stat) != 0){
        return FALSE;  // Source doesn't exist
    }

    if(stat(Str_Cstr(m, b), &build_stat) != 0){
        return TRUE;  // Target doesn't exist, source is "newer"
    }

    return source_stat.st_mtime > build_stat.st_mtime;
}
```

### Subprocess Management

#### Subprocess Execution

```c
status SubCall(MemCh *m, Span *cmd_p, ProcDets *pd);
status SubStatus(ProcDets *pd);
```

**Execute Command with Pipes**:

```c
status SubCall(MemCh *m, Span *cmd_p, ProcDets *pd){
    // Build argv array
    char **cmd = (char **)MemCh_Alloc(m, sizeof(char *) * (cmd_p->max_idx + 2));
    Iter it;
    Iter_Init(&it, cmd_p);
    i32 idx = 0;
    while((Iter_Next(&it) & END) == 0){
        Str *s = (Str *)Iter_Get(&it);
        cmd[idx++] = Str_Cstr(m, s);
    }
    cmd[idx] = NULL;  // NULL-terminate for execvp

    // Create pipes
    i32 p0[2], p1[2], p2[2];
    if(pd->type.state & (PROCDETS_PIPES|PROCDETS_IN_PIPE)){
        if(pipe(p0) != 0 || pipe(p1) != 0 || pipe(p2) != 0){
            Abstract *args[] = {Str_CstrRef(m, strerror(errno)), NULL};
            Error(m, FUNCNAME, FILENAME, LINENUMBER, "pipe() failed: $", args);
            return ERROR;
        }

        // Set non-blocking
        if(fcntl(p0[0], F_SETFL, O_NONBLOCK) == -1 ||
           fcntl(p0[1], F_SETFL, O_NONBLOCK) == -1 ||
           fcntl(p1[0], F_SETFL, O_NONBLOCK) == -1 ||
           fcntl(p1[1], F_SETFL, O_NONBLOCK) == -1 ||
           fcntl(p2[0], F_SETFL, O_NONBLOCK) == -1 ||
           fcntl(p2[1], F_SETFL, O_NONBLOCK) == -1){
            Abstract *args[] = {Str_CstrRef(m, strerror(errno)), NULL};
            Error(m, FUNCNAME, FILENAME, LINENUMBER, "fcntl() failed: $", args);
            return ERROR;
        }
    }

    // Fork child process
    pid_t child = vfork();

    if(child == 0){
        // Child process
        if(pd->type.state & (PROCDETS_PIPES|PROCDETS_IN_PIPE)){
            close(0); close(1); close(2);
            dup2(p0[0], 0);  // stdin from parent
            dup2(p1[1], 1);  // stdout to parent
            dup2(p2[1], 2);  // stderr to parent
            close(p0[1]); close(p1[0]); close(p2[0]);
        }

        execvp(cmd[0], cmd);

        // If execvp returns, it failed
        exit(1);
    }else if(child > 0){
        // Parent process
        pd->pid = child;

        if(pd->type.state & (PROCDETS_PIPES|PROCDETS_IN_PIPE)){
            close(p0[0]); close(p1[1]); close(p2[1]);
            pd->inFd = p0[1];   // Write to child stdin
            pd->outFd = p1[0];  // Read from child stdout
            pd->errFd = p2[0];  // Read from child stderr
        }

        if((pd->type.state & PROCDETS_ASYNC) == 0){
            SubStatus(pd);  // Wait for completion
        }

        return SUCCESS;
    }else{
        // Fork failed
        Abstract *args[] = {Str_CstrRef(m, strerror(errno)), NULL};
        Error(m, FUNCNAME, FILENAME, LINENUMBER, "vfork() failed: $", args);
        return ERROR;
    }
}
```

**Wait for Subprocess**:

```c
status SubStatus(ProcDets *pd){
    i32 status = 0;
    pid_t result = waitpid(pd->pid, &status, 0);

    if(result == -1){
        return ERROR;
    }

    if(WIFEXITED(status)){
        pd->code = WEXITSTATUS(status);
        return (pd->code == 0) ? SUCCESS : ERROR;
    }

    return ERROR;
}
```



---

[← Part 1](file-operations-complete-part1) | **Part 2 of 3** | [Part 3 →](file-operations-complete-part3)
