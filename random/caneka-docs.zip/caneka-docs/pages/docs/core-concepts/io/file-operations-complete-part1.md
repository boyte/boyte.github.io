# File Operations: Complete Guide - Part 1

**Part 1 of 3** | [Part 2 →](file-operations-complete-part2)

---

## Core Philosophy

Caneka's file I/O system embodies the "glass-bottom-boat" philosophy by providing thin, transparent wrappers around POSIX system calls while integrating seamlessly with the MemCh memory management and type systems. Unlike traditional C file I/O that scatters responsibility across many disparate functions, Caneka centralizes file operations around the **Buff abstraction** - a unified interface for both files and sockets that provides buffering, seeking, and lifecycle management.

### Design Principles

1. **Unified Abstraction**: The `Buff` object abstracts both files and sockets with a consistent API
2. **Memory Integration**: All file operations allocate through MemCh contexts for automatic cleanup
3. **Type Safety**: File handles are wrapped in typed structures tracked by the type system
4. **POSIX Foundation**: Direct mapping to standard POSIX calls - no hidden magic
5. **Zero-Copy Composition**: StrVec-backed buffering enables efficient memory usage
6. **Explicit Control**: Flags-based configuration for buffering, sync, and async behavior

### Key Insight: Buff as Universal I/O Handle

Traditional C requires separate handling for files, sockets, pipes, and in-memory buffers:

```c
// Traditional C - fragmented approach
FILE *f = fopen("file.txt", "r");
int fd = open("file.txt", O_RDONLY);
int sock = socket(AF_INET, SOCK_STREAM, 0);
char buffer[4096];
```

Caneka unifies all I/O through Buff:

```c
// Caneka - unified approach
Buff *bf = Buff_Make(m, ZERO);

// Can handle file, socket, or pure memory operations
File_Open(bf, path, O_RDONLY);     // File
Buff_SetSocket(bf, sockfd);        // Socket
Buff_Add(bf, str);                 // Memory buffer
```

This enables code to be written generically - a function that writes to a Buff doesn't care if it's a file, socket, or memory buffer. The StrVec-backed buffering system provides zero-copy composition and efficient memory reuse.


## Structure and Key Definitions

### Buff Structure

The Buff object is the central abstraction for all file I/O:

```c
typedef struct buff {
    Type type;              // Type system metadata with flags
    i32 fd;                 // File descriptor (-1 if not set)
    MemCh *m;               // Memory context for allocations
    StrVec *v;              // Vector of strings (buffer storage)

    struct {
        Str *s;             // Current tail string being written
        i32 idx;            // Index in vector
    } tail;

    struct {
        Str *s;             // Current string being sent/read
        i32 _;              // Reserved
        word offset;        // Offset within current string
        i32 idx;            // Index in vector
        i64 total;          // Total unsent bytes
    } unsent;

    struct stat st;         // File statistics (from fstat)
} Buff;
```

**Key Fields**:

- **type**: Contains both type metadata (`TYPE_BUFF`) and operational flags
- **fd**: POSIX file descriptor, or -1 if operating in pure memory mode
- **m**: Memory context - all allocations go through this MemCh
- **v**: StrVec holding buffered data as a sequence of Str objects
- **tail**: Tracks current write position when adding data to buffer
- **unsent**: Tracks current read/send position when consuming from buffer
- **st**: File metadata populated by `fstat()` system call

### Buff I/O Flags

```c
enum send_recv_flags {
    BUFF_ASYNC = 1 << 8,        // Non-blocking I/O (fcntl O_NONBLOCK)
    BUFF_FD = 1 << 9,           // Regular file descriptor active
    BUFF_SOCKET = 1 << 10,      // Socket descriptor active
    BUFF_DATASYNC = 1 << 11,    // Sync data to disk on close (fdatasync)
    BUFF_FLUSH = 1 << 12,       // Auto-flush after each send
    BUFF_UNBUFFERED = 1 << 13,  // Direct write to fd (bypass StrVec)
    BUFF_SLURP = 1 << 14,       // Read entire file in one operation
    BUFF_CLOBBER = 1 << 15,     // Allow overwriting existing files
};
```

**Flag Semantics**:

- **BUFF_ASYNC**: Sets `O_NONBLOCK` via `fcntl()`, enabling non-blocking reads/writes
- **BUFF_FD**: Indicates fd is a regular file (uses `read()`/`write()`)
- **BUFF_SOCKET**: Indicates fd is a socket (uses `recv()`/`send()`)
- **BUFF_DATASYNC**: Calls `fdatasync()` before closing to ensure data hits disk
- **BUFF_FLUSH**: Automatically flushes buffer after each `Buff_Add()` operation
- **BUFF_UNBUFFERED**: Writes bypass StrVec and go directly to fd
- **BUFF_SLURP**: `File_Open()` reads entire file immediately
- **BUFF_CLOBBER**: Allows `File_Open()` with `O_TRUNC` on existing files

### DirSelector Structure

Used for advanced directory traversal with filtering:

```c
typedef struct dir_selector {
    Type type;
    Str *ext;                    // Extension filter (e.g., "c" for .c files)
    Span *dest;                  // Destination Span for results
    Span *meta;                  // Metadata table (modification times)
    struct timespec time;        // Accumulated modification time
    SourceFunc func;             // Custom filter function
    void *source;                // Source data for filter function
} DirSelector;
```

**DirSelector Flags**:

```c
enum dir_selector_flags {
    DIR_SELECTOR_MTIME_ALL = 1 << 8,      // Track all modification times
    DIR_SELECTOR_MTIME_LOWEST = 1 << 9,   // Track lowest mtime
    DIR_SELECTOR_NODIRS = 1 << 10,        // Exclude directories from results
    DIR_SELECTOR_FILTER = 1 << 11,        // Use custom filter function
    DIR_SELECTOR_FILTER_DIRS = 1 << 12,   // Apply filter to directories
    DIR_SELECTOR_INVERT = 1 << 13,        // Invert filter logic
};
```

### ProcDets Structure

For subprocess management with pipes:

```c
typedef struct procdets {
    Type type;
    pid_t pid;          // Child process ID
    i32 inFd;           // Stdin pipe file descriptor
    i32 outFd;          // Stdout pipe file descriptor
    i32 errFd;          // Stderr pipe file descriptor
    i32 code;           // Exit code from waitpid()
} ProcDets;
```

**ProcDets Flags**:

```c
enum procdets_flags {
    PROCDETS_ASYNC = 1 << 8,      // Don't wait for completion
    PROCDETS_PIPES = 1 << 9,      // Create all three pipes (stdin/stdout/stderr)
    PROCDETS_IN_PIPE = 1 << 10,   // Create stdin pipe only
};
```

### StashCoord Structure

For memory persistence (covered in detail in Stash documentation):

```c
typedef struct stash_coord {
    cls typeOf;     // Type of object at this coordinate
    i32 idx;        // Page/slot index in MemCh
    quad offset;    // Offset within 4K page
} StashCoord;
```



---

**Part 1 of 3** | [Part 2 →](file-operations-complete-part2)
