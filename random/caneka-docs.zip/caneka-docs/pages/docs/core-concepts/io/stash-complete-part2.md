# Stash: Complete Guide to Memory Persistence - Part 2

[← Part 1](stash-complete-part1) | **Part 2 of 3** | [Part 3 →](stash-complete-part3)

---

## Implementation Details

### Pack Operation: Memory → Disk

#### Stash_PackAddr: Convert Single Pointer to Coordinate

**Location**: [src/base/io/stash.c:37-47](../../../src/base/io/stash.c)

```c
status Stash_PackAddr(cls typeOf, i32 slIdx, void **ptr){
    // Extract lower 12 bits (offset within page)
    util u = (util)*ptr;
    u &= MEM_STASH_MASK;

    // Create coordinate structure
    StashCoord coord = {
       .typeOf = typeOf,
       .idx = slIdx,
       .offset = (quad)u,
    };

    // Overwrite pointer with coordinate
    memcpy(ptr, &coord, sizeof(void *));
    return SUCCESS;
}
```

**Algorithm**:

1. **Extract Offset**: `util u = (util)*ptr & MEM_STASH_MASK;`
   - Takes absolute pointer value
   - Masks to get lower 12 bits (page offset)

2. **Create Coordinate**: Build `StashCoord` with type, page index, and offset

3. **Overwrite Pointer**: Use `memcpy()` to write coordinate bytes into pointer location

**Type Punning**: The function writes a `StashCoord` (8 bytes) into a `void **` pointer location (8 bytes). After this call, the memory location no longer contains a pointer—it contains coordinate data.

**Example**:

```c
// Before:
Str *str_ptr = (Str *)0x7F42ABC3;  // Points to object in page 127
void *addr = (void *)str_ptr;       // addr = 0x7F42ABC3

Stash_PackAddr(TYPE_STR, 127, &addr);

// After:
// addr now contains binary representation of:
// StashCoord {typeOf: TYPE_STR, idx: 127, offset: 0xBC3}
// No longer a valid pointer!
```

**Critical Invariant**: The caller must ensure that `slIdx` correctly identifies which page the pointer lives in. This is typically obtained from `MemIter.slIdx` during iteration.

#### Stash_PackMemCh: Traverse and Pack All Pointers

**Location**: [src/base/io/stash.c:49-135](../../../src/base/io/stash.c)

```c
i16 Stash_PackMemCh(MemCh *m, MemIter *mit, Table *tbl, MemCh **persist){
    boolean pack = (mit->type.state & MEM_ITER_STREAM) == 0;
    i16 checksum = 0;

    while((MemIter_Next(mit) & END) == 0){
        Abstract *a = (Abstract *)MemIter_Get(mit);

        if((mit->type.state & MORE) == 0){
            // Handle pointer arrays (TYPE_POINTER_ARRAY)
            if(a->type.of == TYPE_POINTER_ARRAY){
                void **dptr = (void **)(((void *)a)+sizeof(RangeType));
                i32 slots = ((RangeType *)a)->range / sizeof(void *);
                void **end = dptr+slots-1;

                while(dptr <= end){
                    void *ptr = *dptr;
                    if(ptr == NULL) break;

                    if(pack){
                        // PACK: Convert pointer to coordinate
                        StashItem *item = (StashItem *)Table_Get(tbl,
                            Util_Wrapped(m, (util)ptr));
                        if(item != NULL){
                            Stash_PackAddr(item->coord.typeOf,
                                item->coord.idx, (void **)dptr);
                        }
                    } else {
                        // UNPACK: Convert coordinate back to pointer
                        StashCoord *coord = (StashCoord *)dptr;
                        Stash_UnpackAddr(m, coord, mit->input.arr);
                    }
                    checksum++;
                    dptr++;
                }
            }
            // Handle object attribute pointers (via Map system)
            else if(a->type.of > _TYPE_ABSTRACT_BEGIN){
                Map *map = (Map *)Lookup_Get(MapsLookup, a->type.of);
                if(map == NULL){
                    Abstract *args[] = {Util_Wrapped(m, (util)a->type.of), NULL};
                    Error(m, FUNCNAME, FILENAME, LINENUMBER,
                        "Map not found for type $, needed for mem persist", args);
                    return ERROR;
                }

                // Iterate through all pointer-type attributes
                for(i16 i = 1; i <= map->type.range; i++){
                    RangeType *att = map->atts+i;
                    if(att->of > _TYPE_RANGE_TYPE_START){
                        void **aa = ((void *)a)+att->range;

                        if(pack){
                            StashItem *item = (StashItem *)Table_Get(tbl,
                                Util_Wrapped(m, (util)*aa));
                            if(item != NULL){
                                Stash_PackAddr(item->coord.typeOf,
                                    item->coord.idx, (void **)aa);
                            }
                        } else {
                            StashCoord *coord = (StashCoord *)aa;
                            Stash_UnpackAddr(m, coord, mit->input.arr);
                        }
                        checksum++;
                    }
                }
            }
        }
    }

    return checksum;
}
```

**Dual-Mode Operation**:

- **Pack Mode** (`pack == TRUE`): Converts pointers to coordinates
- **Unpack Mode** (`pack == FALSE`): Converts coordinates to pointers

**Algorithm**:

1. **Iterate All Objects**: `MemIter_Next()` walks every object across all pages

2. **Type Dispatch**:
   - **TYPE_POINTER_ARRAY**: Array of raw pointers (e.g., Span's internal array)
   - **Abstract types**: Objects with typed fields (use Map to find pointer fields)

3. **Pointer Array Handling**:
   ```c
   void **dptr = start_of_array;
   while(dptr <= end){
       void *ptr = *dptr;
       // Look up ptr in table to get its coordinate
       StashItem *item = Table_Get(tbl, ptr);
       Stash_PackAddr(item->coord.typeOf, item->coord.idx, dptr);
       dptr++;
   }
   ```

4. **Object Field Handling**:
   ```c
   Map *map = Lookup_Get(MapsLookup, a->type.of);
   for(each attribute in map){
       if(attribute is pointer type){
           void **field_ptr = object + attribute_offset;
           // Pack the pointer at field_ptr
       }
   }
   ```

5. **Checksum Accumulation**: Counts every pointer transformed

**Map System Integration**:

The Map (defined in `*_map.c` files) provides:
- Total number of attributes
- Offset of each attribute within the struct
- Type of each attribute

Example for Str:

```c
// Generated in str_map.c
Map StrMap = {
    .type = {TYPE_MAP, 0, 3},  // 3 attributes
    .atts = {
        {TYPE_TYPE, offsetof(Str, type)},      // Not a pointer
        {TYPE_I64, offsetof(Str, length)},     // Not a pointer
        {TYPE_I64, offsetof(Str, alloc)},      // Not a pointer
        {TYPE_BYTES, offsetof(Str, bytes)},    // Pointer!
    }
};
```

Only attributes with `att->of > _TYPE_RANGE_TYPE_START` are pointers that need packing.

**Checksum Purpose**: Validates that the same number of pointers were found during both pack and unpack. Mismatch indicates corruption or Map misconfiguration.

#### Stash_FlushFree: Full Serialization to Disk

**Location**: [src/base/io/stash.c:137-199](../../../src/base/io/stash.c)

```c
status Stash_FlushFree(Buff *bf, MemCh *persist){
    DebugStack_Push(persist, persist->type.of);

    // Phase 1: Build Lookup Table (pointer → StashItem)
    MemCh *m = bf->m;
    Table *tbl = Table_Make(m);

    MemIter mit;
    MemIter_Init(&mit, persist);

    while((MemIter_Next(&mit) & END) == 0){
        Abstract *a = (Abstract *)MemIter_Get(&mit);
        if((mit.type.state & MORE) == 0){
            void *ptr = (void *)a;

            // For RangeTypes, skip header to get data pointer
            if(a->type.of < _TYPE_RANGE_TYPE_END){
                void *orig = ptr;
                ptr += sizeof(RangeType);
            }

            // Map: pointer → StashItem
            Table_Set(tbl, Util_Wrapped(m, (util)ptr),
                StashItem_Make(m, mit.slIdx, (void *)ptr, a->type.of));
        }
    }

    // Phase 2: Collect All Pages
    Span *pages = Span_Make(m);

    Iter_Reset(&persist->it);
    while((Iter_Next(&persist->it) & END) == 0){
        Abstract *a = (Abstract *)Iter_Get(&persist->it);

        // Add page pointer to table
        Table_Set(tbl, Util_Wrapped(m, (util)a),
            StashItem_Make(m, persist->it.idx, (void *)a, a->type.of));

        // Collect page
        Span_Add(pages, a);
    }

    // Phase 3: PACK - Convert All Pointers to Coordinates
    MemIter_Init(&mit, persist);
    i16 checksum = Stash_PackMemCh(m, &mit, tbl, NULL);

    // Phase 4: Write Header
    StashHeader hdr = {
        .pages = (i16)pages->nvalues,
        .checksum = checksum
    };
    Buff_AddBytes(bf, (byte *)&hdr, sizeof(StashHeader));
    Buff_Flush(bf);

    // Phase 5: Write Each Page
    status r = SUCCESS;
    Iter it;
    Iter_Init(&it, pages);

    while((Iter_Next(&it) & END) == 0){
        MemPage *pg = (MemPage *)Iter_Get(&it);

        // Write raw page bytes
        if((Buff_AddBytes(bf, (byte *)pg, PAGE_SIZE) & SUCCESS) == 0){
            Abstract *args[] = {NULL};
            Error(m, FUNCNAME, FILENAME, LINENUMBER,
                "Error writing page to stream for Stash", args);
            r |= ERROR;
            break;
        }

        Buff_Flush(bf);

        // Free page after writing (hence "FlushFree")
        r |= MemBook_FreePage(m, (MemPage *)Iter_Get(&it));
    }

    DebugStack_Pop();
    return r;
}
```

**Complete Flow**:

1. **Phase 1: Build Lookup Table**
   - Iterate through all objects in `persist` MemCh
   - For each object, create a `StashItem` mapping its pointer to its coordinate
   - Store in hash Table for O(1) lookup

2. **Phase 2: Collect Pages**
   - Iterate through MemCh's page list (`persist->it`)
   - Add each page to a Span for sequential writing
   - Also add pages themselves to the lookup table

3. **Phase 3: Pack Pointers**
   - Call `Stash_PackMemCh()` in pack mode
   - Traverses all objects and transforms every pointer to a coordinate
   - Returns checksum (count of transformed pointers)

4. **Phase 4: Write Header**
   - Create `StashHeader` with page count and checksum
   - Write to Buff and flush

5. **Phase 5: Write Pages**
   - Write each page as raw 4096 bytes
   - Flush after each page to ensure durability
   - Free page immediately after writing (conserves memory)

**Name Explanation**: "FlushFree" because it flushes pages to disk AND frees them from memory—the MemCh is consumed by this operation.

**Example Usage**:

```c
// Create and populate MemCh
MemCh *session = MemCh_Make();
Table *data = Table_Make(session);
Table_Set(data, S(session, "user"), S(session, "alice"));
session->owner = data;

// Serialize to file
Buff *bf = Buff_Make(m, ZERO);
File_Open(bf, S(m, "/tmp/session.stash"), O_WRONLY|O_CREAT|O_TRUNC);

status result = Stash_FlushFree(bf, session);
// After this call, session MemCh has been freed!

File_Close(bf);

if(result & SUCCESS) {
    printf("Session saved successfully\n");
}
```

### Unpack Operation: Disk → Memory

#### Stash_UnpackAddr: Convert Single Coordinate to Pointer

**Location**: [src/base/io/stash.c:22-35](../../../src/base/io/stash.c)

```c
cls Stash_UnpackAddr(MemCh *m, StashCoord *coord, void **arr){
    cls typeOf = coord->typeOf;

    // Look up the physical page from the array
    MemPage *pg = (MemPage *)arr[coord->idx];
    if(pg == NULL){
        Abstract *args[] = {NULL};
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
            "Cannot unpack address onto empty page", args);
        return ZERO;
    }

    // Combine page base address with offset
    util u = (util)pg;
    u |= coord->offset;

    // Write reconstructed pointer back
    void *ptr = (void *)coord;
    memcpy(ptr, &u, sizeof(void *));

    return typeOf;
}
```

**Algorithm**:

1. **Extract Type**: Save `coord->typeOf` for return value

2. **Lookup Page**: Get the page at index `coord->idx` from the array
   - Array is populated during restore with newly-allocated pages
   - Each array slot contains a pointer to a 4096-byte page

3. **Reconstruct Address**:
   ```c
   util u = (util)pg;      // Page base: e.g., 0x7F42A000
   u |= coord->offset;     // OR offset:    e.g., 0x00000BC3
                           // Result:       e.g., 0x7F42ABC3
   ```

4. **Overwrite Coordinate**: Write reconstructed pointer back to where coordinate was stored

**Example**:

```c
// After loading pages from disk:
void *pages[3] = {
    (void *)0x7F42A000,  // Page 0
    (void *)0x7F42B000,  // Page 1
    (void *)0x7F42C000   // Page 2
};

// Coordinate in memory:
StashCoord coord = {typeOf: TYPE_STR, idx: 1, offset: 0x567};

// Unpack:
Stash_UnpackAddr(m, &coord, pages);

// Inside function:
//   pg = pages[1] = 0x7F42B000
//   u = 0x7F42B000 | 0x567 = 0x7F42B567
//   *((void **)&coord) = 0x7F42B567

// After: The memory location that held the coordinate now holds pointer 0x7F42B567
```

**Why OR Works**: The page base address always has its lower 12 bits as 0 (pages are 4K-aligned). The coordinate offset has only lower 12 bits set. ORing them combines both parts without interference.

#### Stash_FromStream: Full Deserialization from Disk

**Location**: [src/base/io/stash.c:201-288](../../../src/base/io/stash.c)

```c
MemCh *Stash_FromStream(Buff *bf){
    DebugStack_Push(bf, bf->type.of);

    StashHeader hdr = {0, 0};
    i16 count = 0;
    MemCh *persist = NULL;
    void **pages = NULL;
    MemCh *m = bf->m;
    status r = ZERO;

    // Phase 1: Read Header
    Str s = {
        .type = {TYPE_STR, ZERO},
        .length = 0,
        .alloc = sizeof(StashHeader),
        .bytes = (byte *)&hdr,
    };

    while((r & (SUCCESS|ERROR)) == 0 && (bf->type.state & END) == 0){
        if((r & PROCESSING) == 0){
            // Read header
            if((Buff_GetStr(bf, &s) & SUCCESS) == 0){
                r |= ERROR;
                break;
            }

            r |= PROCESSING;

            // Pre-allocate page array based on header
            pages = (void **)Bytes_Alloc(bf->m, hdr.pages*sizeof(void *),
                TYPE_POINTER_ARRAY);
        }

        // Phase 2: Read Each Page
        if(count >= hdr.pages){
            r |= SUCCESS;
            break;
        }

        // Allocate new page from MemBook
        pages[count] = MemBook_GetPage(NULL);
        if(pages[count] == NULL){
            Abstract *args[] = {NULL};
            Error(bf->m, FUNCNAME, FILENAME, LINENUMBER,
                "Error allocating page", args);
            r |= ERROR;
            DebugStack_Pop();
            return NULL;
        }

        // Read page bytes from file
        s.alloc = PAGE_SIZE;
        s.length = 0;
        s.bytes = (byte *)pages[count];
        r |= (Buff_GetStr(bf, &s) & SUCCESS);
        count++;
    }

    i16 checksum = 0;

    // Phase 3: UNPACK - Convert Coordinates Back to Pointers
    if(r & SUCCESS){
        r &= ~SUCCESS;

        MemIter mit;
        MemIter_InitArr(&mit, pages, hdr.pages-1);

        // Set STREAM flag to indicate unpack mode
        mit.type.state |= MEM_ITER_STREAM;

        checksum = Stash_PackMemCh(m, &mit, NULL, &persist);
    }

    // Phase 4: Validate Checksum
    if(checksum != hdr.checksum){
        Abstract *args[] = {
            Util_Wrapped(m, (util)hdr.checksum),
            Util_Wrapped(m, (util)checksum),
            NULL
        };
        Error(m, FUNCNAME, FILENAME, LINENUMBER,
            "Error checksum of number of changes does not match for resurecting persisting"
            " expected $, have $", args);
        r |= ERROR;
    } else {
        r |= SUCCESS;
    }

    if((r & (SUCCESS|ERROR)) == SUCCESS){
        DebugStack_Pop();
        return persist;
    }

    DebugStack_Pop();
    return NULL;
}
```

**Complete Flow**:

1. **Phase 1: Read Header**
   - Read `StashHeader` (4 bytes) from Buff
   - Extract page count and checksum
   - Allocate page pointer array: `void *pages[page_count]`

2. **Phase 2: Read Pages**
   - For each page:
     - Allocate a new 4096-byte page via `MemBook_GetPage()`
     - Read 4096 bytes from Buff directly into page
     - Store page pointer in array
   - Result: Array of loaded pages with all coordinates intact

3. **Phase 3: Unpack Pointers**
   - Create `MemIter` initialized with page array (not a live MemCh)
   - Set `MEM_ITER_STREAM` flag to signal unpack mode
   - Call `Stash_PackMemCh()` which:
     - Traverses all objects in the pages
     - Converts every coordinate back to a pointer
     - Discovers the root MemCh object (stored in `&persist`)
   - Returns checksum (count of transformed pointers)

4. **Phase 4: Validate**
   - Compare returned checksum with header checksum
   - If mismatch: return ERROR (corruption detected)
   - If match: return the reconstructed MemCh

**Critical Discovery**: The first page in the array contains the root MemCh object. During unpacking, `Stash_PackMemCh()` sets `*persist` to point to this MemCh, effectively "resurrecting" the memory context.

**Example Usage**:

```c
// Load from file
Buff *bf = Buff_Make(m, ZERO);
File_Open(bf, S(m, "/tmp/session.stash"), O_RDONLY);

MemCh *session = Stash_FromStream(bf);
File_Close(bf);

if(session != NULL && session->owner != NULL) {
    // Access restored root object
    Table *data = (Table *)session->owner;

    Str *user = (Str *)Table_Get(data, S(m, "user"));
    printf("User: %.*s\n", (int)user->length, user->bytes);
    // Output: User: alice
}

// Later: free the entire context
MemCh_Free(session);
```

### MemIter: Hierarchical Page Traversal

#### MemIter Structure

```c
typedef struct mem_iter {
    Type type;
    struct {
        MemCh *target;   // MemCh being iterated (NULL for array mode)
        void **arr;      // Page array (used in restore mode)
    } input;
    i32 slIdx;           // Current page index
    i32 maxSlIdx;        // Maximum page index
    void *ptr;           // Current object pointer
    void *end;           // End of current page
} MemIter;
```

**Location**: [src/base/include/mem/mem_iter.h](../../../src/base/include/mem/mem_iter.h)

**Dual-Mode Operation**:

1. **MemCh Mode**: Iterate through a live MemCh's pages
   ```c
   MemIter mit;
   MemIter_Init(&mit, persist);
   // mit.input.target = persist
   // mit.input.arr = NULL
   ```

2. **Array Mode**: Iterate through a pre-loaded page array (used during restore)
   ```c
   MemIter mit;
   MemIter_InitArr(&mit, pages, maxSlIdx);
   // mit.input.target = NULL
   // mit.input.arr = pages
   ```

#### MemIter Operations

**Initialize from MemCh**:

```c
void MemIter_Init(MemIter *mit, MemCh *target){
    mit->type.of = TYPE_MEM_ITER;
    mit->type.state = ZERO;
    mit->input.target = target;
    mit->input.arr = NULL;
    mit->slIdx = -1;
    mit->maxSlIdx = target->it.p->max_idx;
    mit->ptr = NULL;
    mit->end = NULL;
}
```

**Initialize from Array**:

```c
void MemIter_InitArr(MemIter *mit, void **arr, i32 maxSlIdx){
    mit->type.of = TYPE_MEM_ITER;
    mit->type.state = ZERO;
    mit->input.target = NULL;
    mit->input.arr = arr;
    mit->slIdx = -1;
    mit->maxSlIdx = maxSlIdx;
    mit->ptr = NULL;
    mit->end = NULL;
}
```

**Next Object**:

```c
status MemIter_Next(MemIter *mit){
    // If at end of current page, move to next page
    if(mit->ptr >= mit->end || mit->ptr == NULL){
        mit->slIdx++;

        if(mit->slIdx > mit->maxSlIdx){
            return END;
        }

        MemPage *pg;
        if(mit->input.target != NULL){
            // MemCh mode
            pg = (MemPage *)Span_Get(mit->input.target->it.p, mit->slIdx);
        } else {
            // Array mode
            pg = (MemPage *)mit->input.arr[mit->slIdx];
        }

        mit->ptr = ((void *)pg) + sizeof(MemPage);  // Skip header
        mit->end = ((void *)pg) + PAGE_SIZE;
        mit->type.state &= ~MORE;
    }

    Abstract *a = (Abstract *)mit->ptr;

    // Advance pointer
    if(a->type.of < _TYPE_RANGE_TYPE_END){
        // RangeType: use range field for size
        RangeType *rt = (RangeType *)a;
        mit->ptr += sizeof(RangeType) + rt->range;
    } else {
        // Regular type: use type-specific size
        i64 sz = Type_Size(a->type.of);
        mit->ptr += sz;
    }

    // Check if crossed page boundary
    if(mit->ptr > mit->end){
        mit->type.state |= MORE;  // Partial object, skip
        return MORE;
    }

    return SUCCESS;
}
```

**Get Current Object**:

```c
void *MemIter_Get(MemIter *mit){
    return mit->ptr - Type_Size(...);  // Return previous ptr
}
```

**Iteration Pattern**:

```c
MemIter mit;
MemIter_Init(&mit, m);

while((MemIter_Next(&mit) & END) == 0){
    if((mit.type.state & MORE) == 0){
        Abstract *a = (Abstract *)MemIter_Get(&mit);

        // Process object...
        printf("Type: %d, Page: %d\n", a->type.of, mit.slIdx);
    }
}
```

**Key Feature**: The `MORE` flag indicates when an object spans page boundaries (which shouldn't happen with proper allocation, but is handled defensively).

### Map System: Type-Specific Field Metadata

#### Map Structure

```c
typedef struct map {
    Type type;          // type.of = TYPE_MAP, type.range = attribute count
    RangeType *atts;    // Array of attribute descriptors
} Map;

typedef struct range_type {
    Type type;          // type.of = attribute type
    word range;         // Offset within struct OR size (context-dependent)
} RangeType;
```

**Location**: [src/base/include/types/range_type.h](../../../src/base/include/types/range_type.h)

**Purpose**: Provides compile-time metadata about struct layouts, enabling generic traversal of pointer fields.

#### Example: Str Map

**Generated in**: `src/base/types/str_map.c`

```c
RangeType StrAtts[] = {
    {0, 0},  // Placeholder at index 0
    {TYPE_TYPE, offsetof(Str, type)},
    {TYPE_I64, offsetof(Str, length)},
    {TYPE_I64, offsetof(Str, alloc)},
    {TYPE_BYTES, offsetof(Str, bytes)},  // This is a pointer!
};

Map StrMap = {
    .type = {TYPE_MAP, ZERO, 4},  // 4 attributes
    .atts = StrAtts
};
```

**Usage in Stash**:

```c
// Given a Str object:
Str *s = ...;

// Get its Map:
Map *map = (Map *)Lookup_Get(MapsLookup, TYPE_STR);

// Iterate pointer fields:
for(i16 i = 1; i <= map->type.range; i++){
    RangeType *att = map->atts + i;

    if(att->of > _TYPE_RANGE_TYPE_START){
        // This is a pointer field
        void **field_ptr = ((void *)s) + att->range;

        // Pack the pointer
        StashItem *item = Table_Get(lookup_table, *field_ptr);
        Stash_PackAddr(item->coord.typeOf, item->coord.idx, field_ptr);
    }
}
```

**Pointer Identification**: Types greater than `_TYPE_RANGE_TYPE_START` are pointer types (e.g., `TYPE_BYTES`, `TYPE_STR`, `TYPE_TABLE`).

#### MapsLookup: Global Type Registry

```c
struct lookup *MapsLookup = NULL;
```

**Initialization** (in `src/base/types/types.c`):

```c
void Types_Init(MemCh *m){
    MapsLookup = Lookup_Make(m, 0);

    Lookup_Put(MapsLookup, TYPE_STR, &StrMap);
    Lookup_Put(MapsLookup, TYPE_TABLE, &TableMap);
    Lookup_Put(MapsLookup, TYPE_SPAN, &SpanMap);
    // ... all types
}
```

**Lookup Pattern**:

```c
Map *map = (Map *)Lookup_Get(MapsLookup, object->type.of);
if(map == NULL){
    // Type doesn't have Map metadata (error!)
}
```



---

[← Part 1](stash-complete-part1) | **Part 2 of 3** | [Part 3 →](stash-complete-part3)
