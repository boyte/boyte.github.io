# File Operations: Complete Guide - Part 3

[← Part 2](file-operations-complete-part2) | **Part 3 of 3**

---

## Code Examples

### Example 1: Write String to File

```c
MemCh *m = MemCh_Make();

// Create buffer with clobber flag to allow overwriting
Buff *bf = Buff_Make(m, BUFF_CLOBBER);

// Open file for writing
Str *path = S(m, "./output.txt");
status s = File_Open(bf, path, O_CREAT|O_TRUNC|O_WRONLY);

if(s & ERROR){
    printf("Failed to open file\n");
    MemCh_Free(m);
    return ERROR;
}

// Write content
char *content = "Hello, World!\n";
Buff_AddBytes(bf, (byte *)content, strlen(content));

// Flush and close
Buff_Flush(bf);
File_Close(bf);

MemCh_Free(m);  // Cleanup everything
```

### Example 2: Read Entire File to StrVec

```c
MemCh *m = MemCh_Make();

// High-level file read
Str *path = S(m, "./data.txt");
StrVec *content = File_ToVec(m, path);

if(content == NULL){
    printf("File not found\n");
    MemCh_Free(m);
    return ERROR;
}

// Iterate lines/blocks
Iter it;
Iter_Init(&it, content->p);

while((Iter_Next(&it) & END) == 0){
    Str *line = (Str *)Iter_Get(&it);
    // Process each line...
    printf("Line: %.*s\n", (int)line->length, line->bytes);
}

MemCh_Free(m);
```

### Example 3: Buffered File Reading

```c
MemCh *m = MemCh_Make();

// Create buffer for reading
Buff *bf = Buff_Make(m, ZERO);

// Open file
Str *path = S(m, "./large_file.dat");
File_Open(bf, path, O_RDONLY);

// Read in chunks
while((Buff_ReadAmount(bf, 4096) & END) == 0){
    // Process buffered data in bf->v
    Iter it;
    Iter_Init(&it, bf->v->p);

    while((Iter_Next(&it) & END) == 0){
        Str *chunk = (Str *)Iter_Get(&it);
        // Process chunk...
    }

    // Clear buffer for next read
    bf->v = StrVec_Make(m);
}

File_Close(bf);
MemCh_Free(m);
```

### Example 4: Copy File to File

```c
MemCh *m = MemCh_Make();

// Source buffer
Buff *src = Buff_Make(m, BUFF_SLURP);
File_Open(src, S(m, "./source.txt"), O_RDONLY);
Buff_Read(src);
File_Close(src);

// Destination buffer
Buff *dst = Buff_Make(m, BUFF_CLOBBER);
File_Open(dst, S(m, "./dest.txt"), O_CREAT|O_TRUNC|O_WRONLY);

// Pipe data
Buff_Pipe(dst, src);

Buff_Flush(dst);
File_Close(dst);

MemCh_Free(m);
```

### Example 5: Gather All .c Files in Directory

```c
MemCh *m = MemCh_Make();

// Create result container
Span *results = Span_Make(m);

// Create extension filter
Span *extensions = Span_Make(m);
Span_Add(extensions, S(m, "c"));

// Gather files
DirSelector *sel = Dir_GatherByExt(m, S(m, "./src"), results, extensions);

// Process results
printf("Found %d .c files:\n", results->max_idx + 1);

Iter it;
Iter_Init(&it, results);

while((Iter_Next(&it) & END) == 0){
    StrVec *filepath = (StrVec *)Iter_Get(&it);
    Str *path_str = StrVec_ToStr(m, filepath);
    printf("  %.*s\n", (int)path_str->length, path_str->bytes);
}

MemCh_Free(m);
```

### Example 6: Recursive Directory Traversal with Callbacks

```c
static status my_dir_callback(MemCh *m, StrVec *path, void *source){
    Str *s = StrVec_ToStr(m, path);
    printf("Directory: %.*s\n", (int)s->length, s->bytes);
    return SUCCESS;  // Continue recursion
}

static status my_file_callback(MemCh *m, StrVec *dir, Str *file, void *source){
    printf("  File: %.*s\n", (int)file->length, file->bytes);
    return SUCCESS;
}

void traverse_directory(){
    MemCh *m = MemCh_Make();

    Str *path = S(m, "./src");
    Dir_Climb(m, path, my_dir_callback, my_file_callback, NULL);

    MemCh_Free(m);
}
```

### Example 7: Path Manipulation

```c
MemCh *m = MemCh_Make();

// Parse path
StrVec *path = IoPath(m, "./src/base/io/file.c");

// Get extension
StrVec *ext = IoUtil_GetExt(m, path);
Str *ext_str = StrVec_ToStr(m, ext);
printf("Extension: %.*s\n", (int)ext_str->length, ext_str->bytes);  // "c"

// Swap extension
IoUtil_SwapExt(m, path, S(m, "o"));
Str *new_path = StrVec_ToStr(m, path);
printf("New path: %.*s\n", (int)new_path->length, new_path->bytes);
// "./src/base/io/file.o"

// Get base path (directory)
StrVec *base = IoUtil_BasePath(m, path);
Str *base_str = StrVec_ToStr(m, base);
printf("Base: %.*s\n", (int)base_str->length, base_str->bytes);
// "./src/base/io"

// Convert to absolute
Str *abs = IoUtil_GetAbsPath(m, new_path);
printf("Absolute: %.*s\n", (int)abs->length, abs->bytes);
// "/Users/username/project/src/base/io/file.o"

MemCh_Free(m);
```

### Example 8: Execute Subprocess with Pipes

```c
MemCh *m = MemCh_Make();

// Build command
Span *cmd = Span_Make(m);
Span_Add(cmd, S(m, "ls"));
Span_Add(cmd, S(m, "-la"));
Span_Add(cmd, S(m, "/tmp"));

// Create process details
ProcDets pd;
ProcDets_Init(&pd);
pd.type.state = PROCDETS_PIPES;  // Create stdin/stdout/stderr pipes

// Execute
status s = SubCall(m, cmd, &pd);

if(s & ERROR){
    printf("Failed to execute subprocess\n");
    MemCh_Free(m);
    return ERROR;
}

// Read stdout
Buff *out = Buff_Make(m, ZERO);
Buff_SetFd(out, pd.outFd);
Buff_Read(out);

// Print output
Str *output = StrVec_ToStr(m, out->v);
printf("Output:\n%.*s\n", (int)output->length, output->bytes);

// Read stderr
Buff *err = Buff_Make(m, ZERO);
Buff_SetFd(err, pd.errFd);
Buff_Read(err);

// Close pipes
close(pd.outFd);
close(pd.errFd);
close(pd.inFd);

printf("Exit code: %d\n", pd.code);

MemCh_Free(m);
```

### Example 9: Check File Modification Time

```c
MemCh *m = MemCh_Make();

Str *source = S(m, "./src/file.c");
Str *build = S(m, "./build/file.o");

if(IoUtil_CmpUpdated(m, source, build)){
    printf("Source is newer than build - need to recompile\n");

    // Rebuild logic here...
}else{
    printf("Build is up to date\n");
}

MemCh_Free(m);
```

### Example 10: Advanced DirSelector with Custom Filter

```c
// Custom filter: only include files larger than 1KB
static boolean size_filter(MemCh *m, StrVec *dir, Str *file, void *source){
    StrVec *fullpath = StrVec_Clone(m, dir);
    StrVec_Add(fullpath, file);
    Str *path = StrVec_ToStr(m, fullpath);

    struct stat st;
    if(File_Stat(m, path, &st) & SUCCESS){
        return (st.st_size > 1024);  // > 1KB
    }
    return FALSE;
}

void gather_large_files(){
    MemCh *m = MemCh_Make();

    Span *results = Span_Make(m);
    DirSelector *sel = DirSelector_Make(m, NULL, results, DIR_SELECTOR_FILTER);
    sel->func = size_filter;

    Dir_GatherSel(m, S(m, "./data"), sel);

    printf("Found %d files > 1KB\n", results->max_idx + 1);

    MemCh_Free(m);
}
```

### Example 11: Write with Auto-Flush

```c
MemCh *m = MemCh_Make();

// Create buffer with auto-flush
Buff *bf = Buff_Make(m, BUFF_FLUSH|BUFF_CLOBBER);

File_Open(bf, S(m, "./log.txt"), O_CREAT|O_APPEND|O_WRONLY);

// Each Add automatically flushes to disk
Buff_Add(bf, S(m, "Log entry 1\n"));
Buff_Add(bf, S(m, "Log entry 2\n"));
Buff_Add(bf, S(m, "Log entry 3\n"));

File_Close(bf);
MemCh_Free(m);
```

### Example 12: Seek and Read

```c
MemCh *m = MemCh_Make();

Buff *bf = Buff_Make(m, ZERO);
File_Open(bf, S(m, "./data.bin"), O_RDONLY);

// Seek to offset 1024
Buff_PosAbs(bf, 1024);

// Read 256 bytes from that position
Buff_ReadAmount(bf, 256);

// Process data
Str *data = StrVec_ToStr(m, bf->v);
// ... use data ...

// Seek to end
Buff_PosEnd(bf);

// Get file size
Buff_Stat(bf);
printf("File size: %ld bytes\n", bf->st.st_size);

File_Close(bf);
MemCh_Free(m);
```


## Performance Characteristics

### Buffering Strategy

**StrVec-Backed Buffering**:

- **Memory Allocation**: Buff uses StrVec (Span of Str) for buffering
- **Default Block Size**: `IO_BLOCK_SIZE` = 4096 bytes per Str
- **Chunked Growth**: New Str allocated when current tail fills
- **Zero-Copy Read**: Read chunks stored directly in StrVec without intermediate copy

**Performance Implications**:

- **Reduced Allocations**: Reuses existing Str capacity before allocating new
- **Cache Efficiency**: 4KB blocks align with typical page sizes
- **Iteration Friendly**: StrVec iteration is O(1) per element access
- **Memory Overhead**: Each Str has 56-byte overhead (Type + metadata)

### I/O Operation Costs

**System Call Overhead**:

- **open()**: ~2-5 µs per call (file descriptor allocation)
- **read()/write()**: ~0.5-2 µs per call + data transfer time
- **lseek()**: ~0.5 µs (metadata operation)
- **fstat()**: ~1 µs (inode read)
- **close()**: ~1-2 µs (descriptor cleanup)

**Buffering Impact**:

- **Unbuffered (BUFF_UNBUFFERED)**: Each `Buff_Add()` triggers immediate `write()`
- **Buffered (default)**: Accumulates in StrVec, single `write()` on `Buff_Flush()`
- **Trade-off**: Buffering reduces syscall overhead but increases memory usage

**Example**: Writing 100KB in 1KB chunks:

- Unbuffered: 100 syscalls (~50-200 µs overhead)
- Buffered: 1 syscall + memory operations (~2-5 µs overhead)

### Directory Traversal Performance

**Dir_Climb Characteristics**:

- **Recursive**: Stack depth = directory tree depth
- **opendir/readdir**: ~10-50 µs per directory
- **Callback Overhead**: Minimal (direct function call)
- **Memory**: Allocates StrVec for each file path (~100 bytes per entry)

**Optimization Strategies**:

1. **Early Termination**: Return NOOP from callback to skip recursion
2. **Extension Filtering**: DirSelector reduces result set size
3. **Batch Processing**: Accumulate results, process in bulk

**Example**: Traversing 10,000 files across 1,000 directories:

- Time: ~100-500 ms (depends on filesystem cache)
- Memory: ~1-2 MB for path storage

### File Seeking Performance

**Seek Types**:

- **SEEK_SET (absolute)**: O(1) - direct offset
- **SEEK_CUR (relative)**: O(1) - add to current position
- **SEEK_END**: O(1) - use file size from stat

**Memory-Only Seeking** (Buff without fd):

- Requires O(n) iteration through StrVec to find target Str
- n = number of Str objects in StrVec
- Typical case: ~10-100 iterations for megabyte-sized buffers

**Recommendation**: For frequent seeking, use file descriptor (fd) rather than memory-only Buff.

### Subprocess Overhead

**Fork + Exec Costs**:

- **vfork()**: ~20-100 µs (lightweight fork)
- **execvp()**: ~500 µs - 5 ms (program loading)
- **pipe()**: ~10 µs per pipe creation
- **fcntl(O_NONBLOCK)**: ~5 µs per descriptor

**Total Overhead**: ~1-10 ms per subprocess spawn

**Mitigation**:

- Use `PROCDETS_ASYNC` to avoid blocking parent
- Reuse long-running processes with pipe communication
- Consider forgoing pipes (`PROCDETS_PIPES` unset) when stdio not needed


## Best Practices

### Memory Management Integration

**Always Use MemCh Contexts**:

```c
// GOOD: All allocations under single MemCh
MemCh *m = MemCh_Make();
Buff *bf = Buff_Make(m, ZERO);
Str *path = S(m, "./file.txt");
File_Open(bf, path, O_RDONLY);
Buff_Read(bf);
MemCh_Free(m);  // Cleanup everything

// BAD: Mixing malloc and MemCh
char *data = malloc(1024);
Buff *bf = Buff_Make(m, ZERO);
Buff_AddBytes(bf, data, 1024);
free(data);  // Manual management required
```

**Benefit**: Single `MemCh_Free()` call cleans up all resources - no leak potential.

### File Opening Safety

**Always Check CLOBBER Before Truncate**:

```c
// GOOD: Explicit clobber permission
Buff *bf = Buff_Make(m, BUFF_CLOBBER);
File_Open(bf, path, O_CREAT|O_TRUNC|O_WRONLY);

// BAD: Will error if file exists
Buff *bf = Buff_Make(m, ZERO);
File_Open(bf, path, O_CREAT|O_TRUNC|O_WRONLY);  // ERROR if file exists
```

**Rationale**: Prevents accidental data loss from truncating existing files.

### Buffering Strategy Selection

**Use BUFF_UNBUFFERED for Immediate Writes**:

```c
// Logging: want immediate disk writes
Buff *log = Buff_Make(m, BUFF_UNBUFFERED|BUFF_DATASYNC);
File_Open(log, S(m, "./app.log"), O_CREAT|O_APPEND|O_WRONLY);
Buff_Add(log, S(m, "Critical error occurred\n"));
// Data flushed immediately, no explicit Buff_Flush needed
```

**Use Buffered for Bulk Writes**:

```c
// Report generation: accumulate in memory, write once
Buff *report = Buff_Make(m, ZERO);
File_Open(report, S(m, "./report.txt"), O_CREAT|O_TRUNC|O_WRONLY);

for(i32 i = 0; i < 10000; i++){
    Str *line = generate_report_line(m, i);
    Buff_Add(report, line);
}

Buff_Flush(report);  // Single write of entire buffer
File_Close(report);
```

### Error Handling Patterns

**Check Status After Critical Operations**:

```c
Buff *bf = Buff_Make(m, BUFF_CLOBBER);
status s = File_Open(bf, path, O_CREAT|O_WRONLY);

if(s & ERROR){
    // Check error message in MemCh
    Str *err = MemCh_GetError(m);
    printf("Failed to open file: %.*s\n", (int)err->length, err->bytes);
    return ERROR;
}

// Continue with file operations...
```

**Use Type Flags for State Checking**:

```c
Buff_Read(bf);

if(bf->type.state & END){
    printf("Reached end of file\n");
}

if(bf->type.state & ERROR){
    printf("Read error occurred\n");
}

if(bf->type.state & MORE){
    printf("Non-blocking read would block\n");
}
```

### Path Handling Recommendations

**Always Use Absolute Paths for Robustness**:

```c
// GOOD: Convert to absolute path
Str *relpath = S(m, "./config/app.conf");
Str *abspath = IoUtil_GetAbsPath(m, relpath);
File_Open(bf, abspath, O_RDONLY);

// BAD: Relative path vulnerable to cwd changes
File_Open(bf, S(m, "./config/app.conf"), O_RDONLY);
```

**Use IoPath Parsing for Complex Paths**:

```c
// Parse and manipulate path components
StrVec *path = IoPath(m, "./src/base/io/file.c");
IoUtil_SwapExt(m, path, S(m, "o"));
StrVec *base = IoUtil_BasePath(m, path);
// Result: "./src/base/io/file.o"
```

### Directory Traversal Optimization

**Use DirSelector for Filtering**:

```c
// GOOD: Filter during traversal
Span *results = Span_Make(m);
Span *exts = Span_Make(m);
Span_Add(exts, S(m, "c"));
Dir_GatherByExt(m, S(m, "./src"), results, exts);

// BAD: Gather all, filter afterward
Span *all = Span_Make(m);
Dir_Gather(m, S(m, "./src"), all);
// ... manually filter results ...
```

**Early Termination for Targeted Search**:

```c
static status find_config_dir(MemCh *m, StrVec *path, void *source){
    Str *last = Span_GetLast(path->p);
    if(Str_CmpCstr(last, "config") == 0){
        *(StrVec **)source = path;  // Found it
        return NOOP;  // Stop recursion
    }
    return SUCCESS;  // Continue searching
}

StrVec *found = NULL;
Dir_Climb(m, S(m, "./"), find_config_dir, NULL, &found);
```

### Subprocess Best Practices

**Close Pipes After Use**:

```c
ProcDets pd;
SubCall(m, cmd, &pd);

// Read output
Buff *out = Buff_Make(m, ZERO);
Buff_SetFd(out, pd.outFd);
Buff_Read(out);

// Close pipes explicitly
close(pd.outFd);
close(pd.errFd);
close(pd.inFd);

// Wait for completion
SubStatus(&pd);
```

**Use Non-blocking for Multiple Subprocesses**:

```c
// Launch multiple processes without blocking
ProcDets pd1, pd2, pd3;
pd1.type.state = PROCDETS_ASYNC|PROCDETS_PIPES;
pd2.type.state = PROCDETS_ASYNC|PROCDETS_PIPES;
pd3.type.state = PROCDETS_ASYNC|PROCDETS_PIPES;

SubCall(m, cmd1, &pd1);
SubCall(m, cmd2, &pd2);
SubCall(m, cmd3, &pd3);

// Poll for completion or use select() on pipe fds
```


## Common Pitfalls and Solutions

### Pitfall 1: Forgetting BUFF_CLOBBER Flag

**Problem**:

```c
Buff *bf = Buff_Make(m, ZERO);
File_Open(bf, S(m, "./existing_file.txt"), O_CREAT|O_TRUNC|O_WRONLY);
// ERROR: File exists and CLOBBER flag is unset
```

**Solution**:

```c
Buff *bf = Buff_Make(m, BUFF_CLOBBER);
File_Open(bf, S(m, "./existing_file.txt"), O_CREAT|O_TRUNC|O_WRONLY);
// SUCCESS: CLOBBER allows overwriting
```

**Why**: Safety mechanism to prevent accidental data loss.

### Pitfall 2: Not Flushing Before Close

**Problem**:

```c
Buff *bf = Buff_Make(m, ZERO);
File_Open(bf, path, O_WRONLY);
Buff_Add(bf, S(m, "Data"));
File_Close(bf);  // Data still in buffer, not written!
```

**Solution**:

```c
Buff_Add(bf, S(m, "Data"));
Buff_Flush(bf);  // Ensure write happens
File_Close(bf);
```

**Alternative**: Use `BUFF_FLUSH` flag for auto-flush:

```c
Buff *bf = Buff_Make(m, BUFF_FLUSH);
Buff_Add(bf, S(m, "Data"));  // Automatically flushed
```

### Pitfall 3: Memory-Only Buff Without FD

**Problem**:

```c
Buff *bf = Buff_Make(m, ZERO);
Buff_Add(bf, S(m, "Some data"));
Buff_Flush(bf);  // NOOP: no fd set, nothing to flush to
```

**Solution**: Set file descriptor before flushing:

```c
Buff *bf = Buff_Make(m, ZERO);
File_Open(bf, path, O_WRONLY);  // Sets bf->fd
Buff_Add(bf, S(m, "Some data"));
Buff_Flush(bf);  // SUCCESS: writes to fd
```

### Pitfall 4: Path Separator Confusion

**Problem**:

```c
StrVec *path = StrVec_Make(m);
StrVec_Add(path, S(m, "dir"));
StrVec_Add(path, S(m, "file.txt"));
Str *s = StrVec_ToStr(m, path);
// Result: "dirfile.txt" (missing separator!)
```

**Solution**: Use IoPath functions:

```c
StrVec *path = IoPath(m, "dir");
IoUtil_AddVec(m, path, IoPath(m, "file.txt"));
IoUtil_AddSlash(path);  // Ensures proper separators
Str *s = StrVec_ToStr(m, path);
// Result: "dir/file.txt"
```

### Pitfall 5: Relative Path Dependency

**Problem**:

```c
// Current directory: /home/user
Str *path = S(m, "./config/app.conf");
File_Open(bf, path, O_RDONLY);  // Opens /home/user/config/app.conf

chdir("/tmp");
File_Open(bf2, path, O_RDONLY);  // Opens /tmp/config/app.conf (different file!)
```

**Solution**: Use absolute paths:

```c
Str *abspath = IoUtil_GetAbsPath(m, S(m, "./config/app.conf"));
// Result: /home/user/config/app.conf (fixed)

chdir("/tmp");
File_Open(bf, abspath, O_RDONLY);  // Still opens /home/user/config/app.conf
```

### Pitfall 6: Directory Recursion Infinite Loop

**Problem**:

```c
// Symlink creates cycle: ./a -> ./b, ./b -> ./a
Dir_Climb(m, S(m, "./a"), my_callback, NULL, NULL);
// Infinite recursion!
```

**Solution**: Track visited directories:

```c
typedef struct {
    Table *visited;  // Hash table of visited paths
} DirState;

static status safe_dir_callback(MemCh *m, StrVec *path, void *source){
    DirState *state = (DirState *)source;
    Str *pathstr = StrVec_ToStr(m, path);

    if(Table_Has(state->visited, pathstr)){
        return NOOP;  // Already visited, skip
    }

    Table_Put(state->visited, pathstr, pathstr);
    return SUCCESS;  // Continue recursion
}
```

**Note**: Caneka's `Dir_Climb` has guard variables to prevent excessive recursion, but explicit cycle detection is more robust.

### Pitfall 7: Subprocess Pipe Deadlock

**Problem**:

```c
// Parent writes large data to child stdin, then reads stdout
ProcDets pd;
SubCall(m, cmd, &pd);

// Write 1MB to stdin
Buff *input = Buff_Make(m, ZERO);
Buff_SetFd(input, pd.inFd);
Buff_AddBytes(input, large_data, 1024*1024);
Buff_Flush(input);  // BLOCKS: child's stdout buffer full, waiting for parent to read

// Never reaches this
Buff *output = Buff_Make(m, ZERO);
Buff_SetFd(output, pd.outFd);
Buff_Read(output);
```

**Solution**: Use non-blocking I/O or read/write concurrently:

```c
pd.type.state = PROCDETS_ASYNC|PROCDETS_PIPES;
SubCall(m, cmd, &pd);

// Set non-blocking
fcntl(pd.inFd, F_SETFL, O_NONBLOCK);
fcntl(pd.outFd, F_SETFL, O_NONBLOCK);

// Interleave writes and reads
while(bytes_to_write > 0 || !output_complete){
    if(bytes_to_write > 0){
        // Write chunk
        ssize_t sent = write(pd.inFd, data + offset, min(4096, bytes_to_write));
        if(sent > 0){
            offset += sent;
            bytes_to_write -= sent;
        }
    }

    // Read output
    byte buf[4096];
    ssize_t received = read(pd.outFd, buf, 4096);
    if(received > 0){
        // Process output...
    }else if(received == 0){
        output_complete = TRUE;
    }
}
```

### Pitfall 8: File Descriptor Leaks

**Problem**:

```c
for(i32 i = 0; i < 1000; i++){
    Buff *bf = Buff_Make(m, ZERO);
    File_Open(bf, paths[i], O_RDONLY);
    Buff_Read(bf);
    // File_Close() never called!
}
// Eventually: "Too many open files" error
```

**Solution**: Always close or rely on MemCh cleanup:

```c
for(i32 i = 0; i < 1000; i++){
    MemCh *m_iter = MemCh_Make();  // Per-iteration context
    Buff *bf = Buff_Make(m_iter, ZERO);
    File_Open(bf, paths[i], O_RDONLY);
    Buff_Read(bf);
    MemCh_Free(m_iter);  // Closes all fds allocated in this context
}
```

**Or explicit close**:

```c
for(i32 i = 0; i < 1000; i++){
    Buff *bf = Buff_Make(m, ZERO);
    File_Open(bf, paths[i], O_RDONLY);
    Buff_Read(bf);
    File_Close(bf);  // Explicit close
}
```

### Pitfall 9: Incorrect Unsent Tracking After Seek

**Problem**:

```c
Buff *bf = Buff_Make(m, ZERO);
File_Open(bf, path, O_RDONLY);
Buff_Read(bf);  // Reads data into bf->v

Buff_PosAbs(bf, 0);  // Seek back to start
Buff_Read(bf);  // Reads more data, but unsent tracking may be incorrect
```

**Solution**: Reset unsent tracking after seek:

```c
Buff_PosAbs(bf, 0);

// Reset unsent tracking
bf->unsent.idx = 0;
bf->unsent.offset = 0;
bf->unsent.s = Span_Get(bf->v->p, 0);
bf->unsent.total = bf->v->total;

Buff_Read(bf);  // Correct behavior
```

**Better**: Use separate Buff for each read session, or clear StrVec between reads.

### Pitfall 10: Modification Time Race Condition

**Problem**:

```c
// Check if source newer than build
if(IoUtil_CmpUpdated(m, source, build)){
    // Race: source modified between check and build
    rebuild(source, build);
}
```

**Solution**: Check modification time again after build:

```c
struct timespec before;
File_ModTime(m, source, &before);

rebuild(source, build);

struct timespec after;
File_ModTime(m, source, &after);

if(after.tv_sec != before.tv_sec){
    // Source modified during build, rebuild again
    rebuild(source, build);
}
```

**Alternative**: Use file locking (`flock`) during build process.


## Cross-References

### Related Core Concepts

- **[MemCh Complete](../memory/memchapter.md)**: Memory context management and allocation lifecycle
- **[Str/StrVec/Cursor Complete](../strings-complete.md)**: String handling and zero-copy composition
- **[Span Complete](../memory/span-complete.md)**: Sparse array storage underlying StrVec
- **[Iter Complete](../memory/iter-complete.md)**: Iterator pattern for traversing StrVec contents
- **[Type System Complete](../type-system-complete.md)**: Runtime type identification and flags

### Integration Points

- **[Buff I/O Complete](../buff-io-complete.md)**: Comprehensive buffered I/O guide (this doc's foundation)
- **[HTTP Lifecycle Complete](../http-lifecycle-complete.md)**: Socket operations and HTTP request handling
- **[TCP Server Complete](../tcp-server-complete.md)**: Non-blocking socket I/O with poll()
- **[WWW Routing Complete](../www-routing-complete.md)**: File-based routing and static file serving
- **[BinSeg Complete](../binseg-complete.md)**: Serialization using Buff for I/O

### Implementation Files

- **Headers**: `src/base/include/io/file.h`, `buff.h`, `dir.h`, `ioutil.h`, `subprocess.h`
- **Implementation**: `src/base/src/io/file.c`, `buff.c`, `dir.c`, `ioutil.c`, `subprocess.c`
- **Tests**: `src/programs/test/option/base/buff_tests.c`
- **Examples**: `examples/` directory for practical usage patterns

---

*This documentation provides a comprehensive guide to Caneka's file operations. For specific use cases or advanced patterns, refer to the test suite and example programs in the codebase.*



---

[← Part 2](file-operations-complete-part2) | **Part 3 of 3**
