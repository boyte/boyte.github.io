# Stash: Complete Guide to Memory Persistence - Part 1

**Part 1 of 3** | [Part 2 →](stash-complete-part2)

---

## Core Philosophy

**Stash** is Caneka's page-based memory serialization system designed to persist entire MemCh (memory context) objects to disk and restore them while preserving all internal pointer references. Unlike BinSeg (which serializes individual data structures for data exchange), Stash serializes the underlying memory pages themselves, converting absolute pointers to relative offsets that can be reconstructed when the memory is loaded back.

### Design Principles

1. **Page-Level Serialization**: Writes raw 4096-byte memory pages directly to disk without interpretation
2. **Pointer Compression**: Converts absolute 64-bit pointers to relative 12-bit page offsets + page index
3. **Bidirectional Transformation**: Pack (memory→disk) and Unpack (disk→memory) operations maintain pointer integrity
4. **Hierarchical Traversal**: Uses MemIter to walk every allocated object across all pages
5. **Type-Aware Restoration**: Preserves type information via StashCoord coordinates
6. **Integrity Verification**: Checksum validation ensures all pointers were correctly transformed

### Key Insight: Memory Pages as Serialization Units

Traditional serialization approaches walk object graphs recursively, writing field-by-field representations. Stash takes a radically different approach by treating memory pages as opaque byte arrays and serializing them wholesale:

```c
// Traditional approach (like BinSeg)
void serialize_table(Table *t, Buff *bf) {
    // Write each field
    Buff_Add(bf, &t->size);
    Buff_Add(bf, &t->capacity);
    // Recursively serialize each entry...
}

// Stash approach
void serialize_memch(MemCh *m, Buff *bf) {
    // Write entire pages as raw bytes
    for(each page in m) {
        Buff_AddBytes(bf, page, 4096);
    }
}
```

The advantage: **speed and simplicity**. No recursive traversal needed during writing—just copy memory pages to disk. The complexity comes in **pointer transformation**: before writing, all absolute pointers must be converted to relative coordinates; after reading, all coordinates must be converted back to pointers.

### Comparison: Stash vs BinSeg

| Aspect | Stash | BinSeg |
|--------|-------|--------|
| **What** | Raw memory pages | Structured data |
| **Granularity** | Page-level (4KB) | Object-level |
| **Pointers** | Preserved via relative offsets | No internal pointers |
| **Speed** | Very fast (raw writes) | Slower (recursive serialization) |
| **Size** | Exact memory footprint | Header overhead |
| **Use cases** | Session state, checkpoints | HTTP payloads, data exchange |
| **Restoration** | Complete memory context | Individual objects |

**When to use Stash**:
- Session persistence (save entire session state)
- Crash recovery (checkpoint application state)
- Multi-process state sharing (serialize MemCh, pass to another process)
- Fast save/restore of complex object graphs

**When to use BinSeg**:
- HTTP response bodies
- Network protocol messages
- Cross-language data exchange
- Partial object serialization

### Real-World Use Case: Session Persistence

Caneka's session management system ([src/passport/session/ssid.c](../../../src/passport/session/ssid.c)) uses Stash to persist session dictionaries containing user agent strings, session IDs, and authentication state:

```c
// Save session
MemCh *pst = MemCh_Make();
Table *dict = Table_Make(pst);
Table_Set(dict, S(pst, "user-agent"), StrVec_Str(pst, ua));
Table_Set(dict, S(pst, "orig-ssid"), StrVec_Str(pst, ssid));
pst->owner = dict;

Buff *bf = Buff_Make(m, ZERO);
File_Open(bf, session_path, O_WRONLY|O_CREAT|O_TRUNC);
Stash_FlushFree(bf, pst);  // Serializes entire MemCh to disk
File_Close(bf);

// Load session
Buff *bf = Buff_Make(m, ZERO);
File_Open(bf, session_path, O_RDONLY);
MemCh *stash = Stash_FromStream(bf);  // Reconstructs MemCh from disk
File_Close(bf);

Table *session = (Table *)stash->owner;
// All strings, keys, values perfectly restored with pointers intact
```

The entire session Table—including all its internal hash table structure, collision chains, and string data—is serialized and restored as a single atomic unit. No manual field-by-field serialization code needed.


## Structure and Key Definitions

### StashCoord: Serialized Address Coordinates

```c
typedef struct ref_coords {
    cls typeOf;      // Type of object this coordinate points to
    i16 idx;         // Page index (slot within MemCh's page array)
    quad offset;     // Offset within the page (12-bit value, 0-4095)
} StashCoord;

void StashCoord_Fill(StashCoord *coord, i32 slIdx, void *ptr, cls typeOf);
```

**Location**: [src/base/include/io/stash_coord.h](../../../src/base/include/io/stash_coord.h)

**Purpose**: Replaces an absolute pointer with a relative address that can be reconstructed when memory is loaded from disk.

**Field Semantics**:

- **typeOf** (cls/word): Runtime type identifier (e.g., `TYPE_STR`, `TYPE_TABLE`, `TYPE_SPAN`)
- **idx** (i16): Page index in the MemCh's page array (0 to PAGE_COUNT-1)
- **offset** (quad): 32-bit value encoding the offset within the page—only lower 12 bits used due to `MEM_STASH_MASK`

**Size**: 8 bytes (word + i16 + quad) — same size as a 64-bit pointer!

**Example Encoding**:

```c
// Original pointer: 0x7F42ABC3 (absolute address in page 127)
// Page lives at virtual address: 0x7F42A000
// Object offset within page: 0xBC3 (lower 12 bits)

StashCoord coord = {
    .typeOf = TYPE_STR,
    .idx = 127,        // Page 127
    .offset = 0xBC3    // Offset 0xBC3 within page
};
```

**Key Constraint**: Because pages are always 4096 bytes (2^12), any offset within a page requires exactly 12 bits to represent (0-4095). This is why `MEM_STASH_MASK` is 0xFFF (4095)—it extracts the lower 12 bits of an address.

**StashCoord_Fill Implementation**:

```c
void StashCoord_Fill(StashCoord *coord, i32 slIdx, void *ptr, cls typeOf){
    util u = (util)ptr;
    u &= MEM_STASH_MASK;  // Extract lower 12 bits

    coord->typeOf = typeOf;
    coord->idx = slIdx;
    coord->offset = (quad)u;
}
```

### StashItem: Metadata Container

```c
typedef struct persist_item {
    Type type;        // type.of = TYPE_STASH_ITEM
    void *ptr;        // Original pointer (before packing)
    StashCoord coord; // The packed coordinate
} StashItem;

StashItem *StashItem_Make(MemCh *m, i32 slIdx, void *ptr, cls typeOf);
```

**Location**: [src/base/include/io/stash_item.h](../../../src/base/include/io/stash_item.h)

**Purpose**: Tracks the mapping between original pointers and their serialized coordinates during the packing phase. Used to build a lookup table for pointer-to-coordinate conversion.

**Lifecycle**:

1. **Creation**: During `Stash_FlushFree()`, for every object found, create a StashItem
2. **Storage**: Store in a hash Table keyed by the pointer address
3. **Lookup**: When packing a pointer field, look up the pointer to get its coordinate
4. **Disposal**: Table is freed after packing completes

**Implementation**:

```c
StashItem *StashItem_Make(MemCh *m, i32 slIdx, void *ptr, cls typeOf){
    StashItem *item = MemCh_AllocOf(m, sizeof(StashItem), TYPE_STASH_ITEM);
    item->type.of = TYPE_STASH_ITEM;
    item->ptr = ptr;
    StashCoord_Fill(&item->coord, slIdx, ptr, typeOf);
    return item;
}
```

**Usage Pattern**:

```c
// Build lookup table
Table *tbl = Table_Make(m);

MemIter mit;
MemIter_Init(&mit, persist);

while((MemIter_Next(&mit) & END) == 0){
    Abstract *a = (Abstract *)MemIter_Get(&mit);
    void *ptr = (void *)a;

    // Map pointer → StashItem
    Table_Set(tbl, Util_Wrapped(m, (util)ptr),
        StashItem_Make(m, mit.slIdx, ptr, a->type.of));
}

// Later: lookup pointer to get coordinate
void *some_field = object->field_ptr;
StashItem *item = (StashItem *)Table_Get(tbl, Util_Wrapped(m, (util)some_field));
// item->coord contains the packed coordinate
```

### StashHeader: Persistence File Header

```c
typedef struct persist_header {
    i16 pages;        // Number of memory pages in the file
    i16 checksum;     // Count of pointer references packed (for validation)
} StashHeader;
```

**Location**: [src/base/include/io/stash_header.h](../../../src/base/include/io/stash_header.h)

**Purpose**: File header written once at the beginning of a Stash file. Enables readers to:
1. Pre-allocate the page array (know how many pages to read)
2. Validate data integrity (checksum must match pointer count)

**Size**: 4 bytes (i16 + i16)

**File Layout**:

```
Byte Offset | Content
------------|----------------------------------------------------------
0-3         | StashHeader (pages=N, checksum=C)
4-4099      | MemPage 0 (4096 bytes)
4100-8195   | MemPage 1 (4096 bytes)
...
(N×4096)+4  | MemPage N-1 (4096 bytes)
```

**Example**:

```c
// Writing
StashHeader hdr = {
    .pages = 3,      // 3 pages to follow
    .checksum = 47   // 47 pointers were packed
};
Buff_AddBytes(bf, (byte *)&hdr, sizeof(StashHeader));

// Reading
StashHeader hdr;
Str s = {.bytes = (byte *)&hdr, .alloc = sizeof(StashHeader)};
Buff_GetStr(bf, &s);

// Pre-allocate page array
void **pages = (void **)Bytes_Alloc(m, hdr.pages * sizeof(void *),
    TYPE_POINTER_ARRAY);
```

### MemPage Structure

```c
typedef struct mem_page {
    Type type;        // type.of identifies this as a MemPage
    i16 level;        // Allocation level
    i16 remaining;    // Available space left in page
} MemPage;

#define PAGE_SIZE 4096
#define MEM_SLAB_SIZE (PAGE_SIZE - sizeof(MemPage))  // = 4088 bytes usable
```

**Location**: [src/base/include/mem/mem_page.h](../../../src/base/include/mem/mem_page.h)

**Structure**:

```
Byte 0-7:     Type (type.of + flags)
Byte 8-9:     i16 level
Byte 10-11:   i16 remaining
Byte 12-4095: Usable space (4088 bytes)
```

**Key Insight**: The page header takes 8 bytes (Type is a word), leaving **4088 bytes** for allocations. When Stash writes a page, it writes all 4096 bytes including the header.

### MEM_STASH_MASK: Page Offset Encoding

```c
#define MEM_STASH_MASK 4095  // Binary: 0xFFF (12 bits set)
```

**Purpose**: Extracts the lower 12 bits of an address (the intra-page offset).

**Why 12 bits?**

- Pages are 4096 bytes (2^12)
- Any offset within a page: 0 to 4095
- Representable in 12 bits
- Mask of 0xFFF extracts exactly those 12 bits

**Bit Layout**:

```
64-bit pointer:
┌──────────────────────────────────┬──────────────┐
│  Upper 52 bits (page identity)  │ Lower 12 bits│
│                                  │ (page offset)│
└──────────────────────────────────┴──────────────┘
                                    └─ MEM_STASH_MASK

Example:
Pointer:    0x00007F42ABC3
            ├─────────┘└─┘
            │          └─ Offset: 0xBC3 (3011)
            └─ Page number context (implicit)

After mask:
util offset = 0x00007F42ABC3 & 0xFFF;
// offset = 0xBC3
```

**Usage in Pack**:

```c
status Stash_PackAddr(cls typeOf, i32 slIdx, void **ptr){
    util u = (util)*ptr;
    u &= MEM_STASH_MASK;  // Extract lower 12 bits

    StashCoord coord = {
       .typeOf = typeOf,
       .idx = slIdx,
       .offset = (quad)u,
    };

    memcpy(ptr, &coord, sizeof(void *));
    return SUCCESS;
}
```

**Usage in Unpack**:

```c
cls Stash_UnpackAddr(MemCh *m, StashCoord *coord, void **arr){
    MemPage *pg = (MemPage *)arr[coord->idx];  // Get page base address

    util u = (util)pg;      // Page base: 0x00007F42A000
    u |= coord->offset;     // OR offset:  0x00000000BC3
                            // Result:     0x00007F42ABC3

    void *ptr = (void *)coord;
    memcpy(ptr, &u, sizeof(void *));

    return coord->typeOf;
}
```

**Why OR instead of ADD?**

Because `coord->offset` contains only the lower 12 bits (all upper bits are 0), ORing with the page base address:
- Preserves all upper bits from the page address
- Inserts the correct lower 12 bits
- Mathematically equivalent to addition when offset less than 4096



---

**Part 1 of 3** | [Part 2 →](stash-complete-part2)
