# Terminal I/O - Complete Guide

The Caneka Terminal I/O (TermIO) module provides comprehensive **terminal control, ANSI color support, and command-line argument parsing** for building modern CLI applications. It handles raw terminal mode, interactive status displays, and declarative argument specification with automatic validation.

## Why Terminal I/O?

Building CLI tools requires handling terminal complexity:

- **ANSI Escape Sequences**: Colors, cursor movement, text formatting
- **Raw Mode**: Disable line buffering for interactive input
- **Argument Parsing**: Declarative command-line interface with validation
- **Status Display**: Live-updating progress bars and status lines

**Caneka's TermIO consolidates all terminal concerns** into a unified, easy-to-use system.

## Architecture Overview

```
┌──────────────────────────────────────────────────────────────┐
│                    TERMINAL I/O MODULE                       │
├──────────────────────────────────────────────────────────────┤
│  Location: src/base/termio/                                  │
│                                                               │
│  ┌────────────────┐    ┌──────────────┐   ┌──────────────┐ │
│  │  ANSI Colors   │    │  Raw Mode    │   │  CLI Args    │ │
│  │  ansi.h        │    │  rawmode.h   │   │  args.h      │ │
│  │  ansi_str.h    │    │              │   │              │ │
│  └────────────────┘    └──────────────┘   └──────────────┘ │
│         │                      │                   │         │
│         │                      │                   │         │
│         ▼                      ▼                   ▼         │
│  ┌──────────────────────────────────────────────────────┐   │
│  │            CLI Status Display (cli_status.h)         │   │
│  │   Interactive status bars with custom rendering      │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  Output: Colored terminal text, interactive CLIs             │
└──────────────────────────────────────────────────────────────┘
```

## Module Components

### 1. ANSI Colors and Escape Sequences

**Location**: `src/base/termio/ansi.h`, `ansi_str.h`

ANSI escape sequences control terminal behavior: colors, cursor movement, text attributes.

**Color Constants**:
```c
// Standard terminal colors (0-15)
#define COLOR_BLACK   0
#define COLOR_RED     1
#define COLOR_GREEN   2
#define COLOR_YELLOW  3
#define COLOR_BLUE    4
#define COLOR_MAGENTA 5
#define COLOR_CYAN    6
#define COLOR_WHITE   7

#define COLOR_BRIGHT  8   // Add to base color for bright variant
#define COLOR_DARK    0   // Default (no brightness modifier)

// Example: Bright red = COLOR_RED + COLOR_BRIGHT = 9
```

**Key Code Constants**:
```c
#define KEY_ESCAPE    27
#define KEY_BACKSPACE 127  // DEL character
#define KEY_DELETE    '\b' // Backspace character
#define KEY_ENTER     '\n'
#define KEY_TAB       '\t'
```

**Global ANSI Strings**:
```c
extern const char *ansi_red;
extern const char *ansi_green;
extern const char *ansi_yellow;
extern const char *ansi_blue;
extern const char *ansi_magenta;
extern const char *ansi_cyan;
extern const char *ansi_white;

extern const char *ansi_reset;    // Reset all attributes
extern const char *ansi_bold;     // Bold text
extern const char *ansi_dim;      // Dim text
extern const char *ansi_clear;    // Clear screen
```

**Example ANSI Sequence**:
```
"\033[31m"  → Red foreground color
"\033[1m"   → Bold text
"\033[0m"   → Reset all attributes
```

### 2. ANSI String Functions

#### Str_FromAnsi - Convert ANSI to Str

```c
Str *Str_FromAnsi(MemCh *m, const char *ansi)
```

**Purpose**: Wrap ANSI escape sequence string as Caneka Str

**Parameters**:
- `m`: Memory context
- `ansi`: ANSI escape sequence (C string)

**Returns**: Str object containing ANSI sequence

**Example**:
```c
Str *red = Str_FromAnsi(m, ansi_red);
Str *msg = S(m, "Error:");
StrVec *colored = Sv(m, red, msg, Str_FromAnsi(m, ansi_reset));

// Output: "\033[31mError:\033[0m"
```

#### Str_AnsiCstr - Create Colored C String

```c
const char *Str_AnsiCstr(MemCh *m, Str *s, const char *ansi)
```

**Purpose**: Wrap string with ANSI color codes

**Parameters**:
- `m`: Memory context
- `s`: String to color
- `ansi`: ANSI color code

**Returns**: C string with color prefix and reset suffix

**Example**:
```c
Str *error = S(m, "File not found");
const char *colored = Str_AnsiCstr(m, error, ansi_red);

printf("%s\n", colored);
// Output (visual): File not found (in red)
// Actual: "\033[31mFile not found\033[0m"
```

#### Ansi_SetColor - Set Foreground Color

```c
void Ansi_SetColor(MemCh *m, Str *dest, i32 color)
```

**Purpose**: Generate ANSI color escape sequence

**Parameters**:
- `m`: Memory context
- `dest`: Destination string (must have sufficient capacity)
- `color`: Color code (0-15, see COLOR_* constants)

**Example**:
```c
Str *ansi = Str_Make(m, 16);
Ansi_SetColor(m, ansi, COLOR_RED + COLOR_BRIGHT);  // Bright red

printf("%sError!%s\n", ansi->bytes, ansi_reset);
```

**Color Calculation**:
- **Normal colors**: 0-7 (foreground code: 30-37)
- **Bright colors**: 8-15 (foreground code: 90-97)

**Generated Sequences**:
```
Color 1 (Red):        "\033[31m"
Color 9 (Bright Red): "\033[91m"
```

#### Ansi_HasColor - Check Color Support

```c
bool Ansi_HasColor()
```

**Purpose**: Detect if terminal supports ANSI colors

**Returns**: `true` if colors supported, `false` otherwise

**Detection Method**: Checks `TERM` environment variable for:
- "xterm"
- "vt100"
- "color"
- "ansi"

**Example**:
```c
if(Ansi_HasColor()){
    printf("%sSuccess!%s\n", ansi_green, ansi_reset);
}else{
    printf("Success!\n");  // Plain text fallback
}
```

**Use Case**: Graceful degradation for terminals without color support (e.g., log files, dumb terminals).

### 3. Raw Terminal Mode

**Location**: `src/base/termio/rawmode.h`

Raw mode disables **line buffering** and **echo**, enabling character-by-character input for interactive applications.

#### SetOriginalTios - Save Terminal State

```c
void SetOriginalTios()
```

**Purpose**: Save current terminal settings for later restoration

**Use Case**: Call before entering raw mode, then restore on exit

**Example**:
```c
SetOriginalTios();  // Save original settings

// Enable raw mode
RawMode();

// Do interactive stuff

// Restore original settings (called via atexit)
```

#### RawMode - Enable Raw Terminal

```c
void RawMode()
```

**Purpose**: Enable raw terminal mode for interactive input

**Changes Made**:
1. **Disable Echo**: Characters not echoed to screen
2. **Disable Canonical Mode**: No line buffering (character-at-a-time)
3. **Disable Signals**: Ctrl+C, Ctrl+Z don't generate signals
4. **Disable Output Processing**: Raw output

**Restored On**: Process exit (via `atexit` handler)

**Example Use Case**:
```c
#include "caneka.h"
#include "termio.h"

int main(){
    SetOriginalTios();
    RawMode();

    printf("Press any key (Esc to quit):\n");

    while(true){
        char c = getchar();
        if(c == KEY_ESCAPE) break;

        printf("You pressed: %c (code: %d)\n", c, c);
    }

    printf("Exiting (terminal restored automatically)\n");
    return 0;
}
```

**Output**:
```
Press any key (Esc to quit):
You pressed: a (code: 97)
You pressed: B (code: 66)
You pressed: 5 (code: 53)
Exiting (terminal restored automatically)
```

**IMPORTANT**: Terminal state restored automatically via `atexit` handler. If program crashes, terminal may be left in raw mode—use `reset` command to fix.

### 4. CLI Status Display

**Location**: `src/base/termio/cli_status.h`

Interactive status bars with custom rendering callbacks for build systems, progress indicators, and live-updating displays.

**Structure**:
```c
typedef struct cli_status {
    Type type;                     // TYPE_CLI_STATUS
    MemCh *m;                      // Memory context
    i32 width;                     // Terminal width (columns)
    i32 height;                    // Terminal height (rows)
    void *data;                    // User data for callbacks
    RenderFunc render;             // Rendering callback
} CliStatus;

typedef void (*RenderFunc)(CliStatus *status);
```

#### CliStatus_Make - Create Status Display

```c
CliStatus *CliStatus_Make(MemCh *m, void *data, RenderFunc render)
```

**Parameters**:
- `m`: Memory context
- `data`: User data passed to render callback
- `render`: Function called to render status

**Returns**: CliStatus object

**Example**:
```c
typedef struct {
    i32 current;
    i32 total;
    const char *message;
} BuildStatus;

void RenderBuildStatus(CliStatus *status){
    BuildStatus *build = (BuildStatus *)status->data;

    i32 percent = (build->current * 100) / build->total;
    i32 bars = (percent * status->width) / 100;

    printf("\r[");
    for(i32 i = 0; i < status->width; i++){
        printf(i < bars ? "=" : " ");
    }
    printf("] %d%% - %s", percent, build->message);
    fflush(stdout);
}

BuildStatus status = {0, 100, "Compiling..."};
CliStatus *cli = CliStatus_Make(m, &status, RenderBuildStatus);
```

#### CliStatus_SetKey - Update Display

```c
void CliStatus_SetKey(CliStatus *status, Str *key, Abstract *value)
```

**Purpose**: Update status data and trigger re-render

**Parameters**:
- `status`: CliStatus object
- `key`: Property name (not currently used in implementation)
- `value`: New value (not currently used in implementation)

**Example**:
```c
// Update progress
buildStatus.current = 50;
buildStatus.message = "Linking...";
CliStatus_SetKey(cli, S(m, "progress"), NULL);

// Renders: [==============                    ] 50% - Linking...
```

**Note**: Current implementation doesn't use key/value parameters—render callback accesses data directly via `status->data`.

#### CliStatus_Print - Render Status

```c
void CliStatus_Print(CliStatus *status)
```

**Purpose**: Call render callback to display status

**Example**:
```c
CliStatus_Print(cli);
// Calls RenderBuildStatus(cli)
```

#### CliStatus_SetDims - Set Terminal Dimensions

```c
void CliStatus_SetDims(CliStatus *status, i32 width, i32 height)
```

**Purpose**: Update terminal dimensions for responsive rendering

**Parameters**:
- `status`: CliStatus object
- `width`: Terminal width (columns)
- `height`: Terminal height (rows)

**Example**:
```c
CliStatus_SetDims(cli, 80, 24);  // Standard 80x24 terminal
```

**Use Case**: Handle `SIGWINCH` (terminal resize signal) to update display dynamically.

### 5. Command-Line Arguments Parser

**Location**: `src/base/termio/args.h`

Declarative command-line argument specification with automatic parsing, validation, and type coercion.

**Structure**:
```c
typedef struct cli_args {
    Type type;                     // TYPE_CLI_ARGS
    MemCh *m;                      // Memory context
    Span *argDefs;                 // Argument definitions
    Table *parsedArgs;             // Parsed argument values
} CliArgs;

// Argument flags
#define ARG_DEFAULT   0            // Required argument
#define ARG_OPTIONAL  (1 << 0)     // Optional argument
#define ARG_MULTIPLE  (1 << 1)     // Accept multiple values
#define ARG_ABS_PATH  (1 << 2)     // Convert to absolute path
#define ARG_CHOICE    (1 << 3)     // Must match one of choices
```

#### CliArgs_Make - Create Argument Parser

```c
CliArgs *CliArgs_Make(MemCh *m)
```

**Returns**: CliArgs object ready for argument definitions

**Example**:
```c
CliArgs *args = CliArgs_Make(m);
```

#### Args_Add - Define Argument

```c
void Args_Add(CliArgs *args, const char *name, const char *description,
              word flags, Span *choices)
```

**Parameters**:
- `args`: CliArgs object
- `name`: Argument name (used in `--name` or as positional)
- `description`: Help text
- `flags`: Combination of ARG_* flags
- `choices`: Allowed values (for ARG_CHOICE), or NULL

**Example**:
```c
// Required positional argument
Args_Add(args, "input-file", "Input file path",
         ARG_ABS_PATH, NULL);

// Optional flag
Args_Add(args, "verbose", "Enable verbose output",
         ARG_OPTIONAL, NULL);

// Multiple values
Args_Add(args, "include", "Include directories",
         ARG_OPTIONAL | ARG_MULTIPLE | ARG_ABS_PATH, NULL);

// Choice argument
Span *modes = Span_Make(m);
Span_Add(modes, S(m, "debug"));
Span_Add(modes, S(m, "release"));
Args_Add(args, "mode", "Build mode",
         ARG_CHOICE, modes);
```

#### CliArgs_Parse - Parse Command Line

```c
status CliArgs_Parse(CliArgs *args, int argc, char **argv)
```

**Parameters**:
- `args`: CliArgs object with definitions
- `argc`: Argument count from main()
- `argv`: Argument vector from main()

**Returns**: SUCCESS if parsing succeeded, ERROR if validation failed

**Parsing Rules**:
1. **Flags**: Arguments starting with `--` or `-`
2. **Positional**: Arguments without `--` prefix
3. **Values**: Text after `=` or next argument

**Example**:
```c
int main(int argc, char **argv){
    MemCh *m = MemCh_Make();
    CliArgs *args = CliArgs_Make(m);

    Args_Add(args, "input", "Input file", ARG_DEFAULT, NULL);
    Args_Add(args, "output", "Output file", ARG_OPTIONAL, NULL);
    Args_Add(args, "verbose", "Verbose mode", ARG_OPTIONAL, NULL);

    status result = CliArgs_Parse(args, argc, argv);

    if(!(result & SUCCESS)){
        printf("Usage: program <input> [--output FILE] [--verbose]\n");
        return 1;
    }

    // Access parsed arguments
    Str *input = CliArgs_Get(args, "input");
    printf("Input: %s\n", input->bytes);

    return 0;
}
```

**Command Line Examples**:
```bash
# Valid
./program input.txt
./program input.txt --output result.txt
./program input.txt --output=result.txt --verbose

# Invalid (missing required argument)
./program
# Returns ERROR

# Invalid (unknown flag)
./program input.txt --unknown
# Returns ERROR
```

#### CliArgs_Get - Retrieve Argument Value

```c
Str *CliArgs_Get(CliArgs *args, const char *name)
```

**Parameters**:
- `args`: CliArgs object (after parsing)
- `name`: Argument name

**Returns**: Str with argument value, or NULL if not provided

**Example**:
```c
Str *input = CliArgs_Get(args, "input");

if(input != NULL){
    printf("Processing: %s\n", input->bytes);
}else{
    printf("No input file specified\n");
}

// Optional argument
Str *output = CliArgs_Get(args, "output");
if(output == NULL){
    output = S(m, "output.txt");  // Default value
}
```

**Multiple Values**:
```c
// For ARG_MULTIPLE arguments
StrVec *includes = (StrVec *)CliArgs_Get(args, "include");
if(includes != NULL){
    Iter *it = Iter_Make(m, includes->p);
    while(Iter_Next(it)){
        Str *path = (Str *)Iter_Value(it);
        printf("Include: %s\n", path->bytes);
    }
}
```

**Absolute Path Conversion**:
```c
// With ARG_ABS_PATH flag
Args_Add(args, "config", "Config file", ARG_ABS_PATH, NULL);

// Command: ./program --config=./settings.conf
Str *config = CliArgs_Get(args, "config");
// config->bytes: "/home/user/project/settings.conf" (absolute path)
```

## Complete Examples

### Example 1: Colored Error Messages

```c
#include "caneka.h"
#include "termio.h"

void PrintError(MemCh *m, const char *message){
    if(Ansi_HasColor()){
        printf("%s[ERROR]%s %s\n", ansi_red, ansi_reset, message);
    }else{
        printf("[ERROR] %s\n", message);
    }
}

void PrintSuccess(MemCh *m, const char *message){
    if(Ansi_HasColor()){
        printf("%s[OK]%s %s\n", ansi_green, ansi_reset, message);
    }else{
        printf("[OK] %s\n", message);
    }
}

int main(){
    MemCh *m = MemCh_Make();

    PrintError(m, "Connection timeout");
    PrintSuccess(m, "File saved successfully");

    MemCh_Free(m);
    return 0;
}
```

**Output** (with color support):
```
[ERROR] Connection timeout  (in red)
[OK] File saved successfully  (in green)
```

### Example 2: Interactive Password Input

```c
#include "caneka.h"
#include "termio.h"
#include <stdio.h>

Str *ReadPassword(MemCh *m){
    SetOriginalTios();
    RawMode();

    printf("Enter password: ");
    fflush(stdout);

    Str *password = Str_Make(m, 512);
    password->length = 0;

    while(true){
        char c = getchar();

        if(c == KEY_ENTER || c == '\r'){
            printf("\n");
            break;
        }

        if(c == KEY_BACKSPACE || c == KEY_DELETE){
            if(password->length > 0){
                password->length--;
                printf("\b \b");  // Erase character on screen
            }
            continue;
        }

        if(password->length < password->alloc - 1){
            password->bytes[password->length++] = c;
            printf("*");  // Show asterisk instead of character
        }

        fflush(stdout);
    }

    password->bytes[password->length] = '\0';
    return password;
}

int main(){
    MemCh *m = MemCh_Make();

    Str *password = ReadPassword(m);
    printf("Password length: %lld\n", password->length);

    MemCh_Free(m);
    return 0;
}
```

**Output**:
```
Enter password: ********
Password length: 8
```

### Example 3: Build Progress Display

```c
#include "caneka.h"
#include "termio.h"

typedef struct {
    i32 current;
    i32 total;
    Str *currentFile;
} BuildProgress;

void RenderProgress(CliStatus *status){
    BuildProgress *progress = (BuildProgress *)status->data;

    i32 percent = (progress->current * 100) / progress->total;
    i32 barWidth = status->width - 30;  // Leave room for text
    i32 filled = (percent * barWidth) / 100;

    printf("\r[");
    for(i32 i = 0; i < barWidth; i++){
        printf(i < filled ? "=" : " ");
    }
    printf("] %3d%% ", percent);

    if(Ansi_HasColor()){
        printf("%s%s%s", ansi_cyan, progress->currentFile->bytes, ansi_reset);
    }else{
        printf("%s", progress->currentFile->bytes);
    }

    fflush(stdout);
}

int main(){
    MemCh *m = MemCh_Make();

    BuildProgress progress = {0, 10, S(m, "init.c")};
    CliStatus *status = CliStatus_Make(m, &progress, RenderProgress);
    CliStatus_SetDims(status, 80, 24);

    const char *files[] = {
        "init.c", "parser.c", "memory.c", "strings.c", "io.c",
        "types.c", "table.c", "server.c", "http.c", "main.c"
    };

    for(i32 i = 0; i < 10; i++){
        progress.current = i + 1;
        progress.currentFile = S(m, files[i]);

        CliStatus_Print(status);
        usleep(500000);  // Sleep 0.5 seconds
    }

    printf("\nBuild complete!\n");

    MemCh_Free(m);
    return 0;
}
```

**Output** (animated):
```
[===============               ] 50% parser.c
[==============================] 100% main.c
Build complete!
```

### Example 4: CLI Tool with Arguments

```c
#include "caneka.h"
#include "termio.h"

int main(int argc, char **argv){
    MemCh *m = MemCh_Make();
    CliArgs *args = CliArgs_Make(m);

    // Define arguments
    Args_Add(args, "input", "Input file to process", ARG_ABS_PATH, NULL);
    Args_Add(args, "output", "Output file", ARG_OPTIONAL | ARG_ABS_PATH, NULL);
    Args_Add(args, "verbose", "Enable verbose output", ARG_OPTIONAL, NULL);
    Args_Add(args, "format", "Output format", ARG_OPTIONAL | ARG_CHOICE,
             Sv(m, "json", "xml", "csv")->p);

    // Parse
    status result = CliArgs_Parse(args, argc, argv);

    if(!(result & SUCCESS)){
        printf("%sError: Invalid arguments%s\n", ansi_red, ansi_reset);
        printf("Usage: %s <input> [--output FILE] [--verbose] [--format json|xml|csv]\n",
               argv[0]);
        return 1;
    }

    // Retrieve arguments
    Str *input = CliArgs_Get(args, "input");
    Str *output = CliArgs_Get(args, "output");
    Str *verbose = CliArgs_Get(args, "verbose");
    Str *format = CliArgs_Get(args, "format");

    if(output == NULL){
        output = S(m, "output.txt");
    }

    if(format == NULL){
        format = S(m, "json");
    }

    if(verbose != NULL){
        printf("%sVerbose mode enabled%s\n", ansi_yellow, ansi_reset);
    }

    printf("Processing: %s\n", input->bytes);
    printf("Output: %s\n", output->bytes);
    printf("Format: %s\n", format->bytes);

    MemCh_Free(m);
    return 0;
}
```

**Usage**:
```bash
# Valid
./tool input.txt
./tool input.txt --output=result.json --format=json --verbose

# Invalid (missing required input)
./tool
# Output: Error: Invalid arguments

# Invalid (wrong choice)
./tool input.txt --format=yaml
# Output: Error: Invalid arguments
```

## Best Practices

### 1. Always Check Color Support

```c
// ✅ GOOD: Check before using colors
if(Ansi_HasColor()){
    printf("%sError%s\n", ansi_red, ansi_reset);
}else{
    printf("Error\n");
}

// ❌ BAD: Always use colors
printf("%sError%s\n", ansi_red, ansi_reset);
// Produces garbage in dumb terminals or log files
```

### 2. Reset Terminal State

```c
// ✅ GOOD: Save and restore terminal
int main(){
    SetOriginalTios();  // Save
    RawMode();          // Modify

    // Interactive code

    // Restored automatically on exit
    return 0;
}

// ❌ BAD: Don't save original state
// If program crashes, terminal left in raw mode
```

### 3. Validate Argument Parsing

```c
// ✅ GOOD: Check parse result
status result = CliArgs_Parse(args, argc, argv);
if(!(result & SUCCESS)){
    // Show usage and exit
    return 1;
}

// ❌ BAD: Ignore parse result
CliArgs_Parse(args, argc, argv);
Str *input = CliArgs_Get(args, "input");  // May be NULL!
```

### 4. Use ARG_ABS_PATH for File Paths

```c
// ✅ GOOD: Convert to absolute path
Args_Add(args, "config", "Config file", ARG_ABS_PATH, NULL);

// Command: ./tool --config=./settings.conf
Str *config = CliArgs_Get(args, "config");
// config: "/home/user/project/settings.conf"

// ❌ BAD: Use relative path
// May break if program changes directories
```

### 5. Flush Status Displays

```c
// ✅ GOOD: Flush stdout after status update
printf("\r[Progress] %d%%", percent);
fflush(stdout);

// ❌ BAD: Don't flush
// Status may not appear until line break
```

## Common Pitfalls

### Pitfall 1: Forgetting ANSI Reset

```c
// ❌ BAD: No reset - all subsequent text is red!
printf("%sError\n", ansi_red);
printf("This is also red!\n");

// ✅ GOOD: Always reset after color
printf("%sError%s\n", ansi_red, ansi_reset);
printf("This is normal text\n");
```

### Pitfall 2: Raw Mode Without Restore

```c
// ❌ BAD: No SetOriginalTios()
int main(){
    RawMode();
    // If program crashes, terminal broken!
}

// ✅ GOOD: Save original state
int main(){
    SetOriginalTios();  // Automatically restores on exit
    RawMode();
}
```

### Pitfall 3: Missing Required Arguments

```c
// ❌ BAD: Assume argument exists
Str *input = CliArgs_Get(args, "input");
File_Open(bf, input, O_RDONLY);  // CRASH if input is NULL!

// ✅ GOOD: Check for NULL
Str *input = CliArgs_Get(args, "input");
if(input == NULL){
    printf("Error: input file required\n");
    return 1;
}
```

### Pitfall 4: Wrong Terminal Width

```c
// ❌ BAD: Hard-code width
for(i32 i = 0; i < 80; i++){  // May overflow on narrow terminals
    printf("=");
}

// ✅ GOOD: Use actual terminal width
CliStatus_SetDims(status, actualWidth, actualHeight);
// Render using status->width
```

## Function Reference

| Function | Purpose |
|----------|---------|
| **ANSI Colors** | |
| `Str_FromAnsi(m, ansi)` | Convert ANSI string to Str |
| `Str_AnsiCstr(m, s, ansi)` | Wrap string with color codes |
| `Ansi_SetColor(m, dest, color)` | Generate color escape sequence |
| `Ansi_HasColor()` | Check terminal color support |
| **Raw Mode** | |
| `SetOriginalTios()` | Save terminal state |
| `RawMode()` | Enable raw terminal mode |
| **CLI Status** | |
| `CliStatus_Make(m, data, render)` | Create status display |
| `CliStatus_SetKey(status, key, value)` | Update and re-render |
| `CliStatus_Print(status)` | Call render callback |
| `CliStatus_SetDims(status, width, height)` | Set terminal dimensions |
| **CLI Arguments** | |
| `CliArgs_Make(m)` | Create argument parser |
| `Args_Add(args, name, desc, flags, choices)` | Define argument |
| `CliArgs_Parse(args, argc, argv)` | Parse command line |
| `CliArgs_Get(args, name)` | Retrieve argument value |

## Summary

The Terminal I/O module provides **comprehensive CLI building blocks** with:

**Strengths**:
- ✅ ANSI color support with automatic detection
- ✅ Raw terminal mode for interactive input
- ✅ Declarative argument parsing with validation
- ✅ Interactive status displays with custom rendering
- ✅ Automatic terminal state restoration

**Use Cases**:
- Command-line tools (build systems, utilities)
- Interactive applications (text editors, games)
- Progress indicators (file transfers, compilation)
- Colored log output (errors, warnings, success)

**Best For**:
- Applications requiring rich terminal output
- Tools with complex command-line interfaces
- Interactive CLI programs
- Build systems and development tools

**Examples in Caneka**:
- `buildeka`: Build system with progress display
- `clineka`: CLI tool with argument parsing
- `test`: Test runner with colored output

The module is **production-ready** and used throughout Caneka's own CLI tools.
