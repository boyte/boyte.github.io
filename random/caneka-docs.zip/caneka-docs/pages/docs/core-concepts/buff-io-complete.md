---
sidebar_position: 8
---

# Buff I/O - Complete Guide

**Buff** is Caneka's buffered I/O abstraction that wraps file descriptors and sockets with smart buffering. It provides a unified interface for reading, writing, and manipulating data whether it comes from files, sockets, or memory.

## Core Philosophy

Traditional I/O libraries force you to choose between:
- **Buffered I/O** (fread/fwrite): Memory overhead, delayed writes
- **Unbuffered I/O** (read/write): System call overhead, poor performance

Caneka's Buff provides both modes **in the same structure**, switching based on flags. It also integrates seamlessly with the StrVec multi-part string system for zero-copy operations.

**Key Insights:**
1. **StrVec-based buffering**: Leverages multi-part strings to avoid large contiguous allocations
2. **Dual-pointer tracking**: Separate "tail" (write position) and "unsent" (read position) pointers
3. **Mode flexibility**: Same structure works for files, sockets, and memory buffers
4. **Position seeking**: Navigate buffered data like a file

## Buff Structure

```c
typedef struct buff {
    Type type;           // Type system metadata
    i32 fd;              // File descriptor or socket
    MemCh *m;            // Memory context
    StrVec *v;           // Vector of strings (output buffer)
    struct {
        Str *s;          // Current tail string pointer
        i32 idx;         // Index in vector
    } tail;              // Tracks write position
    struct {
        Str *s;          // Current unsent string pointer
        word offset;     // Byte offset within string
        i32 idx;         // Index in vector
        i64 total;       // Total unsent bytes
    } unsent;            // Tracks read/send position
    struct stat st;      // File statistics (from fstat)
} Buff;
```

### Key Fields

**v (StrVec):** Output buffer holding accumulated data
- Multiple Str objects (avoids large contiguous allocation)
- Zero-copy when data already in strings
- Efficient for building responses

**tail:** Write cursor
- Points to the last Str being written to
- Advances as new data added
- Creates new Str when current fills

**unsent:** Read cursor
- Points to next byte to send/read
- Tracks position across multiple Strs
- Enables seeking within buffered data

**fd:** File descriptor
- File, socket, or -1 for memory-only
- Determines read/write behavior

## Operation Modes

### Buffered Mode (Default)

```c
Buff *bf = Buff_Make(m, ZERO);
```

**Behavior:**
- Data accumulates in StrVec
- No writes to FD until `Buff_Flush()`
- Memory overhead but fewer syscalls
- Ideal for building responses

**Example:**
```c
Buff *response = Buff_Make(m, ZERO);
Buff_AddBytes(response, (byte *)"HTTP/1.1 200 OK\r\n", 17);
Buff_AddBytes(response, (byte *)"Content-Type: text/html\r\n", 25);
Buff_AddBytes(response, (byte *)"\r\n", 2);
Buff_AddBytes(response, (byte *)"<html>...</html>", 16);

// All data in memory, nothing written yet
// response->v->total = 60 bytes

// Now send
Buff_SetSocket(response, socket_fd);
Buff_Flush(response);  // Writes all 60 bytes to socket
```

### Unbuffered Mode

```c
Buff *bf = Buff_Make(m, BUFF_UNBUFFERED);
Buff_SetFd(bf, fd);
```

**Behavior:**
- Data writes immediately to FD
- No accumulation in StrVec
- More syscalls but lower memory
- Ideal for streaming large files

**Example:**
```c
Buff *stream = Buff_Make(m, BUFF_UNBUFFERED);
Buff_SetFd(stream, output_fd);

// Each call writes immediately
Buff_AddBytes(stream, chunk1, len1);  // write() called
Buff_AddBytes(stream, chunk2, len2);  // write() called
Buff_AddBytes(stream, chunk3, len3);  // write() called
```

### Hybrid: Buffered then Unbuffered

```c
// Build in memory first
Buff *bf = Buff_Make(m, ZERO);
Buff_AddBytes(bf, data1, len1);
Buff_AddBytes(bf, data2, len2);

// Later, flush to FD
Buff_SetFd(bf, fd);
Buff_Flush(bf);
```

## Flags

```c
enum send_recv_flags {
    BUFF_ASYNC       = 1 << 8,   // Non-blocking operations
    BUFF_FD          = 1 << 9,   // Regular file descriptor
    BUFF_SOCKET      = 1 << 10,  // Socket file descriptor
    BUFF_DATASYNC    = 1 << 11,  // fdatasync on close
    BUFF_FLUSH       = 1 << 12,  // Clear buffer after flush
    BUFF_UNBUFFERED  = 1 << 13,  // Direct write mode
    BUFF_SLURP       = 1 << 14,  // Read entire file
    BUFF_CLOBBER     = 1 << 15,  // Allow overwrite
};
```

**Common Combinations:**
```c
// HTTP response (buffered, then flush to socket)
Buff_Make(m, ZERO);

// Streaming download (direct socket write)
Buff_Make(m, BUFF_UNBUFFERED);

// Sync file writes (guaranteed durability)
Buff_Make(m, BUFF_DATASYNC);

// Non-blocking socket read
Buff_Make(m, BUFF_ASYNC);

// Flush and reuse buffer
Buff_Make(m, BUFF_FLUSH);
```

## Writing Operations

### Adding Data to Buffer

```c
status Buff_AddBytes(Buff *bf, byte *bytes, i64 length);
```

Adds data to the buffer (buffered) or writes immediately (unbuffered).

**Buffered Mode Algorithm:**
1. Validate length ≤ IO_SEND_MAX (16MB)
2. Get or create tail Str
3. Write bytes to tail Str
4. If tail Str fills, create new Str and continue
5. Update unsent.total and v->total

**Example:**
```c
Buff *bf = Buff_Make(m, ZERO);

char *header = "Content-Type: application/json\r\n";
Buff_AddBytes(bf, (byte *)header, strlen(header));

char *body = "{\"status\":\"ok\"}";
Buff_AddBytes(bf, (byte *)body, strlen(body));

// bf->v now contains multiple Strs with accumulated data
// bf->tail.idx points to last Str
// bf->unsent.total = total bytes
```

### Automatic Tail Management

When the current Str fills:

```c
static void Buff_addTail(Buff *bf) {
    Str *s = Str_Make(bf->m, STR_DEFAULT);  // Create 512-byte Str
    Span_Add(bf->v->p, s);                   // Add to StrVec
    bf->tail.idx = bf->v->p->max_idx;        // Update index
    bf->tail.s = s;                          // Update pointer
}
```

**Why 512 bytes (STR_DEFAULT)?** Balance between allocation overhead and memory waste.

### Adding Strings and StrVecs

```c
status Buff_Add(Buff *bf, Str *s);
status Buff_AddVec(Buff *bf, StrVec *v);
```

**Zero-copy append:**
- Adds Str/StrVec reference directly to buffer
- No data copying
- Ideal when data already in string form

**Example:**
```c
Str *filename = S(m, "data.json");
StrVec *content = File_ToVec(m, filename);

Buff *response = Buff_Make(m, ZERO);
Buff_Add(response, S(m, "HTTP/1.1 200 OK\r\n\r\n"));
Buff_AddVec(response, content);  // Zero-copy add
```

### Flushing Data

```c
status Buff_Flush(Buff *bf);
```

Writes all buffered data to the file descriptor.

**Algorithm:**
1. Loop `Buff_sendToFd()` until all data sent
2. If BUFF_FLUSH flag set, clear all Strs and reset indices
3. Return SUCCESS when complete

**With BUFF_FLUSH:**
```c
Buff *bf = Buff_Make(m, BUFF_FLUSH);
Buff_AddBytes(bf, data1, len1);
Buff_SetFd(bf, fd);
Buff_Flush(bf);
// Buffer wiped, ready for reuse

Buff_AddBytes(bf, data2, len2);
Buff_Flush(bf);
// Buffer wiped again
```

**Without BUFF_FLUSH:**
```c
Buff *bf = Buff_Make(m, ZERO);
Buff_AddBytes(bf, data, len);
Buff_SetFd(bf, fd);
Buff_Flush(bf);
// Data sent, but still in buffer
// bf->unsent.total = 0 (sent)
// bf->v->total still = len (buffered)
```

### Low-Level Write

```c
static status Buff_bytesToFd(Buff *bf, i32 fd, byte *bytes, i64 length, i64 *offset);
```

**Handles partial writes:**
```c
if(bf->type.state & BUFF_SOCKET) {
    sent = send(fd, bytes + *offset, min(length - *offset, IO_BLOCK_SIZE), 0);
} else {
    sent = write(fd, bytes + *offset, min(length - *offset, IO_BLOCK_SIZE));
}

*offset += sent;

if(*offset >= length) {
    return SUCCESS;  // All sent
} else if(sent == 0) {
    return MORE;     // Buffer full, try again
} else {
    return PROCESSING;  // Partial write, continue
}
```

**IO_BLOCK_SIZE (1024):** Chunk size for write operations

## Reading Operations

### Reading from File Descriptor

```c
status Buff_Read(Buff *bf);
status Buff_ReadAmount(Buff *bf, i64 amount);
```

Reads data from FD into the internal StrVec.

**Algorithm:**
1. Create temporary Str for each read
2. Call `read()` or `recv()` (chunked by IO_BLOCK_SIZE)
3. Add resulting Str to StrVec
4. Update total bytes read

**Example:**
```c
i32 fd = open("data.txt", O_RDONLY);
Buff *bf = Buff_Make(m, ZERO);
Buff_SetFd(bf, fd);
Buff_Read(bf);  // Reads entire file into bf->v

// Now buffered in memory
printf("Read %lld bytes\n", bf->v->total);
close(fd);
```

**Socket Example:**
```c
Buff *request = Buff_Make(m, ZERO);
Buff_SetSocket(request, client_fd);
Buff_ReadAmount(request, 4096);  // Read up to 4KB

// Process buffered data
```

### Reading into Pre-allocated String

```c
status Buff_ReadToStr(Buff *bf, Str *s);
```

Fills an existing Str directly from FD (single read).

**Example:**
```c
Str *line = Str_Make(m, 256);  // Pre-allocate 256 bytes
Buff_ReadToStr(bf, line);       // Fill from FD
```

### Getting Data from Buffer

```c
status Buff_GetStr(Buff *bf, Str *s);
```

**Smart buffering:**
1. First, drains from buffered data (unsent.total)
2. Then, reads from FD if needed
3. Respects current position (unsent.idx, unsent.offset)
4. Updates state flags (LAST, END, PROCESSING)

**State Flags:**
- **LAST**: About to read final buffered bytes
- **MORE**: Additional reads needed
- **END**: No more data
- **PROCESSING**: Partial read

**Reading Line by Line:**
```c
Buff *bf = Buff_Make(m, ZERO);
Buff_SetFd(bf, fd);
Buff_Read(bf);  // Load all data

Str *line = Str_Make(m, 128);
while((Buff_GetStr(bf, line) & END) == 0) {
    ProcessLine(line);

    if((bf->type.state & LAST) == 0) {
        line = Str_Make(m, 128);  // Allocate new Str
    }
    // Last line reuses the same Str
}
```

### Reading to StrVec

```c
status Buff_GetToVec(Buff *bf, StrVec *v);
```

Drains entire buffer into a StrVec.

**Example:**
```c
StrVec *content = StrVec_Make(m);
Buff_GetToVec(bf, content);
// All buffered data now in content
```

## Position Management

Buff supports **seeking within buffered data** like a file.

### Absolute Position

```c
status Buff_PosAbs(Buff *bf, i64 position);
```

Seeks to absolute byte position from start (positive) or end (negative).

**Example:**
```c
Buff *bf = Buff_Make(m, ZERO);
Buff_AddBytes(bf, (byte *)"0123456789", 10);

Buff_PosAbs(bf, 5);   // Position at byte 5 ('5')
Buff_PosAbs(bf, -3);  // Position 3 bytes from end ('7')
```

### Relative Position

```c
status Buff_Pos(Buff *bf, i64 offset);
```

Seeks relative to current position.

**Example:**
```c
Buff_PosAbs(bf, 0);  // Start
Buff_Pos(bf, 5);     // Forward 5 bytes
Buff_Pos(bf, -2);    // Back 2 bytes
// Now at position 3
```

### Seek to End

```c
status Buff_PosEnd(Buff *bf);
```

### Position Implementation

**For StrVec (buffered data):**
```c
static status Buff_vecPosFrom(Buff *bf, i32 offset, i64 whence) {
    // Walk through Strs in StrVec
    // Update unsent.idx and unsent.offset
    // Track position across multi-Str buffer
}
```

**For FD (files):**
```c
i64 pos = lseek(bf->fd, offset, whence);
```

**Example: Reading Backwards**
```c
Buff *bf = Buff_Make(m, ZERO);
Buff_AddBytes(bf, (byte *)"The quick brown fox", 19);

// Read from end
Buff_PosAbs(bf, -5);  // Position at "n fox"
Str *tail = Str_Make(m, 256);
Buff_GetStr(bf, tail);
// tail = "n fox"
```

## Buffer Piping

```c
status Buff_Pipe(Buff *to, Buff *from);
```

Transfers all data from one buffer to another.

**Algorithm:**
1. Create temporary Str
2. Loop `Buff_GetStr()` from source
3. Call `Buff_AddBytes()` to destination
4. Preserves all data

**Example: Copy Between Files**
```c
// Read from input
Buff *input = Buff_Make(m, ZERO);
Buff_SetFd(input, open("input.txt", O_RDONLY));
Buff_Read(input);

// Copy to output
Buff *output = Buff_Make(m, ZERO);
Buff_SetFd(output, open("output.txt", O_CREAT|O_WRONLY|O_TRUNC, 0644));
Buff_Pipe(output, input);
Buff_Flush(output);
```

**Example: HTTP Response Assembly**
```c
// Collect multiple response parts
Span *parts = Span_Make(m);
Span_Add(parts, header_buff);
Span_Add(parts, body_buff);
Span_Add(parts, footer_buff);

// Pipe all to output
Buff *response = Buff_Make(m, BUFF_UNBUFFERED);
Buff_SetSocket(response, client_fd);

Iter it = Iter_Make(parts);
while(Iter_HasNext(&it)) {
    Buff *part = Iter_Next(&it);
    Buff_Pipe(response, part);  // Send each part
}
```

## File Descriptor Management

### Setting File Descriptor

```c
status Buff_SetFd(Buff *bf, i32 fd);
```

Attaches a file descriptor.

**Behavior:**
- Sets BUFF_FD flag
- If BUFF_ASYNC: enables non-blocking with `fcntl(F_SETFL, O_NONBLOCK)`

**Example:**
```c
i32 fd = open("data.txt", O_RDONLY);
Buff *bf = Buff_Make(m, ZERO);
Buff_SetFd(bf, fd);
// Now bf reads from fd
```

### Setting Socket

```c
status Buff_SetSocket(Buff *bf, i32 fd);
```

Attaches a socket descriptor.

**Behavior:**
- Sets BUFF_SOCKET flag
- Uses `send()` instead of `write()`
- Uses `recv()` instead of `read()`

**Example:**
```c
i32 sock = socket(AF_INET, SOCK_STREAM, 0);
connect(sock, ...);

Buff *request = Buff_Make(m, ZERO);
Buff_SetSocket(request, sock);
Buff_AddBytes(request, http_request, len);
Buff_Flush(request);
```

### Unsetting

```c
status Buff_UnsetFd(Buff *bf);
status Buff_UnsetSocket(Buff *bf);
```

Detaches FD/socket (doesn't close it).

**Example:**
```c
Buff *bf = Buff_Make(m, ZERO);
Buff_SetFd(bf, fd);
Buff_Flush(bf);
Buff_UnsetFd(bf);  // Detach FD
// fd still open, bf now memory-only
```

## Statistics and Queries

### File Statistics

```c
status Buff_Stat(Buff *bf);
```

Calls `fstat()` on FD and stores in `bf->st`.

**Example:**
```c
Buff_Stat(bf);
printf("File size: %lld bytes\n", bf->st.st_size);
printf("Modified: %s", ctime(&bf->st.st_mtime));
```

### Empty Check

```c
boolean Buff_IsEmpty(Buff *bf);
```

Returns TRUE if buffer contains no data.

**Example:**
```c
if(Buff_IsEmpty(bf)) {
    printf("Buffer is empty\n");
}
```

## Practical Examples

### Example 1: HTTP Server Response

```c
MemCh *m = &book->m;

// Build response in memory
Buff *response = Buff_Make(m, ZERO);

// Status line
Buff_AddBytes(response, (byte *)"HTTP/1.1 200 OK\r\n", 17);

// Headers
Buff_AddBytes(response, (byte *)"Content-Type: text/html\r\n", 25);
Buff_AddBytes(response, (byte *)"Content-Length: ", 16);

// Body
Str *body = S(m, "<html><body>Hello World</body></html>");
char len_str[32];
snprintf(len_str, sizeof(len_str), "%lld\r\n\r\n", (i64)body->length);
Buff_AddBytes(response, (byte *)len_str, strlen(len_str));

Buff_Add(response, body);  // Zero-copy add

// Send to client
Buff_SetSocket(response, client_fd);
Buff_Flush(response);

printf("Sent %lld bytes\n", response->v->total);
```

### Example 2: File Copy with Buffering

```c
// Read input file
i32 input_fd = open("large_file.bin", O_RDONLY);
Buff *input = Buff_Make(m, ZERO);
Buff_SetFd(input, input_fd);
Buff_Read(input);  // Read all into memory
close(input_fd);

// Process data (e.g., encrypt)
ProcessBuffer(input);

// Write to output file
i32 output_fd = open("output.bin", O_CREAT|O_WRONLY|O_TRUNC, 0644);
Buff_SetFd(input, output_fd);  // Reuse same buffer
Buff_Flush(input);
close(output_fd);
```

### Example 3: Socket Echo Server

```c
typedef struct client_ctx {
    Buff *in;
    Buff *out;
} ClientCtx;

status HandleClient(i32 client_fd) {
    MemCh *m = &book->m;
    ClientCtx *ctx = MemCh_AllocOf(m, sizeof(ClientCtx), TYPE_CLIENT);

    // Create buffered input, unbuffered output
    ctx->in = Buff_Make(m, ZERO);
    ctx->out = Buff_Make(m, BUFF_UNBUFFERED);

    Buff_SetSocket(ctx->in, client_fd);
    Buff_SetSocket(ctx->out, client_fd);

    // Read request
    Buff_ReadAmount(ctx->in, 4096);

    // Echo back
    Buff_Pipe(ctx->out, ctx->in);

    return SUCCESS;
}
```

### Example 4: Chunked File Processing

```c
i32 fd = open("log_file.txt", O_RDONLY);
Buff *bf = Buff_Make(m, ZERO);
Buff_SetFd(bf, fd);

Str *line = Str_Make(m, 256);
i32 line_num = 0;

while((Buff_ReadAmount(bf, IO_BLOCK_SIZE) & END) == 0) {
    while((Buff_GetStr(bf, line) & END) == 0) {
        line_num++;
        printf("Line %d: %s\n", line_num, StrVec_GetCStr(line));

        if((bf->type.state & LAST) == 0) {
            line = Str_Make(m, 256);
        }
    }
}

close(fd);
```

### Example 5: Multi-Part Response

```c
// Headers
Buff *headers = Buff_Make(m, ZERO);
Buff_AddBytes(headers, (byte *)"HTTP/1.1 200 OK\r\n", 17);
Buff_AddBytes(headers, (byte *)"Content-Type: text/html\r\n\r\n", 28);

// Body parts
Buff *part1 = Buff_Make(m, ZERO);
Buff_AddBytes(part1, (byte *)"<html><body>", 12);

Buff *part2 = Buff_Make(m, ZERO);
Buff_AddBytes(part2, (byte *)"<h1>Title</h1>", 14);

Buff *part3 = Buff_Make(m, ZERO);
Buff_AddBytes(part3, (byte *)"</body></html>", 14);

// Assemble and send
Buff *response = Buff_Make(m, BUFF_UNBUFFERED);
Buff_SetSocket(response, client_fd);

Buff_Pipe(response, headers);
Buff_Pipe(response, part1);
Buff_Pipe(response, part2);
Buff_Pipe(response, part3);
```

## Performance Characteristics

| Operation | Complexity | Notes |
|-----------|-----------|-------|
| AddBytes (buffered) | O(n) | n = bytes, distributed across Strs |
| AddBytes (unbuffered) | O(k) | k = syscalls (len / IO_BLOCK_SIZE) |
| Read | O(m) | m = data size / IO_BLOCK_SIZE |
| ReadAmount | O(k) | k = syscalls to reach amount |
| GetStr | O(1) per call | Sequential walk through Strs |
| Flush | O(m × IO_BLOCK_SIZE) | m = number of write syscalls |
| Pipe | O(n + m) | n = reads, m = writes |
| Position seek | O(k) | k = Strs to traverse |
| Stat | O(1) | Single fstat syscall |

**Syscall Counts:**
```
Buffered Write:
  AddBytes × 100: 0 syscalls
  Flush: ~ceil(total / IO_BLOCK_SIZE) syscalls

Unbuffered Write:
  AddBytes × 100: 100 syscalls
```

**Memory Overhead:**
```
Buffered: sizeof(Str) × (total / STR_DEFAULT) + sizeof(Buff)
         ≈ 24 bytes × (total / 512) + 128 bytes

Unbuffered: sizeof(Buff) ≈ 128 bytes (no data retained)
```

## Best Practices

1. **Use buffered mode for HTTP responses**: Build entire response in memory, send once
2. **Use unbuffered mode for large file streaming**: Avoid memory overhead
3. **Reuse buffers with BUFF_FLUSH**: Minimize allocations for repeated operations
4. **Check state flags after operations**: Handle LAST, END, PROCESSING correctly
5. **Close FDs explicitly**: Buff doesn't own FDs, caller must close
6. **Use Buff_Pipe for composition**: Combine multiple buffers efficiently

## Common Pitfalls

### Pitfall 1: Forgetting to Set FD

```c
// WRONG - No FD set
Buff *bf = Buff_Make(m, ZERO);
Buff_AddBytes(bf, data, len);
Buff_Flush(bf);  // ERROR: No FD to write to
```

**Fix:**
```c
Buff *bf = Buff_Make(m, ZERO);
Buff_SetFd(bf, fd);  // Set FD first
Buff_AddBytes(bf, data, len);
Buff_Flush(bf);
```

### Pitfall 2: Not Handling Partial Reads

```c
// WRONG - Assuming single read gets all data
Buff_ReadAmount(bf, 1000);
// May not read all 1000 bytes if data not ready
```

**Fix:**
```c
i64 target = 1000;
while(bf->v->total < target && (bf->type.state & (END|ERROR)) == 0) {
    Buff_ReadAmount(bf, target - bf->v->total);
}
```

### Pitfall 3: Modifying Buffer During Iteration

```c
// WRONG - Adding while reading
while((Buff_GetStr(bf, line) & END) == 0) {
    Buff_AddBytes(bf, new_data, len);  // CORRUPTS read position
}
```

**Fix:** Read all data first, then modify

```c
StrVec *lines = StrVec_Make(m);
Buff_GetToVec(bf, lines);  // Drain buffer

// Now modify
Buff_AddBytes(bf, new_data, len);
```

### Pitfall 4: Ignoring END Flag

```c
// WRONG - Infinite loop if END not checked
while(true) {
    Buff_GetStr(bf, line);  // Loops forever at end
    Process(line);
}
```

**Fix:**
```c
while((Buff_GetStr(bf, line) & END) == 0) {
    Process(line);
}
```

### Pitfall 5: Closing FD Too Early

```c
// WRONG - Closing before flush
Buff_AddBytes(bf, data, len);
close(fd);
Buff_Flush(bf);  // ERROR: FD already closed
```

**Fix:**
```c
Buff_AddBytes(bf, data, len);
Buff_Flush(bf);
close(fd);  // Close after flush
```

### Pitfall 6: Not Checking for NULL Line Reuse

```c
// WRONG - Always creating new Str
while((Buff_GetStr(bf, line) & END) == 0) {
    StrVec_Add(lines, line);
    line = Str_Make(m, 256);  // Creates for LAST line too
}
```

**Fix:**
```c
while((Buff_GetStr(bf, line) & END) == 0) {
    StrVec_Add(lines, line);
    if((bf->type.state & LAST) == 0) {
        line = Str_Make(m, 256);  // Only if not last
    }
}
```

## Advanced Patterns

### Pattern 1: Async Socket Reading

```c
Buff *bf = Buff_Make(m, BUFF_ASYNC);
Buff_SetSocket(bf, non_blocking_fd);

status result = Buff_ReadAmount(bf, 4096);
if(result & MORE) {
    // Would block, try again later
    return PROCESSING;
}
else if(result & SUCCESS) {
    // Got data, process it
    ProcessRequest(bf);
}
```

### Pattern 2: Buffered Logging

```c
static Buff *log_buffer;

void Log_Init(MemCh *m) {
    log_buffer = Buff_Make(m, BUFF_FLUSH);
    Buff_SetFd(log_buffer, open("app.log", O_CREAT|O_WRONLY|O_APPEND, 0644));
}

void Log(const char *msg) {
    Buff_AddBytes(log_buffer, (byte *)msg, strlen(msg));
    Buff_AddBytes(log_buffer, (byte *)"\n", 1);

    if(log_buffer->v->total > 4096) {
        Buff_Flush(log_buffer);  // Periodic flush
    }
}

void Log_Close() {
    Buff_Flush(log_buffer);
    close(log_buffer->fd);
}
```

### Pattern 3: Two-Phase Response Building

```c
// Phase 1: Calculate content
Buff *body = Buff_Make(m, ZERO);
BuildDynamicContent(body);

// Phase 2: Add headers
Buff *response = Buff_Make(m, ZERO);
Buff_AddBytes(response, (byte *)"HTTP/1.1 200 OK\r\n", 17);

char content_len[64];
snprintf(content_len, sizeof(content_len),
         "Content-Length: %lld\r\n\r\n", body->v->total);
Buff_AddBytes(response, (byte *)content_len, strlen(content_len));

// Phase 3: Combine and send
Buff_AddVec(response, body->v);  // Zero-copy add
Buff_SetSocket(response, client_fd);
Buff_Flush(response);
```

### Pattern 4: Stateful Line Reader

```c
typedef struct line_reader {
    Buff *bf;
    Str *current;
    boolean eof;
} LineReader;

LineReader *LineReader_Make(MemCh *m, i32 fd) {
    LineReader *lr = MemCh_AllocOf(m, sizeof(LineReader), TYPE_LINE_READER);
    lr->bf = Buff_Make(m, ZERO);
    Buff_SetFd(lr->bf, fd);
    lr->current = Str_Make(m, 256);
    lr->eof = false;
    return lr;
}

Str *LineReader_Next(LineReader *lr) {
    if(lr->eof) return NULL;

    status result = Buff_GetStr(lr->bf, lr->current);

    if(result & END) {
        lr->eof = true;
        return (lr->current->length > 0) ? lr->current : NULL;
    }

    Str *line = lr->current;
    if((lr->bf->type.state & LAST) == 0) {
        lr->current = Str_Make(lr->bf->m, 256);
    }

    return line;
}
```

## See Also

- [String Handling](strings-complete.md) - Str and StrVec used by Buff
- [File Operations](../api-reference/base.md#file-io) - File_Open, File_Close
- [HTTP Handling](http-complete.md) - HTTP protocol using Buff
- [TCP Server](../architecture/ext-layer.md#serve) - Socket-based Buff usage
