# I/O Utilities: Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](io-utilities-complete-part2)

---

## Why I/O Utilities?

Every software system needs robust I/O operations—reading files, traversing directories, managing paths, spawning subprocesses. Caneka's I/O Utilities module (`src/base/io/`) provides a comprehensive foundation for these operations with several key advantages:

1. **Path Safety**: StrVec-based paths eliminate buffer overflow vulnerabilities common in C path handling
2. **Unified Abstractions**: The Buff object unifies file, socket, and memory buffer operations under one interface
3. **Memory Integration**: All operations integrate with MemCh for leak-free resource management
4. **Cross-Platform Design**: Platform-specific code isolated behind clean abstractions
5. **Zero Dependencies**: Built entirely on POSIX primitives with no external libraries

The I/O Utilities system consists of several subsystems:
- **Path Handling** (`ioutil.h`) - Path construction, manipulation, analysis
- **Directory Operations** (`dir.h`) - Traversal, filtering, gathering
- **File Operations** (`file.h`) - Opening, reading, writing, metadata
- **Buffer I/O** (`buff.h`) - Buffered/unbuffered I/O with async support
- **Subprocess Management** (`subprocess.h`) - Process spawning with pipes
- **Socket Utilities** (`sock.h`) - Network connection helpers
- **Stashing** (`stash.h`) - Memory persistence and serialization

This guide focuses on the **Path Handling**, **Directory Operations**, and **Subprocess Management** subsystems. For Buffer I/O details, see [Buff I/O Complete](buff-io-complete.md). For File Operations, see [File Operations Complete](io/file-operations-complete.md). For Stashing, see [Stash Complete](io/stash-complete.md).

---


## Table of Contents

1. [Path Handling](#path-handling)
   - [StrVec Path Representation](#strvec-path-representation)
   - [Path Creation](#path-creation)
   - [Path Analysis](#path-analysis)
   - [Path Manipulation](#path-manipulation)
   - [Extension Handling](#extension-handling)
2. [Directory Operations](#directory-operations)
   - [Directory Existence and Creation](#directory-existence-and-creation)
   - [Directory Traversal](#directory-traversal)
   - [Advanced Gathering with DirSelector](#advanced-gathering-with-dirselector)
   - [Directory Destruction](#directory-destruction)
3. [Subprocess Management](#subprocess-management)
   - [Process Execution Basics](#process-execution-basics)
   - [Pipe Configuration](#pipe-configuration)
   - [Capturing Output](#capturing-output)
   - [Async Process Management](#async-process-management)
4. [Socket Utilities](#socket-utilities)
   - [IPv4 Conversion](#ipv4-conversion)
   - [Network Connection](#network-connection)
5. [Common Patterns](#common-patterns)
6. [Performance Characteristics](#performance-characteristics)
7. [Best Practices](#best-practices)
8. [Common Pitfalls](#common-pitfalls)

---


## Path Handling

### StrVec Path Representation

Caneka represents file paths as **StrVec** objects where each component (directory, filename, extension) is a separate Str element. This representation provides several advantages:

```c
// Traditional C path handling (error-prone)
char path[PATH_MAX];
snprintf(path, PATH_MAX, "%s/%s.%s", dir, name, ext);  // Buffer overflow risk

// Caneka StrVec path (safe)
StrVec *path = IoPath(m, dir);
IoUtil_AddVec(path, IoPath(m, name));
IoUtil_AddExt(path, S(m, ext));
```

**StrVec Path Structure:**
- Each path component is a separate Str with annotation flags
- `MORE` flag indicates path separator follows
- `LAST` flag indicates end of path
- Extensions marked with special separators

**Example Path Breakdown:**

```
/home/user/project/src/main.c

As StrVec:
[0] ""        (MORE)  - Root /
[1] "home"    (MORE)  - /home/
[2] "user"    (MORE)  - /home/user/
[3] "project" (MORE)  - /home/user/project/
[4] "src"     (MORE)  - /home/user/project/src/
[5] "main"    (MORE)  - /home/user/project/src/main.
[6] "c"       (LAST)  - /home/user/project/src/main.c
```

This structure makes operations like "get parent directory" or "change extension" trivial—just adjust the StrVec length.

### Path Creation

#### IoPath() - Create Path from C String

**Signature:**
```c
StrVec *IoPath(MemCh *m, const char *path);
```

Creates a StrVec path from a null-terminated C string. Splits on `/` separators and marks each component appropriately.

**Example:**
```c
StrVec *configPath = IoPath(m, "/etc/caneka/server.config");
// Creates StrVec with components: ["", "etc", "caneka", "server", "config"]
```

**Key Behaviors:**
- Absolute paths start with empty string component (root `/`)
- Relative paths start with non-empty first component
- Trailing slashes preserved with empty final component
- Components marked with `MORE` flag except last (`LAST`)

#### IoPath_FromStr() - Create Path from Str

**Signature:**
```c
StrVec *IoPath_FromStr(MemCh *m, Str *path);
```

Converts a Str object to a StrVec path. Useful when path comes from user input or file content.

**Example:**
```c
Str *userInput = Str_FromChars(m, "./data/users.db");
StrVec *dbPath = IoPath_FromStr(m, userInput);
```

#### IoAbsPath() - Create Absolute Path

**Signature:**
```c
StrVec *IoAbsPath(MemCh *m, const char *path);
```

Creates an absolute path StrVec. If the input path is relative, prepends current working directory.

**Example:**
```c
// If CWD is /home/user
StrVec *abs = IoAbsPath(m, "docs/readme.md");
// Result: /home/user/docs/readme.md

StrVec *abs2 = IoAbsPath(m, "/tmp/output.txt");
// Result: /tmp/output.txt (already absolute)
```

**Use Case:** Ensuring paths are absolute before storing in configuration or comparing paths.

#### IoUtil_AbsPathBuilder() - Build Paths from Parts

**Signature:**
```c
StrVec *IoUtil_AbsPathBuilder(MemCh *m, const char *base, ...);
```

Varargs function to construct absolute paths from multiple C string components. Terminates with NULL.

**Example:**
```c
StrVec *sourcePath = IoUtil_AbsPathBuilder(m,
    "/home/user/project",
    "src",
    "base",
    "io",
    "ioutil.c",
    NULL);
// Result: /home/user/project/src/base/io/ioutil.c
```

**Best Practice:** Use this for programmatic path construction to avoid manual separator handling.

### Path Analysis

#### IoUtil_IsAbs() - Check Absolute Path

**Signature:**
```c
status IoUtil_IsAbs(StrVec *path);
```

Returns SUCCESS if path is absolute (starts with root component), ERROR otherwise.

**Example:**
```c
StrVec *abs = IoPath(m, "/usr/local/bin");
StrVec *rel = IoPath(m, "../config");

if(IoUtil_IsAbs(abs) == SUCCESS){
    printf("Absolute path\n");  // Prints
}

if(IoUtil_IsAbs(rel) == ERROR){
    printf("Relative path\n");  // Prints
}
```

**Implementation Detail:** Checks if first StrVec component has zero length (empty string = root `/`).

#### IoUtil_BasePathAnchor() - Find Base Path Index

**Signature:**
```c
i32 IoUtil_BasePathAnchor(StrVec *path);
```

Returns the index of the last directory component before the filename. Useful for extracting parent directory.

**Example:**
```c
StrVec *path = IoPath(m, "/var/log/system.log");
i32 anchor = IoUtil_BasePathAnchor(path);
// Returns 2 (index of "log")

// Extract directory path
StrVec *dir = StrVec_Cpy(m, path);
StrVec_SetLen(dir, anchor + 1);
// dir now contains: /var/log/
```

**Key Behavior:** Returns -1 if path has no directory component (single filename).

#### IoPath_Descendent() - Check Path Ancestry

**Signature:**
```c
status IoPath_Descendent(StrVec *child, StrVec *parent);
```

Checks if `child` path is a descendant of `parent` path. Useful for security checks and path validation.

**Example:**
```c
StrVec *webroot = IoPath(m, "/var/www/html");
StrVec *request = IoPath(m, "/var/www/html/images/logo.png");
StrVec *attack = IoPath(m, "/etc/passwd");

if(IoPath_Descendent(request, webroot) == SUCCESS){
    printf("Safe: Inside webroot\n");  // Prints
}

if(IoPath_Descendent(attack, webroot) == ERROR){
    printf("BLOCKED: Outside webroot\n");  // Prints
}
```

**Security Application:** Prevent directory traversal attacks by validating all requested paths are within allowed directories.

#### IoUtil_FnameStr() - Extract Filename

**Signature:**
```c
Str *IoUtil_FnameStr(StrVec *path);
```

Returns just the filename component (without directory path) as a Str.

**Example:**
```c
StrVec *path = IoPath(m, "/usr/share/docs/readme.txt");
Str *filename = IoUtil_FnameStr(path);
// Result: "readme.txt"
```

**Use Case:** Display filenames in logs or UI without full path clutter.

#### IoUtil_BasePath() - Get Directory Portion

**Signature:**
```c
StrVec *IoUtil_BasePath(MemCh *m, StrVec *path);
```

Returns a new StrVec containing only the directory portion of the path (without filename).

**Example:**
```c
StrVec *path = IoPath(m, "/home/user/documents/report.pdf");
StrVec *dir = IoUtil_BasePath(m, path);
// Result: /home/user/documents/
```

**Memory:** Allocates new StrVec in provided MemCh.

### Path Manipulation

#### IoUtil_GetAbsPath() - Convert to Absolute Str

**Signature:**
```c
Str *IoUtil_GetAbsPath(MemCh *m, Str *relativePath);
```

Converts a relative path Str to an absolute path Str by prepending CWD if necessary.

**Example:**
```c
// CWD: /home/build
Str *rel = S(m, "../source/main.c");
Str *abs = IoUtil_GetAbsPath(m, rel);
// Result: "/home/source/main.c"
```

#### IoUtil_GetAbsVec() - Convert to Absolute StrVec

**Signature:**
```c
StrVec *IoUtil_GetAbsVec(MemCh *m, Str *relativePath);
```

Converts a relative path Str to an absolute path StrVec.

**Example:**
```c
Str *rel = S(m, "config/settings.ini");
StrVec *abs = IoUtil_GetAbsVec(m, rel);
// Result: StrVec for "/current/working/dir/config/settings.ini"
```

**Difference from IoUtil_GetAbsPath():** Returns StrVec (useful for further path manipulation) instead of flat Str.

#### IoUtil_AbsVec() - Ensure Absolute StrVec

**Signature:**
```c
StrVec *IoUtil_AbsVec(MemCh *m, StrVec *path);
```

Converts any StrVec path to absolute. If already absolute, returns copy. If relative, prepends CWD.

**Example:**
```c
StrVec *rel = IoPath(m, "temp/output.txt");
StrVec *abs = IoUtil_AbsVec(m, rel);
// Prepends CWD

StrVec *alreadyAbs = IoPath(m, "/usr/bin/caneka");
StrVec *abs2 = IoUtil_AbsVec(m, alreadyAbs);
// Returns copy (no CWD prepend needed)
```

#### IoUtil_AddSlash() - Ensure Trailing Slash

**Signature:**
```c
void IoUtil_AddSlash(StrVec *path);
```

Ensures path ends with a trailing slash by appending empty component if needed. Useful for directory paths.

**Example:**
```c
StrVec *dir = IoPath(m, "/var/cache");
IoUtil_AddSlash(dir);
// Now: /var/cache/

// Idempotent - calling again does nothing
IoUtil_AddSlash(dir);
// Still: /var/cache/
```

**Use Case:** Ensuring consistent directory representation before appending filenames.

#### IoUtil_AddVec() - Append Path Components

**Signature:**
```c
void IoUtil_AddVec(StrVec *base, StrVec *addition);
```

Appends all components from `addition` to `base`. Handles separator markers correctly.

**Example:**
```c
StrVec *base = IoPath(m, "/usr/local");
StrVec *subpath = IoPath(m, "share/docs");

IoUtil_AddVec(base, subpath);
// Result: /usr/local/share/docs
```

**Key Behavior:** Automatically manages `MORE`/`LAST` flags during concatenation.

#### IoUtil_RemoveSeps() - Clean Path Separators

**Signature:**
```c
void IoUtil_RemoveSeps(StrVec *path);
```

Removes separator marker annotations from StrVec, converting to plain string components. Rarely needed in application code.

**Use Case:** Internal function for serialization or external API integration.

### Extension Handling

#### IoUtil_GetExt() - Extract Extension

**Signature:**
```c
Str *IoUtil_GetExt(StrVec *path);
```

Returns the file extension (without dot) as a Str, or NULL if no extension.

**Example:**
```c
StrVec *path1 = IoPath(m, "/docs/readme.md");
Str *ext1 = IoUtil_GetExt(path1);
// Result: "md"

StrVec *path2 = IoPath(m, "/bin/caneka");
Str *ext2 = IoUtil_GetExt(path2);
// Result: NULL (no extension)
```

**Use Case:** File type detection, handler dispatch based on extension.

#### IoUtil_AddExt() - Add Extension

**Signature:**
```c
void IoUtil_AddExt(StrVec *path, Str *extension);
```

Appends an extension to a path. Automatically adds dot separator.

**Example:**
```c
StrVec *base = IoPath(m, "/tmp/output");
IoUtil_AddExt(base, S(m, "json"));
// Result: /tmp/output.json
```

**Key Behavior:** Does not check if extension already exists—use `IoUtil_SwapExt()` for replacement.

#### IoUtil_SwapExt() - Replace Extension

**Signature:**
```c
void IoUtil_SwapExt(StrVec *path, Str *newExtension);
```

Replaces existing extension with new one. If no extension exists, adds it.

**Example:**
```c
StrVec *source = IoPath(m, "/src/module.c");
IoUtil_SwapExt(source, S(m, "o"));
// Result: /src/module.o

StrVec *noExt = IoPath(m, "/bin/tool");
IoUtil_SwapExt(noExt, S(m, "exe"));
// Result: /bin/tool.exe
```

**Use Case:** Build systems converting source files to object files.

#### IoUtil_ExtSep() - Get Extension Separator

**Signature:**
```c
const char *IoUtil_ExtSep();
```

Returns the extension separator character as a C string (always `"."`). Provided for API completeness.

#### IoUtil_PathSep() - Get Path Separator

**Signature:**
```c
const char *IoUtil_PathSep();
```

Returns the path component separator character as a C string (always `"/"`). Provided for cross-platform abstraction (even though Caneka currently only supports POSIX).

### Path Utilities

#### IoUtil_Exists() - Check Path Existence

**Signature:**
```c
status IoUtil_Exists(StrVec *path);
```

Checks if a file or directory exists at the given path using `stat()`.

**Example:**
```c
StrVec *config = IoPath(m, "/etc/caneka.config");

if(IoUtil_Exists(config) == SUCCESS){
    // Load configuration
} else {
    // Use defaults or create config
}
```

**Performance:** Performs stat syscall each invocation—cache result if checking repeatedly.

#### IoUtil_Unlink() - Delete File

**Signature:**
```c
status IoUtil_Unlink(StrVec *path);
```

Deletes a file (not directory) at the given path.

**Example:**
```c
StrVec *temp = IoPath(m, "/tmp/build_12345.tmp");
if(IoUtil_Unlink(temp) == ERROR){
    Error(m, "Failed to delete temporary file");
}
```

**Safety:** Only removes files, not directories. Use `Dir_Destroy()` for recursive directory removal.

#### IoUtil_CmpUpdated() - Compare Modification Times

**Signature:**
```c
status IoUtil_CmpUpdated(StrVec *pathA, StrVec *pathB);
```

Compares modification times of two files. Returns SUCCESS if `pathA` is newer than `pathB`, ERROR otherwise.

**Example:**
```c
StrVec *source = IoPath(m, "src/main.c");
StrVec *object = IoPath(m, "obj/main.o");

if(IoUtil_CmpUpdated(source, object) == SUCCESS){
    // Source is newer - recompile needed
    CompileFile(source, object);
}
```

**Build System Use:** Central to incremental build logic—only recompile when source is newer than object file.

---


## Directory Operations

### Directory Existence and Creation

#### Dir_Exists() - Check Directory Existence

**Signature:**
```c
status Dir_Exists(StrVec *path);
```

Checks if a directory exists at the given path using `stat()`.

**Example:**
```c
StrVec *cacheDir = IoPath(m, "/var/cache/caneka");

if(Dir_Exists(cacheDir) == ERROR){
    Dir_Mk(m, cacheDir);  // Create if missing
}
```

**Difference from IoUtil_Exists():** Specifically checks for directory (S_ISDIR), not just any file system entry.

#### Dir_Mk() - Create Directory

**Signature:**
```c
status Dir_Mk(MemCh *m, StrVec *path);
```

Creates a single directory with permissions 0755. Does **not** create parent directories.

**Example:**
```c
StrVec *newDir = IoPath(m, "/tmp/caneka_build");

if(Dir_Mk(m, newDir) == ERROR){
    Error(m, "Failed to create directory");
}
```

**Limitation:** Parent directories must already exist. For recursive creation, see below.

#### Recursive Directory Creation Pattern

To create directories recursively (like `mkdir -p`), iterate through path components:

**Example:**
```c
void DirMkRecursive(MemCh *m, StrVec *path){
    // Start from root, create each component
    for(i32 i = 1; i < StrVec_Len(path); i++){
        StrVec *partial = StrVec_Cpy(m, path);
        StrVec_SetLen(partial, i + 1);

        if(Dir_Exists(partial) == ERROR){
            if(Dir_Mk(m, partial) == ERROR){
                Error(m, "Failed to create: $", partial);
                return;
            }
        }
    }
}

// Usage
StrVec *deep = IoPath(m, "/tmp/a/b/c/d");
DirMkRecursive(m, deep);
// Creates /tmp/a/, /tmp/a/b/, /tmp/a/b/c/, /tmp/a/b/c/d/
```

### Directory Traversal

#### Dir_Climb() - Recursive Directory Traversal

**Signature:**
```c
status Dir_Climb(
    MemCh *m,
    StrVec *path,
    void *ctx,
    DirFunc dirCallback,
    FileFunc fileCallback
);
```

Recursively traverses a directory tree, invoking callbacks for each directory and file encountered.

**Callback Signatures:**
```c
typedef status (*DirFunc)(void *ctx, StrVec *dirPath);
typedef status (*FileFunc)(void *ctx, StrVec *filePath);
```

**Key Behaviors:**
- Skips hidden files/directories (starting with `.`)
- Pre-order traversal (directory callback before contents)
- Callback can return ERROR to stop traversal
- Context pointer passed to all callbacks for state

**Example: Print All Files**
```c
status PrintFile(void *ctx, StrVec *path){
    printf("File: %s\n", StrVec_Chars(path));
    return SUCCESS;
}

status PrintDir(void *ctx, StrVec *path){
    printf("Dir: %s\n", StrVec_Chars(path));
    return SUCCESS;
}

// Traverse
StrVec *root = IoPath(m, "/home/user/project");
Dir_Climb(m, root, NULL, PrintDir, PrintFile);
```

**Output:**
```
Dir: /home/user/project
Dir: /home/user/project/src
File: /home/user/project/src/main.c
File: /home/user/project/src/util.c
Dir: /home/user/project/tests
File: /home/user/project/tests/test_main.c
```

**Example: Count Files by Extension**
```c
typedef struct {
    i32 cFiles;
    i32 hFiles;
    i32 others;
} FileCount;

status CountByExt(void *ctx, StrVec *path){
    FileCount *count = (FileCount*)ctx;
    Str *ext = IoUtil_GetExt(path);

    if(ext == NULL){
        count->others++;
    } else if(Str_Eq(ext, S_CONST("c"))){
        count->cFiles++;
    } else if(Str_Eq(ext, S_CONST("h"))){
        count->hFiles++;
    } else {
        count->others++;
    }

    return SUCCESS;
}

FileCount stats = {0};
Dir_Climb(m, IoPath(m, "/src"), &stats, NULL, CountByExt);
printf("C files: %d, Headers: %d, Other: %d\n",
       stats.cFiles, stats.hFiles, stats.others);
```

**Performance:** Suitable for moderate directory trees. For very large trees with complex filtering, use `Dir_GatherSel()`.

### Advanced Gathering with DirSelector

#### Dir_Gather() - Simple File Gathering

**Signature:**
```c
Span *Dir_Gather(MemCh *m, StrVec *path);
```

Gathers all files and directories from a directory (non-recursive) into a Span of StrVec paths.

**Example:**
```c
Span *contents = Dir_Gather(m, IoPath(m, "/tmp"));

Iter *it = Iter_Make(m, contents);
while(Iter_Avail(it)){
    StrVec *item = Iter_Deref(it);
    printf("%s\n", StrVec_Chars(item));
    Iter_Next(it);
}
```

**Use Case:** Listing directory contents for display or simple filtering.

#### Dir_GatherByExt() - Filter by Extension

**Signature:**
```c
Span *Dir_GatherByExt(MemCh *m, StrVec *path, Str *extension);
```

Recursively gathers all files matching a specific extension.

**Example:**
```c
// Find all C source files
Span *sources = Dir_GatherByExt(m, IoPath(m, "/src"), S(m, "c"));

printf("Found %d C files\n", Span_Len(sources));
```

**Recursive:** Searches entire directory tree, not just immediate children.

#### DirSelector_Make() - Create Advanced Selector

**Signature:**
```c
DirSelector *DirSelector_Make(
    MemCh *m,
    StrVec *path,
    i32 flags,
    FilterFunc filter
);
```

Creates a DirSelector configuration for advanced directory traversal with filtering and metadata tracking.

**DirSelector Flags:**

| Flag | Description |
|------|-------------|
| `DIR_SELECTOR_MTIME_ALL` | Track modification times for all files |
| `DIR_SELECTOR_MTIME_LOWEST` | Track only lowest (oldest) modification time |
| `DIR_SELECTOR_NODIRS` | Exclude directories from results (files only) |
| `DIR_SELECTOR_FILTER` | Apply filter function to files |
| `DIR_SELECTOR_FILTER_DIRS` | Apply filter function to directories |
| `DIR_SELECTOR_INVERT` | Invert filter results (include non-matches) |

**FilterFunc Signature:**
```c
typedef status (*FilterFunc)(void *ctx, StrVec *path);
```

Return SUCCESS to include item, ERROR to exclude.

#### Dir_GatherSel() - Gather with Selector

**Signature:**
```c
Span *Dir_GatherSel(MemCh *m, DirSelector *selector);
```

Performs directory gathering using DirSelector configuration.

**Example: Find Modified Files Since Date**
```c
typedef struct {
    struct timespec cutoff;
} ModTimeCtx;

status IsModifiedRecently(void *ctx, StrVec *path){
    ModTimeCtx *mtx = (ModTimeCtx*)ctx;
    struct stat st;

    // Convert StrVec to C string for stat
    const char *pathStr = StrVec_Chars(path);
    if(stat(pathStr, &st) != 0) return ERROR;

    // Compare modification time
    if(st.st_mtim.tv_sec > mtx->cutoff.tv_sec){
        return SUCCESS;  // Include
    }
    return ERROR;  // Exclude
}

// Find files modified in last 24 hours
ModTimeCtx ctx;
Time_Now(&ctx.cutoff);
ctx.cutoff.tv_sec -= (24 * 60 * 60);  // Subtract 24 hours

DirSelector *sel = DirSelector_Make(
    m,
    IoPath(m, "/var/log"),
    DIR_SELECTOR_FILTER | DIR_SELECTOR_NODIRS,
    IsModifiedRecently
);
sel->ctx = &ctx;

Span *recentLogs = Dir_GatherSel(m, sel);
printf("Found %d log files modified today\n", Span_Len(recentLogs));
```

**Example: Exclude Build Artifacts**
```c
status IsNotBuildFile(void *ctx, StrVec *path){
    Str *ext = IoUtil_GetExt(path);
    if(ext == NULL) return SUCCESS;

    // Exclude .o and .a files
    if(Str_Eq(ext, S_CONST("o"))) return ERROR;
    if(Str_Eq(ext, S_CONST("a"))) return ERROR;

    return SUCCESS;
}

DirSelector *sel = DirSelector_Make(
    m,
    IoPath(m, "/build"),
    DIR_SELECTOR_FILTER | DIR_SELECTOR_NODIRS,
    IsNotBuildFile
);

Span *nonBuild = Dir_GatherSel(m, sel);
// Only source files, headers, etc. (no .o or .a)
```

**Example: Track Oldest File**
```c
DirSelector *sel = DirSelector_Make(
    m,
    IoPath(m, "/cache"),
    DIR_SELECTOR_MTIME_LOWEST | DIR_SELECTOR_NODIRS,
    NULL  // No filter
);

Span *files = Dir_GatherSel(m, sel);

// Access oldest modification time
struct timespec oldest = sel->mtime;
printf("Oldest file timestamp: %ld\n", oldest.tv_sec);
```

**Use Case:** Cache eviction policies—find least recently modified files for deletion.

### Directory Destruction

#### Dir_Destroy() - Recursive Delete

**Signature:**
```c
status Dir_Destroy(MemCh *m, StrVec *path);
```

Recursively deletes entire directory tree including all contents.

**Example:**
```c
StrVec *tempBuild = IoPath(m, "/tmp/caneka_build_12345");

// Clean up temporary build directory
if(Dir_Destroy(m, tempBuild) == ERROR){
    Error(m, "Failed to remove temp directory");
}
```

**⚠️ WARNING:** This is a destructive operation with no confirmation or undo. Validate paths before calling.

**Safety Pattern:**
```c
void SafeDestroyTemp(MemCh *m, StrVec *path){
    // Ensure path is within /tmp
    StrVec *tmpRoot = IoPath(m, "/tmp");

    if(IoPath_Descendent(path, tmpRoot) == ERROR){
        Error(m, "Refusing to delete outside /tmp: $", path);
        return;
    }

    // Additional check: path contains our prefix
    const char *pathStr = StrVec_Chars(path);
    if(strstr(pathStr, "caneka_") == NULL){
        Error(m, "Path doesn't contain 'caneka_' prefix");
        return;
    }

    Dir_Destroy(m, path);
}
```

---


## Subprocess Management

### Process Execution Basics

#### SubProcess() - Synchronous Execution

**Signature:**
```c
status SubProcess(MemCh *m, ProcDets *pd);
```

Forks a child process, executes the command, and waits for completion. Blocks until child exits.

**ProcDets Structure:**
```c
typedef struct procdets {
    Type type;
    MemCh *m;

    pid_t pid;        // Child process ID
    i32 code;         // Exit code
    i32 inFd;         // stdin pipe write end
    i32 outFd;        // stdout pipe read end
    i32 errFd;        // stderr pipe read end

    Span *args;       // Command arguments
    i32 flags;        // Configuration flags
} ProcDets;
```

**Example: Run Git Command**
```c
ProcDets pd;
ProcDets_Init(m, &pd);

// Build argument array
pd.args = Span_Make(m, TYPE_STRVEC);
Span_Push(pd.args, Sv(m, "git"));
Span_Push(pd.args, Sv(m, "status"));
Span_Push(pd.args, Sv(m, "--porcelain"));

if(SubProcess(m, &pd) == SUCCESS){
    if(pd.code == 0){
        printf("Git status succeeded\n");
    } else {
        printf("Git status failed with code %d\n", pd.code);
    }
}
```

**Key Behaviors:**
- Searches PATH for executable
- Inherits current environment
- Inherits stdin/stdout/stderr (unless pipes configured)
- Blocks until child exits
- Exit code stored in `pd.code`

### Pipe Configuration

#### PROCDETS_PIPES - Full Pipe Setup

Creates stdin, stdout, and stderr pipes for child process.

**Example: Send Input and Capture Output**
```c
ProcDets pd;
ProcDets_Init(m, &pd);
pd.flags = PROCDETS_PIPES;

pd.args = Span_Make(m, TYPE_STRVEC);
Span_Push(pd.args, Sv(m, "grep"));
Span_Push(pd.args, Sv(m, "error"));

// Fork process
SubCall(m, &pd);

// Write to stdin
const char *input = "error: file not found\nwarning: deprecated\nerror: syntax\n";
write(pd.inFd, input, strlen(input));
close(pd.inFd);  // Signal EOF

// Read from stdout
char buf[4096];
i32 n = read(pd.outFd, buf, sizeof(buf));
buf[n] = '\0';

printf("Grep output:\n%s", buf);

// Wait for completion
SubStatus(m, &pd);
```

**Output:**
```
Grep output:
error: file not found
error: syntax
```

#### PROCDETS_IN_PIPE - Input Only

Creates only stdin pipe. Useful for feeding data to commands that don't produce output or when output should go to terminal.

**Example: Feed Data to Command**
```c
ProcDets pd;
ProcDets_Init(m, &pd);
pd.flags = PROCDETS_IN_PIPE;

pd.args = Span_Make(m, TYPE_STRVEC);
Span_Push(pd.args, Sv(m, "sha256sum"));

SubCall(m, &pd);

// Write data to hash
const char *data = "Hello, World!";
write(pd.inFd, data, strlen(data));
close(pd.inFd);

// Output goes to terminal
SubStatus(m, &pd);
```

### Capturing Output

#### SubProcToBuff() - Capture to Buffers

**Signature:**
```c
status SubProcToBuff(
    MemCh *m,
    ProcDets *pd,
    Buff *out,
    Buff *err
);
```

Forks process and captures stdout/stderr into Buff objects. Non-blocking read with automatic throttling.

**Example: Capture Compiler Output**
```c
ProcDets pd;
ProcDets_Init(m, &pd);

pd.args = Span_Make(m, TYPE_STRVEC);
Span_Push(pd.args, Sv(m, "gcc"));
Span_Push(pd.args, Sv(m, "-c"));
Span_Push(pd.args, Sv(m, "main.c"));
Span_Push(pd.args, Sv(m, "-o"));
Span_Push(pd.args, Sv(m, "main.o"));

Buff *out = Buff_Make(m, 0);
Buff *err = Buff_Make(m, 0);

if(SubProcToBuff(m, &pd, out, err) == SUCCESS){
    if(pd.code == 0){
        printf("Compilation succeeded\n");
    } else {
        printf("Compilation failed:\n");

        // Print stderr
        Str *errMsg = Buff_GetStr(m, err);
        printf("%s\n", Str_Chars(errMsg));
    }
}
```

**Key Features:**
- Automatically sets up pipes
- Reads stdout and stderr concurrently
- Throttles read loop to prevent busy-waiting
- Stores all output in memory

**Memory Warning:** For commands producing large output, consider streaming to file instead.

### Async Process Management

#### PROCDETS_ASYNC - Non-Blocking Wait

Allows checking process status without blocking.

**Example: Monitor Long-Running Process**
```c
ProcDets pd;
ProcDets_Init(m, &pd);
pd.flags = PROCDETS_ASYNC;

pd.args = Span_Make(m, TYPE_STRVEC);
Span_Push(pd.args, Sv(m, "make"));
Span_Push(pd.args, Sv(m, "all"));

// Start process
SubCall(m, &pd);

// Do other work while building
printf("Build started (PID %d)...\n", pd.pid);

while(true){
    // Check status (non-blocking)
    status st = SubStatus(m, &pd);

    if(st == SUCCESS){
        // Process still running
        printf("Still building...\n");
        sleep(1);  // Do other work
    } else {
        // Process finished
        break;
    }
}

printf("Build finished with exit code %d\n", pd.code);
```

**Use Case:** Progress indicators, concurrent builds, timeout detection.

#### Process Timeout Pattern

**Example: Kill Process After Timeout**
```c
ProcDets pd;
ProcDets_Init(m, &pd);
pd.flags = PROCDETS_ASYNC;

pd.args = Span_Make(m, TYPE_STRVEC);
Span_Push(pd.args, Sv(m, "longRunningCommand"));

SubCall(m, &pd);

struct timespec start, now;
Time_Now(&start);

bool timeout = false;
while(SubStatus(m, &pd) == SUCCESS){
    Time_Now(&now);

    // Check if 30 seconds elapsed
    if(now.tv_sec - start.tv_sec > 30){
        timeout = true;
        kill(pd.pid, SIGTERM);  // Graceful termination
        sleep(1);

        // Force kill if still running
        if(SubStatus(m, &pd) == SUCCESS){
            kill(pd.pid, SIGKILL);
        }
        break;
    }

    sleep(1);  // Throttle loop
}

if(timeout){
    printf("Process killed: timeout\n");
} else {
    printf("Process completed: exit code %d\n", pd.code);
}
```

---



---

**Part 1 of 2** | [Part 2 →](io-utilities-complete-part2)
