---
sidebar_position: 5
---

# Templ Template Engine - Complete Guide

Templ is Caneka's HTML template engine. It parses `.templ` files into a list of
text chunks and `Fetcher` nodes, then renders by walking that list with a data
stack.

## Status and Scope

### Verified (implementation)
- Parser: `src/inter/templ/templ_roebling.c`
- Control-flow preparation: `src/inter/templ/templ_prepare.c`
- Jump execution: `src/inter/templ/templ_jump.c`
- Rendering: `src/inter/templ/templ.c`
- Data fetchers: `src/ext/types/fetcher.c`, `src/ext/types/fetch_target.c`

### Inferred / Not Implemented
- No `else` or `ifnot` syntax (not wired in `templ_roebling.c`)
- No escaping rules for literal `{`, `}`, or `;`
- No HTML escaping during render (raw output)

## Syntax Summary (Verified)

| Form | Example | Meaning |
| --- | --- | --- |
| Text | `<h1>Hi</h1>` | Emitted as-is |
| Variable | `{title}` | Fetch by key |
| Control line | `; items...` | Starts a loop |
| With | `; *value:` | Switches data context |
| If | `; stats.mem ?` | Conditional block |
| End | `;` | Closes most recent block |

### Variable Path Segments (Verified)

Templ splits a path into segments and resolves each with a `FetchTarget`:

| Prefix | Example | Target type | Notes |
| --- | --- | --- | --- |
| (none) | `{title}` | KEY | Table key or Seel property |
| `@` | `{@title}` | KEY | Explicit key segment |
| `#` | `{#name}` | PROP | Table key or Seel property |
| `*` | `{*name}` | ATT | C-struct attribute (via Map) |
| `.` | `{config#page#title}` | PATH SEP | Separates segments |

In current code, both KEY and PROP resolve through Seel when the value is an
`Inst` (type has `TYPE_INSTANCE`), and through `Table_Get` when the value is a
`Table`.

## Whitespace, Comments, Escapes, Errors (Verified)

| Topic | Behavior |
| --- | --- |
| Whitespace | Text whitespace is preserved; control-line whitespace is ignored |
| Comments | Not implemented |
| Escapes | Not implemented for `{`, `}`, or `;` |
| Errors | Missing fetch outside `if` triggers an error and stops rendering |

## Control Blocks (Verified)

### Loop: `...`

```templ
; items.menu...
    <li>{*name}</li>
;
```

Creates a `FETCHER_FOR` with targets `items`, `menu`, and an iterator target.

### With: `:`

```templ
; *value:
    <li><a href="{*local}">{*name}</a></li>
;
```

Creates a `FETCHER_WITH` that pushes a new data context onto the stack.

### If: `?`

```templ
; stats.mem ?
<h2>Memory Heap</h2>
;
```

Creates a `FETCHER_IF`. The block renders if the fetch resolves to a non-NULL
value. Missing values in non-IF blocks raise an error.

### Navigation Tokens (Verified)

Used with nested iterators like `NestSel` (`src/ext/navigate/nestsel.c`):

- `>` -> `FORMAT_TEMPL_LEVEL` (branch with children)
- `=` -> `FORMAT_TEMPL_CURRENT` (leaf, not selected)
- `_` -> `FORMAT_TEMPL_ACTIVE` (leaf, selected)
- `{^}` -> `FORMAT_TEMPL_INDENT` (indent/outdent control)

Example (`examples/doc/nav.templ`):

```templ
;  page.nav...
;  >
    <li><a href="{#url}">{#name}</a>{^}</li>
;  =
    <li><a href="{#url}">{#name}</a></li>
;  _
    <li><span class="active">{#name}</span></li>
;
```

## Walkthrough: `examples/example.templ` (Verified)

Input:

```templ
<h1>{title}</h1>
<p>{para}</p>
<ul>
;   items.menu...
;   *value:
    <li><a href="{*local}">{*name}</a></li>
;
;
</ul>
```

Parsed structure (see `src/programs/test/option/inter/templ_tests.c`):

- Text chunks as `StrVec`
- `FETCHER_VAR` for `{title}` and `{para}`
- `FETCHER_FOR` for `items.menu...`
- `FETCHER_WITH` for `*value:`
- Two `FETCHER_END` nodes to close `with` and `for`

Rendered output (from tests, truncated):

```html
<h1>My Fancy Page</h1>
<p>And here is the masterful list of menu items!</p>
<ul>
    <li><a href="/things/one">One</a></li>
    <li><a href="/things/two">Two</a></li>
    <li><a href="/things/three">Three</a></li>
</ul>
```

## Runtime Data Model (Verified)

| Layer | Type | Role |
| --- | --- | --- |
| Base | `Str`, `StrVec`, `Span` | Text storage and sequences |
| Ext | `Fetcher`, `FetchTarget` | Path resolution over data |
| Inter | `Templ`, `TemplCtx`, `TemplJump` | Parse/prepare/render pipeline |

Data flow:

```
.templ -> TemplCtx (Roebling) -> Span of StrVec/Fetcher
    -> Templ_Prepare (build jumps)
    -> Templ_ToS (walk content + Fetch)
```

## Limitations and Edge Cases (Verified)

- No built-in HTML escaping; values are emitted via `ToS`.
- No `else` blocks (`|`) or `ifnot` syntax.
- No escape syntax for literal `;` or `{` in text.
- A failed fetch outside `if` results in an error and stops rendering.

## See Also

- `src/inter/templ/templ_roebling.c`
- `src/programs/test/option/inter/templ_tests.c`
- `src/programs/test/option/inter/templ_nav_tests.c`
