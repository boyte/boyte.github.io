---
sidebar_position: 4
---

# Templ Template Engine

Templ is Caneka's HTML template engine. It is parsed by a Roebling state
machine and rendered by walking a list of text chunks and `Fetcher` nodes.

## Basic Example (Verified)

```templ
<h1>{title}</h1>
<p>{para}</p>
<ul>
; items...
; *value:
  <li><a href="{*local}">{*name}</a></li>
;
</ul>
```

Example source: `examples/example.templ`

## Features

- Variable substitution
- Collection iteration
- Conditional rendering
- Data-context switching (`with`)

## Location

**Source**: `src/inter/templ/`
**Headers**: `src/inter/include/templ/`

## See Also

- [Templ Format Details](../formats/templ.md)
- [Inter Layer](../architecture/inter-layer.md)
