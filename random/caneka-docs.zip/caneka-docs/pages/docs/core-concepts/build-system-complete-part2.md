# Build System (Buildeka) - Complete Guide - Part 2

[← Part 1](build-system-complete-part1) | **Part 2 of 2**

---

## Progress Display

**File**: `src/programs/buildeka/cli.c`

Buildeka shows a **live progress bar** during compilation.

### Display Format

```
Source 42 of 100
Building compile src/ext/parser.c → build/ext/parser.o
[=======================                        ] 42%
Memory 1.2MB total/maxIdx=2/8 page-size=4096b
```

### Setup

```c
status BuildCli_SetupStatus(BuildCtx *ctx){
    // Create display lines
    FmtLine *line1 = FmtLine_Make(m,
        "^y.Source $ of $^0",
        {ctx->input.countSources, ctx->input.totalSources}
    );

    FmtLine *line2 = FmtLine_Make(m,
        "^y.Building $ $ $^0",
        {ctx->cli.fields.current}
    );

    FmtLine *line3 = FmtLine_Make(m,
        "^B.$^0.^Y.$^0",
        {ctx->cli.fields.steps.barStart, ctx->cli.fields.steps.barLead}
    );

    FmtLine *line4 = FmtLine_Make(m,
        "^c.Memory $ total/maxIdx=^D.$/$^d. page-size=$b^0",
        {memTotal, chapters, chaptersTotal, pageSize}
    );

    // Register render callback
    ctx->cli.cli = CliStatus_Make(m, ctx, BuildCli_RenderStatus);

    return SUCCESS;
}
```

### Rendering

```c
status BuildCli_RenderStatus(MemCh *m, void *a){
    CliStatus *cli = (CliStatus *)as(a, TYPE_CLI_STATUS);
    BuildCtx *ctx = (BuildCtx *)as(cli->source, TYPE_BUILDCTX);

    // Calculate progress bar width
    float total = (float)ctx->input.totalSources->val.i;
    float count = (float)ctx->input.countSources->val.i;
    float width = cli->width - 10;  // Leave room for percentage
    float progress = ceil((count / total) * width);

    // Update bar
    ctx->cli.fields.steps.barStart->length = (i32)progress;
    ctx->cli.fields.steps.barLead->length = (i32)(width - progress);

    // Update memory stats
    MemBookStats st;
    MemBook_GetStats(m, &st);
    Str *memStr = Str_MemCount(st.total * PAGE_SIZE);
    CliStatus_SetByKey(m, cli, "memTotal", memStr);

    // Render all lines
    FmtLine_Print(cli, line1);
    FmtLine_Print(cli, line2);
    FmtLine_Print(cli, line3);
    FmtLine_Print(cli, line4);

    return SUCCESS;
}
```

### Quiet Mode

```c
// Set via --quiet flag
BuildCtx_SetQuiet(true);

// In BuildCtx_Log:
if(_quiet){
    // Simple list output
    Out("Building $ $ $ -> $\n",
        {action, source, dest, target});
}else{
    // Fancy progress bar
    CliStatus_Print(OutStream, ctx->cli.cli);
}
```

**Quiet Output**:
```
Building compile src/base/mem.c → build/base/mem.o
Building compile src/base/str.c → build/base/str.o
Building archive build/base/libcnkbase.a
Building compile src/ext/parser.c → build/ext/parser.o
...
```


## Adding New Modules

### Step-by-Step Guide

**1. Create Module Directory**:
```bash
mkdir -p src/mymodule/include
touch src/mymodule/dependencies.txt
```

**2. Create Public Header**:
```c
// src/mymodule/include/mymodule_module.h
#ifndef MYMODULE_MODULE_H
#define MYMODULE_MODULE_H

#include <base_module.h>

// Type definition
typedef struct myobject {
    Type type;
    MemCh *m;
    i32 value;
} MyObject;

// Function declarations
MyObject *MyObject_Make(MemCh *m, i32 value);
status MyObject_DoSomething(MyObject *obj);

#endif
```

**3. Implement Module**:
```c
// src/mymodule/myobject.c
#include <external.h>
#include "mymodule_module.h"

MyObject *MyObject_Make(MemCh *m, i32 value){
    MyObject *obj = (MyObject *)MemCh_AllocOf(m, sizeof(MyObject), TYPE_MYOBJECT);
    obj->m = m;
    obj->value = value;
    return obj;
}

status MyObject_DoSomething(MyObject *obj){
    printf("Doing something with value: %d\n", obj->value);
    return SUCCESS;
}
```

**4. Define Dependencies**:
```
# src/mymodule/dependencies.txt
base
ext
```

**5. Build**:
```bash
./dist/bin/buildeka --src src/mymodule --option base ext
```

**Result**:
```
build/mymodule/
├─ libcnkmymodule.a       # Static library
└─ myobject.o             # Compiled object
```

### Adding Executable

**1. Create main.c**:
```c
// src/mymodule/main.c
#include <caneka.h>
#include "mymodule_module.h"

int main(int argc, char **argv){
    Caneka_Init();
    MemCh *m = MemCh_Make();

    MyObject *obj = MyObject_Make(m, 42);
    MyObject_DoSomething(obj);

    MemCh_Free(m);
    return 0;
}
```

**2. Update dependencies.txt**:
```
base
ext
exec=main.c
```

**3. Build**:
```bash
./dist/bin/buildeka --src src/mymodule --option base ext
```

**Result**:
```
build/bin/mymodule        # Executable binary
```

### Adding Optional Feature

**1. Create Option Directory**:
```bash
mkdir -p src/mymodule/option/advanced
```

**2. Implement Feature**:
```c
// src/mymodule/option/advanced/advanced.c
#include <caneka.h>

#ifdef CNKOPT_ADVANCED
status MyObject_AdvancedFeature(MyObject *obj){
    printf("Advanced feature enabled!\n");
    return SUCCESS;
}
#endif
```

**3. Update dependencies.txt**:
```
base
ext
option=advanced@src/mymodule/option/advanced
```

**4. Build with Option**:
```bash
./dist/bin/buildeka --src src/mymodule \
    --option base ext advanced@src/mymodule/option/advanced
```

**Result**: Code compiled with `-DCNKOPT_ADVANCED`


## Common Build Scenarios

### Scenario 1: Build Specific Module

```bash
./dist/bin/buildeka --src src/ext --option base
```

**What Happens**:
1. Parses `src/ext/dependencies.txt` → finds dependency on "base"
2. Recursively parses `src/base/dependencies.txt` → no dependencies
3. Compiles base module first
4. Compiles ext module
5. Creates `build/base/libcnkbase.a` and `build/ext/libcnkext.a`

### Scenario 2: Build Test Suite

```bash
./dist/bin/buildeka --src src/programs/test --option base ext inter
```

**What Happens**:
1. Resolves dependencies: test → inter → ext → base
2. Compiles in order: base, ext, inter, test
3. Links executable: `build/bin/test`
4. Runs test if `--run` flag provided

### Scenario 3: Build with Crypto (NaCl)

```bash
./dist/bin/buildeka --src src/programs/test \
    --option base ext inter crypto@third/nacl
```

**What Happens**:
1. Compiles `src/third/nacl/**/*.c`
2. Adds `-DCNKOPT_CRYPTO` flag
3. Skips `src/third/openssl` (not selected)
4. Links against libsodium

### Scenario 4: Clean Build

```bash
rm -rf build
./dist/bin/buildeka --src src/programs/test --option base ext inter
```

**What Happens**:
1. No library timestamps to check
2. Compiles all sources from scratch
3. Progress bar shows 0% → 100%

### Scenario 5: Incremental Build

```bash
# First build
./dist/bin/buildeka --src src/ext --option base

# Modify one file
echo "// comment" >> src/ext/strings.c

# Rebuild
./dist/bin/buildeka --src src/ext --option base
```

**What Happens**:
1. Checks library timestamp
2. Finds `strings.c` newer than `libcnkext.a`
3. Recompiles only `strings.c`
4. Re-archives library
5. Skips all other unchanged files


## Best Practices

### 1. Always Use --option for Dependencies

```bash
# ✅ GOOD: Explicitly list all needed modules
./dist/bin/buildeka --src src/programs/test \
    --option base ext inter

# ❌ BAD: Missing dependencies
./dist/bin/buildeka --src src/programs/test
# ERROR: Undefined symbols (no base, ext, inter compiled)
```

### 2. Use Quiet Mode for CI/CD

```bash
# ✅ GOOD: Quiet mode for scripts
./dist/bin/buildeka --src src/programs/test \
    --quiet \
    --option base ext inter > build.log

# ❌ BAD: Progress bar in CI
# ANSI escape codes pollute log files
```

### 3. Clean Build for Release

```bash
# ✅ GOOD: Clean before release build
rm -rf build
./dist/bin/buildeka --src src/programs/webserver \
    --option base ext inter

# Ensures no stale objects included
```

### 4. Use Specific Crypto Backend

```bash
# ✅ GOOD: Explicit crypto backend
./dist/bin/buildeka --src src/programs/test \
    --option base ext inter crypto@third/nacl

# ❌ BAD: Ambiguous
--option crypto
# ERROR: Which backend? nacl or openssl?
```

### 5. Check Build Exit Code

```bash
# ✅ GOOD: Check success
if ./dist/bin/buildeka --src src/programs/test --option base ext inter; then
    echo "Build succeeded"
else
    echo "Build failed"
    exit 1
fi

# ❌ BAD: Ignore errors
./dist/bin/buildeka ...
# Script continues even on failure
```


## Common Pitfalls

### Pitfall 1: Circular Dependencies

```
# ❌ BAD: Circular dependency
# src/modulea/dependencies.txt
moduleb

# src/moduleb/dependencies.txt
modulea

# Result: Infinite recursion
```

**Solution**: Refactor to break cycle or merge modules

### Pitfall 2: Missing Optional Modules

```bash
# ❌ BAD: Optional module not provided
./dist/bin/buildeka --src src/programs/test --option base

# test/dependencies.txt has: option=inter
# ERROR: inter not compiled, linker fails
```

**Solution**: Include all required options

### Pitfall 3: Wrong Build Order

```bash
# ❌ BAD: Build dependent before dependency
./dist/bin/buildeka --src src/ext    # Depends on base
# ERROR: Can't find base_module.h
```

**Solution**: Buildeka handles order automatically via `dependencies.txt`

### Pitfall 4: Stale Library After Header Change

```c
// Modify src/base/include/base_module.h
// Build ext module

# ❌ PROBLEM: ext library not rebuilt (header change not tracked)
```

**Solution**: Clean build after header changes (`rm -rf build`)

### Pitfall 5: Forgetting exec= Directive

```
# ❌ BAD: dependencies.txt missing exec directive
base
ext

# main.c not marked as executable
# Result: Compiled into library instead of binary
```

**Solution**: Add `exec=main.c` to dependencies.txt


## Troubleshooting

### Build Fails with "Undefined Reference"

**Symptom**:
```
/usr/bin/ld: undefined reference to `MemCh_Make'
```

**Cause**: Missing dependency module

**Solution**: Add module to `--option` list
```bash
./dist/bin/buildeka --src src/programs/test \
    --option base ext inter  # Add missing base
```

### Headers Not Found

**Symptom**:
```
fatal error: 'base_module.h' file not found
```

**Cause**: Module not in dependency chain

**Solution**: Add to `dependencies.txt`:
```
base
```

### Library Already Exists Error

**Symptom**:
```
ar: libcnkbase.a: Permission denied
```

**Cause**: File permissions or process lock

**Solution**: Clean and rebuild
```bash
rm -rf build
./dist/bin/buildeka --src src/ext --option base
```

### Compiler Not Found

**Symptom**:
```
Error: No C compiler found
```

**Cause**: Neither clang nor gcc in PATH

**Solution**: Install compiler
```bash
# macOS
xcode-select --install

# Ubuntu/Debian
sudo apt install build-essential

# Fedora/RHEL
sudo dnf install gcc
```


## Summary

The Caneka Build System provides **sophisticated build automation** with:

**Strengths**:
- ✅ Self-hosted (no external dependencies)
- ✅ Automatic dependency resolution
- ✅ Incremental compilation
- ✅ Multiple compiler support
- ✅ Optional module system
- ✅ Interactive and batch modes
- ✅ Live progress display

**Use Cases**:
- Building Caneka from source
- Adding custom modules
- Selective feature compilation
- CI/CD integration (quiet mode)

**Best For**:
- C projects with modular architecture
- Systems requiring zero dependencies
- Cross-platform builds
- Projects with optional features

The build system is **production-ready** and successfully compiles all of Caneka's ~456 C source files across multiple platforms.



---

[← Part 1](build-system-complete-part1) | **Part 2 of 2**
