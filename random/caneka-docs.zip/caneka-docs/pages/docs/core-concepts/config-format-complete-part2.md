# Config Format: Complete Guide - Part 2

[<- Part 1](config-format-complete-part1) | **Part 2 of 2**

---

## Access Patterns (Verified)

### Direct Attributes

```c
Inst *root = Config_FromPath(m, path);
Inst *page = Inst_ByPath(root, Sv(m, "page"), NULL, SPAN_OP_GET, NULL);
StrVec *title = Inst_Att(page, K(m, "title"));
```

### Nested Lookups with Paths

The API uses `Path_DotAnnotate` to split a dotted string into a path:

```c
StrVec *path = StrVec_From(m, Str_FromCstr(m, "doc.footer", ZERO));
Path_DotAnnotate(m, path);
Inst *footer = Inst_GetByPath(root, path);
```

This is an **API convention**, not config syntax.

## Lists and Sequences (Verified)

List items (`- item`) produce a `Span` under the parent key. Example:

```config
list:
    - one
    - two
```

For space-delimited values (not list items), use `Config_Sequence`:

```config
binseg {
    action: add modify read
}
```

```c
StrVec *actionV = Inst_Att(binseg, K(m, "action"));
Span *actions = Config_Sequence(m, actionV);
```

See `src/inter/www/route.c` for usage.

## Integration: Web Server Config (Verified)

`WebServer_SetConfig` expects a `routes` section:

```config
routes {
    / {
        path: pages/public/
        ext: config
    }
    /static {
        path: pages/static
        ext: png css jpg js
    }
}
```

This matches `examples/web-server/default.config`.

The server loads:
- `routes.<name>.path` to find page directories
- `routes.<name>.ext` to determine route extensions

## Edge Cases and Limitations (Verified)

- No comment syntax.
- No string quoting or escaping.
- Only `:` for key/value pairs (not `=`).
- Tokens are captured up to delimiters; allowed characters are not formally documented.
- Digits-only values are parsed as integers; mixed tokens remain strings.

## Open Questions / Gaps (Inferred)

- Error reporting is minimal (no line/column in errors).
- There is no schema validation layer for config files.
