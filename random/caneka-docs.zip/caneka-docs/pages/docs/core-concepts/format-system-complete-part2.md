# Format System Complete Guide - Part 2

[<- Part 1](format-system-complete-part1) | **Part 2 of 2**

---

## Walkthrough: Fmt -> HTML (Verified)

Input (`examples/example.fmt`):

```pencil
= Hidy Ho

And this is a first paragraph
with a second line.

_link=here@http://example.com
```

Parsed structure (from `src/programs/test/option/ext/mess_tests.c`):

- Heading node (`FORMATTER_INDENT`)
- Paragraph node (`FORMATTER_PARAGRAPH`) with combined lines
- Tag node (`FORMATTER_TAG`) for `_link`

Rendered output (from `src/programs/test/option/ext/fmthtml_tests.c`):

```html
<H1>Hidy Ho</H1>
<P>And this is a first paragraph with a second line.</P>
<P>... <A href="http://example.com">here</A> ...</P>
```

## Walkthrough: Config -> Routes (Verified)

Input (`examples/web-server/default.config`):

```config
routes {
    / {
        path: pages/public/
        ext: config
    }
    /static {
        path: pages/static
        ext: png css jpg js
    }
}
```

Processing:

1. `Config_FromPath` builds a NodeObj tree.
2. `WebServer_SetConfig` reads `routes` and calls `Route_CollectConfig`.
3. Route names are turned into paths with `IoUtil_Annotate`.

See `src/inter/www/webserver.c`.

## CLI: `clineka` (Verified)

Supported options (from `src/programs/clineka/main.c`):

- `--in` / `--out`: input/output files
- `--config`: load config for header/footer paths
- `--no-color`, `--help`, `--licence`, `--version`, `--secret`, `--public`

Supported flow:

- `.fmt` -> `.html` when `--in` is `*.fmt` and `--out` is `*.html`
  - Uses `FormatFmt_Make` + `Fmt_ToHtml`
  - Optional header/footer from `config` under `html { header: ..., footer: ... }`
- `.rbs` input with no `--out` prints BinSeg records

## Error Behavior (Verified)

- Parsers set `ERROR` on Roebling failure.
- Callers should check `rbl->type.state` or function return codes.
- `clineka` exits with a non-zero code when parsing fails.

## Limitations and Gaps (Verified)

- No comment syntax in Config or Fmt.
- No reverse conversions (HTML -> Fmt, HTML -> Config).
- XML support is tag output only (no XML parser).
- Fmt class tokens are parsed but not rendered to HTML.
