---
sidebar_position: 7
---

# Table and Lookup - Complete Guide

Caneka provides two hash-based data structures: **Table** (general-purpose hash table) and **Lookup** (type-indexed dispatch table). Both are built on the Span dynamic array system but serve different purposes.

## Core Philosophy

Traditional hash tables choose between chaining (memory overhead) and open addressing (performance unpredictability). Caneka's approach:

1. **Table**: Span-based hash table with multi-bit linear probing
2. **Lookup**: Type-indexed O(1) dispatch for polymorphic operations
3. **Parity hashing**: Fast checksums instead of cryptographic hashes
4. **50% load factor**: Predictable performance over maximum density

**Key Insight**: Tables prioritize **predictability and memory efficiency** over absolute speed, making them ideal for systems-level code where cache locality matters.

## Table Structure

A **Table** is a **type alias** for Span with hash table semantics:

```c
typedef Span Table;

// Table is a Span with special flags
Table *tbl = Table_Make(m);
// tbl->type.state |= FLAG_SPAN_TABLE
```

### Span Foundation

Tables leverage Span's **multi-dimensional slab architecture**:

```c
typedef struct span {
    Type type;
    byte dims;         // Current dimension (0-4)
    MemCh *m;          // Memory context
    slab *root;        // Root pointer array
    i32 nvalues;       // Number of items stored
    i32 max_idx;       // Maximum index used
} Span;

typedef util *slab[SPAN_STRIDE];  // 16 pointers per slab
```

**Dimension Capacities:**
- **Dim 0**: 16 slots (single slab)
- **Dim 1**: 256 slots (16 × 16 tree)
- **Dim 2**: 4,096 slots (16 × 16 × 16 tree)
- **Dim 3**: 65,536 slots
- **Dim 4**: 1,048,576 slots (maximum)

**Why 16-pointer slabs?** Matches CPU cache line sizes (64-128 bytes), improving memory locality.

## Hashed Structure

Every table entry is a **Hashed** object:

```c
typedef struct hashed {
    Type type;
    i32 idx;       // Position in table's span
    i32 orderIdx;  // Insertion order index
    util id;       // Cached parity/hash
    void *key;     // Key object
    void *value;   // Associated value
} Hashed;
```

**Key Fields:**
- **id**: Pre-computed parity hash (cached to avoid recalculation)
- **idx**: Slot index in the table's Span
- **orderIdx**: Insertion sequence number (enables ordered iteration)
- **key**: Generic pointer to key object
- **value**: Generic pointer to value object

### Why Cache the Hash?

```c
// Without caching (expensive)
util hash1 = Parity_From(key);  // Compute
util hash2 = Parity_From(key);  // Compute again

// With Hashed (efficient)
Hashed *h = Table_GetHashed(tbl, key);
util hash = h->id;  // Use cached value
```

**Benefit**: O(1) hash retrieval vs. O(m) recalculation (m = key size)

## Parity-Based Hashing

Caneka uses **parity checksums** instead of cryptographic hashes:

```c
util Parity_From(Str *s) {
    util parity = 0;
    util slot = 0;
    util size = sizeof(util);  // 8 bytes

    // Sum 8-byte chunks
    while(remaining >= size) {
        memcpy(&slot, ptr, size);
        parity += slot;        // Accumulate
        remaining -= size;
        ptr += size;
    }

    // Handle remainder
    if(remaining) {
        slot = 0;
        memcpy(&slot, ptr, remaining);
        parity += slot;
    }

    parity &= ~7;              // Clear low 3 bits
    parity |= (s->length & 7); // Store length mod 8 in low bits

    return parity;
}
```

**How it works:**
1. Read data in 8-byte chunks
2. Sum all chunks (overflow wraps)
3. Clear low 3 bits
4. Encode string length mod 8 in low bits

**Performance:** O(n) where n = data size, but much faster than SHA/MD5

### Type-Specific Hashing

```c
util Get_Hash(void *_a) {
    Abstract *a = (Abstract *)_a;

    if(a->type.of == TYPE_HASHED) {
        return ((Hashed *)a)->id;  // Return cached hash
    }
    else if(a->type.of == TYPE_STR) {
        return Hash_Str(a);        // String parity
    }
    else if(a->type.of == TYPE_STRVEC) {
        return Hash_StrVec(a);     // Vector parity
    }

    // Lookup dispatch for custom types
    HashFunc func = (HashFunc)Lookup_Get(HashLookup, a->type.of);
    if(func != NULL) {
        return func(a);
    }

    return Hash_Ptr((void *)a);    // Fallback: pointer parity
}
```

**Hash Functions:**
- `Hash_Str()`: Parity of string bytes
- `Hash_StrVec()`: Combined parity of all string segments
- `Hash_WI16()`: Direct value for wrapped 16-bit integers
- `Hash_Util()`: Parity of util wrapper
- `Hash_Ptr()`: Parity of pointer bytes

## Multi-Bit Linear Probing

When collisions occur, Caneka uses **multi-bit extraction probing** instead of simple linear probing.

### HKey Structure

```c
typedef struct hkey {
    Type type;
    i32 idx;      // Current probe index
    util id;      // Hash parity
    i8 dim;       // Current dimension level
    i8 pos;       // Bit position (0-3)
} HKey;
```

### Probing Algorithm

```c
hk->idx = (i32)((hk->id >> (hk->pos * (hk->dim + 1) * 4)) & _modulos[hk->dim + 1]);
```

**Modulo Masks:**
```c
i32 _modulos[5] = {0, 15, 255, 4095, 65535};
//                     ^   ^    ^     ^
//             4-bit  8-bit 12-bit  16-bit
```

### Collision Resolution Steps

**Example: Key with hash `0xABCD1234`**

1. **pos=0, dim=0**: Extract bits 0-3
   ```c
   idx = (0xABCD1234 >> 0) & 15 = 4
   ```

2. **pos=1, dim=0**: Extract bits 4-7
   ```c
   idx = (0xABCD1234 >> 4) & 15 = 3
   ```

3. **pos=2, dim=0**: Extract bits 8-11
   ```c
   idx = (0xABCD1234 >> 8) & 15 = 2
   ```

4. **pos=3, dim=0**: Extract bits 12-15
   ```c
   idx = (0xABCD1234 >> 12) & 15 = 1
   ```

5. **dim=1**: Move to next dimension (256 slots)
   ```c
   idx = (0xABCD1234 >> (0 * 2 * 4)) & 255 = 0x34 = 52
   ```

6. **Linear fallback**: If all bit positions exhausted, increment linearly

### Why Multi-Bit Probing?

**Traditional linear probing:**
```
Hash to slot 10 → 10, 11, 12, 13, 14, ... (clustering!)
```

**Multi-bit extraction:**
```
Hash 0x1234 → 4, 3, 2, 1, 52, 18, ... (scattered)
```

**Benefit**: Better distribution reduces clustering and probe lengths

### Probe Sequence Example

From tests (`table_tests.c`):

```c
Str *k = S(m, "small");
util parity = Parity_From(k);

HKey hk;
Table_HKeyInit(&hk, 1, parity);

// Expected probe sequence:
i32 expected[] = {117, 109, 97, 109, 5, 7, 13, 6, 7, 8, 9, 10};
```

Each call to `Table_HKeyVal(&hk)` returns the next probe index based on bit extraction.

## Table Operations

### Creating Tables

```c
Table *Table_Make(MemCh *m);
```

Creates an empty hash table.

**Example:**
```c
MemCh *m = &book->m;
Table *config = Table_Make(m);
// config->type.state |= FLAG_SPAN_TABLE
// config->nvalues = 0
// config->dims = 0 (starts with 16 slots)
```

### Setting Values

```c
status Table_Set(Table *tbl, void *key, void *value);
```

Inserts or updates a key-value pair.

**Algorithm:**
1. Hash the key: `util parity = Get_Hash(key)`
2. Initialize probe: `HKey hk; Table_HKeyInit(&hk, tbl->dims, parity)`
3. Probe until match or empty slot:
   ```c
   while(true) {
       i32 idx = Table_HKeyVal(&hk);
       Hashed *h = Span_Get(tbl, idx);

       if(h == NULL) {
           // Empty slot - insert here
           h = Hashed_Make(m);
           h->id = parity;
           h->key = key;
           h->value = value;
           h->idx = idx;
           h->orderIdx = tbl->nvalues++;
           Span_Set(tbl, idx, h);
           return SUCCESS;
       }
       else if(h->id == parity && Equals(h->key, key)) {
           // Match - update value
           h->value = value;
           return SUCCESS;
       }
       // Collision - continue probing
   }
   ```
4. Resize if load factor exceeded

**Example:**
```c
Table *users = Table_Make(m);

Str *alice_key = S(m, "alice");
User *alice = User_Make(m, "Alice", "alice@example.com");
Table_Set(users, alice_key, alice);

Str *bob_key = S(m, "bob");
User *bob = User_Make(m, "Bob", "bob@example.com");
Table_Set(users, bob_key, bob);
```

### Getting Values

```c
void *Table_Get(Table *tbl, void *key);
```

Retrieves value for a key, or NULL if not found.

**Algorithm:**
1. Hash key
2. Probe sequence
3. Compare key equality
4. Return value or NULL

**Example:**
```c
User *alice = Table_Get(users, S(m, "alice"));
if(alice != NULL) {
    printf("Found: %s\n", alice->name);
}
```

### Getting Hashed Entries

```c
Hashed *Table_GetHashed(Table *tbl, void *key);
```

Returns the full Hashed structure (includes idx, orderIdx, cached hash).

**Example:**
```c
Hashed *h = Table_GetHashed(users, S(m, "alice"));
if(h != NULL) {
    printf("Key: %s\n", StrVec_GetCStr(h->key));
    printf("Hash: 0x%llx\n", h->id);
    printf("Index: %d\n", h->idx);
    printf("Order: %d\n", h->orderIdx);
    User *alice = h->value;
}
```

### Removing Values

```c
status Table_UnSet(Table *tbl, void *key);
```

Removes a key-value pair.

**Example:**
```c
Table_UnSet(users, S(m, "alice"));
// alice entry removed, orderIdx = -1 marks deletion
```

## Load Factor and Resizing

Tables resize automatically when load factor exceeds **50%**.

### Load Thresholds

```c
static i64 dim_occupied_max[TABLE_MAX_DIMS] = {8, 128, 2048, 3000};
```

**Resize Triggers:**
- **Dim 0** (16 slots): Resize when > 8 items (50% load)
- **Dim 1** (256 slots): Resize when > 128 items (50% load)
- **Dim 2** (4,096 slots): Resize when > 2,048 items (50% load)
- **Dim 3+**: Resize when > 3,000 items

### Resize Operation

```c
if(tbl->nvalues > dim_occupied_max[tbl->dims]) {
    Iter_ExpandTo(it, dim_max_idx[tbl->dims] + 1);
}
```

**Dimension Limits:**
```c
i32 dim_max_idx[5] = {15, 255, 4095, 65535, 1048575};
```

**Resize Process:**
1. Allocate next dimension level
2. Rehash all entries (probe sequence changes with dim size)
3. Update indices

**Example:**
```c
Table *tbl = Table_Make(m);  // Dim 0 (16 slots)

// Add 8 items - OK
for(int i = 0; i < 8; i++) {
    Table_Set(tbl, I32_Wrapped(m, i), S(m, "value"));
}

// Add 9th item - triggers resize to Dim 1 (256 slots)
Table_Set(tbl, I32_Wrapped(m, 8), S(m, "value"));
// tbl->dims = 1
```

## Iteration

Tables support **ordered iteration** using `orderIdx`:

```c
Iter it = Iter_Make(tbl);
while(Iter_HasNext(&it)) {
    Hashed *h = Iter_Next(&it);
    if(h != NULL) {  // Skip gaps
        printf("Key: %s, Value: %s\n",
               StrVec_GetCStr(h->key),
               StrVec_GetCStr(h->value));
    }
}
```

**Iteration order:** Matches insertion order via `orderIdx` field

### Ordered Iteration Example

```c
Table *tbl = Table_Make(m);
Table_Set(tbl, S(m, "zebra"), S(m, "Z"));
Table_Set(tbl, S(m, "apple"), S(m, "A"));
Table_Set(tbl, S(m, "banana"), S(m, "B"));

Iter it = Iter_Make(tbl);
while(Iter_HasNext(&it)) {
    Hashed *h = Iter_Next(&it);
    printf("%s ", StrVec_GetCStr(h->key));
}
// Output: zebra apple banana (insertion order, not sorted)
```

## Lookup: Type-Indexed Dispatch

**Lookup** is a simpler structure for **O(1) type-based dispatch**.

### Lookup Structure

```c
typedef struct lookup {
    Type type;
    word offset;      // Base type index
    Span *values;     // Dynamic array
    int latest_idx;   // Last accessed index (cache hint)
} Lookup;
```

### How It Works

```c
void *Lookup_Get(Lookup *lk, word type) {
    if(type >= lk->offset && type <= lk->offset + lk->values->max_idx) {
        void *result = Span_Get(lk->values, (i32)(type - lk->offset));
        if(result != NULL) {
            lk->latest_idx = type - lk->offset;  // Cache
        }
        return result;
    }
    return NULL;
}
```

**Time Complexity:** O(1) - direct array access by offset

### Creating Lookups

```c
Lookup *Lookup_Make(MemCh *m, word offset);
```

**Example:**
```c
// Create lookup starting at TYPE_ZERO (0)
Lookup *formatters = Lookup_Make(m, _TYPE_ZERO);

// Register formatters for types
Lookup_Add(m, formatters, TYPE_STR, (void *)Format_Str);
Lookup_Add(m, formatters, TYPE_I32, (void *)Format_I32);
Lookup_Add(m, formatters, TYPE_TABLE, (void *)Format_Table);

// Later, dispatch by type
ToStreamFunc func = Lookup_Get(formatters, obj->type.of);
if(func != NULL) {
    func(buffer, obj);
}
```

### Lookup vs Table

| Feature | Table | Lookup |
|---------|-------|--------|
| **Keys** | Any object | Integer type IDs |
| **Access** | O(k) probing (avg k=2-4) | O(1) direct index |
| **Collisions** | Multi-bit probing | None (dense array) |
| **Use Case** | General key-value | Type dispatch |
| **Memory** | Sparse (50% load) | Dense (100% utilized) |
| **Order** | Insertion order | Implicit (type ID order) |

## Practical Examples

### Example 1: Configuration Table

```c
MemCh *m = &book->m;
Table *config = Table_Make(m);

// Store configuration values
Table_Set(config, S(m, "host"), S(m, "localhost"));
Table_Set(config, S(m, "port"), I32_Wrapped(m, 8080));
Table_Set(config, S(m, "debug"), Bool_Wrapped(m, true));
Table_Set(config, S(m, "max-connections"), I32_Wrapped(m, 100));

// Retrieve configuration
Str *host = Table_Get(config, S(m, "host"));
Single *port = Table_Get(config, S(m, "port"));

printf("Server: %s:%d\n", StrVec_GetCStr(host), (i32)port->val.i);
// Output: Server: localhost:8080
```

### Example 2: User Database

```c
typedef struct user {
    Type type;
    Str *name;
    Str *email;
    i32 age;
} User;

User *User_Make(MemCh *m, const char *name, const char *email, i32 age) {
    User *u = MemCh_AllocOf(m, sizeof(User), TYPE_USER);
    u->name = S(m, name);
    u->email = S(m, email);
    u->age = age;
    return u;
}

Table *users = Table_Make(m);

// Add users
Table_Set(users, S(m, "alice"), User_Make(m, "Alice", "alice@example.com", 30));
Table_Set(users, S(m, "bob"), User_Make(m, "Bob", "bob@example.com", 25));
Table_Set(users, S(m, "charlie"), User_Make(m, "Charlie", "charlie@example.com", 35));

// Lookup user
User *bob = Table_Get(users, S(m, "bob"));
printf("%s is %d years old\n", StrVec_GetCStr(bob->name), bob->age);
// Output: Bob is 25 years old

// Iterate all users
Iter it = Iter_Make(users);
while(Iter_HasNext(&it)) {
    Hashed *h = Iter_Next(&it);
    if(h != NULL) {
        User *u = h->value;
        printf("User: %s (%s)\n",
               StrVec_GetCStr(u->name),
               StrVec_GetCStr(u->email));
    }
}
```

### Example 3: Hash Function Registry

```c
// Global hash function lookup
Lookup *HashLookup;

typedef util (*HashFunc)(void *);

status Hash_Init(MemCh *m) {
    HashLookup = Lookup_Make(m, _TYPE_ZERO);

    // Register hash functions for types
    Lookup_Add(m, HashLookup, TYPE_STR, (void *)Hash_Str);
    Lookup_Add(m, HashLookup, TYPE_STRVEC, (void *)Hash_StrVec);
    Lookup_Add(m, HashLookup, TYPE_WRAPPED_I32, (void *)Hash_WI32);
    Lookup_Add(m, HashLookup, TYPE_TABLE, (void *)Hash_Table);

    return SUCCESS;
}

// Later, polymorphic hashing
util Get_Hash(void *obj) {
    Abstract *a = (Abstract *)obj;

    HashFunc func = Lookup_Get(HashLookup, a->type.of);
    if(func != NULL) {
        return func(obj);
    }

    return Hash_Ptr(obj);  // Fallback
}
```

### Example 4: Collision Handling Trace

```c
Table *tbl = Table_Make(m);

// Force collisions by using small table
for(int i = 0; i < 20; i++) {
    Str *key = Fmt(m, "key%d", i);
    Table_Set(tbl, key, I32_Wrapped(m, i));
}

// Inspect collision handling
Hashed *h = Table_GetHashed(tbl, S(m, "key5"));
printf("Key 'key5' stored at index: %d\n", h->idx);
printf("Hash: 0x%llx\n", h->id);
printf("Insertion order: %d\n", h->orderIdx);

// Probe sequence for a key
Str *probe_key = S(m, "test");
util parity = Parity_From(probe_key);

HKey hk;
Table_HKeyInit(&hk, tbl->dims, parity);

printf("Probe sequence for 'test':\n");
for(int i = 0; i < 10; i++) {
    i32 idx = Table_HKeyVal(&hk);
    printf("  Probe %d: index %d\n", i, idx);
}
```

## Performance Characteristics

| Operation | Complexity | Notes |
|-----------|-----------|-------|
| `Table_Set` | O(k) + O(n) | k = probes (avg 2-4), n = resize if triggered |
| `Table_Get` | O(k) | k = probes (avg 2-4) |
| `Table_GetHashed` | O(k) | Returns full Hashed entry |
| `Table_UnSet` | O(k) | Marks entry deleted |
| `Parity_From` | O(m) | m = data size |
| `Lookup_Get` | O(1) | Direct array access |
| `Lookup_Add` | O(1) | Direct array set |
| Table Resize | O(n × k) | n = items, k = avg probes per item |

**Average Probe Lengths:**
- **50% load**: ~1.5 probes per lookup
- **75% load**: ~4 probes per lookup (avoided via resize)
- **90% load**: ~10 probes per lookup (never reached)

### Memory Overhead

```c
// Hashed structure: 40 bytes on 64-bit systems
sizeof(Hashed) = sizeof(Type) + 3*i32 + util + 2*ptr
                = 4 + 12 + 8 + 16 = 40 bytes

// Per table entry overhead
Overhead = Hashed (40) + Span slot (8) = 48 bytes + key + value sizes

// Example: 100 string entries
Total = 100 * (48 + avg_key_size + avg_value_size)
```

**50% load factor trade-off:**
- **Benefit**: Faster lookups (fewer probes)
- **Cost**: 2x memory usage vs. 100% load

## Best Practices

1. **Use String keys for readability**: `Table_Set(tbl, S(m, "config"), value)`
2. **Cache Hashed for repeated access**: Avoid recalculating hash
3. **Pre-size tables when count known**: Reduce resize operations
4. **Use Lookup for type dispatch**: O(1) beats hash table for integer keys
5. **Iterate in insertion order**: Tables preserve orderIdx
6. **Check NULL on Get**: Keys may not exist

## Common Pitfalls

### Pitfall 1: Assuming Sorted Iteration

```c
// WRONG - Iteration is insertion order, not sorted
Table *tbl = Table_Make(m);
Table_Set(tbl, S(m, "zebra"), value1);
Table_Set(tbl, S(m, "apple"), value2);

Iter it = Iter_Make(tbl);
// Iterates: zebra, apple (NOT alphabetical)
```

**Fix:** Sort keys separately if needed

```c
// Collect keys
Span *keys = Span_Make(m);
Iter it = Iter_Make(tbl);
while(Iter_HasNext(&it)) {
    Hashed *h = Iter_Next(&it);
    if(h != NULL) Span_Add(keys, h->key);
}

// Sort keys (custom comparator)
Sort(keys, StringCompare);

// Iterate in sorted order
Iter kit = Iter_Make(keys);
while(Iter_HasNext(&kit)) {
    Str *key = Iter_Next(&kit);
    void *value = Table_Get(tbl, key);
    Process(key, value);
}
```

### Pitfall 2: Modifying Keys After Insertion

```c
// WRONG - Modifying key changes hash
Str *key = Str_From(m, "config");
Table_Set(tbl, key, value);

Str_Add(key, "_backup");  // key now "config_backup"
void *v = Table_Get(tbl, key);  // NULL! Hash changed
```

**Fix:** Use immutable keys or clone before modification

```c
Str *key = Str_From(m, "config");
Table_Set(tbl, key, value);

// Clone before modifying
Str *modified_key = Str_Clone(m, key);
Str_Add(modified_key, "_backup");
```

### Pitfall 3: Using Lookup for Non-Dense Type IDs

```c
// WRONG - Sparse type IDs waste memory
Lookup *lk = Lookup_Make(m, 0);
Lookup_Add(m, lk, 1000, func1);      // Allocates 1000 slots
Lookup_Add(m, lk, 2000, func2);      // Allocates another 1000
// 2000 slots allocated, only 2 used!
```

**Fix:** Use Table for sparse integer keys

```c
Table *dispatch = Table_Make(m);
Table_Set(dispatch, I32_Wrapped(m, 1000), func1);
Table_Set(dispatch, I32_Wrapped(m, 2000), func2);
// Only allocates for used keys
```

### Pitfall 4: Forgetting NULL Checks

```c
// WRONG - Assuming key exists
User *user = Table_Get(users, S(m, "unknown"));
printf("%s\n", user->name);  // CRASH if user == NULL
```

**Fix:** Always check NULL

```c
User *user = Table_Get(users, S(m, "unknown"));
if(user != NULL) {
    printf("%s\n", StrVec_GetCStr(user->name));
} else {
    printf("User not found\n");
}
```

### Pitfall 5: Ignoring Resize Overhead

```c
// WRONG - Triggering many resizes
Table *tbl = Table_Make(m);
for(int i = 0; i < 10000; i++) {
    Table_Set(tbl, I32_Wrapped(m, i), value);  // Resizes at 8, 128, 2048
}
```

**Fix:** Pre-allocate if count known

```c
// Better - Pre-expand to dim 3 (65,536 slots)
Table *tbl = Table_Make(m);
Iter it = Iter_Make(tbl);
Iter_ExpandTo(&it, 65535);  // Pre-allocate

for(int i = 0; i < 10000; i++) {
    Table_Set(tbl, I32_Wrapped(m, i), value);  // No resizes
}
```

## Advanced Patterns

### Pattern 1: Nested Tables

```c
// Create hierarchical config
Table *config = Table_Make(m);

Table *db_config = Table_Make(m);
Table_Set(db_config, S(m, "host"), S(m, "localhost"));
Table_Set(db_config, S(m, "port"), I32_Wrapped(m, 5432));

Table *cache_config = Table_Make(m);
Table_Set(cache_config, S(m, "size"), I32_Wrapped(m, 1000));
Table_Set(cache_config, S(m, "ttl"), I32_Wrapped(m, 60));

Table_Set(config, S(m, "database"), db_config);
Table_Set(config, S(m, "cache"), cache_config);

// Access nested values
Table *db = Table_Get(config, S(m, "database"));
Single *port = Table_Get(db, S(m, "port"));
printf("DB Port: %d\n", (i32)port->val.i);
```

### Pattern 2: Type-Safe Wrapper

```c
// Create type-safe table wrapper
typedef struct user_table {
    Type type;
    Table *tbl;
} UserTable;

UserTable *UserTable_Make(MemCh *m) {
    UserTable *ut = MemCh_AllocOf(m, sizeof(UserTable), TYPE_USER_TABLE);
    ut->tbl = Table_Make(m);
    return ut;
}

status UserTable_Set(UserTable *ut, Str *username, User *user) {
    return Table_Set(ut->tbl, username, user);
}

User *UserTable_Get(UserTable *ut, Str *username) {
    return (User *)Table_Get(ut->tbl, username);
}
```

### Pattern 3: Polymorphic ToString

```c
// Registry of type-specific formatters
Lookup *ToStreamLookup;

typedef status (*ToStreamFunc)(Buff *bf, void *obj, word flags);

status ToStream_Init(MemCh *m) {
    ToStreamLookup = Lookup_Make(m, _TYPE_ZERO);

    Lookup_Add(m, ToStreamLookup, TYPE_STR, (void *)ToStream_Str);
    Lookup_Add(m, ToStreamLookup, TYPE_I32, (void *)ToStream_I32);
    Lookup_Add(m, ToStreamLookup, TYPE_TABLE, (void *)ToStream_Table);

    return SUCCESS;
}

status ToStream(Buff *bf, void *obj) {
    Abstract *a = (Abstract *)obj;

    ToStreamFunc func = Lookup_Get(ToStreamLookup, a->type.of);
    if(func != NULL) {
        return func(bf, obj, ZERO);
    }

    return ERROR;
}
```

### Pattern 4: Bidirectional Lookup

```c
// Forward lookup: username → user
Table *users_by_name = Table_Make(m);

// Reverse lookup: user_id → user
Table *users_by_id = Table_Make(m);

User *user = User_Make(m, "alice", "alice@example.com");

Table_Set(users_by_name, S(m, "alice"), user);
Table_Set(users_by_id, I32_Wrapped(m, user->id), user);

// Lookup by name
User *u1 = Table_Get(users_by_name, S(m, "alice"));

// Lookup by ID
User *u2 = Table_Get(users_by_id, I32_Wrapped(m, 42));
```

## See Also

- [Span Complete](memory/span-complete.md) - Foundation for Table structure
- [Iter Complete](memory/iter-complete.md) - Iteration over tables
- [Type System](type-system-complete.md) - Hashed structure and type dispatch
- [String Handling](strings-complete.md) - String keys in tables
