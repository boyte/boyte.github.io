# Debug System: Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](debug-system-complete-part2)

---

## Why a Debug System?

Debugging C programs is notoriously challenging—segmentation faults with cryptic error messages, memory corruption invisible until crash, missing stack traces in production. Caneka's Debug System addresses these challenges with a comprehensive framework:

1. **Call Stack Tracking** - Automatic function/line capture for detailed error reports
2. **Type-Aware Printing** - Every object knows how to format itself for debugging
3. **Memory Introspection** - Inspect live allocations, detect leaks, track ownership
4. **Guard Validation** - Prevent infinite loops and deep recursion
5. **Error Propagation** - Structured error handling with context preservation
6. **Signal Integration** - Graceful handling of crashes with informative output

**Key Advantages:**
- **Zero Runtime Cost (Release Builds)**: Debug features compile away with -DNDEBUG
- **Automatic Location Capture**: `__FILE__`, `__LINE__`, `__func__` via preprocessor
- **Extensible Type System**: Every module registers its own debug printers
- **Stream-Based Output**: All debugging uses Buff abstraction (files, sockets, memory)
- **Memory Safety**: All debug allocations use MemCh (no leaks)

---


## Table of Contents

1. [Debug Stack](#debug-stack)
   - [Stack Entry Structure](#stack-entry-structure)
   - [Pushing and Popping Entries](#pushing-and-popping-entries)
   - [Printing Stack Traces](#printing-stack-traces)
   - [Object Reference Tracking](#object-reference-tracking)
2. [Universal ToString System](#universal-tostring-system)
   - [ToS Function](#tos-function)
   - [Registering Printers](#registering-printers)
   - [Formatting Flags](#formatting-flags)
   - [Type Registration Pattern](#type-registration-pattern)
3. [Format System](#format-system)
   - [Fmt Function](#fmt-function)
   - [Format Specifiers](#format-specifiers)
   - [Output Streams](#output-streams)
   - [ANSI Color Support](#ansi-color-support)
4. [Memory Debugging](#memory-debugging)
   - [Memory Iteration](#memory-iteration)
   - [Memory Statistics](#memory-statistics)
   - [Memory Validation](#memory-validation)
   - [Leak Detection](#leak-detection)
5. [Guard System](#guard-system)
   - [Guard Counter Pattern](#guard-counter-pattern)
   - [Guard Functions](#guard-functions)
   - [Infinite Loop Prevention](#infinite-loop-prevention)
6. [Error Handling](#error-handling)
   - [Error Function](#error-function)
   - [Fatal Errors](#fatal-errors)
   - [Signal Handling](#signal-handling)
   - [Error Handlers](#error-handlers)
7. [Type Introspection](#type-introspection)
   - [Type Name Lookup](#type-name-lookup)
   - [Type Registry](#type-registry)
   - [State Flags](#state-flags)
8. [Common Patterns](#common-patterns)
9. [Performance Characteristics](#performance-characteristics)
10. [Best Practices](#best-practices)
11. [Common Pitfalls](#common-pitfalls)

---


## Debug Stack

### Stack Entry Structure

The Debug Stack maintains a runtime call stack with location and object information.

**StackEntry Structure:**
```c
typedef struct debug_stack {
    Type type;
    word typeOf;        // Type of referenced object
    word _;             // Reserved
    char *funcName;     // Function name (from __func__)
    char *fname;        // File name (from __FILE__)
    void *ref;          // Object reference
    i32 line;           // Line number (from __LINE__)
    i32 pos;            // Position (reserved)
} StackEntry;
```

**Global Stack:**
- Single process-wide stack (thread-local in multi-threaded builds)
- Maximum depth: 64 entries
- Automatic overflow detection

### Pushing and Popping Entries

#### DebugStack_Push() - Add Entry

**Macro:**
```c
#define DebugStack_Push(ref, typeOf) \
    _DebugStack_Push((char *)__func__, __FILE__, (ref), \
                     ((ref) != NULL ? typeOf : 0), __LINE__, 0)
```

**Underlying Function:**
```c
void _DebugStack_Push(char *cstr, char *fname, void *ref,
                      word typeOf, i32 line, i32 pos);
```

**Example: Track Function Entry**
```c
void ProcessData(MemCh *m, Data *data){
    DebugStack_Push(data, TYPE_DATA);

    // ... process data ...

    DebugStack_Pop();
}
```

**Key Behaviors:**
- Captures `__func__`, `__FILE__`, `__LINE__` automatically
- Stores object reference and type
- No manual cleanup needed if function returns via Error()

#### DebugStack_Pop() - Remove Entry

**Signature:**
```c
void DebugStack_Pop();
```

Removes the most recent stack entry.

**Example: Balanced Push/Pop**
```c
status ParseFile(MemCh *m, Str *filename){
    DebugStack_Push(filename, TYPE_STR);

    Buff *bf = Buff_Make(m, 0);
    File_Open(m, bf, IoPath_FromStr(m, filename), O_RDONLY, 0);

    if(ParseContent(bf) == ERROR){
        DebugStack_Pop();
        return ERROR;
    }

    DebugStack_Pop();
    return SUCCESS;
}
```

**IMPORTANT**: If Error() is called, stack is automatically printed—no need to manually pop.

### Printing Stack Traces

#### DebugStack_Print() - Print Full Stack

**Signature:**
```c
i32 DebugStack_Print(Buff *bf, word flags);
```

Prints the entire debug stack to a buffer.

**Flags:**
- `MORE` - Include detailed object information
- `DEBUG` - Maximum verbosity (all fields)
- `ZERO` - Minimal output (function names only)

**Example: Print to stderr**
```c
DebugStack_Print(ErrStream, MORE);
```

**Output Format:**
```
Debug Stack (depth=5):
  [4] HttpHandler_Process @ src/inter/http/handler.c:245 (HttpCtx @ 0x7fa8c000)
  [3] Route_Dispatch @ src/inter/www/route.c:112 (Route @ 0x7fa8b800)
  [2] TcpTask_Process @ src/ext/serve/tcp_task.c:89 (TcpTask @ 0x7fa8b000)
  [1] Task_Tumble @ src/ext/navigate/task.c:342 (Task @ 0x7fa8a000)
  [0] main @ src/programs/webserver/main.c:56 (NULL)
```

#### DebugStack_Show() - Formatted Display

**Signature:**
```c
status DebugStack_Show(Str *style, Str *msg, word flags);
```

Prints stack with optional style prefix and message.

**Example:**
```c
DebugStack_Show(S(m, "ERROR"), S(m, "Connection failed"), MORE);
```

**Output:**
```
ERROR: Connection failed
[Debug stack follows...]
```

### Object Reference Tracking

#### DebugStack_SetRef() - Update Reference

**Signature:**
```c
void DebugStack_SetRef(void *v, word typeOf);
```

Updates the object reference for the current stack frame.

**Example: Update After Allocation**
```c
void *Parser_Make(MemCh *m){
    DebugStack_Push(NULL, 0);  // Don't have object yet

    Parser *p = (Parser *)MemCh_Alloc(m, sizeof(Parser));
    DebugStack_SetRef(p, TYPE_PARSER);  // Update with actual object

    // ... initialize ...

    DebugStack_Pop();
    return p;
}
```

**Use Case:** When object doesn't exist at function entry but is created during execution.

#### DebugStack_Get() - Retrieve Current Entry

**Signature:**
```c
StackEntry *DebugStack_Get();
```

Returns pointer to the current (top) stack entry.

**Example: Inspect Current Context**
```c
StackEntry *entry = DebugStack_Get();
printf("Current function: %s\n", entry->funcName);
printf("Current file: %s:%d\n", entry->fname, entry->line);
```

---


## Universal ToString System

### ToS Function

**Signature:**
```c
status ToS(Buff *bf, void *t, cls type, word flags);
```

Universal type-aware printing function. Dispatches to registered printer based on object's type.

**Parameters:**
- `bf` - Output buffer
- `t` - Object to print
- `type` - Type ID (can be 0 to auto-detect from object's Type header)
- `flags` - Output format control (ZERO, MORE, DEBUG)

**Example: Print Any Object**
```c
Str *text = S(m, "Hello");
ToS(OutStream, text, TYPE_STR, ZERO);  // Standard output

StrVec *vec = Sv(m, "World");
ToS(OutStream, vec, 0, DEBUG);  // Auto-detect type, full debug

Buff *bf = Buff_Make(m, 0);
ToS(OutStream, bf, TYPE_BUFF, MORE);  // Verbose output
```

### Registering Printers

#### ToSFunc Signature

**Type Definition:**
```c
typedef status (*ToSFunc)(Buff *bf, void *a, cls type, word flags);
```

All printer functions must match this signature.

**Example Printer:**
```c
status MyObject_Print(Buff *bf, void *a, cls type, word flags){
    MyObject *obj = (MyObject *)a;

    if(flags & DEBUG){
        // Full debug output
        Buff_Add(bf, S(bf->m, "MyObject {\n"));
        Buff_Add(bf, S(bf->m, "  field1: "));
        ToS(bf, obj->field1, 0, flags);
        Buff_Add(bf, S(bf->m, "\n  field2: "));
        ToS(bf, obj->field2, 0, flags);
        Buff_Add(bf, S(bf->m, "\n}\n"));
    } else if(flags & MORE){
        // Verbose output
        Buff_Add(bf, S(bf->m, "MyObject("));
        ToS(bf, obj->field1, 0, ZERO);
        Buff_Add(bf, S(bf->m, ")"));
    } else {
        // Standard output
        ToS(bf, obj->field1, 0, ZERO);
    }

    return SUCCESS;
}
```

### Formatting Flags

| Flag | Description | Use Case |
|------|-------------|----------|
| `ZERO` | Standard output, minimal formatting | User-facing display |
| `MORE` | Verbose output, additional context | Logging, debugging |
| `DEBUG` | Maximum verbosity, all fields | Development, troubleshooting |

**Flag Combinations:**
```c
ToS(bf, obj, 0, ZERO);            // Minimal
ToS(bf, obj, 0, MORE);            // Verbose
ToS(bf, obj, 0, DEBUG);           // Full debug
ToS(bf, obj, 0, DEBUG | MORE);    // Maximum output
```

### Type Registration Pattern

#### Module Initialization

Each module registers its type printers during initialization:

**Example: Register MyObject Printer**
```c
status MyModule_ToSInit(MemCh *m, Lookup *lk){
    // Register printer function
    Lookup_Add(m, lk, TYPE_MY_OBJECT, (void *)MyObject_Print);

    // Register type name
    Lookup_Add(m, TypeStringRanges, TYPE_MY_OBJECT, "MyObject");

    return SUCCESS;
}

// Called during module initialization
status MyModule_Init(MemCh *m){
    MyModule_ToSInit(m, ToStreamLookup);
    return SUCCESS;
}
```

**Global ToS Lookup:**
```c
extern Lookup *ToStreamLookup;  // Registry of printer functions
```

---


## Format System

### Fmt Function

**Signature:**
```c
status Fmt(Buff *bf, char *fmt, void *args[]);
```

Powerful formatting function with custom specifiers for debug output.

**Parameters:**
- `bf` - Output buffer
- `fmt` - Format string with specifiers
- `args` - NULL-terminated array of arguments

**Example:**
```c
Str *name = S(m, "caneka");
i32 version = 42;

void *args[] = {name, Single_WrapI64(m, version), NULL};
Fmt(OutStream, "Project: $ Version: $", args);
// Output: Project: caneka Version: 42
```

### Format Specifiers

| Specifier | Description | Debug Level |
|-----------|-------------|-------------|
| `$` | Standard output | ZERO |
| `@` | Minimal debug output | MORE |
| `&` | Maximum debug output | DEBUG \| MORE |
| `^` | ANSI color/style | Special |
| `\\` | Escape (literal `$`, `@`, etc.) | N/A |

**Example: Multiple Debug Levels**
```c
StrVec *path = IoPath(m, "/usr/local/bin");

void *args[] = {path, path, path, NULL};
Fmt(OutStream, "Standard: $\nVerbose: @\nDebug: &", args);
```

**Output:**
```
Standard: /usr/local/bin
Verbose: StrVec(len=4, ["/", "usr", "local", "bin"])
Debug: StrVec {
  type: TYPE_STRVEC
  len: 4
  cap: 8
  data: [
    [0] Str("/")
    [1] Str("usr")
    [2] Str("local")
    [3] Str("bin")
  ]
}
```

### Output Streams

#### Global Buffers

**Declarations:**
```c
extern Buff *OutStream;   // Standard output (stdout)
extern Buff *ErrStream;   // Error output (stderr)
extern Buff *RandStream;  // Random number source (/dev/urandom)
```

Initialized during `Core_Init()`.

#### Out() Convenience Function

**Signature:**
```c
i64 Out(char *fmt, void *args[]);
```

Shorthand for `Fmt(OutStream, fmt, args)`.

**Example:**
```c
Str *msg = S(m, "Processing complete");
void *args[] = {msg, NULL};
Out("$\n", args);  // Print to stdout
```

**Equivalent to:**
```c
Fmt(OutStream, "$\n", args);
Buff_Flush(OutStream);
```

### ANSI Color Support

#### Color Specifier: `^`

**Format:** `^{style}text^{reset}`

**Styles:**
- `r` - Red
- `g` - Green
- `b` - Blue
- `y` - Yellow
- `m` - Magenta
- `c` - Cyan
- `R` - Red background
- `B` - Bold
- `_` - Underline
- `0` - Reset/normal

**Example: Colored Error Message**
```c
void *args[] = {NULL};
Fmt(ErrStream, "^{r}ERROR:^{0} Operation failed\n", args);
// Prints "ERROR:" in red, then normal text
```

**Example: Bold Text**
```c
Fmt(OutStream, "^{B}Important:^{0} Read this carefully", args);
// Prints "Important:" in bold
```

---


## Memory Debugging

### Memory Iteration

#### MemIter - Iterate Live Allocations

**Structure:**
```c
typedef struct mem_iter {
    Type type;
    struct {
        MemCh *target;  // Memory context to inspect
        void **arr;     // Array of allocations
    } input;
    i32 slIdx;          // Current slab index
    i32 maxSlIdx;       // Maximum slab index
    void *ptr;          // Current pointer
    void *end;          // End pointer
} MemIter;
```

**API:**
```c
MemIter *MemIter_Make(MemCh *m, MemCh *target);
status MemIter_Next(MemIter *mit);
void *MemIter_Get(MemIter *mit);
```

**Example: Print All Allocations**
```c
MemCh *targetCtx = GetSomeContext();
MemIter *it = MemIter_Make(m, targetCtx);

void *obj;
while(MemIter_Next(it) != END){
    obj = MemIter_Get(it);

    // Print with type detection
    ToS(OutStream, obj, 0, MORE);
    Buff_Add(OutStream, S(m, "\n"));
}
```

**Use Case:** Debugging memory leaks by inspecting all live objects in a context.

### Memory Statistics

#### MemBook_GetStats() - Get Allocation Info

**Signature:**
```c
status MemBook_GetStats(void *addr, MemBookStats *st);
```

Retrieves statistics for an allocation.

**MemBookStats Structure:**
```c
typedef struct mem_book_stats {
    Type type;
    i32 bookIdx;   // Which memory book (0-63)
    i32 pageIdx;   // Which page in book
    i32 recycled;  // Recycled allocations
    i32 total;     // Total allocations
} MemBookStats;
```

**Example:**
```c
MemBookStats stats;
if(MemBook_GetStats(ptr, &stats) == SUCCESS){
    printf("Book: %d, Page: %d, Recycled: %d, Total: %d\n",
           stats.bookIdx, stats.pageIdx, stats.recycled, stats.total);
}
```

#### MemCount() - Count Allocations by Level

**Signature:**
```c
i64 MemCount(i16 level);
```

Returns count of MemCh contexts at specified nesting level.

**Example:**
```c
i64 topLevel = MemCount(0);    // Root contexts
i64 firstLevel = MemCount(1);  // First-level children
i64 secondLevel = MemCount(2); // Second-level children

printf("Memory hierarchy: %lld / %lld / %lld\n",
       topLevel, firstLevel, secondLevel);
```

#### MemChapterCount() - Total Contexts

**Signature:**
```c
i64 MemChapterCount();
```

Returns total number of active MemCh contexts.

**Example:**
```c
i64 before = MemChapterCount();

// Create temporary contexts
MemCh *tmp1 = MemCh_Make();
MemCh *tmp2 = MemCh_Make();

i64 after = MemChapterCount();

printf("Created %lld new contexts\n", after - before);
// Output: Created 2 new contexts
```

#### MemAvailableChapterCount() - Available Contexts

**Signature:**
```c
i64 MemAvailableChapterCount();
```

Returns count of available (not yet allocated) MemCh slots.

**Use Case:** Detecting context exhaustion before allocation fails.

### Memory Validation

#### IsZeroed() - Validate Zero Memory

**Signature:**
```c
boolean IsZeroed(MemCh *m, byte *b, size_t sz,
                 char *func, char *file, int line);
```

Validates that memory region is properly zeroed. Generates error if not.

**Example:**
```c
byte buffer[256];
memset(buffer, 0, sizeof(buffer));

if(!IsZeroed(m, buffer, sizeof(buffer), __func__, __FILE__, __LINE__)){
    // Error generated automatically
}
```

**Use Case:** Detecting uninitialized memory or corruption.

### Leak Detection

#### Pattern: Compare Context Counts

**Example: Detect Leaks in Function**
```c
void TestForLeaks(MemCh *m){
    i64 before = MemChapterCount();

    // Run code under test
    ProcessData(m);

    i64 after = MemChapterCount();

    if(after > before){
        printf("LEAK: %lld contexts not freed\n", after - before);

        // Iterate to find leaked contexts
        MemIter *it = MemIter_Make(m, m);
        while(MemIter_Next(it) != END){
            void *obj = MemIter_Get(it);
            ToS(ErrStream, obj, 0, DEBUG);
        }
    }
}
```

---


## Guard System

### Guard Counter Pattern

Guards prevent infinite loops and deep recursion by tracking iteration counts.

**Guard Variable:**
```c
i16 guard = 0;  // Must be initialized to 0
```

**Typical Maximum:** 6-10 iterations (configurable per use case)

### Guard Functions

#### Guard_Incr() - Increment with Check

**Signature:**
```c
status Guard_Incr(MemCh *m, i16 *g, i16 max,
                  char *func, char *file, int line);
```

Increments guard counter and checks against maximum. Generates error if exceeded.

**Macro (Preferred):**
```c
#define Guard_Incr(m, g, max) \
    _Guard_Incr((m), (g), (max), __func__, __FILE__, __LINE__)
```

**Example: Prevent Infinite Loop**
```c
void ProcessQueue(MemCh *m, Queue *q){
    i16 guard = 0;

    while(Queue_HasItems(q)){
        if(Guard_Incr(m, &guard, 100) == ERROR){
            break;  // Exceeded 100 iterations
        }

        Item *item = Queue_Pop(q);
        ProcessItem(m, item);
    }
}
```

**Output on Exceeded:**
```
ERROR: Guard exceeded at ProcessQueue (queue.c:42)
  Max: 100
  Actual: 101
[Debug stack printed...]
```

#### Guard() - Check Without Increment

**Signature:**
```c
boolean Guard(i16 *g, i16 max, char *func, char *file, int line);
```

Checks guard counter without incrementing. Returns false if exceeded.

**Example:**
```c
i16 depth = 0;

void RecursiveFunction(MemCh *m, Node *node, i16 *depth){
    (*depth)++;

    if(!Guard(depth, 10, __func__, __FILE__, __LINE__)){
        Error(m, "Recursion too deep");
        return;
    }

    // Process node...

    if(node->left){
        RecursiveFunction(m, node->left, depth);
    }

    (*depth)--;
}
```

#### Guard_Reset() - Reset Counter

**Signature:**
```c
status Guard_Reset(i16 *g);
```

Resets guard counter to zero.

**Example: Reuse Guard**
```c
i16 guard = 0;

// First loop
while(condition1){
    Guard_Incr(m, &guard, 10);
    // ...
}

// Reset for second loop
Guard_Reset(&guard);

// Second loop
while(condition2){
    Guard_Incr(m, &guard, 10);
    // ...
}
```

### Infinite Loop Prevention

**Common Pattern:**

```c
void ServerLoop(MemCh *m, TcpServer *server){
    i16 guard = 0;

    while(true){
        Guard_Incr(m, &guard, 10000);  // Max 10,000 connections per cycle

        TcpTask *task = TcpServer_Accept(server);
        if(task == NULL) break;

        ProcessConnection(m, task);
    }
}
```

**Design Decision:** Guards are defensive programming—loops should terminate naturally, but guards catch bugs during development.

---


## Error Handling

### Error Function

**Macro:**
```c
#define Error(m, fmt, ...) \
    _Error((m), __func__, __FILE__, __LINE__, (fmt), (void*[]){__VA_ARGS__, NULL})
```

**Underlying Signature:**
```c
void Error(MemCh *m, char *func, char *file, int line,
           char *fmt, void *args[]);
```

Generates error message, prints debug stack, and terminates program with exit code 13.

**Example: Basic Error**
```c
if(value < 0){
    Error(m, "Invalid value: $", Single_WrapI64(m, value));
}
```

**Output:**
```
ERROR at ValidateInput (validate.c:42)
Invalid value: -5

Debug Stack (depth=3):
  [2] ValidateInput @ src/validation/validate.c:42
  [1] ProcessRequest @ src/http/handler.c:89
  [0] main @ src/main.c:15

[Program exits with code 13]
```

**Example: Multiple Arguments**
```c
Str *filename = S(m, "config.ini");
i32 line = 23;

Error(m, "Parse error in $:$", filename, Single_WrapI32(m, line));
```

**Output:**
```
ERROR at ParseConfig (parser.c:112)
Parse error in config.ini:23
```

### Fatal Errors

#### Fatal() - Unrecoverable Error

**Signature:**
```c
void Fatal(char *func, char *file, int line, char *fmt, void *args[]);
```

Like Error() but does not require MemCh (for errors during initialization).

**Example:**
```c
if(Core_Init() == ERROR){
    Fatal(__func__, __FILE__, __LINE__, "Core initialization failed", NULL);
}
```

### Signal Handling

The error system installs handlers for common signals:

**Handled Signals:**
- `SIGSEGV` - Segmentation fault
- `SIGINT` - Interrupt (Ctrl+C)
- `SIGTERM` - Termination request
- `SIGHUP` - Hangup
- `SIGPIPE` - Broken pipe

**Behavior:**
- Print debug stack
- Flush error stream
- Exit cleanly (or ignore for SIGPIPE)

**Example: Graceful Ctrl+C Handling**

When user presses Ctrl+C:
```
SIGNAL: SIGINT (Interrupt)
  Received at: src/programs/webserver/main.c:245

Debug Stack (depth=2):
  [1] ServerLoop @ src/webserver/main.c:245
  [0] main @ src/webserver/main.c:56

[Server shuts down cleanly]
```

### Error Handlers

**Pluggable Error System:**

```c
extern Lookup *ErrorHandlers;  // Registry of error handlers
```

Each type can register a custom error handler for specialized error reporting.

**Example: Register Handler**
```c
status MyType_ErrorHandler(MemCh *m, void *obj, ErrorMsg *err){
    MyType *mt = (MyType *)obj;

    // Custom error formatting
    Buff_Add(ErrStream, S(m, "MyType Error: "));
    ToS(ErrStream, mt, TYPE_MY_TYPE, DEBUG);

    return SUCCESS;
}

void MyType_Init(MemCh *m){
    Lookup_Add(m, ErrorHandlers, TYPE_MY_TYPE, (void *)MyType_ErrorHandler);
}
```

---


## Type Introspection

### Type Name Lookup

#### Type_ToStr() - Get Type Name as Str

**Signature:**
```c
Str *Type_ToStr(MemCh *m, cls type);
```

Returns the human-readable name of a type as an allocated Str.

**Example:**
```c
Str *typeName = Type_ToStr(m, TYPE_STR);
printf("Type: %s\n", Str_Chars(typeName));
// Output: Type: Str
```

#### Type_ToChars() - Get Type Name as C String

**Signature:**
```c
char *Type_ToChars(cls type);
```

Returns C string pointer to type name (no allocation).

**Example:**
```c
printf("Object type: %s\n", Type_ToChars(TYPE_BUFF));
// Output: Object type: Buff
```

### Type Registry

**Global Type String Lookup:**
```c
extern Lookup *TypeStringRanges;  // Extensible type name registry
extern char *TypeStrings[];        // Base type names array
```

**Base Type Names:**
- `TypeStrings[TYPE_I64]` → `"i64"`
- `TypeStrings[TYPE_STR]` → `"Str"`
- `TypeStrings[TYPE_BUFF]` → `"Buff"`
- `TypeStrings[TYPE_MEMCTX]` → `"MemCh"`

**Registering New Types:**
```c
status MyModule_RegisterTypes(MemCh *m){
    Lookup_Add(m, TypeStringRanges, TYPE_MY_OBJECT, "MyObject");
    Lookup_Add(m, TypeStringRanges, TYPE_MY_OTHER, "MyOtherObject");
    return SUCCESS;
}
```

### State Flags

#### State_ToStr() - Convert Status to String

**Signature:**
```c
Str *State_ToStr(MemCh *m, status state);
```

Converts status flags to human-readable string.

**Example:**
```c
status result = SUCCESS | DEBUG;
Str *stateStr = State_ToStr(m, result);
printf("Status: %s\n", Str_Chars(stateStr));
// Output: Status: SUCCESS | DEBUG
```

**Standard State Labels:**

| Value | Label | Description |
|-------|-------|-------------|
| 0 | `ZERO/READY` | Initial/ready state |
| 1 | `SUCCESS` | Operation succeeded |
| 2 | `ERROR` | Operation failed |
| 3 | `NOOP` | No operation performed |
| 4 | `DEBUG` | Debug mode flag |
| 5 | `MORE` | Verbose output flag |
| 6 | `LAST` | Last element flag |
| 7 | `END` | End of iteration |
| 8 | `PROCESSING` | In-progress state |

#### Type_StateVec() - Get State as StrVec

**Signature:**
```c
StrVec *Type_StateVec(MemCh *m, cls typeOf, word flags);
```

Returns a StrVec of individual flag names.

**Example:**
```c
word flags = SUCCESS | MORE | DEBUG;
StrVec *flagNames = Type_StateVec(m, TYPE_BUFF, flags);

// flagNames contains: ["SUCCESS", "DEBUG", "MORE"]
```

---


## Common Patterns

### Pattern 1: Debug-Friendly Function

**Template:**
```c
ReturnType FunctionName(MemCh *m, ArgType arg){
    DebugStack_Push(arg, TYPE_ARG);

    // Validation
    if(arg == NULL){
        Error(m, "Null argument");
    }

    // Processing with guard
    i16 guard = 0;
    while(condition){
        Guard_Incr(m, &guard, 10);
        // ... work ...
    }

    // Success path
    DebugStack_Pop();
    return result;
}
```

### Pattern 2: Conditional Debug Output

**Example:**
```c
void ProcessData(MemCh *m, Data *data, bool verbose){
    if(verbose){
        void *args[] = {data, NULL};
        Fmt(OutStream, "Processing: &\n", args);  // Full debug
    }

    // ... process ...

    if(verbose){
        void *args[] = {data, NULL};
        Fmt(OutStream, "Result: @\n", args);  // Verbose
    }
}
```

### Pattern 3: Memory Leak Detection in Tests

**Example:**
```c
void Test_MemoryLeaks(){
    MemCh *m = MemCh_Make();
    i64 before = MemChapterCount();

    // Run test code
    RunTestScenario(m);

    // All temporary allocations should be freed
    i64 after = MemChapterCount();

    if(after != before){
        printf("FAIL: Memory leak detected (%lld contexts)\n",
               after - before);

        // Print leaked objects
        MemIter *it = MemIter_Make(m, m);
        while(MemIter_Next(it) != END){
            ToS(OutStream, MemIter_Get(it), 0, DEBUG);
        }
    } else {
        printf("PASS: No memory leaks\n");
    }

    MemCh_Free(m);
}
```

### Pattern 4: Custom Type Printer

**Example: JSON-Style Output**
```c
status Config_Print(Buff *bf, void *a, cls type, word flags){
    Config *cfg = (Config *)a;

    if(flags & DEBUG){
        // JSON-style debug output
        Buff_Add(bf, S(bf->m, "{\n"));
        Buff_Add(bf, S(bf->m, "  \"type\": \"Config\",\n"));
        Buff_Add(bf, S(bf->m, "  \"host\": \""));
        ToS(bf, cfg->host, 0, ZERO);
        Buff_Add(bf, S(bf->m, "\",\n"));
        Buff_Add(bf, S(bf->m, "  \"port\": "));
        Buff_Add(bf, Str_FromI64(bf->m, cfg->port, 0));
        Buff_Add(bf, S(bf->m, "\n}\n"));
    } else {
        // Compact output
        ToS(bf, cfg->host, 0, ZERO);
        Buff_Add(bf, S(bf->m, ":"));
        Buff_Add(bf, Str_FromI64(bf->m, cfg->port, 0));
    }

    return SUCCESS;
}
```

### Pattern 5: Error with Context

**Example:**
```c
void ParseJSON(MemCh *m, Str *json){
    DebugStack_Push(json, TYPE_STR);

    i32 line = 1;
    i32 col = 1;

    for(i32 i = 0; i < Str_Len(json); i++){
        byte c = Str_At(json, i);

        if(c == '\n'){
            line++;
            col = 1;
        } else {
            col++;
        }

        if(InvalidCharacter(c)){
            Error(m, "Invalid JSON character '$' at line $, col $",
                  Single_WrapI8(m, c),
                  Single_WrapI32(m, line),
                  Single_WrapI32(m, col));
        }
    }

    DebugStack_Pop();
}
```

---


## Performance Characteristics

### Debug Stack Operations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| `DebugStack_Push()` | O(1) | Array append |
| `DebugStack_Pop()` | O(1) | Array decrement |
| `DebugStack_Print()` | O(n) | n = stack depth |

**Memory:** 64-entry array (~2KB), allocated once at startup.

### ToString Operations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| `ToS()` lookup | O(1) avg | Hash table lookup |
| `ToS()` execution | O(f) | f = printer function cost |
| `Type_ToStr()` | O(1) | Lookup or array access |

**Overhead:** ToString adds ~10-50 CPU cycles per call (lookup + dispatch).

### Guard Operations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| `Guard_Incr()` | O(1) | Increment + compare |
| `Guard()` | O(1) | Compare only |
| `Guard_Reset()` | O(1) | Assignment |

**Cost:** Negligible (<5 cycles), suitable for tight loops.

### Memory Iteration

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| `MemIter_Make()` | O(1) | Setup iterator |
| `MemIter_Next()` | O(1) amortized | Linear scan with slab jumps |
| Full iteration | O(n) | n = total allocations |

**Scalability:** Can iterate 100,000+ allocations in <100ms.

---



---

**Part 1 of 2** | [Part 2 →](debug-system-complete-part2)
