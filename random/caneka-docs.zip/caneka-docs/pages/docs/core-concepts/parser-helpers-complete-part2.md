# Parser Helpers: Complete Guide - Part 2

[← Part 1](parser-helpers-complete-part1) | **Part 2 of 2**

---

## Performance Characteristics

### Split Operations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| `Str_SplitToSpan()` (char) | O(n) | Linear scan |
| `Str_SplitToSpan()` (string) | O(n × m) | n = input length, m = delimiter length |
| `Str_SplitToSpan()` (pattern) | O(n × p) | p = pattern complexity |
| `StrVec_Split()` | O(n) | In-place modification |

**Optimization:** Single-character delimiters are fastest. Use `Single_WrapI8(m, 'c')` when possible.

### Snip Operations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| `SnipSpan_AddFrom()` | O(1) | Append to span |
| `SnipSpan_Remove()` | O(1) amortized | May shrink last snip |
| `SnipSpan_Total()` | O(n) | n = snip count |
| `StrVec_Snip()` | O(n) | Extract content |

**Memory:** SnipSpan overhead is minimal (one Snip per region = ~16 bytes).

### Match Operations

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| `Match_Feed()` | O(1) to O(k) | k = pattern alternatives |
| `Match_FeedStrVec()` | O(n × k) | n = vector length |
| `Match_StrReplace()` | O(n × m) | n = string length, m = pattern complexity |

**Scalability:** Match operations are designed for streaming—process megabyte files character-by-character without loading entire file.

---


## Best Practices

### 1. Reuse Match Objects in Loops

Avoid re-creating Match objects for repeated operations.

```c
// Bad: Re-creates matcher each iteration
for(i32 i = 0; i < N; i++){
    Match *mt = Match_Make(m, pattern, NULL);  // Wasteful
    Match_Feed(m, mt, input[i]);
}

// Good: Reuse matcher
Match *mt = Match_Make(m, pattern, NULL);
for(i32 i = 0; i < N; i++){
    Match_Feed(m, mt, input[i]);
    Match_StartOver(mt);  // Reset state
}
```

### 2. Prefer Single-Character Delimiters

Single-character splits are significantly faster than pattern splits.

```c
// Fast: O(n)
Span *parts = Str_SplitToSpan(m, csv, Single_WrapI8(m, ','), 0);

// Slower: O(n × m)
Span *parts = Str_SplitToSpan(m, csv, S(m, ","), 0);
```

### 3. Use SnipSpan_Total() Before Extraction

Calculate output size before allocating buffers.

```c
i64 contentSize = SnipSpan_Total(snips, SNIP_CONTENT);

// Pre-allocate buffer if needed
StrVec *output = StrVec_Make(m, contentSize);

// Extract
StrVec_Snip(m, snips, curs);
```

### 4. Mark Boundaries for Nested Structures

Use `SNIP_STR_BOUNDRY` to track nesting levels in complex parsers.

```c
// Parsing JSON array: [1, 2, [3, 4]]
SnipSpan_AddFrom(snips, 1, SNIP_STR_BOUNDRY);   // [
SnipSpan_AddFrom(snips, 1, SNIP_CONTENT);        // 1
SnipSpan_AddFrom(snips, 2, SNIP_SEP);            // ", "
SnipSpan_AddFrom(snips, 1, SNIP_CONTENT);        // 2
// Nested array:
SnipSpan_AddFrom(snips, 1, SNIP_STR_BOUNDRY);   // [
SnipSpan_AddFrom(snips, 1, SNIP_CONTENT);        // 3
```

### 5. Validate Split Results

Always check split result counts before accessing indices.

```c
Span *parts = Str_SplitToSpan(m, input, Single_WrapI8(m, ','), 0);

if(Span_Len(parts) < 3){
    Error(m, "Expected at least 3 fields");
    return ERROR;
}

Str *field1 = Span_At(parts, 0);
Str *field2 = Span_At(parts, 1);
Str *field3 = Span_At(parts, 2);
```

---


## Common Pitfalls

### Pitfall 1: Forgetting Match_StartOver()

**Problem:** Match state persists between uses, causing incorrect results.

```c
// Bad: Matcher retains state
Match *mt = Match_Make(m, pattern, NULL);

for(i32 i = 0; i < N; i++){
    Match_Feed(m, mt, inputs[i]);  // State accumulates!
}

// Good: Reset between uses
Match *mt = Match_Make(m, pattern, NULL);

for(i32 i = 0; i < N; i++){
    Match_Feed(m, mt, inputs[i]);
    Match_StartOver(mt);  // Clear state
}
```

### Pitfall 2: Split Delimiter Consumed

**Problem:** Split operations consume the delimiter, it doesn't appear in results.

```c
Str *text = S(m, "a,b,c");
Span *parts = Str_SplitToSpan(m, text, Single_WrapI8(m, ','), 0);

// parts[0] = "a" (no leading comma)
// parts[1] = "b" (no comma)
// parts[2] = "c" (no trailing comma)

// Delimiters are REMOVED, not preserved
```

**Solution:** If delimiters needed, use Snip markers to track them separately.

### Pitfall 3: Snip Length Mismatch

**Problem:** Snip lengths don't match actual string length, causing extraction errors.

```c
// Bad: Snip lengths incorrect
Span *snips = Span_Make(m, TYPE_SNIP);
SnipSpan_AddFrom(snips, 10, SNIP_CONTENT);  // Claims 10 bytes
SnipSpan_AddFrom(snips, 5, SNIP_GAP);       // Claims 5 bytes
// Total: 15 bytes

// But actual string is only 12 bytes!
Str *actual = S(m, "Hello World!");  // 12 bytes

// StrVec_Snip will ERROR: snips claim more bytes than exist
```

**Solution:** Ensure snip lengths exactly match string being processed.

### Pitfall 4: Pattern Type Confusion

**Problem:** Passing wrong type to split parameter.

```c
// Bad: Passing raw char instead of wrapped
Span *parts = Str_SplitToSpan(m, text, ',', 0);  // ERROR: char is not void*

// Good: Wrap char correctly
Span *parts = Str_SplitToSpan(m, text, Single_WrapI8(m, ','), 0);
```

### Pitfall 5: Empty String Handling

**Problem:** Split on delimiter at start/end creates empty strings.

```c
Str *text = S(m, ",apple,banana,");
Span *parts = Str_SplitToSpan(m, text, Single_WrapI8(m, ','), 0);

// Result:
// parts[0] = "" (empty before first comma)
// parts[1] = "apple"
// parts[2] = "banana"
// parts[3] = "" (empty after last comma)
```

**Solution:** Filter empty results or trim input before splitting.

```c
// Filter empty strings
Span *filtered = Span_Make(m, TYPE_STR);
Iter *it = Iter_Make(m, parts);
while(Iter_Avail(it)){
    Str *s = Iter_Deref(it);
    if(Str_Len(s) > 0){
        Span_Push(filtered, s);
    }
    Iter_Next(it);
}
```

### Pitfall 6: Match Backlog Memory Growth

**Problem:** Backlog span grows unbounded in long-running matchers.

```c
// Bad: Backlog accumulates all matches
Span *backlog = Span_Make(m, TYPE_SNIP);
Match *mt = Match_Make(m, pattern, backlog);

// Feed megabytes of data
for(i32 i = 0; i < MEGABYTES; i++){
    Match_Feed(m, mt, data[i]);
    // backlog keeps growing!
}
```

**Solution:** Use temporary MemCh or periodically clear backlog.

```c
// Use temporary memory context
MemCh *tmpM = MemCh_Make();
Span *backlog = Span_Make(tmpM, TYPE_SNIP);
Match *mt = Match_Make(tmpM, pattern, backlog);

// Process chunk
ProcessChunk(mt, data, chunkSize);

// Free all temporary allocations
MemCh_Free(tmpM);
```

---


## Related Documentation

- **[Roebling Parser Overview](parser/overview.md)** - Core parsing engine
- **[Pattern Matching](parser/pattern-matching.md)** - PatCharDef system details
- **[Writing Parsers Guide](../guides/writing-parsers.md)** - Step-by-step parser tutorial
- **[Strings Complete](strings-complete.md)** - Str/StrVec foundations
- **[Mess Complete](navigate/mess-complete.md)** - Message tree with tokenize integration

---


## Summary

The Parser Helpers system provides a comprehensive toolkit for string manipulation and pattern matching:

**Split System:**
- Simple delimiter-based breaking
- Supports char, string, and pattern delimiters
- In-place and copy modes available

**Snip System:**
- Fine-grained region marking
- Content vs. gap classification
- Zero-copy extraction

**Tokenize System:**
- Metadata attachment to parsed regions
- Type classification
- Capture key integration with Roebling

**PatChar System:**
- Pattern creation from strings
- Knockout (inverse) patterns
- Predefined macros for common patterns

**Match System:**
- Byte-by-byte pattern execution
- State management and reuse
- Backlog tracking for complex parsing

**Match_Replace System:**
- Search-and-replace operations
- Pattern-based substitution
- Iterator-style replacement loops

These helpers work independently for simple tasks and compose together for complex parsing scenarios. The Roebling parser orchestrates all helpers for industrial-strength text processing (HTTP parsing, template rendering, configuration parsing, etc.).

**Integration Points:**
- MemCh for automatic cleanup
- Str/StrVec for safe string handling
- Span for collections
- Cursor for streaming
- Type system for runtime dispatch

The layered design allows progressive complexity: use simple Split for CSV parsing, add Snip for HTML tag removal, combine with Match for regex-like operations, or integrate all with Roebling for full DSL creation.



---

[← Part 1](parser-helpers-complete-part1) | **Part 2 of 2**
