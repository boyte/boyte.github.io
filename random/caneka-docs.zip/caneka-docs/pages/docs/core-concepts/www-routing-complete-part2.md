# WWW Routing System Complete Guide - Part 2

[← Part 1](www-routing-complete-part1) | **Part 2 of 3** | [Part 3 →](www-routing-complete-part3)

---

## Code Examples

### Example 1: Basic Route Setup

Setting up routes for a simple website:

```c
// Initialize routing system
Route_Init(m);

// Create root route
Route *pages = Route_Make(m);

// Scan directory and build routes
StrVec *publicPath = IoAbsPath(m, "pages/public");
Table *configAtts = Table_Make(m);
Route_CollectConfig(pages, Sv(m, "/"), publicPath, configAtts);

// Routes are now available:
// - /index (from index.fmt or index.templ)
// - /stats (from stats.templ)
// - /tests (from tests.fmt)
// - etc.

// Create separate tree for includes (header/footer)
Route *inc = Route_Make(m);
StrVec *incPath = IoAbsPath(m, "pages/inc");
Route_CollectConfig(inc, Sv(m, "/"), incPath, configAtts);

// Store routes in TCP context
TcpCtx *tcp = TcpCtx_Make(m);
tcp->pages = pages;
tcp->inc = inc;
```

### Example 2: Serving a Template Route

From test [route_tests.c:268-419](../../../src/programs/test/option/inter/route_tests.c#L268-L419):

```c
// Build routes from filesystem
StrVec *path = IoPath(m, "examples/test/pages/public");
Route *rt = Route_From(m, path);

// Get specific route
path = IoPath(m, "/stats");
Route *handler = Inst_ByPath(rt, path, NULL, SPAN_OP_GET, NULL);

// Prepare data table for template
Table *data = Table_Make(m);

// Add configuration
Str *configPath = IoUtil_GetAbsPath(m,
    Str_CstrRef(m, "./examples/test/pages/public/stats.config"));
Inst *config = Config_FromPath(m, configPath);
Table_Set(data, Str_CstrRef(m, "config"), config);

// Add template variables
Table *stats = Table_Make(m);
struct timespec now;
Time_Now(&now);
Table_Set(stats, K(m, "uptime"), Time_ToStr(m, &now));

MemBookStats st;
MemBook_GetStats(m, &st);
Table *mem = Table_Make(m);
Table_Set(mem, K(m, "mem-used"), Str_MemCount(m, st.pageIdx * PAGE_SIZE));
Table_Set(mem, K(m, "mem-total"), Str_MemCount(m, PAGE_COUNT * PAGE_SIZE));
Table_Set(mem, K(m, "mem-details"), Map_ToTable(m, &st));
Table_Set(stats, K(m, "mem"), mem);

Table_Set(data, K(m, "stats"), stats);

// Render page
Buff *bf = Buff_Make(m, ZERO);
Route_Handle(handler, bf, data, NULL);

// bf->v now contains rendered HTML
```

### Example 3: Composing Full Page with Header/Footer

From test [route_tests.c:343-372](../../../src/programs/test/option/inter/route_tests.c#L343-L372):

```c
// Build main content routes
StrVec *path = IoPath(m, "examples/test/pages/public");
Route *rt = Route_From(m, path);

// Build include routes (header/footer)
Route *inc = Route_Make(m);
StrVec *incPath = IoUtil_GetAbsVec(m,
    Str_CstrRef(m, "./examples/test/pages/inc"));
StrVec *incAbs = IoUtil_AbsVec(m, incPath);
Route_Collect(inc, incAbs);

// Get routes
StrVec *hv = IoPath(m, "header");
Route *header = Inst_ByPath(inc, hv, NULL, SPAN_OP_GET, NULL);
StrVec *fv = IoPath(m, "footer");
Route *footer = Inst_ByPath(inc, fv, NULL, SPAN_OP_GET, NULL);

path = IoPath(m, "/stats");
Route *handler = Inst_ByPath(rt, path, NULL, SPAN_OP_GET, NULL);

// Prepare shared data
Table *data = getGenericData(m, rt);

// Compose page
Buff *dest = Buff_Make(m, ZERO);

// Render header
Buff *bf = Buff_Make(m, ZERO);
Route_Handle(header, bf, data, NULL);
Buff_Pipe(dest, bf);

// Render main content
bf = Buff_Make(m, ZERO);
Route_Handle(handler, bf, data, NULL);
Buff_Pipe(dest, bf);

// Render footer
bf = Buff_Make(m, ZERO);
Route_Handle(footer, bf, data, NULL);
Buff_Pipe(dest, bf);

// dest->v now contains complete page
```

### Example 4: BinSeg Database Endpoint

From test [route_tests.c:572-659](../../../src/programs/test/option/inter/route_tests.c#L572-L659):

```c
// Create BinSeg route
StrVec *rbsPath = IoAbsPath(m, "examples/test/pages/forms");
Route *root = Route_Make(m);
Route_Collect(root, rbsPath);

// Get signup form handler
StrVec *url = IoPath(m, "/signup");
Route *rt = Route_GetHandler(root, url);

// Simulate HTTP POST with JSON body
ProtoCtx *proto = HttpProto_Make(m);
HttpCtx *ctx = (HttpCtx*)as(proto->ctx, TYPE_HTTP_CTX);

Str *content = S(m,
    "POST /forms/signup?action=add HTTP/1.1\r\n"
    "Content-Type: application/json\r\n"
    "Accept: text/html\r\n"
    "Content-Length: 60\r\n"
    "\r\n"
    "{\"email\": \"fancy.pantsy@example.com\", \"first-name\": \"Fantsy\"}");

// Parse HTTP request
Cursor *curs = Cursor_Make(m, StrVec_From(m, content));
Roebling *rbl = HttpRbl_Make(m, curs, proto);
Roebling_Run(rbl);

// Parse JSON body
NodeObj *config = Inst_Make(m, TYPE_NODEOBJ);
HttpCtx_ParseBody(ctx, config, curs);

// Prepare data table
Table *data = Table_Make(m);
Table *rtData = Seel_Get(rt, K(m, "data"));
Table_Set(data, S(m, "config"), Table_Get(rtData, K(m, "config")));

// Handle request (adds record to database)
Buff *bf = Buff_Make(m, ZERO);
status r = Route_Handle(rt, bf, data, ctx);

// bf->v contains HTML confirmation message
// Database file now contains new record

// Read back from database to verify
BinSegCtx *bsCtx = BinSegCtx_Make(m, BINSEG_READ|BINSEG_REVERSED);
BinSegCtx_Open(bsCtx, StrVec_Str(m, rbsFilePath));
BinSegCtx_Load(bsCtx);

Table *tbl = Span_Get(bsCtx->records, 0);
Str *firstName = Table_Get(tbl, K(m, "first-name"));  // "Fantsy"
Str *email = Table_Get(tbl, K(m, "email"));          // "fancy.pantsy@example.com"

BinSegCtx_Close(bsCtx);
```

### Example 5: Custom Handler Registration

Adding a custom handler for a new file type:

```c
// Define custom handler function
static status routeFuncMarkdown(Buff *bf, Route *rt,
                                Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get prepared markdown AST from route
    MarkdownDoc *doc = (MarkdownDoc *)as(Seel_Get(rt, K(m, "action")),
                                         TYPE_MARKDOWN_DOC);

    // Render markdown to HTML
    return Markdown_ToHtml(bf, doc);
}

// Register handler during initialization
void registerMarkdownHandler(MemCh *m){
    // Add to extension list
    Str *key = S(m, "md");
    Span_Add(AllExtSpan, key);

    // Wrap handler function
    Single *funcW = Func_Wrapped(m, routeFuncMarkdown);
    funcW->type.state |= ROUTE_DYNAMIC;  // Set appropriate flags

    // Register in handler table
    Table_Set(RouteFuncTable, key, funcW);

    // Register MIME type
    Table_Set(RouteMimeTable, key, S(m, "text/html"));
}

// Now .md files will be automatically routed and handled
```

### Example 6: ETag Caching

Checking ETag for conditional responses:

```c
// In request handler
status WebServer_GatherPage(Step *st, Task *tsk){
    // ... (route lookup) ...

    // Get If-None-Match header from request
    StrVec *etag = Table_Get(ctx->headersIt.p, K(m, "If-None-Match"));

    // Check if ETag matches
    if((etag != NULL) && Route_CheckEtag(ctx->route, etag) & SUCCESS){
        // File hasn't changed, return 304 Not Modified
        ctx->code = 304;
        HttpProto_PrepareResponse(proto, tsk);
        Task_AddDataStep(tsk, TcpTask_WriteStep, NULL, NULL, NULL, ZERO);
        return (MORE|SUCCESS);
    }

    // ETag doesn't match, serve full content
    // ... (normal handling) ...
}
```

**Route_CheckEtag Implementation** [route.c:221-230](../../../src/inter/www/route.c#L221-L230):

```c
status Route_CheckEtag(Route *rt, StrVec *etag){
    MemCh *m = rt->m;

    // Only check ETags for cacheable assets
    Single *funcW = Seel_Get(rt, K(m, "func"));
    if((funcW->type.state & ROUTE_ASSET) == 0){
        return NOOP;  // Not an asset, skip ETag check
    }

    // Get stored ETag from route headers
    Table *headers = Seel_Get(rt, K(m, "headers"));
    StrVec *etagRegistered = Table_Get(headers, K(m, "Etag"));

    // Compare ETags
    return (etagRegistered != NULL && Equals(etag, etagRegistered))
           ? SUCCESS : MORE;
}
```

### Example 7: Configuration-Driven Routing

Using .config files to control routing behavior:

**pages/api/.config:**

```
[routes]
ext = rbs

[binseg]
action = read add modify
seel = UserSchema
```

**Code to apply configuration:**

```c
// Load configuration
Str *configPath = IoUtil_GetAbsPath(m,
    S(m, "pages/api/.config"));
Inst *config = Config_FromPath(m, configPath);

// Extract attributes
NodeObj *routes = Inst_ByPath(config, Sv(m, "routes"),
                              NULL, SPAN_OP_GET, NULL);
Table *atts = Seel_Get(routes, K(m, "atts"));

// Build routes with configuration
Route *root = Route_Make(m);
StrVec *path = IoAbsPath(m, "pages/api");
Route_CollectConfig(root, Sv(m, "/api"), path, atts);

// Routes now built with:
// - Only .rbs files (ext = rbs)
// - BinSeg actions: read, add, modify
// - Typed deserialization using UserSchema
```


## Performance Characteristics

### Route Lookup Performance

Route lookup is **O(n)** where n is the depth of the URL path, not the total number of routes. This is because routes form a tree structure with `Inst_ByPath` navigation.

**Example:**
- 1,000 routes in flat structure: O(1000) linear search
- 1,000 routes in tree with average depth 4: O(4) tree walk

**Benchmark Data** (from HTTP Lifecycle docs):
- Route lookup: ~0.5-2 microseconds per request
- Handler dispatch: ~0.1 microseconds
- Total routing overhead: less than 5% of request time

### Preparation vs Runtime Cost

The routing system follows a **prepare-once, serve-many** model:

**Startup Cost (One-Time):**
- Route scanning: ~1-5ms per 100 files
- Template preparation: ~10-50ms per template
- Format parsing: ~5-20ms per document
- BinSeg opening: ~1-3ms per database

**Per-Request Cost:**
- Static files: ~0 preparation (direct file streaming)
- Templates: ~50-200 microseconds (variable substitution only)
- Formats: ~20-50 microseconds (HTML serialization only)
- BinSeg: ~100-500 microseconds (depends on operation)

**Memory Cost:**
- Route object: ~200-500 bytes
- Prepared template: ~2-20KB (depends on complexity)
- Prepared format: ~5-50KB (depends on document size)
- BinSeg context: ~500-2000 bytes

### ETag Caching Impact

ETags provide **significant performance gains** for static assets:

**Without ETags:**
- Read file from disk: ~100-500 microseconds
- Stream to socket: ~50-200 microseconds per KB
- Total: ~150-700 microseconds + data transfer time

**With ETag Hit:**
- ETag comparison: ~1-2 microseconds
- 304 response: ~10-20 microseconds
- Total: ~11-22 microseconds (20-50x faster)

**ETag Hit Rate:**
- First visit: 0% (must fetch)
- Subsequent visits: 90-95% (if file unchanged)
- Effective average: ~80-85% hit rate

### Buffer Piping Overhead

Page composition via `Buff_Pipe` has minimal overhead:

**Single Buffer:**
- Direct write: ~5 microseconds per buffer

**Piped Composition (header + content + footer):**
- Three buffers: ~15 microseconds total
- Overhead: ~10 microseconds vs single buffer (negligible)

**Memory Impact:**
- No extra copying (buffers share StrVec references)
- Composition is zero-copy until final write


## Best Practices

### File Organization

**1. Mirror URL Structure**

Organize files to match desired URL hierarchy:

```
pages/public/
├── index.fmt               # /
├── about.templ             # /about
├── stats.templ             # /stats
├── api/
│   ├── users.rbs          # /api/users
│   └── posts.rbs          # /api/posts
└── static/
    ├── style.css          # /static/style.css
    └── logo.png           # /static/logo.png
```

**2. Separate Includes from Public Routes**

Keep shared includes (header/footer) in separate directory:

```
pages/
├── public/         # Public routes
├── inc/           # Includes (header, footer, nav)
└── system/        # Error pages (404, 500)
```

**3. Use Index Files for Directory Defaults**

Name default pages `index.*`:

```
pages/public/
├── index.fmt               # /
└── docs/
    └── index.templ         # /docs
```

### Configuration Patterns

**1. Hierarchical Configuration**

Place `.config` files at appropriate levels:

```
pages/
├── .config                 # Global config
├── api/
│   ├── .config            # API-specific config
│   └── users.rbs
└── public/
    └── .config            # Public site config
```

**2. Configuration Inheritance**

Child routes inherit parent configuration:

```
# pages/.config (global)
[page]
pre-content = header
post-content = footer

# pages/api/.config (overrides)
[page]
# No header/footer for API endpoints

[binseg]
action = read add modify
```

**3. Type-Specific Configuration**

Use configuration to control handler behavior:

```
[binseg]
action = read add          # Only allow read and add
seel = UserSchema          # Use typed deserialization

[routes]
ext = rbs templ           # Only build .rbs and .templ routes
```

### Handler Design

**1. Keep Handlers Stateless**

Handlers should not maintain state between requests:

```c
// GOOD: Stateless handler
static status routeFuncTempl(Buff *bf, Route *rt,
                             Table *data, HttpCtx *ctx){
    Templ *templ = (Templ *)as(Seel_Get(rt, K(m, "templ")), TYPE_TEMPL);
    Templ_Reset(templ);  // Reset state
    Templ_ToS(templ, bf, data, NULL);
    return templ->type.state;
}

// BAD: Stateful handler
static int requestCount = 0;  // DON'T DO THIS
static status routeFuncBad(Buff *bf, Route *rt,
                          Table *data, HttpCtx *ctx){
    requestCount++;  // Race condition!
    // ...
}
```

**2. Use Route Properties for Prepared Content**

Store prepared content in route properties, not globals:

```c
// GOOD: Per-route prepared content
Templ *templ = (Templ *)Seel_Get(rt, K(m, "templ"));

// BAD: Global prepared content
static Templ *globalTempl = NULL;  // Shared across all routes
```

**3. Check Content Type Before Handling**

Verify expected content type in route:

```c
static status routeFuncTempl(Buff *bf, Route *rt,
                             Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;

    // Get and validate templ object
    Abstract *templObj = Seel_Get(rt, K(m, "templ"));
    if(templObj == NULL || templObj->type.of != TYPE_TEMPL){
        ctx->code = 500;
        ctx->type.state |= ERROR;
        return ERROR;
    }

    Templ *templ = (Templ *)as(templObj, TYPE_TEMPL);
    // ... (handle) ...
}
```

### Route Registration

**1. Register Handlers Early**

Register all custom handlers before building routes:

```c
// Initialize base routing system
Route_Init(m);

// Register custom handlers
registerMarkdownHandler(m);
registerYamlHandler(m);

// Now build routes (custom handlers available)
Route *pages = Route_Make(m);
Route_CollectConfig(pages, Sv(m, "/"), publicPath, configAtts);
```

**2. Use Consistent Extension Mapping**

Keep extension-to-handler mapping predictable:

```c
// GOOD: Clear mapping
.html   → routeFuncStatic     (static HTML)
.templ  → routeFuncTempl      (dynamic templates)
.fmt    → routeFuncFmt        (Pencil documents)

// BAD: Confusing mapping
.html   → routeFuncTempl      (dynamic? static?)
.templ  → routeFuncStatic     (not dynamic?)
```

**3. Set Appropriate Flags**

Use flags to control handler behavior:

```c
// For cacheable assets
funcW->type.state |= (ROUTE_STATIC|ROUTE_ASSET);

// For dynamic content
funcW->type.state |= ROUTE_DYNAMIC;

// For database endpoints
funcW->type.state |= ROUTE_BINSEG;
```

### Performance Optimization

**1. Enable Unbuffered I/O for Large Files**

Use `BUFF_UNBUFFERED` for static file streaming:

```c
static status routeFuncStatic(Buff *bf, Route *rt,
                              Table *_data, HttpCtx *ctx){
    MemCh *m = bf->m;
    Str *pathS = StrVec_Str(bf->m,
        (StrVec *)as(Seel_Get(rt, K(m, "action")), TYPE_STRVEC));

    bf->type.state |= BUFF_UNBUFFERED;  // Direct streaming
    return File_Open(bf, pathS, O_RDONLY);
}
```

**2. Prepare Content at Startup**

Parse templates/formats once during preparation:

```c
// GOOD: Prepare once at startup
static Templ *prepareTempl(Route *rt, StrVec *path){
    StrVec *content = File_ToVec(m, StrVec_Str(m, path));
    Cursor *curs = Cursor_Make(m, content);
    TemplCtx *ctx = TemplCtx_FromCurs(m, curs, NULL);
    Templ *templ = (Templ *)Templ_Make(m, ctx->it.p);
    Templ_Prepare(templ);  // Parse once
    return templ;
}

// BAD: Parse per request
static status routeFuncTemplBad(Buff *bf, Route *rt,
                               Table *data, HttpCtx *ctx){
    StrVec *path = Seel_Get(rt, K(m, "file"));
    StrVec *content = File_ToVec(m, StrVec_Str(m, path));
    Cursor *curs = Cursor_Make(m, content);
    TemplCtx *ctx = TemplCtx_FromCurs(m, curs, NULL);
    Templ *templ = Templ_Make(m, ctx->it.p);
    Templ_Prepare(templ);  // Parsing every request!
    // ...
}
```

**3. Use ETags for Cacheable Content**

Enable ETag generation for static assets:

```c
// During preparation
if(funcW != NULL && (funcW->type.state & ROUTE_ASSET)){
    struct timespec mod;
    File_ModTime(m, pathS, &mod);
    Route_SetEtag(rt, pathS, &mod);  // Generate ETag
}
```


## Common Pitfalls

### Pitfall 1: Forgetting to Prepare Routes

**Problem:** Routes must be prepared before use, but preparation call is easy to forget.

```c
// BAD: Routes not prepared
Route *pages = Route_Make(m);
Route_CollectConfig(pages, Sv(m, "/"), publicPath, configAtts);
// Start serving... (templates not parsed!)

// GOOD: Explicit preparation
Route *pages = Route_Make(m);
Route_CollectConfig(pages, Sv(m, "/"), publicPath, configAtts);
Route_Prepare(pages);  // Parse all templates/formats
```

**Symptom:** Templates return empty content or error status.

**Fix:** Call `Route_Prepare` after building route tree, or ensure preparation happens during collection.

### Pitfall 2: Modifying Route Tree During Serving

**Problem:** Route tree should be immutable after preparation. Adding/removing routes during request handling causes race conditions.

```c
// BAD: Modifying routes during serving
status WebServer_HandleRequest(Task *tsk){
    // ...
    Route *newRoute = Route_Make(m);
    Inst_ByPath(pages, newPath, newRoute, SPAN_OP_SET, NULL);  // RACE!
    // ...
}

// GOOD: Build all routes at startup
status WebServer_Init(Task *tsk){
    Route *pages = Route_Make(m);
    Route_CollectConfig(pages, Sv(m, "/"), publicPath, configAtts);
    Route_Prepare(pages);
    // Now immutable during serving
}
```

**Symptom:** Intermittent crashes, corrupted route tree, incorrect route lookups.

**Fix:** Build and prepare entire route tree before starting request handling. For dynamic routes, use a separate mechanism (not tree modification).

### Pitfall 3: Incorrect Extension Mapping

**Problem:** Route building strips extensions for non-asset files. URLs must not include extension.

```c
// BAD: Including extension in URL
StrVec *path = IoPath(m, "/stats.templ");  // Won't match!
Route *route = Inst_ByPath(pages, path, NULL, SPAN_OP_GET, NULL);
// route is NULL

// GOOD: Extension stripped from URL
StrVec *path = IoPath(m, "/stats");  // Matches stats.templ
Route *route = Inst_ByPath(pages, path, NULL, SPAN_OP_GET, NULL);
// route found
```

**Exception:** Asset routes (ROUTE_ASSET flag) keep extensions:

```c
// Correct: Asset keeps extension
StrVec *path = IoPath(m, "/static/style.css");  // Matches style.css
Route *route = Inst_ByPath(pages, path, NULL, SPAN_OP_GET, NULL);
```

**Symptom:** 404 errors for valid files, routes not found.

**Fix:** Understand extension stripping rules. Use URLs without extensions for templates/formats, with extensions for assets.

### Pitfall 4: Missing Index File

**Problem:** Directory URLs require index files to serve content.

```c
// Directory structure:
// pages/public/docs/guide.templ

// BAD: No index file
GET /docs → 404 Not Found

// GOOD: Add index file
// pages/public/docs/index.templ
GET /docs → Serves docs/index.templ
```

**Symptom:** Directory URLs return 404 even though child pages exist.

**Fix:** Create `index.*` files for directories that should serve content.

### Pitfall 5: ETag Mismatch After File Update

**Problem:** ETags are cached in `.etag` files. After updating source file, old ETag may persist.

```c
// Scenario:
// 1. Server starts, generates ETag for logo.png
// 2. Developer updates logo.png
// 3. Server restarts, but .etag file still has old ETag
// 4. Client sends If-None-Match with old ETag
// 5. Server returns 304 (but file changed!)
```

**Fix:** `Route_SetEtag` checks modification time and updates `.etag` file if changed [route.c:232-262](../../../src/inter/www/route.c#L232-L262):

```c
// Check if ETag changed
Buff_Read(bf);
File_Close(bf);
if(!Equals(bf->v, etag)){
    // Update ETag file with new value
    bf->type.state = BUFF_UNBUFFERED|BUFF_CLOBBER;
    File_Open(bf, etagPathS, O_WRONLY|O_TRUNC);
    Buff_AddVec(bf, etag);
    File_Close(bf);
}
```

**Best Practice:** Delete `.etag` files when deploying updated assets, or rely on modification time check.

### Pitfall 6: Handler Memory Leaks

**Problem:** Handlers run per-request. Memory allocated in handler must use request MemCh.

```c
// BAD: Using global memory
static status routeFuncLeaky(Buff *bf, Route *rt,
                            Table *data, HttpCtx *ctx){
    MemCh *globalM = GetGlobalMemCh();  // DON'T!
    Str *s = Str_Make(globalM, 100);    // Memory leak
    // ...
}

// GOOD: Using request memory
static status routeFuncGood(Buff *bf, Route *rt,
                           Table *data, HttpCtx *ctx){
    MemCh *m = bf->m;  // Request memory chapter
    Str *s = Str_Make(m, 100);  // Freed with request
    // ...
}
```

**Symptom:** Memory usage grows over time, eventually exhausting memory.

**Fix:** Always use `bf->m` or `ctx->m` for per-request allocations.

### Pitfall 7: Configuration Override Confusion

**Problem:** Configuration inheritance can be non-obvious.

```c
// pages/.config
[page]
pre-content = header
post-content = footer

// pages/api/.config
[binseg]
action = read add

// What does pages/api/users.rbs get?
// - pre-content from parent (.config)? YES
// - binseg config from child (api/.config)? YES

// To disable header/footer in API:
// pages/api/.config
[page]
pre-content =         # Empty value disables
post-content =        # Empty value disables
```

**Symptom:** Unexpected header/footer on API endpoints, missing configuration.

**Fix:** Explicitly override parent configuration with empty values to disable inherited behavior.

### Pitfall 8: Templ Reset Forgotten

**Problem:** Templates are reused across requests and must be reset before rendering.

```c
// BAD: Not resetting template
static status routeFuncTemplBad(Buff *bf, Route *rt,
                               Table *data, HttpCtx *ctx){
    Templ *templ = (Templ *)as(Seel_Get(rt, K(m, "templ")), TYPE_TEMPL);
    // No Templ_Reset(templ)!
    Templ_ToS(templ, bf, data, NULL);  // Accumulated state from previous requests
    return templ->type.state;
}

// GOOD: Resetting template
static status routeFuncTempl(Buff *bf, Route *rt,
                            Table *data, HttpCtx *ctx){
    Templ *templ = (Templ *)as(Seel_Get(rt, K(m, "templ")), TYPE_TEMPL);
    Templ_Reset(templ);  // Clear state from previous rendering
    Templ_ToS(templ, bf, data, NULL);
    return templ->type.state;
}
```

**Symptom:** Template output includes data from previous requests, incorrect rendering.

**Fix:** Always call `Templ_Reset` before rendering.

### Pitfall 9: BinSeg Action Not Specified

**Problem:** BinSeg endpoints require `?action=` query parameter.

```c
// BAD: No action specified
GET /api/users → 403 Forbidden

// GOOD: Action specified
GET /api/users?action=read → Success
POST /api/users?action=add → Success
```

**Handler Code** [route.c:35-71](../../../src/inter/www/route.c#L35-L71):

```c
Abstract *action = Table_Get(ctx->queryIt.p, K(m, "action"));
if(action == NULL){
    ctx->code = 403;
    ctx->type.state |= ERROR;
    return ctx->type.state;
}
```

**Symptom:** All BinSeg requests return 403 Forbidden.

**Fix:** Always include `?action=read|add|modify` in BinSeg URLs.

### Pitfall 10: Route Tree Not Stored in TcpCtx

**Problem:** Routes must be accessible from TCP context for request handling.

```c
// BAD: Routes not stored
Route *pages = Route_Make(m);
Route_CollectConfig(pages, Sv(m, "/"), publicPath, configAtts);
// Start server... (routes inaccessible!)

// GOOD: Routes stored in TcpCtx
TcpCtx *tcp = TcpCtx_Make(m);
tcp->pages = pages;
tcp->inc = inc;

Task *tsk = ServeTcp_Make(NULL);
tsk->source = (Abstract *)tcp;
```

**Symptom:** All requests return 404, route lookup fails.

**Fix:** Store route tree in `TcpCtx.pages` and includes in `TcpCtx.inc`.


## Integration with HTTP Lifecycle

The routing system integrates with the HTTP lifecycle at multiple points:

### 1. Request Parsing → Routing

After HTTP request is parsed, routing occurs in `HttpTask_AddRecieve` callback registered with `WebServer_GatherPage` [webserver.c:100](../../../src/inter/www/webserver.c#L100):

```c
// HTTP Lifecycle Step 6: Body Parsed
// → WebServer_GatherPage called
status WebServer_GatherPage(Step *st, Task *tsk){
    // Extract path from parsed HTTP request
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Perform route lookup
    ctx->route = Route_Get(tcp->pages, ctx->path);

    // Add serving step
    Task_AddStep(tsk, WebServer_ServePage, NULL, NULL, ZERO);
}
```

### 2. Routing → Handler Dispatch

Handler dispatch occurs in `WebServer_ServePage` [webserver.c:188](../../../src/inter/www/webserver.c#L188):

```c
// HTTP Lifecycle Step 7: Response Generation
status WebServer_ServePage(Step *st, Task *tsk){
    // Get handler from route
    ctx->mime = (Str *)Seel_Get(ctx->route, K(m, "mime"));

    // Dispatch to handler
    Buff *bf = Buff_Make(m, ZERO);
    Route_Handle(ctx->route, bf, ctx->data, ctx);

    // Add to response
    HttpProto_AddBuff(proto, bf);
}
```

### 3. Handler → Response Finalization

Handler output is collected into response buffers and finalized in HTTP protocol:

```c
// Handler generates content
Route_Handle(ctx->route, bf, ctx->data, ctx);

// Add to response buffer span
HttpProto_AddBuff(proto, bf);

// Finalize response headers
HttpProto_PrepareResponse(proto, tsk);

// Write to socket
Task_AddDataStep(tsk, TcpTask_WriteStep, NULL, NULL, NULL, ZERO);
```

### Request Flow Diagram

```
Client Request
    ↓
[HTTP Parser] (Roebling)
    ↓
[WebServer_GatherPage] ← Routing Entry Point
    ├─ Route_Get(path)
    ├─ Route_CheckEtag()
    └─ Task_AddStep(WebServer_ServePage)
    ↓
[WebServer_ServePage] ← Handler Dispatch
    ├─ Route_Handle(header)
    ├─ Route_Handle(main content) ← Handler Execution
    └─ Route_Handle(footer)
    ↓
[HttpProto_PrepareResponse] ← Response Finalization
    ↓
[TcpTask_WriteStep] ← Socket Write
    ↓
Client Response
```



---

[← Part 1](www-routing-complete-part1) | **Part 2 of 3** | [Part 3 →](www-routing-complete-part3)
