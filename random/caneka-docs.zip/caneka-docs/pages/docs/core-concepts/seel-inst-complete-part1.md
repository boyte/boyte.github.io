# Seel/Inst Property System: Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](seel-inst-complete-part2)

---

## Core Philosophy

The Seel/Inst system is Caneka's approach to object-oriented programming without traditional OOP overhead. It provides **schema-driven typed instances** where a "Seel" (schema) defines the structure and types of properties, and an "Inst" (instance) is a Span with properties accessible by name.

**The fundamental insight**: Most object systems couple three concerns—memory layout, property access, and type checking. Caneka separates these:

1. **Memory layout**: Inst is just a Span (sparse array), properties stored by index
2. **Property access**: Seel maps property names → indices + types
3. **Type checking**: The Type system validates access at runtime

This separation enables:
- **Zero overhead property access**: Name lookup happens once at compile time (via `K()` macro), runtime access is array indexing
- **Transparent data**: Inst is a Span you can iterate, inspect, and serialize
- **Schema evolution**: Modify Seel without recompiling instances (property indices shift, but lookups adapt)
- **Type safety**: Runtime checks ensure you don't cast `StrVec *` when property holds `Table *`

**Contrast with traditional OOP**:
- **C++ objects**: Fixed layout (vtable + members), name → offset resolved at compile time, opaque
- **Seel/Inst**: Dynamic layout (Span), name → index resolved via Table, fully transparent

The Seel/Inst system is pervasive in Caneka—used for Routes, HTTP contexts, Config files, Templates, and any hierarchical data structure. Understanding it is key to working with the Inter layer.


## Structure & Components

### The Seel (Schema)

A Seel is a **sealed Table** that maps property names to type information:

```c
// Example Seel for a "Person" type
Table *personSeel = Table_Make(m);

// Property "name" at index 0, type StrVec
Table_Set(personSeel, S(m, "name"), I16_Wrapped(m, TYPE_STRVEC));

// Property "age" at index 1, type Single (wrapped integer)
Table_Set(personSeel, S(m, "age"), I16_Wrapped(m, TYPE_WRAPPED_I32));

// Property "friends" at index 2, type Span (of Person instances)
Table_Set(personSeel, S(m, "friends"), I16_Wrapped(m, TYPE_SPAN));

// Seal the table and register globally
Seel_Seel(m, personSeel, S(m, "Person"), TYPE_PERSON);
```

**What `Seel_Seel` does** (from [seel.c:89](../../../src/ext/types/seel.c)):

```c
status Seel_Seel(MemCh *m, Table *seel, Str *name, cls typeOf){
    // Mark table as sealed (no more properties can be added)
    seel->type.state |= TABLE_SEALED;

    // Register in global lookups
    Lookup_Add(m, SeelLookup, typeOf, seel);              // Type → Seel
    Lookup_Add(m, SeelOrdLookup, typeOf, Table_Ordered(m, seel));  // Type → Ordered props
    Lookup_Add(m, SeelNameLookup, typeOf, name);          // Type → Name string
    Table_Set(SeelByName, name, I16_Wrapped(m, typeOf)); // Name → Type

    // Register print function for this type
    Lookup_Add(m, ToStreamLookup, typeOf, Inst_Print);

    return seel->type.state;
}
```

**Global Seel registries** (initialized in `Seel_Init`):

```c
Lookup *SeelLookup = NULL;      // cls → Table (the Seel)
Lookup *SeelOrdLookup = NULL;   // cls → Span (ordered property list)
Lookup *SeelNameLookup = NULL;  // cls → Str (type name)
Table *SeelByName = NULL;       // Str → cls (name → type)
```

These lookups enable:
- **`Seel_Get(inst, key)`**: Look up the inst's type in `SeelLookup`, find the key in the Seel, get the index
- **`Seel_TypeByName(name)`**: Convert type name string to cls type ID
- **Type introspection**: Get all properties of a type via `SeelOrdLookup`

### The Inst (Instance)

An Inst is a **Span with a type flag** (`TYPE_INSTANCE`) whose elements correspond to Seel properties:

```c
typedef Span Inst;
```

**That's it.** An Inst is just a Span. The magic is in how it's created and accessed.

**Standard NodeObj structure** (from [inst.h:1](../../../src/ext/include/types/inst.h)):

```c
enum nodeobj_prop_idx {
    INST_PROPIDX_NAME = 0,      // StrVec: Instance name
    INST_PROPIDX_ATTS = 1,      // Table: Generic attributes
    INST_PROPIDX_CHILDREN = 2,  // Table: Nested instances
};
```

Most Inst types inherit this base structure—first 3 properties are standard, additional properties start at index 3.

**Example memory layout** for a Person instance:

```
Inst (Span):
  [0] → StrVec("Alice")         // name property
  [1] → Single(30)               // age property
  [2] → Span([Person1, Person2]) // friends property
```

When you call `Seel_Get(person, K(m, "age"))`:
1. Lookup `TYPE_PERSON` in `SeelLookup` → gets `personSeel`
2. Lookup `"age"` in `personSeel` → gets index 1
3. Return `Span_Get(person, 1)` → `Single(30)`

### Property Registration Example

**NodeObj is the simplest Seel** (from [nodeobj.c:4](../../../src/ext/navigate/nodeobj.c)):

```c
status NodeObj_ClsInit(MemCh *m){
    Table *tbl = Table_Make(m);

    // Define three properties
    Table_Set(tbl, S(m, "name"), I16_Wrapped(m, TYPE_STRVEC));
    Table_Set(tbl, S(m, "atts"), I16_Wrapped(m, TYPE_TABLE));
    Table_SetHashed(tbl, S(m, "children"), I16_Wrapped(m, TYPE_TABLE));

    // Register as TYPE_NODEOBJ
    return Seel_Seel(m, tbl, S(m, "NodeObj"), TYPE_NODEOBJ);
}
```

**Why `Table_SetHashed` for the last property?** It ensures the property ends up at a specific insertion order (preserving the 0, 1, 2 indices). Regular `Table_Set` works too, but `Table_SetHashed` guarantees control over ordering.

**Route is a more complex Seel** (from exploration, see [route.c](../../../src/inter/www/route.c)):

```c
// Route is typedef'd as Inst
typedef Inst Route;

// Route flags (stored in type.state)
enum route_flags {
    ROUTE_STATIC = 1 << 8,
    ROUTE_DYNAMIC = 1 << 9,
    ROUTE_FMT = 1 << 10,
    ROUTE_INDEX = 1 << 13,
    ROUTE_BINSEG = 1 << 11,
    ROUTE_ACTION = 1 << 14,
    ROUTE_FORBIDDEN = 1 << 15,
};

// Route property indices (extend NodeObj)
enum route_prop_idx {
    ROUTE_PROPIDX_PATH = 0,      // NodeObj: name
    ROUTE_PROPIDX_DATA = 1,      // NodeObj: atts
    ROUTE_PROPIDX_CHILDREN = 2,  // NodeObj: children
    ROUTE_ROUTE_GENS = 3,        // Route-specific: generation count
};

// Route Seel initialization (conceptual, actual code in route.c)
Table *routeSeel = Table_Make(m);
Table_Set(routeSeel, S(m, "name"), I16_Wrapped(m, TYPE_STRVEC));
Table_Set(routeSeel, S(m, "atts"), I16_Wrapped(m, TYPE_TABLE));
Table_Set(routeSeel, S(m, "children"), I16_Wrapped(m, TYPE_TABLE));
Table_Set(routeSeel, S(m, "gens"), I16_Wrapped(m, TYPE_WRAPPED_I32));
Seel_Seel(m, routeSeel, S(m, "Route"), TYPE_ROUTE);
```

Routes use the standard NodeObj base (indices 0-2), then add custom properties starting at index 3.


## Property Access

### Getting Properties: `Seel_Get`

**Function signature**:
```c
void *Seel_Get(Span *inst, void *key);
```

**Implementation** (from [seel.c:56](../../../src/ext/types/seel.c)):

```c
void *Seel_Get(Span *inst, void *key){
    if(inst == NULL){
        return NULL;
    }

    // Get the Seel for this inst's type
    Table *seel = Lookup_Get(SeelLookup, inst->type.of);
    if(seel == NULL){
        Error(inst->m, FUNCNAME, FILENAME, LINENUMBER,
            "Seel not found for type $", ...);
        return NULL;
    }

    // Find the property in the Seel
    Hashed *h = Table_GetHashed(seel, key);
    if(h == NULL){
        Error(inst->m, FUNCNAME, FILENAME, LINENUMBER,
            "Seel prop not found key: @", ...);
        return NULL;
    }

    // Extract type from Seel entry
    Single *sg = (Single *)h->value;

    // If type is TYPE_ABSTRACT, return raw pointer
    if(sg->val.w == TYPE_ABSTRACT){
        return Span_Get(inst, h->orderIdx);
    }else{
        // Otherwise, validate type and cast
        Abstract *value = Span_Get(inst, h->orderIdx);
        if(value != NULL){
            as(value, sg->val.w);  // Type check via macro
        }
        return value;
    }
}
```

**Key steps**:
1. Lookup inst's type in `SeelLookup` → get Seel
2. Lookup key in Seel → get `Hashed` with `orderIdx` and type
3. Access `Span_Get(inst, orderIdx)` to get value
4. Type-check value via `as()` macro before returning

**Usage example**:

```c
Route *route = Inst_Make(m, TYPE_ROUTE);

// Get the "name" property (returns StrVec *)
StrVec *path = Seel_Get(route, K(m, "name"));

// Get the "children" property (returns Table *)
Table *children = Seel_Get(route, K(m, "children"));

// Get a custom property "templ" (if it exists in this Route's atts)
Templ *templ = Seel_Get(route, K(m, "templ"));
```

**Why `K(m, "name")` instead of just `"name"`?** The `K()` macro creates a compile-time StrVec constant that's used as the hash key. This avoids runtime string allocation and hashing—the key is pre-computed.

### Setting Properties: `Seel_Set`

**Function signature**:
```c
status Seel_Set(Span *inst, void *key, void *value);
```

**Implementation** (from [seel.c:33](../../../src/ext/types/seel.c)):

```c
status Seel_Set(Span *inst, void *key, void *value){
    // Get the Seel for this inst's type
    Table *seel = Lookup_Get(SeelLookup, inst->type.of);
    if(seel == NULL){
        Error(inst->m, FUNCNAME, FILENAME, LINENUMBER,
            "Seel not found for type $", ...);
        return ERROR;
    }

    // Find the property in the Seel
    Hashed *h = Table_GetHashed(seel, key);
    if(h == NULL){
        Error(inst->m, FUNCNAME, FILENAME, LINENUMBER,
            "Seel prop not found key: @ for @", ...);
        return ERROR;
    }

    // Set the value at the property's index
    return Span_Set(inst, h->orderIdx, value);
}
```

**Usage example**:

```c
Route *route = Inst_Make(m, TYPE_ROUTE);

// Set the "name" property
Seel_Set(route, K(m, "name"), Sv(m, "/api/users"));

// Set the "atts" property (a Table)
Table *atts = Table_Make(m);
Table_Set(atts, K(m, "method"), Sv(m, "POST"));
Seel_Set(route, K(m, "atts"), atts);

// Set a custom property in the "atts" table
Seel_SetKv(route, S(m, "atts"), K(m, "auth"), Sv(m, "required"));
```

**`Seel_SetKv` helper** (from [seel.c:25](../../../src/ext/types/seel.c)):

```c
status Seel_SetKv(Span *inst, Str *prop, void *key, void *value){
    // Get the property (should be a Table)
    Table *tbl = Seel_Get(inst, prop);

    if(tbl != NULL && tbl->type.of == TYPE_TABLE){
        // Set key-value in that table
        return Table_Set(tbl, key, value);
    }

    return NOOP;
}
```

This is a convenience for setting nested properties without manually getting the intermediate Table.

### NodeObj Property Helpers

For the standard NodeObj structure, there are specialized helpers:

**Getting/setting attributes** (from [inst.c:15](../../../src/ext/types/inst.c)):

```c
void *Inst_Att(Inst *inst, void *key){
    Table *obj = (Table *)Span_Get(inst, INST_PROPIDX_ATTS);
    if(obj != NULL){
        return Table_Get(obj, key);
    }
    return NULL;
}

status Inst_SetAtt(Inst *inst, void *key, void *value){
    Table *obj = (Table *)Span_Get(inst, INST_PROPIDX_ATTS);
    if(obj != NULL){
        return Table_Set(obj, key, value);
    }
    return ERROR;
}
```

**Getting children**:

```c
void *Inst_GetChild(Inst *inst, void *key){
    Table *children = (Table *)Span_Get(inst, INST_PROPIDX_CHILDREN);
    return Table_Get(children, key);
}
```

**Usage**:

```c
Route *route = Inst_Make(m, TYPE_ROUTE);

// Set an attribute
Inst_SetAtt(route, K(m, "mime"), Sv(m, "text/html"));

// Get an attribute
StrVec *mime = Inst_Att(route, K(m, "mime"));

// Get a child route
Route *childRoute = Inst_GetChild(route, K(m, "index"));
```

These helpers are faster than `Seel_Get/Seel_Set` because they directly access known indices (0, 1, 2) without Seel lookup.


## Instance Creation

### `Inst_Make` - Creating Instances

**Function signature**:
```c
Span *Inst_Make(MemCh *m, cls typeOf);
```

**Implementation** (from [inst.c:187](../../../src/ext/types/inst.c)):

```c
Span *Inst_Make(MemCh *m, cls typeOf){
    // Get the Seel for this type
    Table *seel = Lookup_Get(SeelLookup, typeOf);
    if(seel == NULL){
        Error(m, FUNCNAME, FILENAME, LINENUMBER, "Error Seel not found $", ...);
        return NULL;
    }

    // Create a Span instance
    Span *inst = Span_Make(m);
    inst->type.of = typeOf;  // Set type to typeOf
    inst->type.state |= TYPE_INSTANCE;  // Mark as instance

    // Initialize properties based on Seel
    Iter it;
    Iter_Init(&it, seel);
    while((Iter_Next(&it) & END) == 0){
        Hashed *h = (Hashed *)Iter_Get(&it);
        Single *sg = (Single *)h->value;

        // Auto-create container properties (Table, Span)
        if(sg->val.w == TYPE_TABLE){
            Span_Set(inst, h->orderIdx, Table_Make(m));
        }else if(sg->val.w == TYPE_SPAN){
            Span_Set(inst, h->orderIdx, Span_Make(m));
        }
        // Other types (StrVec, Single, etc.) remain NULL until set
    }

    return inst;
}
```

**What this does**:
1. Creates a Span
2. Sets its type to the provided `typeOf`
3. Iterates over the Seel properties
4. For container types (Table, Span), pre-allocates them
5. For value types (StrVec, Single, etc.), leaves them NULL

**Usage example**:

```c
// Create a NodeObj instance
Inst *config = Inst_Make(m, TYPE_NODEOBJ);

// Properties are initialized:
// config[0] (name) → NULL (not set yet)
// config[1] (atts) → Table (empty)
// config[2] (children) → Table (empty)

// Set properties
Seel_Set(config, K(m, "name"), Sv(m, "database"));
Inst_SetAtt(config, K(m, "host"), Sv(m, "localhost"));
Inst_SetAtt(config, K(m, "port"), I32_Wrapped(m, 5432));

// Result:
// config[0] → StrVec("database")
// config[1] → Table {"host" → "localhost", "port" → 5432}
// config[2] → Table (empty)
```

### `Inst_ByPath` - Hierarchical Access

**Purpose**: Navigate and create nested Inst structures using path notation.

**Function signature**:
```c
void *Inst_ByPath(Span *inst, StrVec *path, void *value, word op, Span *coords);

// Convenience macros
#define Inst_GetByPath(n, p) Inst_ByPath((n), (p), NULL, SPAN_OP_GET, NULL)
#define Inst_SetByPath(n, p, v) Inst_ByPath((n), (p), (v), SPAN_OP_SET, NULL)
```

**Implementation overview** (from [inst.c:58](../../../src/ext/types/inst.c)):

```c
void *Inst_ByPath(Span *inst, StrVec *path, void *value, word op, Span *coords){
    // path must be a STRVEC_PATH (e.g., "database/users/table")
    if((path->type.state & STRVEC_PATH) == 0 && path->p->nvalues > 1){
        Error(inst->m, FUNCNAME, FILENAME, LINENUMBER,
            "Error Inst_ByPath requires a strvec path", ...);
        return NULL;
    }

    Inst *current = inst;
    Abstract *prev = NULL;

    // Iterate over path tokens
    Iter it;
    Iter_Init(&it, path->p);
    while((Iter_Next(&it) & END) == 0){
        Abstract *token = Iter_Get(&it);

        if(it.type.state & LAST){
            // Last token: this is the target property
            Abstract *key = ((token->type.state & MORE) && it.idx > 0) ? prev : token;
            Table *children = Span_Get(current, INST_PROPIDX_CHILDREN);

            if(op == SPAN_OP_SET){
                // Set the value in children table
                Table_SetHashed(children, key, value);
                return value;
            }else{
                // Get the value from children table
                return Table_Get(children, key);
            }

        }else if(token->type.state & MORE){
            // Intermediate token: navigate to child Inst
            if(prev){
                Table *children = Span_Get(current, INST_PROPIDX_CHILDREN);
                Abstract *child = Table_Get(children, prev);

                if(op == SPAN_OP_SET){
                    if(child == NULL){
                        // Auto-create intermediate Inst
                        Inst *new = Inst_Make(inst->m, inst->type.of);
                        Table_Set(children, prev, new);
                        current = new;
                    }else if(child->type.of == inst->type.of){
                        current = (Inst *)child;
                    }else{
                        Error(...); // Type conflict
                        break;
                    }
                }else{
                    if(child == NULL){
                        return NULL;  // Path doesn't exist
                    }else if(child->type.of == inst->type.of){
                        current = (Inst *)child;
                    }else{
                        break;  // Type mismatch
                    }
                }
            }
        }
        prev = token;
    }

    return NULL;
}
```

**Usage example**:

```c
// Create root config
Inst *config = Inst_Make(m, TYPE_NODEOBJ);

// Set nested value: config → database → users → table_name
StrVec *path = Sv(m, "database/users/table_name");
path->type.state |= STRVEC_PATH;  // Mark as path

Inst_SetByPath(config, path, Sv(m, "user_accounts"));

// This creates:
// config[CHILDREN] → Table {
//   "database" → Inst {
//     [CHILDREN] → Table {
//       "users" → Inst {
//         [CHILDREN] → Table {
//           "table_name" → StrVec("user_accounts")
//         }
//       }
//     }
//   }
// }

// Retrieve the value
StrVec *tableName = Inst_GetByPath(config, path);
// tableName → "user_accounts"
```

**Key feature**: Intermediate Inst nodes are auto-created during `SPAN_OP_SET`. This enables building deep hierarchies without manually creating each level.

**Path syntax**: Paths are StrVecs with `STRVEC_PATH` flag. Tokens are separated by `/` (by convention, though the implementation just iterates the StrVec's Span of strings).


## Type Safety & Validation

### Runtime Type Checking

**The `as()` macro** (from type system, typically in types.h):

```c
#define as(a, t) \
    (((Abstract *)(a))->type.of == (t) ? (a) : \
        (Error_Type(((Abstract *)(a))->m, (t), ((Abstract *)(a))->type.of), NULL))
```

**What it does**:
- Checks if the Abstract's `type.of` matches expected type `t`
- If match: returns the pointer
- If no match: logs an error and returns NULL

**Used in `Seel_Get`**:

```c
Abstract *value = Span_Get(inst, h->orderIdx);
if(value != NULL){
    as(value, sg->val.w);  // Validate type from Seel matches actual value
}
return value;
```

**Example type error**:

```c
Route *route = Inst_Make(m, TYPE_ROUTE);

// Set "name" to a StrVec
Seel_Set(route, K(m, "name"), Sv(m, "/api"));

// Try to get "name" as a Table
Table *name = Seel_Get(route, K(m, "name"));
// ERROR: Type is not TYPE_TABLE, expected TYPE_STRVEC
// Returns NULL
```

The Seel records that `"name"` should be `TYPE_STRVEC`. When you retrieve it, `as()` checks the actual value's type matches.

### Seel Sealing

**`TABLE_SEALED` flag**: Once a Seel is sealed (via `Seel_Seel`), no more properties can be added.

**Enforcement** (in Table_Set for sealed tables):

```c
if(tbl->type.state & TABLE_SEALED){
    Error(m, FUNCNAME, FILENAME, LINENUMBER,
        "Cannot modify a sealed table", ...);
    return ERROR;
}
```

This prevents accidental schema modification after types are registered globally.

### Type Hierarchy Integration

**Instance types are flagged**:

```c
inst->type.state |= TYPE_INSTANCE;
```

This allows type system functions to distinguish Inst from regular Span:

```c
if((a->type.of & TYPE_INSTANCE) != 0){
    // This is an Inst, use Seel_Get/Seel_Set
}else{
    // This is a plain Span, use Span_Get/Span_Set
}
```

**Type registration**: When you call `Seel_Seel`, it registers a print function:

```c
Lookup_Add(m, ToStreamLookup, typeOf, Inst_Print);
```

This makes Inst instances printable via `ToS(bf, inst, 0, ZERO)`, which calls `Inst_Print` to serialize the instance.


## Fetcher System (Dynamic Property Access)

### Purpose

The Fetcher system enables **runtime resolution of property paths** for templates, JSON mapping, and dynamic queries. Instead of hardcoding `Inst_Att(inst, K(m, "username"))`, you can specify a path like `"session.user.name"` and fetch it dynamically.

### FetchTarget Structure

**Conceptual definition** (from exploration, actual definition in types/fetcher.h):

```c
typedef struct {
    Type type;
    MemCh *m;
    StrVec *path;        // e.g., "session/user/name"
    cls sourceType;      // Expected source type (e.g., TYPE_HTTP_CTX)
    cls targetType;      // Expected result type (e.g., TYPE_STRVEC)
} FetchTarget;
```

**Usage in templates**:

```c
// Template: {session.user.name}
// Compiled to:
FetchTarget *target = FetchTarget_Make(m);
target->path = Sv(m, "session/user/name");
target->sourceType = TYPE_TABLE;  // Assume source is a Table
target->targetType = TYPE_STRVEC; // Expect result to be StrVec

// At render time:
Table *data = ...; // Template data context
StrVec *userName = Fetcher_Get(data, target);
// userName → retrieved value or NULL if path invalid
```

### Fetcher_Get Implementation

**Conceptual** (simplified from actual implementation):

```c
void *Fetcher_Get(Abstract *source, FetchTarget *target){
    // Validate source type
    if(source->type.of != target->sourceType){
        return NULL;
    }

    // Tokenize path
    Span *tokens = StrVec_Split(source->m, target->path, K(source->m, "/"));

    Abstract *current = source;
    Iter it;
    Iter_Init(&it, tokens);

    while((Iter_Next(&it) & END) == 0){
        StrVec *token = Iter_Get(&it);

        if(current->type.of == TYPE_TABLE){
            // Navigate into table
            current = Table_Get((Table *)current, token);
        }else if(current->type.of & TYPE_INSTANCE){
            // Navigate into Inst via Seel_Get or Inst_GetChild
            current = Seel_Get((Inst *)current, token);
        }else{
            return NULL;  // Can't navigate further
        }

        if(current == NULL){
            return NULL;  // Path doesn't exist
        }
    }

    // Validate result type
    if(target->targetType != TYPE_ABSTRACT && current->type.of != target->targetType){
        return NULL;
    }

    return current;
}
```

**Key steps**:
1. Tokenize the path by `/`
2. For each token:
   - If current is Table: `Table_Get`
   - If current is Inst: `Seel_Get` or `Inst_GetChild`
   - Otherwise: error
3. Validate final result type matches target

### Use Case: Template Variable Resolution

**Template source**:

```html
<h1>Welcome, {user.name}!</h1>
<p>Your email: {user.email}</p>
```

**Template preparation** (during `Templ_Prepare`):

```c
// For "{user.name}"
FetchTarget *nameTarget = FetchTarget_Make(m);
nameTarget->path = Sv(m, "user/name");
nameTarget->sourceType = TYPE_TABLE;
nameTarget->targetType = TYPE_STRVEC;

// Store in template
templ->targets[0] = nameTarget;

// For "{user.email}"
FetchTarget *emailTarget = FetchTarget_Make(m);
emailTarget->path = Sv(m, "user/email");
emailTarget->sourceType = TYPE_TABLE;
emailTarget->targetType = TYPE_STRVEC;

templ->targets[1] = emailTarget;
```

**Template rendering** (during `Templ_ToS`):

```c
Table *data = ...; // Data context
data = {
    "user" → Table {
        "name" → StrVec("Alice"),
        "email" → StrVec("alice@example.com")
    }
};

// Resolve {user.name}
StrVec *name = Fetcher_Get(data, templ->targets[0]);
Buff_AddVec(bf, name);  // Write "Alice"

// Resolve {user.email}
StrVec *email = Fetcher_Get(data, templ->targets[1]);
Buff_AddVec(bf, email);  // Write "alice@example.com"
```

**Result**:

```html
<h1>Welcome, Alice!</h1>
<p>Your email: alice@example.com</p>
```

The Fetcher system allows templates to reference arbitrary nested properties without knowing the exact data structure at compile time.



---

**Part 1 of 2** | [Part 2 →](seel-inst-complete-part2)
