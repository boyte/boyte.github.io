# Guard Mechanism: Complete Guide to Loop Detection - Part 2

[← Part 1](guard-mechanism-complete-part1) | **Part 2 of 2**

---

## Best Practices

### Initialize Guards to Zero

**GOOD**:
```c
i16 guard = 0;  // Explicit initialization
while(condition) {
    Guard_Incr(m, &guard, MAX, ...);
}
```

**BAD**:
```c
i16 guard;  // Uninitialized!
while(condition) {
    Guard_Incr(m, &guard, MAX, ...);  // Undefined behavior
}
```

### Reset Structure Guards Between Operations

**GOOD**:
```c
Roebling *rbl = Roebling_Make(m);

// First parse
Guard_Reset(&rbl->guard);
Roebling_Run(rbl);

// Second parse
Guard_Reset(&rbl->guard);  // Reset before reuse
Roebling_Run(rbl);
```

**BAD**:
```c
Roebling *rbl = Roebling_Make(m);

// First parse
Guard_Reset(&rbl->guard);
Roebling_Run(rbl);  // guard=500 at exit

// Second parse (no reset!)
Roebling_Run(rbl);  // guard=501, 502, ... starts high!
```

### Use Appropriate Limits

**GOOD**: Choose limits based on expected iteration count:

```c
// Simple buffer operation: 512 limit
i16 guard = 0;
while(writing) {
    Guard_Incr(m, &guard, BUFF_CYCLE_MAX, ...);  // 512
}

// Complex pattern matching: 8192 limit
while(parsing) {
    Guard_Incr(m, &guard, RBL_GUARD_MAX, ...);  // 8192
}
```

**BAD**: Using arbitrary limits:

```c
// Limit too low - false positives
i16 guard = 0;
while(parsing_complex_pattern) {
    Guard_Incr(m, &guard, 10, ...);  // Too low! Normal parsing hits limit
}

// Limit too high - defeats purpose
while(simple_loop) {
    Guard_Incr(m, &guard, 1000000, ...);  // Infinite loop still hangs for minutes
}
```

### Check Guard Return Value

**GOOD**:
```c
i16 guard = 0;
while(condition) {
    status result = Guard_Incr(m, &guard, MAX, FUNCNAME, FILENAME, LINENUMBER);

    if(result & ERROR) {
        // Clean up and return error
        cleanup_resources();
        return ERROR;
    }

    // Continue work
}
```

**ACCEPTABLE** (if loop has other exit conditions):
```c
while((status & SUCCESS) == 0) {
    Guard_Incr(m, &guard, MAX, ...);  // Don't check return

    status = do_work();  // Sets status to SUCCESS or ERROR
}
// If guard exceeds, do_work() will eventually see ERROR state
```

### Separate Guards for Nested Loops

**GOOD**:
```c
i16 outer_guard = 0;
while(outer_condition) {
    Guard_Incr(m, &outer_guard, OUTER_MAX, ...);

    i16 inner_guard = 0;  // Separate guard
    while(inner_condition) {
        Guard_Incr(m, &inner_guard, INNER_MAX, ...);
    }
}
```

**BAD**:
```c
i16 guard = 0;  // Shared guard
while(outer_condition) {
    Guard_Incr(m, &guard, MAX, ...);

    while(inner_condition) {
        Guard_Incr(m, &guard, MAX, ...);  // Same guard!
        // If inner loops many times, outer guard fails
    }
}
```

### Use FUNCNAME/FILENAME/LINENUMBER Macros

**GOOD**:
```c
Guard_Incr(m, &guard, MAX, FUNCNAME, FILENAME, LINENUMBER);
// Error message includes: "at file.c:123 in MyFunction"
```

**BAD**:
```c
Guard_Incr(m, &guard, MAX, "MyFunction", "file.c", 123);
// Hardcoded values get stale if code moves
```

### Disable Guards for Ultra-Performance Paths

**GOOD**:
```c
#ifdef NDEBUG
    i16 max = 0;  // Disable guards in release builds
#else
    i16 max = GUARD_MAX;  // Enable in debug
#endif

Guard_Incr(m, &guard, max, ...);
```

**WHEN TO DISABLE**:
- Performance-critical inner loop profiled as bottleneck
- Code thoroughly tested and proven correct
- Risk of infinite loop is negligible

**WHEN TO KEEP ENABLED**:
- Parsing untrusted input
- User-facing operations
- Network I/O
- Recursion or complex state machines


## Common Pitfalls and Solutions

### Pitfall 1: Forgetting to Initialize Guard

**Problem**:
```c
i16 guard;  // Uninitialized! Could be any value
while(condition) {
    Guard_Incr(m, &guard, 100, ...);
    // If guard started at 95, fails after 5 iterations!
}
```

**Solution**:
```c
i16 guard = 0;  // Always initialize to zero
while(condition) {
    Guard_Incr(m, &guard, 100, ...);
}
```

### Pitfall 2: Reusing Guard Without Reset

**Problem**:
```c
Counter *c = Counter_Make(m);

Counter_IncrementTo(c, 500);  // guard=500
Counter_IncrementTo(c, 1000); // guard=501, 502, ...
// Second call starts at guard=500, hits limit sooner!
```

**Solution**:
```c
status Counter_IncrementTo(Counter *c, i32 target) {
    Guard_Reset(&c->guard);  // Reset at operation start

    while(c->value < target) {
        Guard_Incr(c->m, &c->guard, 1000, ...);
        c->value++;
    }

    Guard_Reset(&c->guard);  // Reset at operation end
    return SUCCESS;
}
```

### Pitfall 3: Limit Too Low for Normal Operation

**Problem**:
```c
// Large file with 10,000 chunks
i16 guard = 0;
while(has_more_chunks) {
    Guard_Incr(m, &guard, 1000, ...);  // Limit too low!
    write_chunk();
}
// Fails at chunk 1000 even though operation is valid
```

**Solution**:
```c
// Choose limit based on maximum expected iterations
#define LARGE_FILE_CHUNKS 20000  // 2x expected max for headroom

i16 guard = 0;
while(has_more_chunks) {
    Guard_Incr(m, &guard, LARGE_FILE_CHUNKS, ...);
    write_chunk();
}
```

### Pitfall 4: Ignoring Guard Errors

**Problem**:
```c
while(condition) {
    Guard_Incr(m, &guard, MAX, ...);  // Return value ignored!
    do_work();
}
// Guard exceeds, but loop continues until condition becomes false
// May never happen, hanging the system
```

**Solution**:
```c
while(condition) {
    if(Guard_Incr(m, &guard, MAX, ...) & ERROR) {
        return ERROR;  // Propagate guard error
    }
    do_work();
}
```

### Pitfall 5: Shared Guard in Nested Loops

**Problem**:
```c
i16 guard = 0;
for(i32 i = 0; i < 10; i++) {
    Guard_Incr(m, &guard, 50, ...);  // guard=1, 2, 3, ...

    for(i32 j = 0; j < 100; j++) {
        Guard_Incr(m, &guard, 50, ...);  // guard=11, 12, ...
        // Exceeds limit even though each individual loop is fine!
    }
}
```

**Solution**:
```c
i16 outer_guard = 0;
for(i32 i = 0; i < 10; i++) {
    Guard_Incr(m, &outer_guard, 20, ...);

    i16 inner_guard = 0;  // Separate guard for inner loop
    for(i32 j = 0; j < 100; j++) {
        Guard_Incr(m, &inner_guard, 200, ...);
    }
}
```

### Pitfall 6: Wrong Limit Constant

**Problem**:
```c
// Buffer operation using parser limit
i16 guard = 0;
while(writing) {
    Guard_Incr(m, &guard, RBL_GUARD_MAX, ...);  // 8192 - too high!
}
```

**Solution**:
```c
// Use module-appropriate limit
i16 guard = 0;
while(writing) {
    Guard_Incr(m, &guard, BUFF_CYCLE_MAX, ...);  // 512 - correct
}
```

### Pitfall 7: Guard in Performance-Critical Section

**Problem**:
```c
// Tight loop executed billions of times
for(i64 i = 0; i < 1000000000; i++) {
    Guard_Incr(m, &guard, 2000000000, ...);  // Overhead adds up!
    // Micro-operation
}
```

**Solution**:
```c
// Disable guard for verified tight loops
for(i64 i = 0; i < 1000000000; i++) {
    // No guard - loop bound is explicit
    // Micro-operation
}

// Or check periodically
for(i64 i = 0; i < 1000000000; i++) {
    if(i % 1000000 == 0) {  // Check every million iterations
        Guard_Incr(m, &guard, 2000, ...);
    }
}
```

### Pitfall 8: Guard Overflow

**Problem**:
```c
// Guard is i16: max value 32767
i16 guard = 0;
while(condition) {
    Guard_Incr(m, &guard, 50000, ...);  // Limit exceeds i16 range!
    // Guard wraps around: 32767 → -32768
}
```

**Solution**:
```c
// Keep limits under 32767
#define REASONABLE_MAX 10000  // Well under i16 limit

i16 guard = 0;
while(condition) {
    Guard_Incr(m, &guard, REASONABLE_MAX, ...);
}

// Or use larger type if needed
i32 big_guard = 0;
// ... custom guard checking with i32
```

### Pitfall 9: No Guard on User Input Loop

**Problem**:
```c
// No guard - vulnerable to DOS
while(read_byte_from_network() != '\n') {
    // Attacker sends stream without newline → infinite loop
}
```

**Solution**:
```c
i16 guard = 0;
while(read_byte_from_network() != '\n') {
    if(Guard_Incr(m, &guard, 1024, ...) & ERROR) {
        close_connection();
        return ERROR;  // Limit line length to 1024 bytes
    }
}
```

### Pitfall 10: Guard Error Not Logged

**Problem**:
```c
if(Guard_Incr(m, &guard, MAX, ...) & ERROR) {
    return ERROR;  // Silent failure - no logging
}
```

**Solution**:
```c
if(Guard_Incr(m, &guard, MAX, ...) & ERROR) {
    // Error already logged by Guard_Incr via Error() system
    // Just propagate the error
    return ERROR;
}

// Or add context:
if(Guard_Incr(m, &guard, MAX, ...) & ERROR) {
    Abstract *args[] = {operation_name, NULL};
    Error(m, FUNCNAME, FILENAME, LINENUMBER,
        "Operation @ exceeded guard limit", args);
    return ERROR;
}
```


## Cross-References

### Related Core Concepts

- **[Error Handling](error-handling-complete.md)**: Guard mechanism integrates with error system
- **[MemCh Complete](memory/memchapter.md)**: Guards embedded in MemCh structure
- **[Type System Complete](type-system-complete.md)**: Guard uses type system for error formatting
- **[Iter Complete](memory/iter-complete.md)**: Extensive guard usage in iteration
- **[Buff I/O Complete](buff-io-complete.md)**: Buffer operations with BUFF_CYCLE_MAX guards

### Integration Points

- **[Roebling Parser](parser/pattern-matching.md)**: Parser uses RBL_GUARD_MAX for pattern matching
- **[Template Engine](templ-complete.md)**: Template rendering with guard protection
- **[BinSeg Serialization](binseg-complete.md)**: Segment processing guards
- **[HTTP Lifecycle](http-lifecycle-complete.md)**: Request parsing with guard limits
- **[Task Execution](navigate/task-execution-complete.md)**: Task step guards

### Implementation Files

- **Headers**:
  - [src/base/include/types/guard.h](../../../src/base/include/types/guard.h) - Guard function declarations
  - [src/base/include/core/arch.h](../../../src/base/include/core/arch.h) - Guard limit constants
- **Implementation**:
  - [src/base/types/guard.c](../../../src/base/types/guard.c) - Guard_Incr, Guard, Guard_Reset
  - [src/base/types/error.c](../../../src/base/types/error.c) - Error integration with guards
- **Usage Examples**:
  - [src/base/io/buff.c](../../../src/base/io/buff.c) - Buffer I/O guards
  - [src/base/mem/iter.c](../../../src/base/mem/iter.c) - Iterator guards
  - [src/ext/parser/roebling.c](../../../src/ext/parser/roebling.c) - Parser guards
  - [src/inter/templ/templ.c](../../../src/inter/templ/templ.c) - Template guards

---

*This documentation provides a comprehensive guide to Caneka's Guard Mechanism for infinite loop prevention. For specific use cases or integration patterns, refer to the module-specific documentation and code examples throughout the codebase.*



---

[← Part 1](guard-mechanism-complete-part1) | **Part 2 of 2**
