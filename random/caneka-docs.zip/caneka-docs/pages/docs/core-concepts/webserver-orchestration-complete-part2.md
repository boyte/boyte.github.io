# WebServer Orchestration: Complete Guide - Part 2

[← Part 1](webserver-orchestration-complete-part1) | **Part 2 of 2**

---

## Best Practices

### 1. Use Memory Chapters for Isolation

```c
// GOOD: Isolated per-connection memory
MemCh *tm = MemCh_Make();
Task *child = Task_Make(Span_Make(tm), parent);
tm->owner = child;

// All allocations in connection context
Buff *bf = Buff_Make(tm, ZERO);

// Atomic cleanup
MemCh_Free(child->m);
```

```c
// BAD: Using global memory chapter
Buff *bf = Buff_Make(m, ZERO);  // Leaked if connection terminates early!
```

### 2. Set Appropriate Timeouts

```c
// GOOD: Reasonable timeout
child->timeout.tv_sec = 6;   // 6 seconds for HTTP request

// BAD: No timeout
child->timeout.tv_sec = 0;  // Connection can hang forever
```

### 3. Handle Socket Errors

```c
// GOOD: Check poll events
if(pfd->revents & (POLLHUP | POLLERR | POLLNVAL)){
    tsk->type.state |= ERROR;
    return ERROR;
}

// BAD: Assume socket is always valid
Buff_ReadAmount(bf, 1024);  // Might hang or crash
```

### 4. Limit Step Iterations

```c
// GOOD: Bounded steps
child->stepGuardMax = TCP_STEP_MAX;  // 16,000 steps

// BAD: Infinite steps
child->stepGuardMax = -1;  // Connection can loop forever
```

### 5. Use Zero-Copy Where Possible

```c
// GOOD: Zero-copy composition
Buff_Pipe(output, header);   // Shallow copy
Buff_Pipe(output, content);  // Shallow copy

// LESS OPTIMAL: Deep copy
StrVec_Append(output->v, header->v);  // Copies data
```

### 6. Close Sockets Explicitly

```c
// GOOD: Explicit close
status finalize(Step *st, Task *tsk){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    close(pfd->fd);
    return SUCCESS;
}

// BAD: Relying on OS to close
// (File descriptor leaks!)
```

### 7. Log Errors with Context

```c
// GOOD: Detailed error logging
Out("^r.Error %s %d %s %ldμs - %s^0\n",
    (void *[]){ctx->method, I32_Wrapped(m, ctx->code), ctx->path,
               I64_Wrapped(m, latency), S(m, "Timeout"), NULL});

// BAD: Minimal logging
printf("Error\n");  // No context!
```

### 8. Validate Configuration

```c
// GOOD: Validate port range
if(port <= 0 || port > 65535){
    fprintf(stderr, "Invalid port: %d\n", port);
    exit(1);
}

// BAD: Assume config is valid
bind(fd, &addr, sizeof(addr));  // Might fail silently
```


## Common Pitfalls

### Pitfall 1: Forgetting Non-Blocking Mode

**Problem**:
```c
i32 fd = accept(listen_fd, NULL, NULL);
// Forgot to set non-blocking!
```

**Why Bad**: Blocking reads/writes stall the entire event loop.

**Solution**:
```c
i32 fd = accept(listen_fd, NULL, NULL);
fcntl(fd, F_SETFL, O_NONBLOCK);
```

### Pitfall 2: Not Checking poll() Results

**Problem**:
```c
poll(pfds, nfds, 100);
// Proceed without checking result
```

**Why Bad**: Errors or signals can interrupt poll().

**Solution**:
```c
i32 ready = poll(pfds, nfds, 100);
if(ready < 0){
    if(errno == EINTR) continue;  // Signal
    return ERROR;
}
```

### Pitfall 3: Memory Leaks into Global Chapter

**Problem**:
```c
Buff *bf = Buff_Make(m, ZERO);  // 'm' is global chapter
// Connection terminates early
// 'bf' is leaked!
```

**Why Bad**: Per-connection allocations accumulate in global memory.

**Solution**:
```c
Buff *bf = Buff_Make(child->m, ZERO);  // Connection-scoped
// Freed automatically with child->m
```

### Pitfall 4: Not Handling EAGAIN

**Problem**:
```c
ssize_t n = read(fd, buf, len);
if(n < 0){
    return ERROR;  // Treats EAGAIN as error!
}
```

**Why Bad**: EAGAIN means "no data yet", not an error.

**Solution**:
```c
ssize_t n = read(fd, buf, len);
if(n < 0){
    if(errno == EAGAIN || errno == EWOULDBLOCK){
        return STEP_REPEAT;  // Try again later
    }
    return ERROR;
}
```

### Pitfall 5: Infinite Step Loops

**Problem**:
```c
status MyStep(Step *st, Task *tsk){
    return STEP_REPEAT;  // Always repeats!
}
```

**Why Bad**: Bypasses step guard, hangs event loop.

**Solution**:
```c
status MyStep(Step *st, Task *tsk){
    if(condition_met){
        return SUCCESS;
    }
    return STEP_REPEAT;
}
```

### Pitfall 6: Not Updating Poll Events

**Problem**:
```c
pfd->events = POLLIN;
// Later, need to write
Buff_WriteTo(bf, pfd->fd);  // Won't detect socket ready!
```

**Why Bad**: poll() waits for wrong event.

**Solution**:
```c
pfd->events = POLLOUT;
tsk->type.state |= TASK_UPDATE_CRIT;  // Signal queue update
```

### Pitfall 7: Assuming Complete Writes

**Problem**:
```c
write(fd, buf, len);
// Assume all data written!
```

**Why Bad**: Non-blocking writes may be partial.

**Solution**:
```c
ssize_t sent = write(fd, buf, len);
if(sent < len){
    // Handle partial write
    return STEP_REPEAT;
}
```

### Pitfall 8: Not Closing on Error

**Problem**:
```c
if(error){
    tsk->type.state |= ERROR;
    return ERROR;
}
// Socket never closed!
```

**Why Bad**: File descriptor leak.

**Solution**:
```c
if(error){
    struct pollfd *pfd = TcpTask_GetPollFd(tsk);
    close(pfd->fd);
    tsk->type.state |= ERROR;
    return ERROR;
}
```


## Cross-References

### Related Core Concepts

- **[TCP Server](tcp-server-complete.md)** - Underlying TCP transport layer
- **[HTTP Lifecycle](http-lifecycle-complete.md)** - HTTP protocol handling
- **[WWW Routing](www-routing-complete.md)** - Route matching and content generation
- **[Task Execution](navigate/task-execution-complete.md)** - Task/Step execution model
- **[Queue](navigate/queue-complete.md)** - Connection queue management
- **[Memory Management](memory/memchapter.md)** - Per-connection memory isolation
- **[Config Format](config-format-complete.md)** - Server configuration files
- **[Buff I/O](buff-io-complete.md)** - Buffered socket operations

### Source Code Files

**TCP Server**:
- [src/ext/serve/serve_tcp.c](../../../src/ext/serve/serve_tcp.c) - TCP server implementation
- [src/ext/serve/tcp_task.c](../../../src/ext/serve/tcp_task.c) - Socket I/O operations
- [src/ext/serve/tcp_ctx.c](../../../src/ext/serve/tcp_ctx.c) - Server context
- [src/ext/include/serve/](../../../src/ext/include/serve/) - Header files

**HTTP/WWW**:
- [src/inter/www/webserver.c](../../../src/inter/www/webserver.c) - HTTP server integration
- [src/inter/www/route.c](../../../src/inter/www/route.c) - Routing system
- [src/inter/http/](../../../src/inter/http/) - HTTP protocol handling

**WebServer Program**:
- [src/programs/webserver/](../../../src/programs/webserver/) - Executable program

### API Reference

- **[Base API](../../api-reference/base.md)** - Memory, strings, I/O
- **[Ext API](../../api-reference/ext.md)** - Navigate, Task, Queue, TCP Server
- **[Inter API](../../api-reference/inter.md)** - HTTP, WWW, routing

### Developer Guides

- **[Creating Web Apps](../../guides/creating-web-apps.md)** - Building web applications
- **[Testing](../../guides/testing.md)** - Testing server implementations

---

This comprehensive guide covers all aspects of the WebServer orchestration system in Caneka. For questions or contributions, see [Contributing](../../contributing.md).



---

[← Part 1](webserver-orchestration-complete-part1) | **Part 2 of 2**
