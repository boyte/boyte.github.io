# Writing Parsers: Complete Tutorial - Part 1

**Part 1 of 2** | [Part 2 →](writing-parsers-part2)

---

## Introduction

This guide teaches you how to write custom parsers using Caneka's **Roebling** pattern matching engine. We'll progress from simple single-state parsers to complex multi-state DSL parsers, building your understanding incrementally with real, working examples drawn directly from Caneka's codebase.

**What You'll Learn**:
- Pattern definition fundamentals (PatCharDef arrays)
- State machine architecture and transitions
- Capture function implementation
- Building output structures (StrVec, Table, NodeObj, Mess)
- Error handling strategies
- Real-world parser examples (HTML, INI, Config, HTTP, Templ)

**Philosophy**: Roebling is not a traditional regex engine. It's a **concurrent pattern matching system** that evaluates multiple patterns simultaneously and generates data structures as it parses. Instead of backtracking, it uses state transitions to guide the parse process.

**Why This Matters**: Caneka uses Roebling to parse all custom formats (.fmt, .templ, .cnk, .config), HTTP requests, JSON, XML, and more. Understanding Roebling means you can create your own DSLs and file formats with minimal code.


## Progressive Learning Path

We'll build four parsers of increasing complexity:

1. **Level 1: Single-State Parser** - HTML Entity Escaper (simplest: character replacement)
2. **Level 2: Two-State Parser** - INI File Parser (key-value pairs with state transitions)
3. **Level 3: Hierarchical Parser** - Config Parser (nested structures with indentation)
4. **Level 4: Protocol Parser** - HTTP Request Parser (multi-phase protocol handling)

Each level introduces new concepts while reinforcing previous ones. By Level 4, you'll understand how to build production-quality parsers for complex formats.

---


## Level 1: Single-State Parser

**Goal**: Build an HTML entity escaper that converts `&`, `<`, `>`, `"`, and `'` to their entity equivalents.

**Input**: `<div class="test">Hello & goodbye</div>`
**Output**: `&lt;div class=&quot;test&quot;&gt;Hello &amp; goodbye&lt;/div&gt;`

**Concepts Introduced**:
- Pattern definitions (PatCharDef)
- Single state function
- Capture functions
- StrVec output accumulation

### Complete Code

```c
#include "parser/roebling.h"
#include "bytes/str_vec.h"

// Capture keys (unique IDs for each pattern)
enum {
    HTML_ENT_CONTENT = 100,  // Regular content (everything else)
    HTML_ENT_AMPER,          // & character
    HTML_ENT_LT,             // < character
    HTML_ENT_GT,             // > character
    HTML_ENT_QUOTE,          // " character
    HTML_ENT_SQUOTE,         // ' character
    HTML_ENT_END
};

// Pattern definitions - one per special character
static PatCharDef amperDef[] = {
    {PAT_TERM, '&', '&'},  // Match exactly '&', terminal
    {PAT_END, 0, 0}
};

static PatCharDef ltDef[] = {
    {PAT_TERM, '<', '<'},
    {PAT_END, 0, 0}
};

static PatCharDef gtDef[] = {
    {PAT_TERM, '>', '>'},
    {PAT_END, 0, 0}
};

static PatCharDef quoteDef[] = {
    {PAT_TERM, '"', '"'},
    {PAT_END, 0, 0}
};

static PatCharDef squoteDef[] = {
    {PAT_TERM, '\'', '\''},
    {PAT_END, 0, 0}
};

// Fallback pattern - match everything else
static PatCharDef contentDef[] = {
    {PAT_KO, '&', '&'},      // Knockout: fail if we see '&'
    {PAT_KO, '<', '<'},      // Knockout: fail if we see '<'
    {PAT_KO, '>', '>'},      // Knockout: fail if we see '>'
    {PAT_KO, '"', '"'},      // Knockout: fail if we see '"'
    {PAT_KO, '\'', '\''},    // Knockout: fail if we see '\''
    {PAT_MANY|PAT_TERM, 32, 255},  // Match any printable character
    {PAT_END, 0, 0}
};

// Capture function - called when a pattern matches
static status Capture(Roebling *rbl, word captureKey, StrVec *v){
    StrVec *output = as(rbl->dest, TYPE_STRVEC);

    if(captureKey == HTML_ENT_AMPER){
        StrVec_AddS(output, "&amp;");
    }else if(captureKey == HTML_ENT_LT){
        StrVec_AddS(output, "&lt;");
    }else if(captureKey == HTML_ENT_GT){
        StrVec_AddS(output, "&gt;");
    }else if(captureKey == HTML_ENT_QUOTE){
        StrVec_AddS(output, "&quot;");
    }else if(captureKey == HTML_ENT_SQUOTE){
        StrVec_AddS(output, "&#39;");
    }else if(captureKey == HTML_ENT_CONTENT){
        // Regular content - just copy it over
        StrVec_AddVec(output, v);
    }

    return SUCCESS;
}

// State function - defines which patterns are active
static status state_content(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);

    // Set up all patterns (order matters - more specific patterns first)
    Roebling_SetPattern(rbl, amperDef, HTML_ENT_AMPER, 0);
    Roebling_SetPattern(rbl, ltDef, HTML_ENT_LT, 0);
    Roebling_SetPattern(rbl, gtDef, HTML_ENT_GT, 0);
    Roebling_SetPattern(rbl, quoteDef, HTML_ENT_QUOTE, 0);
    Roebling_SetPattern(rbl, squoteDef, HTML_ENT_SQUOTE, 0);
    Roebling_SetPattern(rbl, contentDef, HTML_ENT_CONTENT, 0);  // Fallback last

    return READY;
}

// Parse function
status HtmlEscape(MemCh *m, Str *input, StrVec *output){
    Cursor *curs = Cursor_Make(m, input);
    Roebling *rbl = Roebling_Make(m, curs, (RblCaptureFunc)Capture, output);

    // Set up state machine
    Roebling_AddStep(rbl, state_content);
    rbl->state = 0;  // Start at state 0

    // Run the parser
    Roebling_Start(rbl);
    status result = Roebling_Run(rbl);

    return result;
}
```

### Usage Example

```c
MemCh *m = MemCh_Make();
Str *input = Str_FromS(m, "<div class=\"test\">Hello & goodbye</div>");
StrVec *output = StrVec_Make(m);

HtmlEscape(m, input, output);

// output now contains: &lt;div class=&quot;test&quot;&gt;Hello &amp; goodbye&lt;/div&gt;
```

### Key Concepts Explained

**1. PatCharDef Structure**:
```c
typedef struct {
    word flags;       // Control behavior (PAT_TERM, PAT_MANY, PAT_KO, etc.)
    byte rangeStart;  // Character range start (or exact character if start == end)
    byte rangeEnd;    // Character range end
} PatCharDef;
```

**2. Pattern Flags**:
- `PAT_TERM` - This pattern is **terminal** (triggers capture when matched)
- `PAT_MANY` - Match 0 or more times (like regex `*`)
- `PAT_KO` - **Knockout** pattern (fail entire pattern if this matches)
- `PAT_END` - Marks end of PatCharDef array

**3. Pattern Evaluation**:
Roebling evaluates **all active patterns concurrently** at each character. The first pattern to become terminal wins and triggers its capture function.

**4. Capture Functions**:
```c
status CaptureFunc(Roebling *rbl, word captureKey, StrVec *captured)
```
- `captureKey` - Identifies which pattern matched (from SetPattern call)
- `captured` - The matched text as a StrVec
- Return `SUCCESS` to continue, or error status to abort

**5. State Functions**:
```c
status StateFunc(MemCh *m, Roebling *rbl)
```
- Called when entering a state
- Sets up active patterns for this state
- Returns `READY` to continue parsing

**6. Roebling_SetPattern**:
```c
Roebling_SetPattern(rbl, patDef, captureKey, jumpState)
```
- `patDef` - Pattern definition array
- `captureKey` - ID passed to capture function when matched
- `jumpState` - State to jump to after capture (0 = stay in current state)

### What Makes This "Single-State"?

All patterns are active simultaneously, and we never change states. The parser stays in `state_content` (state 0) for the entire input. This is perfect for simple character-level transformations.

---


## Level 2: Two-State Parser

**Goal**: Build an INI file parser that extracts key-value pairs.

**Input**:
```ini
name = Caneka
version = 1.0
author = CompareBasic
```

**Output**: Table with `{"name": "Caneka", "version": "1.0", "author": "CompareBasic"}`

**New Concepts**:
- Multiple states with transitions
- Context object to hold parse state
- State jumping after captures
- Building structured output (Table)

### Complete Code

```c
#include "parser/roebling.h"
#include "sequence/table.h"

// Capture keys
enum {
    INI_KEY = 200,
    INI_VALUE,
    INI_COMMENT,
    INI_END
};

// Context object - holds parse state
typedef struct ini_ctx {
    Type type;          // For type system
    Table *data;        // Output: key-value pairs
    Str *currentKey;    // Temporary: key we just parsed
} IniCtx;

// Pattern definitions
static PatCharDef keyDef[] = {
    {PAT_MANY, 'a', 'z'},              // Lowercase letters
    {PAT_MANY, 'A', 'Z'},              // Uppercase letters
    {PAT_MANY, '0', '9'},              // Digits
    {PAT_MANY, '_', '_'},              // Underscores
    {PAT_TERM|PAT_INVERT_CAPTURE, ' ', ' '},  // Space ends key (don't capture it)
    {PAT_END, 0, 0}
};

static PatCharDef equalsDef[] = {
    {PAT_TERM|PAT_CONSUME, '=', '='},  // Match '=' but don't capture it
    {PAT_END, 0, 0}
};

static PatCharDef valueDef[] = {
    {PAT_KO|PAT_KO_TERM, '\n', '\n'},  // Newline ends value (knockout)
    {PAT_MANY|PAT_TERM, 32, 126},      // Any printable character
    {PAT_END, 0, 0}
};

static PatCharDef commentDef[] = {
    {PAT_TERM|PAT_CONSUME, '#', '#'},  // Match '#' but don't capture
    {PAT_MANY, 32, 126},               // Consume rest of line
    {PAT_TERM, '\n', '\n'},            // Newline ends comment
    {PAT_END, 0, 0}
};

static PatCharDef newlineDef[] = {
    {PAT_TERM|PAT_CONSUME, '\n', '\n'},  // Consume newlines
    {PAT_END, 0, 0}
};

static PatCharDef whitespaceDef[] = {
    {PAT_MANY|PAT_TERM|PAT_CONSUME, ' ', ' '},  // Consume spaces
    {PAT_MANY|PAT_TERM|PAT_CONSUME, '\t', '\t'}, // Consume tabs
    {PAT_END, 0, 0}
};

// Capture function
static status Capture(Roebling *rbl, word captureKey, StrVec *v){
    IniCtx *ctx = as(rbl->source, TYPE_INI_CTX);

    if(captureKey == INI_KEY){
        // Store key temporarily
        ctx->currentKey = Str_FromVec(rbl->mem, v);

    }else if(captureKey == INI_VALUE){
        // Trim whitespace from value
        Str *value = Str_FromVec(rbl->mem, v);
        Str_Trim(value);

        // Store key-value pair
        if(ctx->currentKey){
            Table_PutStr(ctx->data, ctx->currentKey, value);
            ctx->currentKey = NULL;
        }

    }else if(captureKey == INI_COMMENT){
        // Ignore comments
    }

    return SUCCESS;
}

// State 0: Start of line (looking for key or comment)
static status state_start(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);

    Roebling_SetPattern(rbl, commentDef, INI_COMMENT, 0);    // Stay in state 0
    Roebling_SetPattern(rbl, keyDef, INI_KEY, 1);            // Jump to state 1
    Roebling_SetPattern(rbl, newlineDef, 0, 0);              // Consume blank lines
    Roebling_SetPattern(rbl, whitespaceDef, 0, 0);           // Consume leading space

    return READY;
}

// State 1: After key (looking for '=' and value)
static status state_value(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);

    Roebling_SetPattern(rbl, whitespaceDef, 0, 1);           // Consume space, stay in state 1
    Roebling_SetPattern(rbl, equalsDef, 0, 2);               // Jump to state 2 after '='

    return READY;
}

// State 2: After '=' (parsing value)
static status state_parse_value(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);

    Roebling_SetPattern(rbl, whitespaceDef, 0, 2);           // Skip leading space
    Roebling_SetPattern(rbl, valueDef, INI_VALUE, 0);        // Capture value, back to state 0

    return READY;
}

// Parse function
status ParseINI(MemCh *m, Str *input, Table *output){
    IniCtx ctx = {
        .type = TYPE_INI_CTX,
        .data = output,
        .currentKey = NULL
    };

    Cursor *curs = Cursor_Make(m, input);
    Roebling *rbl = Roebling_Make(m, curs, (RblCaptureFunc)Capture, &ctx);

    // Set up three-state machine
    Roebling_AddStep(rbl, state_start);        // State 0
    Roebling_AddStep(rbl, state_value);        // State 1
    Roebling_AddStep(rbl, state_parse_value);  // State 2
    rbl->state = 0;  // Start at state 0

    Roebling_Start(rbl);
    status result = Roebling_Run(rbl);

    return result;
}
```

### Usage Example

```c
MemCh *m = MemCh_Make();
Str *input = Str_FromS(m,
    "name = Caneka\n"
    "version = 1.0\n"
    "# This is a comment\n"
    "author = CompareBasic\n"
);

Table *data = Table_Make(m);
ParseINI(m, input, data);

// data now contains: {"name": "Caneka", "version": "1.0", "author": "CompareBasic"}
Str *name = Table_GetStr(data, Str_FromS(m, "name"));  // "Caneka"
```

### State Machine Flow

```
State 0 (start_of_line)
    ↓ [key matched]
State 1 (after_key)
    ↓ ['=' matched]
State 2 (parsing_value)
    ↓ [value matched]
State 0 (start_of_line)  ← loop continues
```

### New Concepts Explained

**1. Context Object**:
The `IniCtx` structure holds state between captures:
```c
typedef struct ini_ctx {
    Type type;          // Type system marker
    Table *data;        // Output accumulator
    Str *currentKey;    // Temporary storage for parsed key
} IniCtx;
```

**2. State Jumping**:
```c
Roebling_SetPattern(rbl, keyDef, INI_KEY, 1);  // Jump to state 1 after capture
```
The fourth parameter (1) tells Roebling to transition to state 1 after the capture function returns.

**3. Pattern Flag Combinations**:
```c
{PAT_TERM|PAT_INVERT_CAPTURE, ' ', ' '}  // Space ends pattern but isn't captured
{PAT_TERM|PAT_CONSUME, '=', '='}         // '=' ends pattern and is consumed (not passed to capture)
{PAT_KO|PAT_KO_TERM, '\n', '\n'}         // Newline fails pattern (knockout terminal)
```

**4. Multi-State Patterns**:
Each state defines different active patterns:
- **State 0** (start): Looking for key or comment
- **State 1** (after key): Looking for '=' sign
- **State 2** (after '='): Looking for value

This prevents ambiguity and enforces the `key = value` structure.

**5. Temporary Storage**:
Notice how we store `currentKey` in the context when we capture the key (state 0 → 1), then use it when we capture the value (state 2 → 0). This pattern is essential for parsers that need to remember earlier captures.

---


## Level 3: Hierarchical Parser

**Goal**: Build a config file parser that handles nested sections with indentation.

**Input**:
```
server {
    host = localhost
    port = 8080
    ssl {
        cert = /path/to/cert
        key = /path/to/key
    }
}
```

**Output**: Hierarchical NodeObj tree structure

**New Concepts**:
- Indentation tracking with stack
- Nested structures (NodeObj trees)
- Parent-child relationships
- Backtracking through hierarchy

### Complete Code

```c
#include "parser/roebling.h"
#include "navigate/mess.h"

// Capture keys
enum {
    CFG_KEY = 300,
    CFG_VALUE,
    CFG_SECTION_START,
    CFG_SECTION_END,
    CFG_WHITESPACE,
    CFG_NEWLINE,
    CFG_END
};

// Context object - tracks nesting
typedef struct cfg_ctx {
    Type type;
    NodeObj *root;          // Root of tree
    NodeObj *current;       // Current node we're adding to
    Shelf *parentStack;     // Stack of parent nodes (for nesting)
    word indentLevel;       // Current indentation level
    Str *currentKey;        // Temporary: key we just parsed
} CfgCtx;

// Pattern definitions
static PatCharDef keyDef[] = {
    {PAT_MANY, 'a', 'z'},
    {PAT_MANY, 'A', 'Z'},
    {PAT_MANY, '0', '9'},
    {PAT_MANY, '_', '_'},
    {PAT_MANY, '-', '-'},
    {PAT_TERM, 0, 255},  // Any character ends key
    {PAT_END, 0, 0}
};

static PatCharDef valueDef[] = {
    {PAT_KO|PAT_KO_TERM, '\n', '\n'},  // Newline ends value
    {PAT_MANY|PAT_TERM, 32, 126},      // Any printable
    {PAT_END, 0, 0}
};

static PatCharDef equalsDef[] = {
    {PAT_TERM|PAT_CONSUME, '=', '='},
    {PAT_END, 0, 0}
};

static PatCharDef openBraceDef[] = {
    {PAT_TERM|PAT_INVERT_CAPTURE, '{', '{'},
    {PAT_END, 0, 0}
};

static PatCharDef closeBraceDef[] = {
    {PAT_TERM|PAT_INVERT_CAPTURE, '}', '}'},
    {PAT_END, 0, 0}
};

static PatCharDef indentDef[] = {
    {PAT_MANY|PAT_CONSUME, ' ', ' '},   // Consume spaces (don't capture)
    {PAT_MANY|PAT_CONSUME, '\t', '\t'},  // Consume tabs
    {PAT_TERM, 0, 255},                  // Any character ends indent
    {PAT_END, 0, 0}
};

static PatCharDef newlineDef[] = {
    {PAT_TERM|PAT_CONSUME, '\n', '\n'},
    {PAT_END, 0, 0}
};

// Capture function
static status Capture(Roebling *rbl, word captureKey, StrVec *v){
    CfgCtx *ctx = as(rbl->source, TYPE_CFG_CTX);

    if(captureKey == CFG_KEY){
        ctx->currentKey = Str_FromVec(rbl->mem, v);
        Str_Trim(ctx->currentKey);

    }else if(captureKey == CFG_VALUE){
        Str *value = Str_FromVec(rbl->mem, v);
        Str_Trim(value);

        // Add key-value to current node
        if(ctx->currentKey && ctx->current){
            NodeObj_PutStr(ctx->current, ctx->currentKey, value);
            ctx->currentKey = NULL;
        }

    }else if(captureKey == CFG_SECTION_START){
        // Create new child section
        if(ctx->currentKey){
            NodeObj *child = NodeObj_Make(rbl->mem);
            NodeObj_PutObj(ctx->current, ctx->currentKey, child);

            // Push current to stack, descend into child
            Shelf_Push(ctx->parentStack, ctx->current);
            ctx->current = child;
            ctx->indentLevel++;

            ctx->currentKey = NULL;
        }

    }else if(captureKey == CFG_SECTION_END){
        // Pop back to parent section
        if(ctx->indentLevel > 0){
            ctx->current = as(Shelf_Pop(ctx->parentStack), TYPE_NODEOBJ);
            ctx->indentLevel--;
        }
    }

    return SUCCESS;
}

// State 0: Start of line
static status state_start(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);

    Roebling_SetPattern(rbl, indentDef, 0, 0);               // Consume indent
    Roebling_SetPattern(rbl, closeBraceDef, CFG_SECTION_END, 0);  // Close section
    Roebling_SetPattern(rbl, keyDef, CFG_KEY, 1);            // Found key
    Roebling_SetPattern(rbl, newlineDef, 0, 0);              // Blank line

    return READY;
}

// State 1: After key
static status state_after_key(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);

    Roebling_SetPattern(rbl, indentDef, 0, 1);                    // Skip space
    Roebling_SetPattern(rbl, openBraceDef, CFG_SECTION_START, 0); // Section start
    Roebling_SetPattern(rbl, equalsDef, 0, 2);                    // Value coming

    return READY;
}

// State 2: Parsing value
static status state_value(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);

    Roebling_SetPattern(rbl, indentDef, 0, 2);          // Skip space
    Roebling_SetPattern(rbl, valueDef, CFG_VALUE, 0);   // Capture value

    return READY;
}

// Parse function
status ParseConfig(MemCh *m, Str *input, NodeObj *output){
    CfgCtx ctx = {
        .type = TYPE_CFG_CTX,
        .root = output,
        .current = output,
        .parentStack = Shelf_Make(m),
        .indentLevel = 0,
        .currentKey = NULL
    };

    Cursor *curs = Cursor_Make(m, input);
    Roebling *rbl = Roebling_Make(m, curs, (RblCaptureFunc)Capture, &ctx);

    // Set up state machine
    Roebling_AddStep(rbl, state_start);       // State 0
    Roebling_AddStep(rbl, state_after_key);   // State 1
    Roebling_AddStep(rbl, state_value);       // State 2
    rbl->state = 0;

    Roebling_Start(rbl);
    status result = Roebling_Run(rbl);

    return result;
}
```

### Usage Example

```c
MemCh *m = MemCh_Make();
Str *input = Str_FromS(m,
    "server {\n"
    "    host = localhost\n"
    "    port = 8080\n"
    "    ssl {\n"
    "        cert = /path/to/cert\n"
    "        key = /path/to/key\n"
    "    }\n"
    "}\n"
);

NodeObj *config = NodeObj_Make(m);
ParseConfig(m, input, config);

// Navigate the tree
NodeObj *server = NodeObj_GetObj(config, Str_FromS(m, "server"));
Str *host = NodeObj_GetStr(server, Str_FromS(m, "host"));  // "localhost"
word port = NodeObj_GetWord(server, Str_FromS(m, "port")); // 8080

NodeObj *ssl = NodeObj_GetObj(server, Str_FromS(m, "ssl"));
Str *cert = NodeObj_GetStr(ssl, Str_FromS(m, "cert"));     // "/path/to/cert"
```

### Hierarchical Structure

The parsed tree looks like:
```
config (NodeObj)
  └─ server (NodeObj)
       ├─ host: "localhost" (Str)
       ├─ port: 8080 (word)
       └─ ssl (NodeObj)
            ├─ cert: "/path/to/cert" (Str)
            └─ key: "/path/to/key" (Str)
```

### New Concepts Explained

**1. Parent Stack**:
```c
Shelf *parentStack;  // Stack of NodeObj pointers
```
When we encounter `{`, we push the current node onto the stack and descend into a child. When we encounter `}`, we pop the stack to return to the parent.

**2. Current Node Tracking**:
```c
NodeObj *current;  // Current node we're adding properties to
```
This pointer moves through the tree as we parse:
- Start: `current = root`
- See `server {`: Push `current`, `current = server` child
- See `ssl {`: Push `current`, `current = ssl` child
- See `}`: Pop stack, `current = server` again
- See `}`: Pop stack, `current = root` again

**3. Indentation Handling**:
```c
static PatCharDef indentDef[] = {
    {PAT_MANY|PAT_CONSUME, ' ', ' '},  // Consume spaces
    {PAT_TERM, 0, 255},                // Any character ends indent
    {PAT_END, 0, 0}
};
```
We consume (but don't capture) leading whitespace. This allows arbitrary indentation without affecting the parse.

**4. Section Nesting**:
```c
if(captureKey == CFG_SECTION_START){
    NodeObj *child = NodeObj_Make(rbl->mem);
    NodeObj_PutObj(ctx->current, ctx->currentKey, child);

    Shelf_Push(ctx->parentStack, ctx->current);  // Save parent
    ctx->current = child;                         // Descend
    ctx->indentLevel++;
}
```

**5. NodeObj API**:
```c
NodeObj_PutStr(node, key, value);     // Store string property
NodeObj_PutObj(node, key, childNode); // Store child node
NodeObj_GetStr(node, key);            // Retrieve string
NodeObj_GetObj(node, key);            // Retrieve child node
```

---



---

**Part 1 of 2** | [Part 2 →](writing-parsers-part2)
