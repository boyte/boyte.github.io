# Writing Parsers: Complete Tutorial - Part 2

[← Part 1](writing-parsers-part1) | **Part 2 of 2**

---

## Level 4: Protocol Parser

**Goal**: Build an HTTP request parser that handles method, URL, headers, and body.

**Input**:
```
GET /api/users?id=123 HTTP/1.1
Host: example.com
User-Agent: Caneka/1.0
Content-Length: 0

```

**Output**: HttpCtx structure with parsed components

**New Concepts**:
- Linear state flow (not circular)
- Protocol-specific parsing phases
- Header loop state
- URL encoding/decoding
- Query parameter extraction

### Complete Code (Simplified)

```c
#include "parser/roebling.h"
#include "http/http_ctx.h"

// Capture keys
enum {
    HTTP_METHOD = 400,
    HTTP_URL,
    HTTP_PROTOCOL,
    HTTP_HEADER_KEY,
    HTTP_HEADER_VALUE,
    HTTP_BODY,
    HTTP_END
};

// Context object
typedef struct http_ctx {
    Type type;
    HttpCtx *http;          // Output structure
    Str *currentHeader;     // Temporary: header name we just parsed
} HttpParseCtx;

// Pattern definitions
static PatCharDef methodDef[] = {
    {PAT_MANY, 'A', 'Z'},                    // HTTP methods are uppercase
    {PAT_TERM|PAT_INVERT_CAPTURE, ' ', ' '}, // Space ends method
    {PAT_END, 0, 0}
};

static PatCharDef urlDef[] = {
    {PAT_KO|PAT_KO_TERM, ' ', ' '},          // Space ends URL
    {PAT_MANY|PAT_TERM, 33, 126},            // Printable characters
    {PAT_END, 0, 0}
};

static PatCharDef protocolDef[] = {
    {PAT_KO|PAT_KO_TERM, '\r', '\r'},        // CR ends protocol
    {PAT_MANY|PAT_TERM, 33, 126},
    {PAT_END, 0, 0}
};

static PatCharDef headerKeyDef[] = {
    {PAT_MANY, 'a', 'z'},
    {PAT_MANY, 'A', 'Z'},
    {PAT_MANY, '-', '-'},
    {PAT_TERM|PAT_INVERT_CAPTURE, ':', ':'},  // Colon ends key
    {PAT_END, 0, 0}
};

static PatCharDef headerValueDef[] = {
    {PAT_KO|PAT_KO_TERM, '\r', '\r'},         // CR ends value
    {PAT_MANY|PAT_TERM, 32, 126},
    {PAT_END, 0, 0}
};

static PatCharDef crlfDef[] = {
    {PAT_TERM|PAT_CONSUME, '\r', '\r'},
    {PAT_TERM|PAT_CONSUME, '\n', '\n'},
    {PAT_END, 0, 0}
};

static PatCharDef blankLineDef[] = {
    {PAT_TERM|PAT_CONSUME, '\r', '\r'},
    {PAT_TERM|PAT_CONSUME, '\n', '\n'},
    {PAT_TERM|PAT_CONSUME, '\r', '\r'},
    {PAT_TERM|PAT_CONSUME, '\n', '\n'},
    {PAT_END, 0, 0}
};

static PatCharDef bodyDef[] = {
    {PAT_MANY|PAT_TERM, 0, 255},  // Match everything remaining
    {PAT_END, 0, 0}
};

// Capture function
static status Capture(Roebling *rbl, word captureKey, StrVec *v){
    HttpParseCtx *ctx = as(rbl->source, TYPE_HTTP_PARSE_CTX);
    HttpCtx *http = ctx->http;

    if(captureKey == HTTP_METHOD){
        Str *method = Str_FromVec(rbl->mem, v);
        http->method = HttpMethod_FromStr(method);  // Convert to enum

    }else if(captureKey == HTTP_URL){
        http->url = Str_FromVec(rbl->mem, v);
        HttpCtx_ParseURL(http);  // Extract path and query params

    }else if(captureKey == HTTP_PROTOCOL){
        http->protocol = Str_FromVec(rbl->mem, v);

    }else if(captureKey == HTTP_HEADER_KEY){
        ctx->currentHeader = Str_FromVec(rbl->mem, v);

    }else if(captureKey == HTTP_HEADER_VALUE){
        Str *value = Str_FromVec(rbl->mem, v);
        Str_Trim(value);

        if(ctx->currentHeader){
            Table_PutStr(http->headers, ctx->currentHeader, value);
            ctx->currentHeader = NULL;
        }

    }else if(captureKey == HTTP_BODY){
        http->body = Str_FromVec(rbl->mem, v);
    }

    return SUCCESS;
}

// State 0: Parse request line (method)
static status state_method(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);
    Roebling_SetPattern(rbl, methodDef, HTTP_METHOD, 1);  // → state 1
    return READY;
}

// State 1: Parse URL
static status state_url(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);
    Roebling_SetPattern(rbl, urlDef, HTTP_URL, 2);  // → state 2
    return READY;
}

// State 2: Parse protocol version
static status state_protocol(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);
    Roebling_SetPattern(rbl, protocolDef, HTTP_PROTOCOL, 3);  // → state 3
    Roebling_SetPattern(rbl, crlfDef, 0, 3);  // Consume CRLF, → state 3
    return READY;
}

// State 3: Parse headers (loop state)
static status state_headers(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);
    Roebling_SetPattern(rbl, blankLineDef, 0, 4);  // Blank line → body (state 4)
    Roebling_SetPattern(rbl, headerKeyDef, HTTP_HEADER_KEY, 5);  // → state 5
    return READY;
}

// State 4: Parse body
static status state_body(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);
    Roebling_SetPattern(rbl, bodyDef, HTTP_BODY, -1);  // -1 = end parsing
    return READY;
}

// State 5: Parse header value
static status state_header_value(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);
    Roebling_SetPattern(rbl, headerValueDef, HTTP_HEADER_VALUE, 6);  // → state 6
    return READY;
}

// State 6: After header value (consume CRLF, loop back to state 3)
static status state_after_header(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);
    Roebling_SetPattern(rbl, crlfDef, 0, 3);  // Consume CRLF, → state 3 (loop)
    return READY;
}

// Parse function
status ParseHTTPRequest(MemCh *m, Str *input, HttpCtx *output){
    HttpParseCtx ctx = {
        .type = TYPE_HTTP_PARSE_CTX,
        .http = output,
        .currentHeader = NULL
    };

    Cursor *curs = Cursor_Make(m, input);
    Roebling *rbl = Roebling_Make(m, curs, (RblCaptureFunc)Capture, &ctx);

    // Set up linear state machine with header loop
    Roebling_AddStep(rbl, state_method);         // State 0
    Roebling_AddStep(rbl, state_url);            // State 1
    Roebling_AddStep(rbl, state_protocol);       // State 2
    Roebling_AddStep(rbl, state_headers);        // State 3 (loop point)
    Roebling_AddStep(rbl, state_body);           // State 4
    Roebling_AddStep(rbl, state_header_value);   // State 5
    Roebling_AddStep(rbl, state_after_header);   // State 6 (loops to 3)
    rbl->state = 0;

    Roebling_Start(rbl);
    status result = Roebling_Run(rbl);

    return result;
}
```

### Usage Example

```c
MemCh *m = MemCh_Make();
Str *request = Str_FromS(m,
    "GET /api/users?id=123 HTTP/1.1\r\n"
    "Host: example.com\r\n"
    "User-Agent: Caneka/1.0\r\n"
    "\r\n"
);

HttpCtx *http = HttpCtx_Make(m);
ParseHTTPRequest(m, request, http);

// Access parsed data
http->method;  // HTTP_GET (enum)
http->url;     // "/api/users?id=123"
http->path;    // "/api/users"

Str *host = Table_GetStr(http->headers, Str_FromS(m, "Host"));  // "example.com"
Str *ua = Table_GetStr(http->headers, Str_FromS(m, "User-Agent"));  // "Caneka/1.0"

// Query parameters
Str *id = Table_GetStr(http->queryParams, Str_FromS(m, "id"));  // "123"
```

### State Machine Flow

```
State 0 (method)     → "GET " → State 1
State 1 (url)        → "/api/users?id=123 " → State 2
State 2 (protocol)   → "HTTP/1.1\r\n" → State 3
State 3 (headers)    → "Host:" → State 5
State 5 (header_val) → " example.com" → State 6
State 6 (after_hdr)  → "\r\n" → State 3  ← LOOP
State 3 (headers)    → "User-Agent:" → State 5
State 5 (header_val) → " Caneka/1.0" → State 6
State 6 (after_hdr)  → "\r\n" → State 3  ← LOOP
State 3 (headers)    → "\r\n\r\n" (blank line) → State 4
State 4 (body)       → (end of input) → DONE
```

### New Concepts Explained

**1. Linear State Flow**:
Unlike previous examples, this parser follows a **linear progression** through protocol phases:
1. Method (GET/POST/etc)
2. URL
3. Protocol version
4. Headers (loop)
5. Body

Each state advances to the next, except for the header loop.

**2. Loop State Pattern**:
```c
// State 3 (headers) can jump to:
// - State 4 (body) if blank line
// - State 5 (header value) if we found a header key

// State 6 (after header) jumps back to:
// - State 3 (headers) to parse next header
```
This creates a loop for parsing multiple headers without knowing the count in advance.

**3. End-of-Parse Signal**:
```c
Roebling_SetPattern(rbl, bodyDef, HTTP_BODY, -1);  // -1 = stop parsing
```
Jump state `-1` tells Roebling to stop after this capture. This is how we terminate the parse.

**4. Protocol-Specific Patterns**:
```c
// CRLF (Carriage Return + Line Feed)
static PatCharDef crlfDef[] = {
    {PAT_TERM|PAT_CONSUME, '\r', '\r'},
    {PAT_TERM|PAT_CONSUME, '\n', '\n'},
    {PAT_END, 0, 0}
};

// Blank line (signals end of headers)
static PatCharDef blankLineDef[] = {
    {PAT_TERM|PAT_CONSUME, '\r', '\r'},
    {PAT_TERM|PAT_CONSUME, '\n', '\n'},
    {PAT_TERM|PAT_CONSUME, '\r', '\r'},
    {PAT_TERM|PAT_CONSUME, '\n', '\n'},
    {PAT_END, 0, 0}
};
```
HTTP uses `\r\n` as line separator. Double `\r\n\r\n` signals end of headers.

**5. Multi-Phase Parsing**:
```c
if(captureKey == HTTP_URL){
    http->url = Str_FromVec(rbl->mem, v);
    HttpCtx_ParseURL(http);  // Secondary parse of URL → path + query
}
```
After capturing the URL, we invoke a secondary parser to extract path and query parameters. This demonstrates **layered parsing** - first parse the protocol structure, then parse specific fields.

---


## Pattern Definition Reference

### Pattern Flags

| Flag | Description | Example Use Case |
|------|-------------|------------------|
| `PAT_TERM` | Terminal - triggers capture when matched | End of word, delimiter |
| `PAT_MANY` | Match 0 or more times | Repeated characters, whitespace |
| `PAT_KO` | Knockout - fail pattern if matched | "Match everything except..." |
| `PAT_KO_TERM` | Knockout terminal - end pattern if matched | Delimiter that shouldn't be captured |
| `PAT_CONSUME` | Match but don't capture | Skip whitespace, consume punctuation |
| `PAT_INVERT_CAPTURE` | Match as terminal but don't include in capture | Delimiter at end of token |

### Flag Combinations

| Combination | Behavior | Example |
|-------------|----------|---------|
| `PAT_TERM` | Match one, capture, trigger | `{PAT_TERM, '&', '&'}` - exact match |
| `PAT_MANY\|PAT_TERM` | Match many, capture all, trigger | `{PAT_MANY\|PAT_TERM, ' ', ' '}` - whitespace |
| `PAT_TERM\|PAT_CONSUME` | Match one, trigger, don't capture | `{PAT_TERM\|PAT_CONSUME, '=', '='}` - skip '=' |
| `PAT_TERM\|PAT_INVERT_CAPTURE` | Match one, trigger, don't capture match | `{PAT_TERM\|PAT_INVERT_CAPTURE, '\n', '\n'}` - newline delimiter |
| `PAT_KO\|PAT_KO_TERM` | Fail pattern if matched | `{PAT_KO\|PAT_KO_TERM, '\n', '\n'}` - stop at newline |
| `PAT_MANY\|PAT_CONSUME` | Match many, don't capture | `{PAT_MANY\|PAT_CONSUME, ' ', ' '}` - skip leading space |

### Common Pattern Idioms

**Match Word Tokens**:
```c
static PatCharDef wordDef[] = {
    {PAT_MANY, 'a', 'z'},
    {PAT_MANY, 'A', 'Z'},
    {PAT_MANY, '0', '9'},
    {PAT_TERM, 0, 255},  // Any character ends word
    {PAT_END, 0, 0}
};
```

**Skip Whitespace**:
```c
static PatCharDef skipSpaceDef[] = {
    {PAT_MANY|PAT_TERM|PAT_CONSUME, ' ', ' '},
    {PAT_MANY|PAT_TERM|PAT_CONSUME, '\t', '\t'},
    {PAT_END, 0, 0}
};
```

**Match Until Delimiter**:
```c
static PatCharDef untilNewlineDef[] = {
    {PAT_KO|PAT_KO_TERM, '\n', '\n'},  // Stop at newline
    {PAT_MANY|PAT_TERM, 32, 255},      // Match any printable
    {PAT_END, 0, 0}
};
```

**Match Exact String** (for keywords):
```c
// For "function" keyword
static PatCharDef functionDef[] = {
    {PAT_TERM, 'f', 'f'},
    {PAT_TERM, 'u', 'u'},
    {PAT_TERM, 'n', 'n'},
    {PAT_TERM, 'c', 'c'},
    {PAT_TERM, 't', 't'},
    {PAT_TERM, 'i', 'i'},
    {PAT_TERM, 'o', 'o'},
    {PAT_TERM, 'n', 'n'},
    {PAT_END, 0, 0}
};
```

**Match Fallback** (everything else):
```c
static PatCharDef fallbackDef[] = {
    // Knockout all specific patterns first
    {PAT_KO, '{', '{'},
    {PAT_KO, '}', '}'},
    {PAT_KO, '=', '='},
    // Then match anything
    {PAT_MANY|PAT_TERM, 32, 255},
    {PAT_END, 0, 0}
};
```

---


## Error Handling

### Pattern Errors

**Problem**: Pattern never becomes terminal.

**Symptom**: Parser hangs or returns `FAIL`.

**Solution**: Ensure at least one pattern in each state has `PAT_TERM` flag.

```c
// BAD - no terminal
static PatCharDef badDef[] = {
    {PAT_MANY, 'a', 'z'},  // Never terminates!
    {PAT_END, 0, 0}
};

// GOOD - terminal on space
static PatCharDef goodDef[] = {
    {PAT_MANY, 'a', 'z'},
    {PAT_TERM|PAT_INVERT_CAPTURE, ' ', ' '},  // Terminates
    {PAT_END, 0, 0}
};
```

### State Transition Errors

**Problem**: State jump target doesn't exist.

**Symptom**: Crash or unexpected behavior.

**Solution**: Ensure all jump states are valid indices into the steps array.

```c
// BAD - only 3 states (0, 1, 2) but jumping to 5
Roebling_AddStep(rbl, state_0);
Roebling_AddStep(rbl, state_1);
Roebling_AddStep(rbl, state_2);
Roebling_SetPattern(rbl, someDef, KEY, 5);  // ERROR! State 5 doesn't exist

// GOOD
Roebling_AddStep(rbl, state_0);
Roebling_AddStep(rbl, state_1);
Roebling_AddStep(rbl, state_2);
Roebling_SetPattern(rbl, someDef, KEY, 1);  // OK - state 1 exists
```

### Capture Function Errors

**Problem**: Wrong type cast in capture function.

**Symptom**: Segfault or corrupted data.

**Solution**: Use type system and `as()` macro for safe casting.

```c
// BAD - unsafe cast
MyCtx *ctx = (MyCtx*)rbl->source;  // May crash if wrong type

// GOOD - type-checked cast
MyCtx *ctx = as(rbl->source, TYPE_MY_CTX);  // Safe, returns NULL if wrong type
if(!ctx) return FAIL;
```

### Memory Errors

**Problem**: Forgetting to use MemCh for allocations.

**Symptom**: Memory leaks.

**Solution**: Always allocate from the MemCh passed to state functions.

```c
static status state_start(MemCh *m, Roebling *rbl){
    // BAD - heap allocation, will leak
    MyData *data = malloc(sizeof(MyData));

    // GOOD - MemCh allocation, automatically freed when chapter closes
    MyData *data = MemCh_Alloc(m, sizeof(MyData));

    return READY;
}
```

### Guard Loop Protection

Roebling uses the Guard mechanism to prevent infinite loops:

```c
Roebling_Run(rbl);  // Has internal Guard_Incr() calls
```

If your parser enters an infinite loop (e.g., state transitions with no input consumption), the Guard will trigger and return `FAIL` after ~10,000 iterations.

**How to Debug**:
1. Add debug prints in state functions to see transition loop
2. Ensure every state consumes at least one character eventually
3. Check that PAT_CONSUME patterns actually match input

---


## Best Practices

### 1. Order Patterns by Specificity

**Why**: Roebling evaluates all patterns concurrently. More specific patterns should be registered first to win conflicts.

```c
// GOOD - specific before general
Roebling_SetPattern(rbl, keywordDef, KEYWORD, 0);    // Specific: "function"
Roebling_SetPattern(rbl, identifierDef, IDENT, 0);   // General: any word

// BAD - general before specific
Roebling_SetPattern(rbl, identifierDef, IDENT, 0);   // Will match "function" as IDENT!
Roebling_SetPattern(rbl, keywordDef, KEYWORD, 0);    // Never matches
```

### 2. Use Context Objects for State

**Why**: Capture functions need to share state across calls.

```c
// Structure to hold parse state
typedef struct {
    Type type;
    Table *output;
    Str *currentKey;
    word nestingLevel;
} ParseCtx;

// Pass to Roebling
ParseCtx ctx = {...};
Roebling *rbl = Roebling_Make(m, curs, Capture, &ctx);
```

### 3. Reset Patterns in Every State Function

**Why**: Prevents pattern bleed-over from previous state.

```c
static status state_start(MemCh *m, Roebling *rbl){
    Roebling_ResetPatterns(rbl);  // ALWAYS do this first
    Roebling_SetPattern(rbl, ...);
    return READY;
}
```

### 4. Use PAT_CONSUME for Delimiters You Don't Need

**Why**: Keeps captured text clean and reduces processing.

```c
// Without PAT_CONSUME - captured text includes '='
{PAT_TERM, '=', '='}  // Captured: "key="

// With PAT_CONSUME - captured text is clean
{PAT_TERM|PAT_CONSUME, '=', '='}  // Captured: "key"
```

### 5. Always Check Return Status

**Why**: Parse errors need to propagate.

```c
status result = Roebling_Run(rbl);
if(result != SUCCESS){
    // Handle error
    Error(rbl->mem, "Parse failed at position %d", Cursor_Pos(rbl->cursor));
    return result;
}
```

### 6. Use Str_Trim on Captured Values

**Why**: Whitespace often bleeds into captures.

```c
static status Capture(Roebling *rbl, word captureKey, StrVec *v){
    Str *value = Str_FromVec(rbl->mem, v);
    Str_Trim(value);  // Remove leading/trailing whitespace
    // Now use cleaned value
}
```

### 7. Design State Transitions on Paper First

**Why**: Complex state machines are hard to debug. Plan before coding.

```
[Diagram your state flow]

State 0 --[key]--> State 1
State 1 --['=']--> State 2
State 2 --[value]--> State 0  (loop)
```

### 8. Use Enums for Capture Keys

**Why**: Magic numbers are hard to debug.

```c
// BAD
Roebling_SetPattern(rbl, keyDef, 42, 0);

// GOOD
enum { KEY_CAPTURE = 42 };
Roebling_SetPattern(rbl, keyDef, KEY_CAPTURE, 0);
```

### 9. Start Simple, Add Complexity Incrementally

**Why**: Easier to debug small working pieces than a complex broken parser.

**Process**:
1. Write single-state parser for basic syntax
2. Add second state for one feature
3. Test thoroughly
4. Add third state, test, repeat

### 10. Study Existing Caneka Parsers

**Why**: Production-tested patterns and idioms.

**Recommended Reading Order**:
1. [src/ext/format/html/html_escape_roebling.c](../../src/ext/format/html/html_escape_roebling.c) - Simplest
2. [src/ext/format/config/config_roebling.c](../../src/ext/format/config/config_roebling.c) - Hierarchical
3. [src/inter/http/http_roebling.c](../../src/inter/http/http_roebling.c) - Protocol
4. [src/inter/templ/templ_roebling.c](../../src/inter/templ/templ_roebling.c) - Full DSL

---


## Common Pitfalls

### 1. Forgetting PAT_END Marker

**Problem**: Pattern array not properly terminated.

**Symptom**: Segfault or reading garbage memory.

```c
// BAD - no PAT_END
static PatCharDef badDef[] = {
    {PAT_TERM, 'a', 'z'}
    // Missing {PAT_END, 0, 0}
};

// GOOD
static PatCharDef goodDef[] = {
    {PAT_TERM, 'a', 'z'},
    {PAT_END, 0, 0}  // Must be present
};
```

### 2. Infinite State Loop

**Problem**: State transitions that don't consume input.

**Symptom**: Guard triggers, parse fails.

```c
// BAD - State 1 → State 2 → State 1 without consuming anything
static status state_1(MemCh *m, Roebling *rbl){
    Roebling_SetPattern(rbl, emptyDef, KEY, 2);  // Matches nothing, jumps to 2
}
static status state_2(MemCh *m, Roebling *rbl){
    Roebling_SetPattern(rbl, emptyDef, KEY, 1);  // Matches nothing, jumps to 1
}
```

**Fix**: Ensure state transitions consume at least one character or use capture-dependent logic to break the loop.

### 3. Capture Key Conflicts

**Problem**: Reusing same capture key for different patterns.

**Symptom**: Capture function can't distinguish patterns.

```c
// BAD - both use same key
Roebling_SetPattern(rbl, keyDef, 100, 0);
Roebling_SetPattern(rbl, valueDef, 100, 0);  // Same key!

// GOOD - unique keys
enum { KEY_CAPTURE = 100, VALUE_CAPTURE = 101 };
Roebling_SetPattern(rbl, keyDef, KEY_CAPTURE, 0);
Roebling_SetPattern(rbl, valueDef, VALUE_CAPTURE, 0);
```

### 4. Not Handling EOF

**Problem**: Parser expects more input but reaches end of file.

**Symptom**: Incomplete parse or missing final captures.

**Solution**: Use PAT_MANY to make final patterns optional.

```c
// Handles EOF gracefully
static PatCharDef finalDef[] = {
    {PAT_KO|PAT_KO_TERM, '\n', '\n'},
    {PAT_MANY|PAT_TERM, 32, 255},  // PAT_MANY allows 0 matches (EOF)
    {PAT_END, 0, 0}
};
```

### 5. Type Mismatches in Context

**Problem**: Context object doesn't have Type marker or wrong type.

**Symptom**: `as()` macro returns NULL, crash in capture function.

```c
// BAD - missing Type field
typedef struct {
    Table *data;  // No Type field!
} BadCtx;

// GOOD - includes Type for runtime checking
typedef struct {
    Type type;      // Must be first field
    Table *data;
} GoodCtx;
```

Always initialize:
```c
GoodCtx ctx = {
    .type = TYPE_GOOD_CTX,
    .data = Table_Make(m)
};
```

---


## Testing Your Parser

### Unit Test Pattern

```c
status test_my_parser(MemCh *m){
    // Arrange - create input
    Str *input = Str_FromS(m, "key = value\n");
    Table *output = Table_Make(m);

    // Act - run parser
    status result = ParseMyFormat(m, input, output);

    // Assert - check results
    Test_Assert(result == SUCCESS, "Parse should succeed");

    Str *value = Table_GetStr(output, Str_FromS(m, "key"));
    Test_Assert(value != NULL, "Key should exist");
    Test_AssertStrEq(value, Str_FromS(m, "value"), "Value should match");

    return SUCCESS;
}
```

### Edge Cases to Test

1. **Empty input**: `""`
2. **Whitespace only**: `"   \n\t  "`
3. **Single token**: `"word"`
4. **Malformed input**: `"key = = value"` (double equals)
5. **Missing delimiters**: `"key value"` (no '=')
6. **Extra delimiters**: `"key = value = extra"`
7. **Unicode/special characters**: `"key = café"`
8. **Very long input**: Stress test with 10MB file
9. **Deeply nested structures**: Config with 20 levels of nesting
10. **EOF mid-token**: `"key = val"` (no trailing newline)

### Test Harness Example

```c
void RunParserTests(void){
    MemBook *book = MemBook_Make("Parser Tests");
    MemCh *m = MemBook_NextCh(book);

    status result = SUCCESS;

    result &= test_empty_input(m);
    result &= test_single_key_value(m);
    result &= test_multiple_pairs(m);
    result &= test_nested_sections(m);
    result &= test_malformed_input(m);
    result &= test_whitespace_handling(m);

    if(result == SUCCESS){
        printf("✓ All parser tests passed\n");
    }else{
        printf("✗ Some parser tests failed\n");
    }

    MemBook_Close(book);
}
```

### Performance Testing

```c
void BenchmarkParser(void){
    MemBook *book = MemBook_Make("Benchmark");
    MemCh *m = MemBook_NextCh(book);

    // Create large input (1MB config file)
    StrVec *input = StrVec_Make(m);
    for(word i = 0; i < 10000; i++){
        StrVec_AddS(input, "key");
        StrVec_AddWord(input, i);
        StrVec_AddS(input, " = value");
        StrVec_AddWord(input, i);
        StrVec_AddChar(input, '\n');
    }

    Str *inputStr = StrVec_Compact(input);
    Table *output = Table_Make(m);

    // Benchmark
    clock_t start = clock();
    status result = ParseMyFormat(m, inputStr, output);
    clock_t end = clock();

    double seconds = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Parsed %ld bytes in %.3f seconds (%.2f MB/s)\n",
           Str_Len(inputStr),
           seconds,
           (Str_Len(inputStr) / 1024.0 / 1024.0) / seconds);

    MemBook_Close(book);
}
```

---


## Next Steps

### Further Reading

1. **[Roebling Parser Overview](../core-concepts/parser/overview.md)** - Conceptual foundation
2. **[Creating DSLs](../core-concepts/parser/creating-dsls.md)** - Advanced DSL patterns
3. **[Pattern Matching](../core-concepts/parser/pattern-matching.md)** - Deep dive on pattern system

### Real-World Examples

Study these production parsers in Caneka's source:

1. **HTML Escape** - [src/ext/format/html/html_escape_roebling.c](../../src/ext/format/html/html_escape_roebling.c)
   - Single-state character replacement
   - Simplest real-world example

2. **Config Parser** - [src/ext/format/config/config_roebling.c](../../src/ext/format/config/config_roebling.c)
   - Hierarchical structure with nesting
   - Indentation handling
   - NodeObj tree building

3. **JSON Parser** - [src/ext/format/json/json_roebling.c](../../src/ext/format/json/json_roebling.c)
   - Type-aware parsing (numbers, strings, booleans, null)
   - Nested objects and arrays
   - String escape handling

4. **HTTP Parser** - [src/inter/http/http_roebling.c](../../src/inter/http/http_roebling.c)
   - Protocol-level parsing
   - Multi-line header continuation
   - URL encoding/decoding
   - Query parameter extraction

5. **Templ Parser** - [src/inter/templ/templ_roebling.c](../../src/inter/templ/templ_roebling.c)
   - Full DSL with variables, conditionals, loops
   - AST construction during parsing
   - Most complex example

### Exercise: Build Your Own Parser

**Challenge**: Create a parser for a simple markup language:

```
# Heading
Regular paragraph text.


## Subheading
- List item 1
- List item 2

[link text](url)
```

**Requirements**:
- Parse headings (# and ##)
- Parse paragraphs (text until blank line)
- Parse lists (lines starting with -)
- Parse links ([text](url) syntax)
- Build a Mess tree structure representing the document

**Hints**:
- Use 4-5 states (heading, paragraph, list, link, start)
- Pattern for heading: `{PAT_MANY, '#', '#'}` followed by `{PAT_MANY|PAT_TERM, 'a', 'z'}`
- Use Mess_AddChild to build tree structure
- Test with real markdown-style documents

---


## Summary

You've learned how to build parsers with Roebling from simple character replacement to complex protocol parsing. The key principles:

1. **Pattern definitions** (PatCharDef arrays) describe what to match
2. **State functions** activate patterns and control flow
3. **Capture functions** process matched text and build output structures
4. **State transitions** guide the parse through phases
5. **Flags** (PAT_TERM, PAT_MANY, PAT_KO, PAT_CONSUME) control pattern behavior

**Progressive Complexity**:
- **Level 1**: Single-state (HTML escaping)
- **Level 2**: Two-state with transitions (INI files)
- **Level 3**: Hierarchical with stack (Config files)
- **Level 4**: Protocol with loops (HTTP requests)

With these foundations, you can build parsers for any custom file format, DSL, or protocol. Start simple, test thoroughly, and add complexity incrementally.

Happy parsing!



---

[← Part 1](writing-parsers-part1) | **Part 2 of 2**
