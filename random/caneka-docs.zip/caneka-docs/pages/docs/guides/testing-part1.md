# Testing: Complete Guide - Part 1

**Part 1 of 2** | [Part 2 →](testing-part2)

---

## Introduction

This guide teaches you how to write, run, and debug tests in Caneka's comprehensive test framework. Unlike typical C testing frameworks that require external dependencies and manual test registration, Caneka provides an **integrated testing system** with automatic memory leak detection, colorized output, and hierarchical test organization built directly into the runtime.

**What You'll Learn**:
- Running the test suite
- Test framework architecture
- Writing unit tests and integration tests
- Memory leak detection and stress testing
- Test assertions and reporting
- Debugging failed tests
- Best practices and common patterns

**Philosophy**: Caneka treats testing as a first-class component of the runtime. Tests are not an afterthought—they use the same memory management, type system, and I/O primitives as your production code. This means tests are **fast**, **isolated**, and **automatically check for memory leaks**.

**Why This Matters**: You can write comprehensive tests with minimal boilerplate, get immediate feedback on memory safety, and trust that passing tests mean your code won't leak memory in production.

---


## Quick Start

### Running All Tests

```bash
# Build the test program
./build.sh

# Run all test suites
./dist/bin/tests

# Run with output to file
./dist/bin/tests --dist

# Run without colors (for logs)
./dist/bin/tests --no-color
```

### Expected Output

```
= Test Suite: Caneka base

Starting Mem at 4.0 KiB total/maxIdx=1/128. page-size=4096b

== Basic Features
=== Testing: Core

- PASS Test that a test can run
- PASS Test that the STR_MAX is less than a MemPage with 5 expansions span slabs

== Memory Management
=== Testing: MemCh

- PASS MemBook chapters match the start level
- PASS Memory hierarchy works correctly

...

Suite Caneka base pass(32) fail(0)
```

### Interpreting Results

- **Green PASS** - Test assertion succeeded ✓
- **Red FAIL** - Test assertion failed ✗
- **Yellow SKIP** - Test was skipped
- **Cyan SECTION** - Organizational header

**Success**: All suites show `fail(0)`
**Failure**: Any suite shows `fail(N)` where N > 0

---


## Test Framework Architecture

### Component Overview

Caneka's test framework consists of:

**1. Test Runner** (`testsuite.c`)
- Executes tests in isolation
- Tracks memory before/after each test
- Detects leaks automatically
- Reports pass/fail counts

**2. Test Suites** (header files)
- BASE - Core functionality (memory, strings, collections)
- EXT - Extended features (parsing, objects, formatting)
- INTER - Integration tests (HTTP, templating, routing)
- CRYPTO - Cryptographic functions (optional)

**3. Test Files** (`option/base/`, `option/ext/`, `option/inter/`)
- Individual component tests
- Organized by layer and component
- Compiled conditionally based on build options

**4. Test Framework** (`testsuite.h`)
- Core macros: `Test()`, `TestShow()`
- Memory utilities
- Debug stack for crash tracking

### Directory Structure

```
src/programs/test/
├── main.c                         # Entry point
├── testsuite.c                    # Test runner implementation
├── include/
│   ├── testsuite.h               # Framework definitions
│   ├── base_tests.h              # Base suite declarations
│   ├── ext_tests.h               # Extended suite declarations
│   ├── inter_tests.h             # Integration suite declarations
│   └── test_module.h             # Conditional includes
└── option/
    ├── base/                      # Base component tests
    │   ├── core_tests.c
    │   ├── memch_tests.c
    │   ├── span_tests.c
    │   ├── str_tests.c
    │   ├── table_tests.c
    │   └── ... (32 test files)
    ├── ext/                       # Extended component tests
    │   ├── binseg_tests.c
    │   ├── config_tests.c
    │   ├── roebling_tests.c
    │   ├── object_tests.c
    │   └── ... (14 test files)
    ├── inter/                     # Integration tests
    │   ├── http_tests.c
    │   ├── templ_tests.c
    │   ├── route_tests.c
    │   └── ... (10 test files)
    └── crypto/                    # Cryptographic tests
        └── crypto_tests.c
```

---


## Writing Your First Test

### Minimal Example

**File**: `src/programs/test/option/base/example_tests.c`

```c
#include <external.h>
#include <caneka.h>
#include <test_module.h>

status Example_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // Simple assertion
    r |= Test(TRUE, "Test that TRUE is true", NULL);

    // Assertion with variables
    i32 value = 42;
    void *args[] = {
        I32_Wrapped(m, value),
        NULL
    };
    r |= Test(value == 42, "Value should be $", args);

    DebugStack_Pop();
    return r;
}
```

**Key Components**:

1. **Function Signature**: `status FunctionName_Tests(MemCh *m)`
   - Returns `SUCCESS` if all tests pass, `ERROR` if any fail
   - Receives isolated `MemCh` for memory management

2. **DebugStack**: `DebugStack_Push(NULL, 0)` / `DebugStack_Pop()`
   - Tracks execution for crash debugging
   - Always pair push/pop

3. **Status Accumulation**: `r |= Test(...)`
   - Accumulates pass/fail state
   - `|=` ensures any failure marks entire test as failed

4. **Test Macro**: `Test(condition, format, args)`
   - First argument: boolean expression
   - Second argument: message format string
   - Third argument: NULL-terminated array of arguments (or NULL)

### Registering the Test

**File**: `src/programs/test/include/base_tests.h`

```c
// Add declaration
status Example_Tests(MemCh *m);

// Add to TestSet array
static TestSet BaseTests[] = {
    // ... existing tests ...

    {
        "Example",              // Display name
        Example_Tests,          // Function pointer
        "Testing examples",     // Description
        FEATURE_COMPLETE,       // Status flag
    },

    // Terminator (required!)
    {
        NULL,
        NULL,
        NULL,
        0,
    }
};
```

**Status Flags**:
- `SECTION_LABEL` - Organizational header (not a test)
- `SKIP_TEST` - Skip this test
- `NOT_STARTED` - Implementation not begun
- `PREVIOUSLY_WORKING` - Known to work before
- `PARTIAL_FEATURE` - Incomplete implementation
- `FEATURE_COMPLETE` - **Most common** - full implementation
- `PRE_PRODUCTION` - Almost ready
- `PRODUCTION` - Production quality

### Building and Running

```bash
# Rebuild with your new test
./build.sh

# Run tests
./dist/bin/tests

# Expected output:
# === Testing: Example
#
# Testing examples
#
# - PASS Test that TRUE is true
# - PASS Value should be 42
```

---


## Test Assertions

### Test() - Standard Assertion

**Signature**:
```c
status Test(boolean condition, char *fmt, void *args[]);
```

**Usage**:
```c
// Simple boolean test
r |= Test(1 + 1 == 2, "Math works", NULL);

// With formatted output
Str *name = Str_FromS(m, "Alice");
void *args[] = {
    name,
    I32_Wrapped(m, name->length),
    NULL
};
r |= Test(name->length == 5, "Name $ has length $", args);
```

**Output**:
```
- PASS Math works
- PASS Name Alice has length 5
```

### TestShow() - Success/Error Messages

**Signature**:
```c
status TestShow(boolean condition, char *fmtSuccess, char *fmtError, void *args[]);
```

**Usage**:
```c
i32 result = calculate();
i32 expected = 42;

void *args[] = {
    I32_Wrapped(m, expected),
    I32_Wrapped(m, result),
    NULL
};

r |= TestShow(
    result == expected,
    "Calculation correct: $",            // Success message
    "Expected $ but got $",               // Error message
    args
);
```

**Output (Success)**:
```
- PASS Calculation correct: 42
```

**Output (Failure)**:
```
- FAIL Expected 42 but got 17
```

### Format Strings

**Special Codes** (used in `Fmt()`):

| Code | Meaning | Example |
|------|---------|---------|
| `$` | Insert next argument | `"Value is $"` |
| `@` | Display object | `"Object: @"` |
| `^r` | Red color (errors) | `"^r.ERROR^0"` |
| `^g` | Green color (success) | `"^g.PASS^0"` |
| `^y` | Yellow color (warnings) | `"^y.SKIP^0"` |
| `^c` | Cyan color (info) | `"^c.INFO^0"` |
| `^0` | Reset color | End of colored text |
| `^D`/`^d` | Number formatting | Different display |

**Argument Wrapping**:

```c
// Primitive types need wrapping
void *args[] = {
    I32_Wrapped(m, 42),         // i32 → Single
    I64_Wrapped(m, 1000000),    // i64 → Single
    Str_FromS(m, "text"),       // Already a pointer
    NULL                         // Terminator
};
r |= Test(condition, "Int: $, Long: $, Text: $", args);
```

---


## Memory Testing

### Automatic Leak Detection

**How It Works**:

Every test runs in an isolated `MemCh` context. The test runner:

1. **Records baseline** memory before test
2. **Runs test** in isolated MemCh
3. **Checks ceiling** (stress test limit)
4. **Frees test memory**
5. **Verifies return to baseline** (leak detection)

**Example from Test Runner**:

```c
// Get baseline memory
MemBookStats st;
MemBook_GetStats(m, &st);
i32 baseMem = st.total;

// Create isolated MemCh for test
MemCh *tm = MemCh_Make();

// Run test
status r = set->func(tm);

// Check ceiling (stress limit)
if(tm->metrics.totalCeiling > TEST_MEM_MAX_CEILING){
    Out("^r.Ceiling for test memory too high...^0\n", NULL);
    r |= ERROR;
}

// Free test memory
MemCh_Free(tm);

// Verify no leaks
MemBook_GetStats(m, &st);
i32 threshold = 2;  // Allow 2 pages tolerance

if(st.total > (baseMem + threshold)){
    Out("^r.MemLeak detected...^0\n", NULL);
    r |= ERROR;
}
```

**What Gets Detected**:
- Memory allocated but not freed
- Memory allocated at wrong level
- External allocations (`malloc()` instead of `MemCh`)

### Writing Memory-Safe Tests

**Good Pattern**:

```c
status MyComponent_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // All allocations use MemCh 'm'
    Span *p = Span_Make(m);
    Str *s = Str_FromS(m, "test");
    Table *t = Table_Make(m);

    // Use the structures
    Span_Add(p, s);
    Table_Set(t, s, I32_Wrapped(m, 42));

    // No need to explicitly free - MemCh_Free(m) handles it

    DebugStack_Pop();
    return r;
}
```

**Bad Pattern**:

```c
status MyComponent_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // BAD: malloc() allocates outside MemCh!
    char *buffer = malloc(1024);  // LEAK!

    // BAD: Forgot to use 'm' parameter
    Span *p = Span_Make(MemCh_Make());  // Creates orphaned MemCh!

    DebugStack_Pop();
    return r;
}
```

### Memory Hierarchy Testing

**Level System**:

```c
status MemChLevel_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // Get baseline
    MemBookStats st;
    MemBook_GetStats(m, &st);
    i32 start = st.total;

    // Level 0 allocations (persistent)
    MemCh *x = MemCh_Make();
    Span *p = Span_Make(x);
    for(i32 i = 0; i < 700; i++){
        Span_Add(p, I32_Wrapped(x, i));
    }

    // Enter level 1 (temporary)
    x->level++;
    Span *temp = Span_Make(x);
    for(i32 i = 0; i < 1000; i++){
        Span_Add(temp, I32_Wrapped(x, i));
    }

    // Exit level 1 - frees temporary allocations
    x->level--;
    MemCh_FreeTemp(x);

    // Verify level 1 freed but level 0 persists
    MemBook_GetStats(m, &st);
    // ... assertions ...

    // Free everything
    MemCh_Free(x);

    // Verify total cleanup
    MemBook_GetStats(m, &st);
    r |= Test(st.total == start, "MemBook chapters match start level", NULL);

    DebugStack_Pop();
    return r;
}
```

**Memory Ceiling Tests**:

```c
// Stress test with large allocations
status SpanMax_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // Allocate many large structures
    m->level++;
    Span *p = Span_Make(m);

    for(i64 i = 0; i < 10000; i++){
        Span_Set(p, i, I64_Wrapped(m, i));
    }

    // Memory ceiling tracked in tm->metrics.totalCeiling
    // Test runner checks: totalCeiling <= TEST_MEM_MAX_CEILING (512 pages)

    MemCh_FreeTemp(m);
    m->level--;

    DebugStack_Pop();
    return r;
}
```

---


## Unit Tests vs Integration Tests

### Unit Test Pattern

**Characteristics**:
- Test single component in isolation
- Simple data structures
- Minimal dependencies
- Fast execution
- Located in `option/base/` or `option/ext/`

**Example: String Tests**

**File**: `src/programs/test/option/base/str_tests.c`

```c
status Str_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // Test 1: Type check
    Str *s = Str_CstrRef(m, "Hi");
    void *args1[] = {
        Type_ToStr(m, TYPE_STR),
        s,
        NULL
    };
    r |= Test(s->type.of == TYPE_STR,
        "Expect string to have fixed type $ found @", args1);

    // Test 2: Length check
    void *args2[] = {
        I32_Wrapped(m, 2),
        I32_Wrapped(m, s->length),
        NULL
    };
    r |= Test(s->length == 2,
        "Expect string length of @ found @", args2);

    // Test 3: Content check
    void *args3[] = {
        Str_CstrRef(m, "Hi"),
        s,
        NULL
    };
    r |= Test(strncmp((char *)s->bytes, "Hi\0", 3) == 0,
        "Expect string match of @ found @", args3);

    // Test 4: I64 conversion
    i64 value = 35072;
    s = Str_FromI64(m, value);
    Str *expected = Str_CstrRef(m, "35072");

    void *args4[] = {
        I64_Wrapped(m, value),
        I16_Wrapped(m, expected->length),
        I16_Wrapped(m, s->length),
        NULL
    };
    r |= Test(s->length == expected->length,
        "Expect for i64 value $ length of $ found $", args4);

    DebugStack_Pop();
    return r;
}
```

**Example: Span Tests**

```c
static status makeAndCompareItems(MemCh *m, i64 max){
    status r = READY;

    m->level++;
    Span *p = Span_Make(m);

    // Add items
    for(i64 i = 0; i < max; i++){
        Span_Set(p, i, I64_Wrapped(m, i));
    }

    // Verify items
    for(i64 i = 0; i < max; i++){
        Single *sg = Span_Get(p, i);
        if(sg->val.i != i){
            r |= ERROR;
            break;
        }
    }

    void *args[] = {
        I64_Wrapped(m, max),
        NULL
    };
    r |= Test((r & ERROR) == 0, "Adding and comparing $ items", args);

    MemCh_FreeTemp(m);
    m->level--;

    return r;
}

status Span_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // Test with different sizes
    r |= makeAndCompareItems(m, 100);
    r |= makeAndCompareItems(m, 1000);
    r |= makeAndCompareItems(m, 10000);

    DebugStack_Pop();
    return r;
}
```

### Integration Test Pattern

**Characteristics**:
- Test multiple components working together
- Real-world scenarios
- Network/IO operations
- Complex data structures
- Located in `option/inter/`

**Example: HTTP Tests**

**File**: `src/programs/test/option/inter/http_tests.c`

```c
status Http_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // 1. Create protocol context (multiple components)
    ProtoCtx *proto = HttpProto_Make(m);

    // 2. Create realistic HTTP request
    StrVec *v = Sv(m,
        "GET /fancy.html HTTP/1.1\r\n"
        "User-Agent: Firefudge/Aluminum\r\n"
        "Broken-Header: One,Two,Three,\r\n"
        "\tFour\r\n"
        "\r\n"
    );

    // 3. Parse using Roebling parser
    Cursor *curs = Cursor_Make(m, v);
    Roebling *rbl = HttpRbl_Make(m, curs, proto);
    status parseResult = Roebling_Run(rbl);

    r |= Test(parseResult == SUCCESS, "HTTP parse succeeded", NULL);

    // 4. Extract parsed context
    HttpCtx *ctx = (HttpCtx*)as(proto->ctx, TYPE_HTTP_CTX);

    // 5. Verify method
    void *args1[] = {
        I32_Wrapped(m, HTTP_METHOD_GET),
        NULL
    };
    r |= Test(ctx->method == HTTP_METHOD_GET,
        "Method is as expected $", args1);

    // 6. Verify path
    void *args2[] = {
        K(m, "/fancy.html"),
        NULL
    };
    r |= Test(Equals(ctx->path, args2[0]),
        "Path is as expected $", args2);

    // 7. Verify headers
    Str *userAgent = Table_Get(ctx->headersIt.p, K(m, "User-Agent"));
    void *args3[] = {
        K(m, "User-Agent"),
        K(m, "Firefudge/Aluminum"),
        userAgent,
        NULL
    };
    r |= Test(Equals(userAgent, K(m, "Firefudge/Aluminum")),
        "Header $ is as expected $, found @", args3);

    // 8. Verify multi-line header continuation
    Str *brokenHeader = Table_Get(ctx->headersIt.p, K(m, "Broken-Header"));
    r |= Test(brokenHeader != NULL, "Multi-line header parsed", NULL);

    DebugStack_Pop();
    return r;
}
```

**Example: Template Tests**

```c
status Templ_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // 1. Create template source
    StrVec *source = Sv(m,
        "<h1>{title}</h1>\n"
        "; items...\n"
        "<li>{*value}</li>\n"
        ";\n"
    );

    // 2. Parse template
    Cursor *curs = Cursor_Make(m, StrVec_Str(m, source));
    Mess *mess = TemplParse_Make(m, curs);
    Templ *templ = Templ_Make(m, mess);

    // 3. Create data
    Table *data = Table_Make(m);
    Table_Set(data, K(m, "title"), K(m, "My List"));

    Span *items = Span_Make(m);
    Span_Add(items, K(m, "Item 1"));
    Span_Add(items, K(m, "Item 2"));
    Span_Add(items, K(m, "Item 3"));
    Table_Set(data, K(m, "items"), items);

    // 4. Render template
    Buff *output = Buff_Make(m, ZERO);
    Templ_ToS(templ, output, data, NULL);

    // 5. Verify output
    Str *expected = Str_FromS(m,
        "<h1>My List</h1>\n"
        "<li>Item 1</li>\n"
        "<li>Item 2</li>\n"
        "<li>Item 3</li>\n"
    );

    Str *actual = Buff_ToStr(m, output);

    void *args[] = {
        expected,
        actual,
        NULL
    };
    r |= Test(Str_Equals(expected, actual),
        "Template output matches expected\nExpected: @\nActual: @", args);

    DebugStack_Pop();
    return r;
}
```

---


## Test Organization

### Organizing Tests with Sections

**Purpose**: Group related tests for better readability

**Example from Base Tests**:

```c
static TestSet BaseTests[] = {
    // Section header
    {
        "Basic Features",        // Section name
        NULL,                    // No function
        NULL,                    // No description
        SECTION_LABEL,           // Flag marks this as section
    },

    // Tests in this section
    {
        "Core",
        Core_Tests,
        "Fundamental system tests",
        FEATURE_COMPLETE,
    },
    {
        "MemCh",
        MemCh_Tests,
        "Memory chapter tests",
        FEATURE_COMPLETE,
    },

    // Another section
    {
        "String Handling",
        NULL,
        NULL,
        SECTION_LABEL,
    },

    {
        "Str",
        Str_Tests,
        "String tests",
        FEATURE_COMPLETE,
    },
    {
        "StrVec",
        StrVec_Tests,
        "String vector tests",
        FEATURE_COMPLETE,
    },

    // Terminator (required!)
    {
        NULL,
        NULL,
        NULL,
        0,
    }
};
```

**Output**:
```
== Basic Features
=== Testing: Core
...
=== Testing: MemCh
...

== String Handling
=== Testing: Str
...
=== Testing: StrVec
...
```

### Skipping Tests

**Temporarily Disable**:

```c
{
    "Experimental Feature",
    Experimental_Tests,
    "Not ready for testing",
    FEATURE_COMPLETE|SKIP_TEST,  // Will be skipped
},
```

**Output**:
```
=== Skipping Experimental Feature
```

### Conditional Compilation

**Platform-Specific Tests**:

```c
#ifdef __FreeBSD__
{
    "FreeBSD System Query",
    SysQuery_Tests,
    "Platform-specific tests",
    FEATURE_COMPLETE,
},
#endif
```

**Feature-Specific Tests**:

```c
#ifdef MEM_MAX_TESTS
{
    "Span Max Tests",
    SpanMax_Tests,
    "Stress test with maximum values",
    FEATURE_COMPLETE,
},
#endif
```

---


## Advanced Testing Patterns

### Testing Error Conditions

```c
status Error_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // Test that function properly fails
    status result = FunctionThatShouldFail(m);

    void *args[] = {
        State_ToStr(m, result),
        NULL
    };
    r |= Test((result & ERROR) != 0,
        "Function correctly returned error state $", args);

    // Test error message was set
    Str *errorMsg = Error_Get(m);
    r |= Test(errorMsg != NULL, "Error message was set", NULL);

    r |= Test(Str_Contains(errorMsg, K(m, "expected substring")),
        "Error message contains expected text", NULL);

    DebugStack_Pop();
    return r;
}
```

### Testing with Mock Data

**File**: `src/programs/test/fixtures/mock_109strings.c`

```c
// Generate predictable test data
Str **Test_Get109Strings(MemCh *m){
    Str **strings = MemCh_Alloc(m, sizeof(Str*) * 109);

    strings[0] = Str_FromS(m, "alpha");
    strings[1] = Str_FromS(m, "beta");
    strings[2] = Str_FromS(m, "gamma");
    // ... 106 more strings

    return strings;
}

// Use in tests
status Table_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    Table *t = Table_Make(m);
    Str **strings = Test_Get109Strings(m);

    // Add all strings to table
    for(i32 i = 0; i < 109; i++){
        Table_Set(t, strings[i], I32_Wrapped(m, i));
    }

    // Verify all strings can be retrieved
    for(i32 i = 0; i < 109; i++){
        Single *value = Table_Get(t, strings[i]);
        r |= Test(value != NULL && value->val.i == i,
            "Table retrieved correct value for entry", NULL);
    }

    DebugStack_Pop();
    return r;
}
```

### Testing Iterators

```c
status Iter_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // Create collection
    Span *p = Span_Make(m);
    for(i32 i = 0; i < 100; i++){
        Span_Add(p, I32_Wrapped(m, i));
    }

    // Test forward iteration
    i32 count = 0;
    i32 expectedValue = 0;

    Iter it;
    Iter_Init(&it, p);

    while((Iter_Next(&it) & END) == 0){
        Single *value = Iter_Get(&it);

        void *args[] = {
            I32_Wrapped(m, expectedValue),
            I32_Wrapped(m, value->val.i),
            NULL
        };
        r |= Test(value->val.i == expectedValue,
            "Iterator value $ matches expected $", args);

        count++;
        expectedValue++;
    }

    void *args[] = {
        I32_Wrapped(m, 100),
        I32_Wrapped(m, count),
        NULL
    };
    r |= Test(count == 100,
        "Iterator counted $ items, expected $", args);

    DebugStack_Pop();
    return r;
}
```

### Testing File I/O

```c
status FileIO_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // Create test file path
    Str *testFile = Str_FromS(m, "/tmp/caneka_test_file.txt");

    // Write data
    Buff *writeBuffer = Buff_Make(m, ZERO);
    StrVec *testData = Sv(m, "Test data\nLine 2\nLine 3\n");
    Buff_AddVec(writeBuffer, testData);

    status writeResult = File_Create(writeBuffer, testFile);
    r |= Test(writeResult == SUCCESS, "File creation succeeded", NULL);

    // Read data back
    Buff *readBuffer = Buff_Make(m, ZERO);
    status readResult = File_Open(readBuffer, testFile, O_RDONLY);
    r |= Test(readResult == SUCCESS, "File read succeeded", NULL);

    // Verify content
    Str *readData = Buff_ToStr(m, readBuffer);
    r |= Test(Str_Equals(readData, StrVec_Str(m, testData)),
        "File content matches written data", NULL);

    // Cleanup
    File_Remove(m, testFile);

    DebugStack_Pop();
    return r;
}
```

---


## Debugging Failed Tests

### Debug Output

**Add Debug Prints**:

```c
status MyComponent_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    Span *p = Span_Make(m);

    // Debug: Show span state
    void *debugArgs[] = {
        I32_Wrapped(m, p->length),
        I32_Wrapped(m, p->capacity),
        NULL
    };
    Out("DEBUG: Span length=$, capacity=$\n", debugArgs);

    // Test continues...
    r |= Test(p->length == 0, "Span starts empty", NULL);

    DebugStack_Pop();
    return r;
}
```

### DebugStack Tracing

**Purpose**: Shows execution path on crash

```c
status Complex_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);

    // Nested function calls
    DebugStack_Push(K(m, "Setup phase"), 0);
    setupData(m);
    DebugStack_Pop();

    DebugStack_Push(K(m, "Execution phase"), 0);
    runTest(m);
    DebugStack_Pop();

    DebugStack_Push(K(m, "Verification phase"), 0);
    verifyResults(m);
    DebugStack_Pop();

    DebugStack_Pop();
    return SUCCESS;
}
```

**On crash**, DebugStack prints:
```
Debug Stack:
  → Verification phase
  → Complex_Tests
```

### State Inspection

```c
// Inspect object state
void *args[] = {
    State_ToStr(m, obj->type.state),
    Type_ToStr(m, obj->type.of),
    Type_StateVec(m, obj->type.of, obj->type.state),
    NULL
};

Out("Object state: $, type: $, state vector: @\n", args);
```

### Memory Debugging

**Check for Leaks Manually**:

```c
status MemDebug_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // Get baseline
    MemBookStats before;
    MemBook_GetStats(m, &before);

    // Run operations
    for(i32 i = 0; i < 1000; i++){
        Span *temp = Span_Make(m);
        // ... use temp ...
    }

    // Check after
    MemBookStats after;
    MemBook_GetStats(m, &after);

    void *args[] = {
        I32_Wrapped(m, before.total),
        I32_Wrapped(m, after.total),
        NULL
    };

    Out("Memory before: $, after: $\n", args);

    r |= Test(after.total == before.total,
        "No memory leak detected", NULL);

    DebugStack_Pop();
    return r;
}
```

---



---

**Part 1 of 2** | [Part 2 →](testing-part2)
