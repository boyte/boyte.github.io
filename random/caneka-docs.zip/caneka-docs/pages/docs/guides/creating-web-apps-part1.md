# Creating Web Applications: Complete Tutorial - Part 1

**Part 1 of 3** | [Part 2 →](creating-web-apps-part2)

---

## Introduction

This guide teaches you how to build complete web applications using Caneka's integrated HTTP server, routing system, and template engine. Unlike traditional frameworks that bolt together disparate libraries, Caneka provides a **cohesive full-stack runtime** where every component—from memory management to HTTP parsing to template rendering—is designed to work together.

**What You'll Learn**:
- Web server setup and configuration
- Filesystem-driven routing
- Template-based page rendering
- Data binding and dynamic content
- Form handling with BinSeg persistence
- Session management and authentication
- Static asset serving with ETags
- Error handling and 404 pages
- Complete working web applications

**Philosophy**: Caneka web development follows a **convention-over-configuration** approach. Routes are defined by your filesystem layout, templates are plain files in your pages directory, and configuration is minimal. This tutorial will show you how to build real applications quickly without fighting framework abstractions.

**Why This Matters**: You can build production web applications in C with the same ergonomics as high-level scripting languages, but with complete transparency, zero dependencies, and predictable performance.


## Progressive Learning Path

We'll build applications of increasing complexity:

1. **Hello World**: Minimal web server (~50 lines)
2. **Static Site**: Serving HTML, CSS, and images
3. **Dynamic Pages**: Templates with data binding
4. **Interactive App**: Forms, database, sessions
5. **Complete Application**: Multi-page app with authentication

Each step builds on previous concepts, giving you a complete understanding of web development in Caneka by the end.

---


## Prerequisites

Before starting, ensure you have:

1. **Caneka built and installed** (see [Installation Guide](../getting-started/installation.md))
2. **Basic C knowledge** (pointers, structs, functions)
3. **HTTP fundamentals** (requests, responses, headers, status codes)
4. **HTML/CSS basics** (for templates and styling)

**Recommended Reading**:
- [Templ Template Engine](../core-concepts/templ-complete.md) - Template syntax
- [WWW Routing System](../core-concepts/www-routing-complete.md) - Routing architecture
- [HTTP Lifecycle](../core-concepts/http-lifecycle-complete.md) - Request/response flow

---


## Level 1: Hello World Web Server

**Goal**: Create the simplest possible web server that responds with "Hello, World!"

### Complete Code

**File**: `hello.c`

```c
#include <caneka.h>

// Custom handler to provide "Hello, World!" response
static status helloHandler(Step *st, Task *tsk){
    MemCh *m = tsk->m;

    // Get HTTP context from task
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *http = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Set response
    http->code = 200;  // HTTP OK
    http->mime = Str_FromS(m, "text/plain");

    // Create response body
    Buff *body = Span_Get(proto->outSpan, 0);
    Buff_AddBytes(body, (byte *)"Hello, World!\n", 14);
    http->contentLength = 14;

    st->type.state |= SUCCESS;
    return SUCCESS;
}

int main(int argc, char **argv){
    // Initialize Caneka system
    Caneka_Init();
    Inter_Init();

    MemCh *m = MemCh_Make();

    // Create web server on port 3000
    Task *server = WebServer_Make(3000, 0, NULL);  // port 3000, IPv4, no IPv6

    // Set up minimal route
    TcpCtx *tcp = (TcpCtx *)as(server->source, TYPE_TCP_CTX);
    Route *root = Route_Make(m);

    // Register hello handler for all paths
    Table *handlers = Table_Make(m);
    Single *sg = Single_Make(m);
    sg->type.of = TYPE_WRAPPED_PTR;
    sg->val.ptr = helloHandler;
    Table_Set(handlers, Str_FromS(m, "helloHandler"), sg);

    tcp->pages = root;

    // Start server
    printf("Server listening on http://localhost:3000\n");
    Task_Tumble(server);

    return 0;
}
```

### Build and Run

```bash
# Compile
gcc -I./dist/include -L./dist/lib hello.c -lcaneka -o hello

# Run
./hello

# In another terminal, test:
curl http://localhost:3000
# Output: Hello, World!
```

### What's Happening

**1. Initialization**:
```c
Caneka_Init();   // Initialize base layer (memory, types, I/O)
Inter_Init();    // Initialize inter layer (HTTP, WWW, Templ)
```

**2. Server Creation**:
```c
Task *server = WebServer_Make(3000, 0, NULL);
```
- Creates a TCP server task listening on port 3000
- Server runs as a Task in the event loop
- Non-blocking, poll-based I/O

**3. Handler Function**:
```c
static status helloHandler(Step *st, Task *tsk)
```
- Handlers are Step functions in the Task execution model
- Receive Task containing HTTP context
- Return SUCCESS to continue, FAIL to abort

**4. HTTP Context Access**:
```c
ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
HttpCtx *http = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);
```
- `ProtoCtx` wraps protocol-specific context (HTTP, WebSocket, etc.)
- `HttpCtx` contains request data and response controls

**5. Response Building**:
```c
http->code = 200;  // Status code
http->mime = Str_FromS(m, "text/plain");  // Content-Type
Buff *body = Span_Get(proto->outSpan, 0);  // Output buffer
Buff_AddBytes(body, (byte *)"Hello, World!\n", 14);
http->contentLength = 14;
```

**6. Event Loop**:
```c
Task_Tumble(server);
```
- Starts the server event loop
- Blocks indefinitely, handling connections
- Ctrl+C to stop

---


## Level 2: Static Site with Filesystem Routing

**Goal**: Serve HTML, CSS, and images from a directory structure without writing handler code.

### Directory Structure

```
my-site/
├── main.c                 # Server program
├── pages/
│   ├── index.html        # Home page
│   ├── about.html        # About page
│   ├── contact.html      # Contact page
│   └── static/
│       ├── style.css     # Stylesheet
│       ├── app.js        # JavaScript
│       └── logo.png      # Image
└── default.config        # Route configuration
```

### Configuration File

**File**: `default.config`

```
routes {
    / {
        path: pages/
        ext: html
    }
    /static {
        path: pages/static/
        ext: css js png jpg gif svg
    }
}
```

**Configuration Syntax**:
- Routes are defined hierarchically
- `/` = root route, maps to `pages/` directory
- `/static` = asset route, maps to `pages/static/` directory
- `ext:` = file extensions to serve
- Space-separated lists for multiple extensions

### HTML Files

**File**: `pages/index.html`

```html
<!DOCTYPE html>
<html>
<head>
    <title>My Site</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <header>
        <img src="/static/logo.png" alt="Logo">
        <nav>
            <a href="/">Home</a>
            <a href="/about">About</a>
            <a href="/contact">Contact</a>
        </nav>
    </header>
    <main>
        <h1>Welcome to My Site</h1>
        <p>This is a static site served by Caneka.</p>
    </main>
</body>
</html>
```

**File**: `pages/about.html`

```html
<!DOCTYPE html>
<html>
<head>
    <title>About - My Site</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <h1>About Us</h1>
    <p>Learn more about our mission and team.</p>
    <a href="/">Back to Home</a>
</body>
</html>
```

### Server Program

**File**: `main.c`

```c
#include <caneka.h>

int main(int argc, char **argv){
    Caneka_Init();
    Inter_Init();

    MemCh *m = MemCh_Make();

    // Load configuration
    StrVec *configPath = StrVec_FromS(m, "./default.config");
    NodeObj *config = Config_FromPath(m, configPath);

    if(config == NULL){
        fprintf(stderr, "Failed to load configuration\n");
        return 1;
    }

    // Create web server
    Task *server = WebServer_Make(3000, 0, NULL);

    // Load routes from config
    StrVec *pagesPath = StrVec_FromS(m, "./");
    status result = WebServer_SetConfig(server, pagesPath, config, NULL);

    if(result != SUCCESS){
        fprintf(stderr, "Failed to load routes\n");
        return 1;
    }

    printf("Server listening on http://localhost:3000\n");
    printf("Routes:\n");
    printf("  http://localhost:3000/        -> pages/index.html\n");
    printf("  http://localhost:3000/about   -> pages/about.html\n");
    printf("  http://localhost:3000/static/* -> pages/static/*\n");

    Task_Tumble(server);

    return 0;
}
```

### Build and Run

```bash
# Compile
gcc -I./dist/include -L./dist/lib main.c -lcaneka -o server

# Run
./server

# Test in browser:
# http://localhost:3000/
# http://localhost:3000/about
# http://localhost:3000/static/style.css
```

### How Routing Works

**Request**: `GET /about`

1. **Path Resolution**: `/about` → look for route starting with `/`
2. **File Search**: Check `pages/about.html` (root route path + requested path + extension)
3. **File Type**: `.html` → ROUTE_STATIC flag
4. **Handler**: `routeFuncStatic()` - opens file and streams to client
5. **Response**: 200 OK with `Content-Type: text/html`

**Request**: `GET /static/style.css`

1. **Path Resolution**: `/static/style.css` → route `/static`
2. **File Search**: Check `pages/static/style.css`
3. **File Type**: `.css` → ROUTE_ASSET flag
4. **ETag Check**: Calculate file hash, check `If-None-Match` header
5. **Handler**: `routeFuncStatic()` with caching
6. **Response**: 200 OK with `ETag` header, or 304 Not Modified

### ETag Caching

Caneka automatically generates ETags for asset files:

```c
// Server calculates ETag from file hash
StrVec *etag = Route_GetEtag(route);  // e.g., "a3f5b9c2d1"

// Client sends on subsequent request:
// If-None-Match: "a3f5b9c2d1"

// Server checks:
if(Route_CheckEtag(route, clientEtag) == SUCCESS){
    http->code = 304;  // Not Modified - don't send file again
}
```

**Benefits**:
- Reduces bandwidth (browser uses cache)
- Faster page loads
- Automatic - no configuration needed

---


## Level 3: Dynamic Pages with Templates

**Goal**: Use templates to generate HTML dynamically with data binding.

### Directory Structure

```
dynamic-site/
├── main.c
├── default.config
└── pages/
    ├── index.templ       # Template for home page
    ├── index.config      # Data for home page
    ├── users.templ       # User list template
    ├── users.config      # User list configuration
    └── inc/
        ├── header.templ  # Shared header
        └── footer.html   # Shared footer
```

### Configuration

**File**: `default.config`

```
data {
    site {
        title: My Dynamic Site
        description: A Caneka-powered website
    }
}
routes {
    / {
        path: pages/
        ext: templ config
        header: pages/inc/header.templ
        footer: pages/inc/footer.html
    }
}
nav {
    Home: /
    Users: /users
}
```

**New Features**:
- `data { }` - Global data available to all templates
- `header:` / `footer:` - Automatically wrap content
- `nav { }` - Navigation menu data

### Header Template

**File**: `pages/inc/header.templ`

```templ
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>{config#children#page#atts#title} - {config#children#data#atts#site#title}</title>
</head>
<body>
<header>
    <h1>{config#children#data#atts#site#title}</h1>
    <nav>
        <ul>
;           nav...
            <li><a href="{route#path}">{*key}</a></li>
;
        </ul>
    </nav>
</header>
<main>
```

**Template Syntax Breakdown**:
- `{config#children#page#atts#title}` - Navigate object tree: config → children → page → atts → title
- `{*key}` - Current iteration key (in `nav` loop)
- `{route#path}` - Route path from navigation config
- `; nav...` - Iterate over `nav` collection
- `;` - End iteration block

### Footer Template

**File**: `pages/inc/footer.html`

```html
</main>
<footer>
    <p>&copy; 2024 {config#children#data#atts#site#title}</p>
</footer>
</body>
</html>
```

### Home Page Template

**File**: `pages/index.templ`

```templ
<h2>Welcome</h2>
<p>{config#children#data#atts#site#description}</p>

<section>
    <h3>Recent News</h3>
    <ul>
;       news...
        <li>
            <h4>{*value#title}</h4>
            <p>{*value#summary}</p>
            <time>{*value#date}</time>
        </li>
;
    </ul>
</section>
```

### Home Page Configuration

**File**: `pages/index.config`

```
page {
    title: Home
}
news {
    article1 {
        title: Caneka 1.0 Released
        summary: The first stable release is now available.
        date: 2024-01-15
    }
    article2 {
        title: New Template Features
        summary: Enhanced template syntax with nested loops.
        date: 2024-01-10
    }
}
```

**Configuration Structure**:
- `page { }` - Page metadata (title, id, handlers)
- `news { }` - Custom data structure
- Nested objects with properties

### Users Page Template

**File**: `pages/users.templ`

```templ
<h2>User Directory</h2>

; users ?
<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
        </tr>
    </thead>
    <tbody>
;       users...
        <tr>
            <td>{*value#name}</td>
            <td>{*value#email}</td>
            <td>{*value#role}</td>
        </tr>
;
    </tbody>
</table>
; ->
<p>No users found.</p>
;
```

**New Syntax**:
- `; users ?` - Conditional: render block if `users` exists and is non-empty
- `; ->` - Else branch: render if condition fails
- `;` - End conditional

### Users Page Configuration

**File**: `pages/users.config`

```
page {
    title: Users
}
users {
    user1 {
        name: Alice Johnson
        email: alice@example.com
        role: Administrator
    }
    user2 {
        name: Bob Smith
        email: bob@example.com
        role: Editor
    }
    user3 {
        name: Carol Williams
        email: carol@example.com
        role: Viewer
    }
}
```

### Server Program (Unchanged)

Same as Level 2 - configuration-driven, no code changes needed!

```c
#include <caneka.h>

int main(int argc, char **argv){
    Caneka_Init();
    Inter_Init();

    MemCh *m = MemCh_Make();

    NodeObj *config = Config_FromPath(m, StrVec_FromS(m, "./default.config"));
    Task *server = WebServer_Make(3000, 0, NULL);
    WebServer_SetConfig(server, StrVec_FromS(m, "./"), config, NULL);

    printf("Server listening on http://localhost:3000\n");
    Task_Tumble(server);

    return 0;
}
```

### Request Flow for Templates

**Request**: `GET /users`

1. **Route Resolution**: `/users` → root route `/`
2. **File Discovery**:
   - `pages/users.templ` (template file)
   - `pages/users.config` (configuration file)
3. **Route Type**: `.templ` → ROUTE_DYNAMIC flag
4. **Configuration Load**: Parse `users.config` into NodeObj tree
5. **Data Merge**:
   - Global `data { }` from `default.config`
   - Page-specific `users { }` from `users.config`
   - Navigation `nav { }` from `default.config`
6. **Template Preparation**:
   - Parse `header.templ` (Templ_Prepare)
   - Parse `users.templ` (Templ_Prepare)
   - Parse `footer.html` (static)
7. **Template Rendering**:
   - Render header with data (Templ_ToS)
   - Render body with data (Templ_ToS)
   - Append footer
8. **Response**: 200 OK with rendered HTML

### Data Access in Templates

Templates access data through object navigation syntax:

**Syntax**: `{object#property#nested#...}`

**Example Access Paths**:

```templ
{config#children#page#atts#title}
```
→ Navigates: `config` → `children` → `page` → `atts` → `title`
→ Returns: "Users"

```templ
{config#children#data#atts#site#title}
```
→ Navigates: `config` → `children` → `data` → `atts` → `site` → `title`
→ Returns: "My Dynamic Site"

```templ
{*value#name}
```
→ In iteration context: current item → `name` property
→ Returns: "Alice Johnson"

**Data Structure** (conceptual):
```
{
  config: {
    children: {
      data: {
        atts: {
          site: {
            title: "My Dynamic Site",
            description: "A Caneka-powered website"
          }
        }
      },
      page: {
        atts: {
          title: "Users"
        }
      }
    }
  },
  users: {
    user1: {
      name: "Alice Johnson",
      email: "alice@example.com",
      role: "Administrator"
    },
    ...
  },
  nav: {
    "Home": { path: "/" },
    "Users": { path: "/users" }
  }
}
```

---


## Level 4: Dynamic Data with Custom Handlers

**Goal**: Generate data programmatically in C handlers instead of static config files.

### Use Case: Server Stats Page

Display live server statistics (uptime, memory usage, request count).

### Page Configuration

**File**: `pages/stats.config`

```
page {
    title: Server Statistics
    handlers: statsData
}
```

**New Feature**:
- `handlers:` - Names of C functions to call for data gathering
- Space-separated for multiple handlers

### Template

**File**: `pages/stats.templ`

```templ
<h2>Server Statistics</h2>

<section>
    <h3>Uptime</h3>
    <p>Server started: {stats#uptime}</p>
</section>

<section>
    <h3>Memory Usage</h3>
    <p>Used: {stats#mem#mem-used}</p>
    <p>Total: {stats#mem#mem-total}</p>

    <h4>Detailed Breakdown</h4>
    <table>
        <thead>
            <tr><th>Component</th><th>Bytes</th></tr>
        </thead>
        <tbody>
;           stats#mem#mem-details...
            <tr>
                <td>{*key}</td>
                <td>{*value}</td>
            </tr>
;
        </tbody>
    </table>
</section>

<section>
    <h3>Request Metrics</h3>
    <p>Total Requests: {stats#requests#total}</p>
    <p>Active Connections: {stats#requests#active}</p>
</section>
```

### Server Program with Custom Handler

**File**: `main.c`

```c
#include <caneka.h>

// Custom data handler for /stats page
static status Load_stats(Step *st, Task *tsk){
    MemCh *m = tsk->m;

    // Get contexts
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    TcpCtx *tcp = (TcpCtx *)as(tsk->source, TYPE_TCP_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Gather memory statistics
    MemBookStats memStats;
    MemBook_GetStats(m, &memStats);

    // Build statistics data structure
    Table *stats = Table_Make(m);

    // Uptime
    Str *uptime = Time_ToStr(m, &tcp->metrics.start);
    Table_Set(stats, Str_FromS(m, "uptime"), uptime);

    // Memory statistics
    Table *mem = Table_Make(m);
    word memUsed = memStats.pageIdx * PAGE_SIZE;
    word memTotal = PAGE_COUNT * PAGE_SIZE;

    Table_Set(mem, Str_FromS(m, "mem-used"), Str_MemCount(m, memUsed));
    Table_Set(mem, Str_FromS(m, "mem-total"), Str_MemCount(m, memTotal));

    // Detailed memory breakdown
    Table *details = Table_Make(m);
    Table_Set(details, Str_FromS(m, "Pages Used"), Str_FromI64(m, memStats.pageIdx));
    Table_Set(details, Str_FromS(m, "Pages Total"), Str_FromI64(m, PAGE_COUNT));
    Table_Set(details, Str_FromS(m, "Books"), Str_FromI64(m, memStats.bookCount));
    Table_Set(details, Str_FromS(m, "Chapters"), Str_FromI64(m, memStats.chapterCount));

    Table_Set(mem, Str_FromS(m, "mem-details"), details);
    Table_Set(stats, Str_FromS(m, "mem"), mem);

    // Request metrics
    Table *requests = Table_Make(m);
    Table_Set(requests, Str_FromS(m, "total"), Str_FromI64(m, tcp->metrics.count));
    Table_Set(requests, Str_FromS(m, "active"), Str_FromI64(m, tcp->metrics.open));

    Table_Set(stats, Str_FromS(m, "requests"), requests);

    // Attach to HTTP context data
    Table_Set(ctx->data, Str_FromS(m, "stats"), stats);

    st->type.state |= SUCCESS;
    return SUCCESS;
}

int main(int argc, char **argv){
    Caneka_Init();
    Inter_Init();

    MemCh *m = MemCh_Make();

    // Load configuration
    NodeObj *config = Config_FromPath(m, StrVec_FromS(m, "./default.config"));

    // Create handler registry
    Table *handlers = Table_Make(m);

    // Register statsData handler
    Single *statsHandler = Single_Make(m);
    statsHandler->type.of = TYPE_WRAPPED_PTR;
    statsHandler->val.ptr = Load_stats;  // Function pointer
    Table_Set(handlers, Str_FromS(m, "statsData"), statsHandler);

    // Create server and load routes
    Task *server = WebServer_Make(3000, 0, NULL);
    WebServer_SetConfig(server, StrVec_FromS(m, "./"), config, handlers);

    printf("Server listening on http://localhost:3000\n");
    printf("Visit http://localhost:3000/stats for live statistics\n");

    Task_Tumble(server);

    return 0;
}
```

### How Handler Registration Works

**1. Handler Table**:
```c
Table *handlers = Table_Make(m);
```
- Key: Handler name (from config `handlers:` field)
- Value: Function pointer wrapped in Single

**2. Function Pointer Wrapping**:
```c
Single *statsHandler = Single_Make(m);
statsHandler->type.of = TYPE_WRAPPED_PTR;
statsHandler->val.ptr = Load_stats;
```
- `Single` is Caneka's wrapper type for primitives
- `TYPE_WRAPPED_PTR` allows storing void* (function pointer)

**3. Handler Discovery**:
```c
WebServer_SetConfig(server, path, config, handlers);
```
- Reads `handlers:` field from `stats.config`
- Looks up "statsData" in handlers table
- Adds `Load_stats` as a Step in the request task

**4. Execution Flow**:
```
Request /stats
  ↓
WebServer_GatherPage (route resolution)
  ↓
Load_stats (custom handler - gathers data)
  ↓
WebServer_ServePage (template rendering)
  ↓
Response
```

### Handler Function Signature

All handlers must match this signature:

```c
status HandlerFunc(Step *st, Task *tsk)
```

**Parameters**:
- `Step *st` - Current step in task execution (set `st->type.state` to SUCCESS/FAIL)
- `Task *tsk` - Task context containing HTTP data

**Access HTTP Context**:
```c
ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);
```

**Add Data to Response**:
```c
Table_Set(ctx->data, key, value);
```

**Return Value**:
- `SUCCESS` - Handler succeeded, continue to next step
- `FAIL` - Handler failed, abort request with error page

---


## Level 5: Forms and Data Persistence with BinSeg

**Goal**: Handle form submissions and persist data to disk using BinSeg serialization.

### Use Case: User Signup Form

Collect user information and save to a database file.

### Form Template

**File**: `pages/signup.templ`

```templ
<h2>Sign Up</h2>

; form ?
<div class="success">
    <p>Thank you for signing up, {form#name}!</p>
    <p>We'll contact you at {form#email}.</p>
</div>
; ->
<form method="POST" action="/forms/signup?action=add">
    <label>
        Name:
        <input type="text" name="name" required>
    </label>

    <label>
        Email:
        <input type="email" name="email" required>
    </label>

    <label>
        Role:
        <select name="role">
            <option value="user">User</option>
            <option value="editor">Editor</option>
            <option value="admin">Admin</option>
        </select>
    </label>

    <button type="submit">Sign Up</button>
</form>
;
```

**Template Logic**:
- `; form ?` - If form data exists (after submission), show success message
- `; ->` - Else, show form
- Form submits to `/forms/signup?action=add`

### Form Configuration

**File**: `pages/signup.config`

```
page {
    title: Sign Up
}
binseg {
    action: add modify read
    path: data/signups.rbs
}
```

**New Configuration**:
- `binseg { }` - BinSeg database configuration
- `action:` - Allowed operations (add, modify, read)
- `path:` - Database file location

### Route Configuration

**File**: `default.config`

```
routes {
    / {
        path: pages/
        ext: templ config
    }
    /forms {
        path: pages/
        ext: rbs
    }
}
```

`ext: rbs` selects the BinSeg handler for `.rbs` routes.

**BinSeg Extension**: `.rbs` (Resource Binary Segment)
- Triggers BinSeg handler (`routeFuncFileDb`)
- Handles add/modify/read actions
- Serializes/deserializes data automatically

### How Form Submission Works

**1. User Fills Form**:
```html
<form method="POST" action="/forms/signup?action=add">
    <input name="name" value="Alice Johnson">
    <input name="email" value="alice@example.com">
    <select name="role"><option value="admin">Admin</option></select>
</form>
```

**2. Browser Sends POST Request**:
```http
POST /forms/signup?action=add HTTP/1.1
Content-Type: application/x-www-form-urlencoded

name=Alice+Johnson&email=alice%40example.com&role=admin
```

**3. Server Parses Request**:
```c
// HTTP parser extracts:
ctx->method = HTTP_POST
ctx->path = "/forms/signup"
ctx->queryParams = { "action": "add" }
ctx->body = Table {
    "name": "Alice Johnson",
    "email": "alice@example.com",
    "role": "admin"
}
```

**4. Route Matches**:
- Path: `/forms/signup`
- Route: `/forms` with ext `.rbs`
- Config: `pages/signup.config` (has `binseg { }`)
- Handler: `routeFuncFileDb` (BinSeg database handler)

**5. BinSeg Serialization**:
```c
static status routeFuncFileDb(Buff *bf, Route *rt, Table *data, HttpCtx *ctx){
    BinSegCtx *bsCtx = (BinSegCtx *)Seel_Get(rt, K(m, "action"));

    // Check action query parameter
    Abstract *action = Table_Get(ctx->queryIt.p, K(m, "action"));

    if(Equals(action, K(m, "add")) && ctx->body != NULL){
        // Serialize form data to binary format
        BinSegCtx_Send(bsCtx, ctx->body);  // Writes to data/signups.rbs

        // Add form data to template context for success message
        Table_Set(data, K(m, "form"), ctx->body);

        // Render template with success message
        return routeFuncTempl(bf, rt, data, ctx);
    }

    return SUCCESS;
}
```

**6. BinSeg File Format** (data/signups.rbs):
```
[Binary Segment Header]
- Version: 1
- Type: Table
- Item Count: 3

[Item 1: "name"]
- Type: Str
- Length: 13
- Data: "Alice Johnson"

[Item 2: "email"]
- Type: Str
- Length: 19
- Data: "alice@example.com"

[Item 3: "role"]
- Type: Str
- Length: 5
- Data: "admin"

[Footer]
- Checksum: 0xABCDEF12
```

**7. Response**:
- Template renders with `form` data available
- Shows success message: "Thank you for signing up, Alice Johnson!"

### Reading BinSeg Data

**Query**: `GET /forms/signup?action=read`

**Handler**:
```c
if(Equals(action, K(m, "read"))){
    // Open BinSeg file
    Buff *bf = Buff_Make(m, ZERO);
    File_Open(bf, StrVec_Str(m, bsCtx->path), O_RDONLY);

    // Deserialize
    Shelf *records = Shelf_Make(m);
    BinSegCtx_Receive(bsCtx, bf, records);  // Reads all records

    // Convert to JSON or HTML
    StrVec *accept = Table_Get(ctx->headersIt.p, K(m, "Accept"));
    if(Equals(accept, K(m, "text/html"))){
        Table_Set(data, K(m, "records"), records);
        return routeFuncTempl(bf, rt, data, ctx);
    }else{
        // Return JSON
        Json_From(bf, records);
        return SUCCESS;
    }
}
```

**Template for Record Listing** (pages/signups-list.templ):
```templ
<h2>Signups</h2>

<table>
    <thead>
        <tr><th>Name</th><th>Email</th><th>Role</th></tr>
    </thead>
    <tbody>
;       records...
        <tr>
            <td>{*value#name}</td>
            <td>{*value#email}</td>
            <td>{*value#role}</td>
        </tr>
;
    </tbody>
</table>
```

### BinSeg Actions

**1. Add** (`?action=add`):
```c
BinSegCtx_Send(bsCtx, ctx->body);  // Append record to file
```

**2. Modify** (`?action=modify&id=123`):
```c
word id = Str_ToI64(Table_Get(ctx->queryParams, K(m, "id")));
BinSegCtx_Modify(bsCtx, id, ctx->body);  // Update record by ID
```

**3. Read** (`?action=read`):
```c
Shelf *records = Shelf_Make(m);
BinSegCtx_Receive(bsCtx, bf, records);  // Load all records
```

**4. Delete** (custom handler):
```c
// Not built-in, but easy to implement:
word id = Str_ToI64(Table_Get(ctx->queryParams, K(m, "id")));
BinSegCtx_Delete(bsCtx, id);  // Remove record
```

---



---

**Part 1 of 3** | [Part 2 →](creating-web-apps-part2)
