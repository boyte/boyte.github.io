# Testing: Complete Guide - Part 2

[← Part 1](testing-part1) | **Part 2 of 2**

---

## Best Practices

### 1. Use Isolated MemCh

**Why**: Prevents cross-test contamination and enables leak detection.

```c
// GOOD
status MyTests(MemCh *m){  // Use provided MemCh
    Span *p = Span_Make(m);
    // All allocations isolated to this test
}

// BAD
status MyTests(MemCh *m){
    MemCh *local = MemCh_Make();  // Creates orphaned context!
    Span *p = Span_Make(local);   // Leak!
}
```

### 2. Always Use DebugStack

**Why**: Provides crash location on failures.

```c
status MyTests(MemCh *m){
    DebugStack_Push(NULL, 0);  // ALWAYS at start
    status r = READY;

    // Test code here

    DebugStack_Pop();           // ALWAYS before return
    return r;
}
```

### 3. NULL-Terminate Test Arrays

**Why**: Test runner uses NULL to find array end.

```c
static TestSet BaseTests[] = {
    {"Test 1", Test1_Func, "Description", FEATURE_COMPLETE},
    {"Test 2", Test2_Func, "Description", FEATURE_COMPLETE},

    // Terminator - REQUIRED!
    {NULL, NULL, NULL, 0}
};
```

### 4. Accumulate Status with |=

**Why**: Ensures any failure marks test as failed.

```c
status r = READY;

r |= Test(condition1, "Test 1", NULL);  // PASS → r = SUCCESS
r |= Test(condition2, "Test 2", NULL);  // FAIL → r = ERROR
r |= Test(condition3, "Test 3", NULL);  // PASS → r still ERROR

return r;  // Returns ERROR if any test failed
```

### 5. Test One Concept Per Assertion

**Why**: Clear failure messages.

```c
// GOOD - separate assertions
r |= Test(s->type.of == TYPE_STR, "Type is STR", NULL);
r |= Test(s->length == 5, "Length is 5", NULL);
r |= Test(Str_Equals(s, expected), "Content matches", NULL);

// BAD - combined assertion
r |= Test(s->type.of == TYPE_STR && s->length == 5 && Str_Equals(s, expected),
    "String is valid", NULL);  // Which part failed?
```

### 6. Use Descriptive Test Names

**Why**: Easier to locate failures.

```c
// GOOD
{
    "HTTP Request Parsing",
    Http_Tests,
    "Parse GET request with headers",
    FEATURE_COMPLETE,
},

// BAD
{
    "Test 1",
    Test1,
    "Test",
    FEATURE_COMPLETE,
},
```

### 7. Test Edge Cases

**Why**: Edge cases often reveal bugs.

```c
status EdgeCase_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // Empty input
    Span *empty = Span_Make(m);
    r |= Test(empty->length == 0, "Empty span has length 0", NULL);

    // Single element
    Span *single = Span_Make(m);
    Span_Add(single, I32_Wrapped(m, 42));
    r |= Test(single->length == 1, "Single element span", NULL);

    // Very large input
    Span *large = Span_Make(m);
    for(i32 i = 0; i < 10000; i++){
        Span_Add(large, I32_Wrapped(m, i));
    }
    r |= Test(large->length == 10000, "Large span holds 10000 elements", NULL);

    // Boundary values
    r |= Test(Str_FromI64(m, 0)->bytes[0] == '0', "Zero converts to '0'", NULL);
    r |= Test(Str_FromI64(m, -1)->bytes[0] == '-', "Negative has minus sign", NULL);

    DebugStack_Pop();
    return r;
}
```

### 8. Verify Error Handling

**Why**: Ensure graceful failures.

```c
status ErrorHandling_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    // Test invalid input handling
    status result = ParseInvalidData(m);
    r |= Test((result & ERROR) != 0, "Invalid data returns error", NULL);

    // Test NULL handling
    result = ProcessNullInput(m, NULL);
    r |= Test((result & ERROR) != 0, "NULL input returns error", NULL);

    // Test out-of-bounds
    Span *p = Span_Make(m);
    Single *value = Span_Get(p, 999);  // Index out of range
    r |= Test(value == NULL, "Out of bounds returns NULL", NULL);

    DebugStack_Pop();
    return r;
}
```

### 9. Keep Tests Fast

**Why**: Fast tests run more often.

```c
// GOOD - focused test
status String_Tests(MemCh *m){
    // Tests only string operations, runs in milliseconds
}

// BAD - slow test
status Integration_Tests(MemCh *m){
    // Tests entire HTTP stack, file I/O, templating
    // Takes seconds to run
    // → Split into multiple focused tests instead
}
```

### 10. Document Complex Test Logic

**Why**: Future maintainers understand intent.

```c
status ComplexAlgorithm_Tests(MemCh *m){
    DebugStack_Push(NULL, 0);
    status r = READY;

    /**
     * Testing hash table collision handling:
     * 1. Create keys that hash to same bucket
     * 2. Verify all keys can be retrieved
     * 3. Check probe sequence is correct
     */

    // Force collisions by using specific keys
    Str *key1 = Str_FromS(m, "abc");  // Hash: 0x1234
    Str *key2 = Str_FromS(m, "xyz");  // Hash: 0x1234 (collision)

    // ... test implementation ...

    DebugStack_Pop();
    return r;
}
```

---


## Common Pitfalls

### 1. Forgetting NULL Terminator

**Problem**: Test array not properly terminated.

**Symptom**: Segfault, reading garbage tests.

```c
// BAD
static TestSet BaseTests[] = {
    {"Test", TestFunc, "Description", FEATURE_COMPLETE}
    // Missing terminator!
};

// GOOD
static TestSet BaseTests[] = {
    {"Test", TestFunc, "Description", FEATURE_COMPLETE},
    {NULL, NULL, NULL, 0}  // Terminator
};
```

### 2. Memory Leaks

**Problem**: Allocating outside MemCh.

**Symptom**: "MemLeak detected" error.

```c
// BAD
status MyTests(MemCh *m){
    char *buffer = malloc(1024);  // External allocation!
    // ... forget to free ...
    return SUCCESS;
}

// GOOD
status MyTests(MemCh *m){
    Str *buffer = Str_FromS(m, "");  // Uses MemCh
    // Automatically freed
    return SUCCESS;
}
```

### 3. Missing DebugStack

**Problem**: Forgot DebugStack_Push/Pop.

**Symptom**: No crash trace on failure.

```c
// BAD
status MyTests(MemCh *m){
    // No DebugStack_Push
    status r = READY;
    // ... tests ...
    return r;  // No DebugStack_Pop
}

// GOOD
status MyTests(MemCh *m){
    DebugStack_Push(NULL, 0);  // Added
    status r = READY;
    // ... tests ...
    DebugStack_Pop();          // Added
    return r;
}
```

### 4. Not Accumulating Status

**Problem**: Overwriting status instead of accumulating.

**Symptom**: Early failures hidden.

```c
// BAD
status r = READY;
r = Test(condition1, "Test 1", NULL);  // FAIL → r = ERROR
r = Test(condition2, "Test 2", NULL);  // PASS → r = SUCCESS (overwrites!)
return r;  // Returns SUCCESS, hiding first failure!

// GOOD
status r = READY;
r |= Test(condition1, "Test 1", NULL);  // FAIL → r = ERROR
r |= Test(condition2, "Test 2", NULL);  // PASS → r still ERROR
return r;  // Correctly returns ERROR
```

### 5. Incorrect Argument Wrapping

**Problem**: Forgetting to wrap primitive types.

**Symptom**: Crash or garbage output.

```c
// BAD
i32 value = 42;
void *args[] = {
    value,  // ERROR! Not a pointer!
    NULL
};
r |= Test(condition, "Value is $", args);  // Crash!

// GOOD
i32 value = 42;
void *args[] = {
    I32_Wrapped(m, value),  // Wrapped
    NULL
};
r |= Test(condition, "Value is $", args);  // Works
```

### 6. External State Contamination

**Problem**: Tests depend on external state.

**Symptom**: Tests pass/fail based on run order.

```c
// BAD
static i32 globalCounter = 0;  // Shared state!

status Test1(MemCh *m){
    globalCounter++;
    r |= Test(globalCounter == 1, "Counter is 1", NULL);
    // Fails if Test2 ran first!
}

status Test2(MemCh *m){
    globalCounter++;
    r |= Test(globalCounter == 1, "Counter is 1", NULL);
    // Fails if Test1 ran first!
}

// GOOD
status Test1(MemCh *m){
    i32 localCounter = 0;  // Isolated
    localCounter++;
    r |= Test(localCounter == 1, "Counter is 1", NULL);
    // Always passes
}
```

### 7. Not Testing Failure Paths

**Problem**: Only testing success cases.

**Symptom**: Production failures not caught.

```c
// BAD
status MyTests(MemCh *m){
    // Only test valid input
    r |= Test(Parse(m, "valid") == SUCCESS, "Parse valid", NULL);
}

// GOOD
status MyTests(MemCh *m){
    // Test valid input
    r |= Test(Parse(m, "valid") == SUCCESS, "Parse valid", NULL);

    // Test invalid input
    r |= Test((Parse(m, "invalid") & ERROR) != 0, "Parse invalid fails", NULL);

    // Test NULL input
    r |= Test((Parse(m, NULL) & ERROR) != 0, "Parse NULL fails", NULL);
}
```

### 8. Large Test Functions

**Problem**: One test function tests too much.

**Symptom**: Hard to debug failures, slow tests.

```c
// BAD
status Everything_Tests(MemCh *m){
    // 500 lines of tests...
    // Tests strings, memory, I/O, parsing, etc.
}

// GOOD
status Str_Tests(MemCh *m){
    // Focused on string operations only
}

status MemCh_Tests(MemCh *m){
    // Focused on memory operations only
}
```

### 9. Magic Numbers

**Problem**: Unexplained constants in tests.

**Symptom**: Unclear test intent.

```c
// BAD
r |= Test(result == 42, "Result is correct", NULL);
// Why 42? What does it represent?

// GOOD
const i32 EXPECTED_USER_COUNT = 42;
r |= Test(result == EXPECTED_USER_COUNT,
    "User count matches expected", NULL);
```

### 10. Not Cleaning Up Test Files

**Problem**: Tests create files but don't remove them.

**Symptom**: Disk fills with test artifacts.

```c
// BAD
status FileTests(MemCh *m){
    File_Create(buffer, Str_FromS(m, "/tmp/test.dat"));
    // ... test ...
    // File left behind!
}

// GOOD
status FileTests(MemCh *m){
    Str *testFile = Str_FromS(m, "/tmp/test.dat");
    File_Create(buffer, testFile);
    // ... test ...
    File_Remove(m, testFile);  // Cleanup
}
```

---


## Next Steps

### Further Reading

1. **[MemCh Complete](../core-concepts/memory/memchapter.md)** - Memory management deep dive
2. **[Type System](../core-concepts/type-system-complete.md)** - Type system and `as()` macro
3. **[Error Handling](../core-concepts/error-handling-complete.md)** - Error propagation patterns
4. **[Fmt System](../core-concepts/format-system-complete.md)** - Output formatting

### Explore Test Source

Study these well-structured test files:

1. **src/programs/test/option/base/str_tests.c** - String testing patterns
2. **src/programs/test/option/base/span_tests.c** - Collection testing
3. **src/programs/test/option/base/memch_tests.c** - Memory hierarchy testing
4. **src/programs/test/option/ext/roebling_tests.c** - Parser testing
5. **src/programs/test/option/inter/http_tests.c** - Integration testing

### Contribute Tests

When adding new features:
1. Write tests first (TDD)
2. Ensure 100% code coverage
3. Test both success and failure paths
4. Verify no memory leaks
5. Add to appropriate suite (base/ext/inter)

---


## Summary

You've learned how to write and run tests in Caneka:

1. **Running Tests** - `./dist/bin/tests` with various flags
2. **Test Structure** - Test functions, registration, organization
3. **Assertions** - `Test()`, `TestShow()` with format strings
4. **Memory Testing** - Automatic leak detection, level system
5. **Test Types** - Unit tests (isolated) vs integration tests (combined)
6. **Debugging** - DebugStack, state inspection, memory debugging
7. **Best Practices** - Isolation, descriptive names, edge cases
8. **Common Pitfalls** - Memory leaks, missing terminators, status accumulation

**Key Principles**:
- **Isolation** - Each test runs in its own MemCh
- **Automatic Leak Detection** - No manual memory tracking needed
- **Clear Output** - Colorized pass/fail with descriptive messages
- **Fast Feedback** - Tests run in milliseconds
- **Type Safety** - Same type system as production code

With these foundations, you can ensure your Caneka code is correct, memory-safe, and production-ready through comprehensive testing.

Happy testing!



---

[← Part 1](testing-part1) | **Part 2 of 2**
