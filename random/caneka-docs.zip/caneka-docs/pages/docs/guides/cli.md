---
sidebar_position: 4
---

# Clineka CLI

## Overview

Clineka is Caneka's general-purpose command-line entry point for working with
the runtime without running the full web server. It is intentionally small and
task-focused. Instead of subcommands, it switches behavior based on which flags
you pass. This makes it easy to wire Clineka into build scripts, conversion
pipelines, or quick inspections while keeping the implementation simple.

Today, Clineka supports three practical workflows:

1. Convert Pencil `.fmt` files to HTML.
2. Inspect reversed BinSeg (`.rbs`) files and print their records.
3. Run a small "forever" process supervisor defined in a `.config` file.

If you are contributing, the CLI is a clean place to add or prototype tools
because it already has argument parsing, Caneka initialization, and IO helpers.

## Where The Binary Lives

After a build, the CLI binary is generated at:

```bash
./build/bin/clineka
```

If you create a distribution build, Clineka may be copied into `dist/bin`, but
the default build output is `build/bin`.

## Argument Model (How All Caneka CLIs Work)

Clineka uses the shared `CliArgs` system in `src/base/termio/args.c`. This is
the same argument model used by other Caneka programs.

Key rules:

- All options are long flags with `--`, for example `--in`, `--out`, `--config`.
- Flags with values are `--key value`.
- Flags with no value are treated as booleans (present or not).
- Multi-value flags accept multiple tokens until the next `--` flag.
- Unknown flags cause help output plus an error.

Global flags currently defined for Clineka:

- `--help`: Print help and exit.
- `--no-color`: Disable ANSI color sequences in output.
- `--in`: Input file path.
- `--out`: Output file path.
- `--config`: Config file path (used by the `forever` supervisor and HTML wrapper).
- `--secret`, `--public`, `--licence`, `--version`: Parsed but not used yet.

## How Clineka Chooses A Mode

This is the decision flow in `src/programs/clineka/main.c`:

1. If `--config` points to a config with a `forever` node, Clineka enters the
   supervisor loop and does not perform any other action.
2. Otherwise, if `--in` and `--out` are provided and the extensions are
   `.fmt` -> `.html`, Clineka runs the Pencil-to-HTML conversion.
3. Otherwise, if `--in` is provided with a `.rbs` file and `--out` is not
   provided, Clineka prints BinSeg records to stdout.
4. Any other flag combination is currently a no-op.

## Workflow 1: Convert Pencil (.fmt) to HTML

This mode uses the Roebling parser to parse `.fmt` into a `Mess` structure and
then uses the Fmt HTML renderer to produce output.

```bash
./build/bin/clineka --in examples/example.fmt --out /tmp/example.html
```

If parsing fails, Clineka prints an error and exits non-zero.

### Optional HTML Wrapper (Header/Footer)

If you want a header and footer wrapped around the generated HTML, supply a
config file with an `html` node:

```config
html {
    header: /absolute/path/to/header.html
    footer: /absolute/path/to/footer.html
}
```

Then run:

```bash
./build/bin/clineka \
  --config /path/to/wrapper.config \
  --in examples/example.fmt \
  --out /tmp/example.html
```

Notes:

- The header/footer paths are read from `html` attributes, not CLI flags.
- If the config has a `forever` node, the supervisor loop will run instead of
  the conversion. Use a config file that only contains the `html` node when
  you want wrapper behavior.

## Workflow 2: Inspect BinSeg (.rbs) Records

When you pass only `--in` and the extension is `.rbs`, Clineka loads the file
as a reversed BinSeg stream and prints each record:

```bash
./build/bin/clineka --in examples/test/pages/forms/signup.rbs
```

This is useful for quick validation and debugging of persisted runtime data.

Current behavior notes:

- Only `.rbs` (reversed format) is handled here.
- The CLI prints the records using Caneka's `Out` formatting.
- There is no filtering or conversion option yet.

## Workflow 3: "Forever" Process Supervisor

If your config file defines a `forever` section, Clineka can run a basic
supervisor loop that restarts a process when it exits.

Example (`examples/forever.config`):

```config
forever {
    cmd: ./build/bin/webserver --no-color --log /basic/logs/webserver
    logdir: /basic/logs/forever
}
```

Run it with:

```bash
./build/bin/clineka --config examples/forever.config
```

Behavior details (from `src/programs/clineka/main.c`):

- `cmd` is split into an argv array and executed with `execvp`.
- The process is respawned if it exits.
- A throttle delay is applied if the process exits too quickly
  (`RESPAWN_THRESHOLD_SEC` is 2 seconds).
- `logdir` is printed in status output but is not used to redirect stdout/stderr
  in the current implementation.

## Output Behavior And Color

Clineka emits ANSI color sequences by default. Use `--no-color` when piping
output into tools that expect plain text.

## Current Limitations (As Implemented)

These are real limitations in the current code:

- Only `.fmt` -> `.html` conversion is supported.
- Only reversed BinSeg (`.rbs`) files are printed.
- `--secret`, `--public`, `--licence`, and `--version` are parsed but unused.
- Placeholder modules (`show`, `unlog`, `translate`) exist but are not wired in.

## Implementation Pointers (For Contributors)

If you want to extend or improve the CLI, these are the key files:

- `src/programs/clineka/main.c`: mode selection and workflow wiring.
- `src/base/termio/args.c`: argument parsing and help rendering.
- `src/ext/format/fmt/`: Pencil parsing and HTML rendering.
- `src/ext/persist/binseg.c`: BinSeg read/write logic.
- `src/ext/format/config/`: config parsing into `NodeObj` structures.
- `examples/forever.config`: example of supervisor config.

Suggested contributions:

- Add new file conversions or format inspections by extending the
  `--in`/`--out` branch in `main.c`.
- Implement `show`, `translate`, or `unlog` features and wire them into the CLI.
- Add tests for new CLI behaviors in `src/programs/test/`.
