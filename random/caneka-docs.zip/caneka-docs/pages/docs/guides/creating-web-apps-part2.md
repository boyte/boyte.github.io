# Creating Web Applications: Complete Tutorial - Part 2

[← Part 1](creating-web-apps-part1) | **Part 2 of 3** | [Part 3 →](creating-web-apps-part3)

---

## Level 6: Sessions and Authentication

**Goal**: Track users across requests with sessions and implement login/logout.

### Session System Overview

Caneka provides built-in session management:
- **SSID** (Session ID) - Unique identifier for each session
- **Stash** - Serialized session data (MemCh snapshot)
- **Login** - User authentication state

### Login Form

**File**: `pages/login.templ`

```templ
<h2>Login</h2>

; error ?
<div class="error">
    <p>{error}</p>
</div>
;

; user ?
<p>Welcome, {user#name}! You are logged in.</p>
<a href="/logout">Logout</a>
; ->
<form method="POST" action="/login">
    <label>
        Username:
        <input type="text" name="username" required>
    </label>

    <label>
        Password:
        <input type="password" name="password" required>
    </label>

    <button type="submit">Login</button>
</form>
;
```

### Session Handler

**File**: `main.c`

```c
#include <caneka.h>
#include <passport/session/ssid.h>
#include <passport/session/login.h>

// Global session context
static SsidCtx *sessionCtx = NULL;

// Login handler
static status Handle_Login(Step *st, Task *tsk){
    MemCh *m = tsk->m;
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    if(ctx->method == HTTP_POST){
        // Get form data
        Str *username = Table_Get(ctx->body, Str_FromS(m, "username"));
        Str *password = Table_Get(ctx->body, Str_FromS(m, "password"));

        // Verify credentials (simplified - use proper hashing in production!)
        if(Str_Equals(username, Str_FromS(m, "admin")) &&
           Str_Equals(password, Str_FromS(m, "secret"))){

            // Create session
            struct timespec ts;
            Time_Now(&ts);

            StrVec *userAgent = Table_Get(ctx->headersIt.p, K(m, "User-Agent"));
            StrVec *ssid = Ssid_Start(sessionCtx, userAgent, &ts);

            // Open session to get data table
            Table *session = Ssid_Open(sessionCtx, ssid, userAgent);

            // Store user data in session
            Table_Set(session, K(m, "username"), username);
            Table_Set(session, K(m, "logged_in"), Single_FromWord(m, 1));

            // Save session
            Ssid_Save(sessionCtx, ssid);

            // Set cookie
            StrVec *cookie = StrVec_Make(m);
            StrVec_AddS(cookie, "ssid=");
            StrVec_AddVec(cookie, ssid);
            StrVec_AddS(cookie, "; Path=/; HttpOnly");
            Table_Set(ctx->headersOut, K(m, "Set-Cookie"), cookie);

            // Redirect to home
            ctx->code = 302;
            Table_Set(ctx->headersOut, K(m, "Location"), K(m, "/"));

        }else{
            // Failed login
            Table_Set(ctx->data, K(m, "error"), K(m, "Invalid credentials"));
        }
    }

    st->type.state |= SUCCESS;
    return SUCCESS;
}

// Logout handler
static status Handle_Logout(Step *st, Task *tsk){
    MemCh *m = tsk->m;
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Get session ID from cookie
    StrVec *cookies = Table_Get(ctx->headersIt.p, K(m, "Cookie"));
    if(cookies != NULL){
        // Parse ssid from "ssid=XXX; other=YYY"
        Cursor *curs = Cursor_Make(m, StrVec_Str(m, cookies));
        // ... cookie parsing logic ...

        // Close session
        Ssid_Close(sessionCtx, ssid);
    }

    // Clear cookie
    Table_Set(ctx->headersOut, K(m, "Set-Cookie"),
              K(m, "ssid=; Path=/; Max-Age=0"));

    // Redirect to home
    ctx->code = 302;
    Table_Set(ctx->headersOut, K(m, "Location"), K(m, "/"));

    st->type.state |= SUCCESS;
    return SUCCESS;
}

// Middleware: Check session on every request
static status Check_Session(Step *st, Task *tsk){
    MemCh *m = tsk->m;
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Get cookies
    StrVec *cookies = Table_Get(ctx->headersIt.p, K(m, "Cookie"));
    if(cookies != NULL){
        // Extract ssid
        StrVec *ssid = ParseCookie(m, cookies, "ssid");
        if(ssid != NULL){
            // Open session
            StrVec *userAgent = Table_Get(ctx->headersIt.p, K(m, "User-Agent"));
            Table *session = Ssid_Open(sessionCtx, ssid, userAgent);

            if(session != NULL){
                Single *loggedIn = Table_Get(session, K(m, "logged_in"));
                if(loggedIn != NULL && loggedIn->val.word == 1){
                    // User is logged in - add to template data
                    Table *user = Table_Make(m);
                    Table_Set(user, K(m, "name"),
                             Table_Get(session, K(m, "username")));
                    Table_Set(ctx->data, K(m, "user"), user);
                }
            }
        }
    }

    st->type.state |= SUCCESS;
    return SUCCESS;
}

int main(int argc, char **argv){
    Caneka_Init();
    Inter_Init();

    MemCh *m = MemCh_Make();

    // Initialize session system
    sessionCtx = SsidCtx_Make(m);
    sessionCtx->path = Str_FromS(m, "./sessions");

    // Create sessions directory
    Dir_Mk(m, sessionCtx->path);

    // Load configuration
    NodeObj *config = Config_FromPath(m, StrVec_FromS(m, "./default.config"));

    // Register handlers
    Table *handlers = Table_Make(m);

    Single *loginHandler = Single_Make(m);
    loginHandler->type.of = TYPE_WRAPPED_PTR;
    loginHandler->val.ptr = Handle_Login;
    Table_Set(handlers, K(m, "loginHandler"), loginHandler);

    Single *logoutHandler = Single_Make(m);
    logoutHandler->type.of = TYPE_WRAPPED_PTR;
    logoutHandler->val.ptr = Handle_Logout;
    Table_Set(handlers, K(m, "logoutHandler"), logoutHandler);

    // Create server
    Task *server = WebServer_Make(3000, 0, NULL);
    WebServer_SetConfig(server, StrVec_FromS(m, "./"), config, handlers);

    // Add session check middleware to all requests
    // (This would require modifying WebServer to support global middleware)

    printf("Server listening on http://localhost:3000\n");
    Task_Tumble(server);

    return 0;
}
```

### Session Flow

**1. Login Request**:
```
POST /login
  username=admin&password=secret
    ↓
Handle_Login
    ↓
Ssid_Start() → Generate session ID: "a1b2c3-1234567890.123456-4f5e"
    ↓
Ssid_Open() → Create session.stash file in ./sessions/a1b2c3-1234567890.123456-4f5e/
    ↓
Table_Set(session, "logged_in", 1)
    ↓
Ssid_Save() → Serialize session to disk
    ↓
Set-Cookie: ssid=a1b2c3-1234567890.123456-4f5e
    ↓
302 Redirect → /
```

**2. Authenticated Request**:
```
GET /profile
  Cookie: ssid=a1b2c3-1234567890.123456-4f5e
    ↓
Check_Session middleware
    ↓
Parse cookie → extract ssid
    ↓
Ssid_Open() → Deserialize ./sessions/a1b2c3-1234567890.123456-4f5e/session.stash
    ↓
Table_Get(session, "logged_in") → 1
    ↓
Add user data to ctx->data
    ↓
Template renders with {user#name}
```

**3. Logout Request**:
```
GET /logout
  Cookie: ssid=a1b2c3-1234567890.123456-4f5e
    ↓
Handle_Logout
    ↓
Ssid_Close() → Remove session directory
    ↓
Set-Cookie: ssid=; Max-Age=0 (delete cookie)
    ↓
302 Redirect → /
```

### Session Security

**User-Agent Verification**:
```c
StrVec *ssid = Ssid_From(ctx, ua, ts);
```
- Session ID includes hash of User-Agent header
- Prevents session hijacking (attacker must match User-Agent)

**HttpOnly Cookie**:
```c
StrVec_AddS(cookie, "; HttpOnly");
```
- JavaScript cannot access cookie
- Prevents XSS attacks from stealing sessions

**Secure Cookie** (for HTTPS):
```c
StrVec_AddS(cookie, "; Secure; SameSite=Strict");
```
- Only sent over HTTPS
- SameSite prevents CSRF

**Session Expiration**:
```c
struct timespec now;
Time_Now(&now);

if(now.tv_sec - session->created.tv_sec > 3600){  // 1 hour
    Ssid_Close(sessionCtx, ssid);  // Expire session
}
```

---


## Complete Example: Blog Application

**Goal**: Build a full-featured blog with posts, comments, and authentication.

### Features

- Public homepage with post list
- Individual post pages with comments
- Admin area (login required)
- Create/edit/delete posts
- BinSeg persistence for posts and comments
- Session-based authentication

### Directory Structure

```
blog/
├── main.c
├── default.config
├── data/
│   ├── posts.rbs          # Post database
│   └── comments.rbs       # Comments database
├── sessions/               # Session storage
└── pages/
    ├── index.templ        # Homepage (post list)
    ├── post.templ         # Single post view
    ├── admin/
    │   ├── login.templ
    │   ├── dashboard.templ
    │   ├── edit-post.templ
    │   └── new-post.templ
    ├── inc/
    │   ├── header.templ
    │   └── footer.html
    └── static/
        ├── style.css
        └── admin.css
```

### Main Configuration

**File**: `default.config`

```
data {
    site {
        title: My Blog
        tagline: Thoughts and musings
    }
}
routes {
    / {
        path: pages/
        ext: templ config
        header: pages/inc/header.templ
        footer: pages/inc/footer.html
    }
    /static {
        path: pages/static/
        ext: css js png jpg
    }
    /admin {
        path: pages/admin/
        ext: templ config
        header: pages/inc/header.templ
        footer: pages/inc/footer.html
    }
    /api {
        path: data/
        ext: rbs
    }
}
nav {
    Home: /
    About: /about
}
```

### Homepage Template

**File**: `pages/index.templ`

```templ
<h2>Recent Posts</h2>

; posts ?
<div class="post-list">
;   posts...
    <article class="post-preview">
        <h3><a href="/post?id={*value#id}">{*value#title}</a></h3>
        <p class="meta">
            By {*value#author} on {*value#date}
        </p>
        <p class="excerpt">{*value#excerpt}</p>
        <a href="/post?id={*value#id}">Read more →</a>
    </article>
;
</div>
; ->
<p>No posts yet. Check back soon!</p>
;

; user#admin ?
<div class="admin-actions">
    <a href="/admin/new-post">+ New Post</a>
</div>
;
```

### Post Page Template

**File**: `pages/post.templ`

```templ
; post ?
<article class="post-full">
    <h2>{post#title}</h2>
    <p class="meta">
        By {post#author} on {post#date}
    </p>

    <div class="content">
        {post#body}
    </div>

    ; user#admin ?
    <div class="admin-actions">
        <a href="/admin/edit-post?id={post#id}">Edit</a>
        <a href="/api/posts?action=delete&id={post#id}"
           onclick="return confirm('Delete this post?')">Delete</a>
    </div>
    ;

    <section class="comments">
        <h3>Comments</h3>

        ; comments ?
        <div class="comment-list">
;           comments...
            <div class="comment">
                <p class="comment-author">{*value#author}</p>
                <p class="comment-date">{*value#date}</p>
                <p class="comment-body">{*value#body}</p>
            </div>
;
        </div>
        ;

        <form method="POST" action="/api/comments?action=add&post_id={post#id}">
            <h4>Add a Comment</h4>
            <label>
                Name:
                <input type="text" name="author" required>
            </label>
            <label>
                Comment:
                <textarea name="body" required></textarea>
            </label>
            <button type="submit">Post Comment</button>
        </form>
    </section>
</article>
; ->
<p>Post not found.</p>
;
```

### Server Implementation

**File**: `main.c`

```c
#include <caneka.h>
#include <passport/session/ssid.h>

static SsidCtx *sessionCtx = NULL;

// Load posts from database
static status Load_Posts(Step *st, Task *tsk){
    MemCh *m = tsk->m;
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Open posts database
    Buff *bf = Buff_Make(m, ZERO);
    status result = File_Open(bf, Str_FromS(m, "./data/posts.rbs"), O_RDONLY);

    if(result == SUCCESS){
        // Deserialize posts
        Shelf *posts = Shelf_Make(m);
        BinSegCtx *bsCtx = BinSegCtx_Make(m);
        BinSegCtx_Receive(bsCtx, bf, posts);

        // Sort by date (newest first)
        // ... sorting logic ...

        Table_Set(ctx->data, K(m, "posts"), posts);
    }

    st->type.state |= SUCCESS;
    return SUCCESS;
}

// Load single post by ID
static status Load_Post(Step *st, Task *tsk){
    MemCh *m = tsk->m;
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Get post ID from query params
    Str *postId = Table_Get(ctx->queryIt.p, K(m, "id"));
    if(postId == NULL){
        ctx->code = 404;
        st->type.state |= FAIL;
        return FAIL;
    }

    // Load all posts
    Shelf *posts = Shelf_Make(m);
    // ... load from database ...

    // Find post by ID
    Table *post = NULL;
    Iter it;
    Iter_Init(&it, posts);
    while((Iter_Next(&it) & END) == 0){
        Table *p = Iter_Get(&it);
        Str *id = Table_Get(p, K(m, "id"));
        if(Str_Equals(id, postId)){
            post = p;
            break;
        }
    }

    if(post == NULL){
        ctx->code = 404;
        st->type.state |= FAIL;
        return FAIL;
    }

    Table_Set(ctx->data, K(m, "post"), post);

    // Load comments for this post
    // ... similar logic ...

    st->type.state |= SUCCESS;
    return SUCCESS;
}

// Session check middleware
static status Check_Session(Step *st, Task *tsk){
    MemCh *m = tsk->m;
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Parse cookies and check for valid session
    // ... cookie parsing ...

    if(session != NULL){
        Single *isAdmin = Table_Get(session, K(m, "admin"));
        if(isAdmin != NULL && isAdmin->val.word == 1){
            Table *user = Table_Make(m);
            Table_Set(user, K(m, "admin"), Single_FromWord(m, 1));
            Table_Set(user, K(m, "name"),
                     Table_Get(session, K(m, "username")));
            Table_Set(ctx->data, K(m, "user"), user);
        }
    }

    st->type.state |= SUCCESS;
    return SUCCESS;
}

// Admin middleware - require login
static status Require_Admin(Step *st, Task *tsk){
    MemCh *m = tsk->m;
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    Table *user = Table_Get(ctx->data, K(m, "user"));
    if(user == NULL){
        // Not logged in - redirect to login
        ctx->code = 302;
        Table_Set(ctx->headersOut, K(m, "Location"), K(m, "/admin/login"));
        st->type.state |= FAIL;
        return FAIL;
    }

    st->type.state |= SUCCESS;
    return SUCCESS;
}

// Create new post
static status Create_Post(Step *st, Task *tsk){
    MemCh *m = tsk->m;
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    if(ctx->method != HTTP_POST){
        st->type.state |= SUCCESS;
        return SUCCESS;
    }

    // Generate post ID
    Str *postId = Str_UniRandom(m, 0, 8);

    // Build post object
    Table *post = Table_Make(m);
    Table_Set(post, K(m, "id"), postId);
    Table_Set(post, K(m, "title"), Table_Get(ctx->body, K(m, "title")));
    Table_Set(post, K(m, "body"), Table_Get(ctx->body, K(m, "body")));
    Table_Set(post, K(m, "author"), Table_Get(ctx->body, K(m, "author")));

    struct timespec ts;
    Time_Now(&ts);
    Table_Set(post, K(m, "date"), Time_ToStr(m, &ts));

    // Append to database
    BinSegCtx *bsCtx = BinSegCtx_Make(m);
    bsCtx->path = StrVec_FromS(m, "./data/posts.rbs");
    BinSegCtx_Send(bsCtx, post);

    // Redirect to new post
    ctx->code = 302;
    StrVec *location = StrVec_Make(m);
    StrVec_AddS(location, "/post?id=");
    StrVec_Add(location, postId);
    Table_Set(ctx->headersOut, K(m, "Location"), location);

    st->type.state |= SUCCESS;
    return SUCCESS;
}

int main(int argc, char **argv){
    Caneka_Init();
    Inter_Init();

    MemCh *m = MemCh_Make();

    // Initialize sessions
    sessionCtx = SsidCtx_Make(m);
    sessionCtx->path = Str_FromS(m, "./sessions");
    Dir_Mk(m, sessionCtx->path);

    // Create data directory
    Dir_Mk(m, Str_FromS(m, "./data"));

    // Load configuration
    NodeObj *config = Config_FromPath(m, StrVec_FromS(m, "./default.config"));

    // Register handlers
    Table *handlers = Table_Make(m);

    #define REGISTER_HANDLER(name, func) do { \
        Single *h = Single_Make(m); \
        h->type.of = TYPE_WRAPPED_PTR; \
        h->val.ptr = func; \
        Table_Set(handlers, K(m, name), h); \
    } while(0)

    REGISTER_HANDLER("loadPosts", Load_Posts);
    REGISTER_HANDLER("loadPost", Load_Post);
    REGISTER_HANDLER("checkSession", Check_Session);
    REGISTER_HANDLER("requireAdmin", Require_Admin);
    REGISTER_HANDLER("createPost", Create_Post);

    // Create server
    Task *server = WebServer_Make(3000, 0, NULL);
    WebServer_SetConfig(server, StrVec_FromS(m, "./"), config, handlers);

    printf("Blog server listening on http://localhost:3000\n");
    printf("\n");
    printf("Pages:\n");
    printf("  http://localhost:3000/              - Homepage (post list)\n");
    printf("  http://localhost:3000/post?id=XXX   - Individual post\n");
    printf("  http://localhost:3000/admin/login   - Admin login\n");
    printf("  http://localhost:3000/admin/new-post - Create new post\n");
    printf("\n");

    Task_Tumble(server);

    return 0;
}
```

### Page Configurations

**File**: `pages/index.config`

```
page {
    title: Home
    handlers: checkSession loadPosts
}
```

**File**: `pages/post.config`

```
page {
    title: Post
    handlers: checkSession loadPost
}
```

**File**: `pages/admin/new-post.config`

```
page {
    title: New Post
    handlers: checkSession requireAdmin createPost
}
```

### Building and Running

```bash
# Compile
gcc -I./dist/include -L./dist/lib main.c -lcaneka -o blog

# Run
./blog

# Create first post (as admin):
# 1. Login at http://localhost:3000/admin/login
# 2. Navigate to http://localhost:3000/admin/new-post
# 3. Fill form and submit
# 4. View at http://localhost:3000/
```

---


## Best Practices

### 1. Use Configuration Files for Routes

**Why**: Changing routes doesn't require recompilation.

```c
// GOOD - routes from config
NodeObj *config = Config_FromPath(m, path);
WebServer_SetConfig(server, basePath, config, handlers);

// BAD - hardcoded routes
Route *root = Route_Make(m);
Route *aboutRoute = Route_Make(m);
// ... manual setup for every route ...
```

### 2. Separate Data Handlers from Templates

**Why**: Keeps logic out of templates, easier to test.

```c
// GOOD - C handler gathers data
static status Load_Stats(Step *st, Task *tsk){
    Table *stats = CalculateStats();
    Table_Set(ctx->data, K(m, "stats"), stats);
}

// BAD - complex logic in template
// (Templates should only handle presentation)
```

### 3. Use BinSeg for Structured Data

**Why**: Type-safe serialization, efficient storage, easy querying.

```c
// GOOD - BinSeg for persistent data
BinSegCtx_Send(bsCtx, post);  // Serialize entire structure

// BAD - manual file I/O
fprintf(file, "%s|%s|%s\n", title, author, body);  // Fragile, no types
```

### 4. Always Validate User Input

**Why**: Security - prevent injection attacks.

```c
// GOOD - validate before use
Str *email = Table_Get(ctx->body, K(m, "email"));
if(!Str_IsValidEmail(email)){
    Table_Set(ctx->data, K(m, "error"), K(m, "Invalid email"));
    return SUCCESS;
}

// BAD - trust user input
// (Could lead to XSS, SQL injection if passed to other systems)
```

### 5. Use HttpOnly and Secure Cookies

**Why**: Security - prevent XSS and MITM attacks.

```c
// GOOD - secure cookies
StrVec_AddS(cookie, "; HttpOnly; Secure; SameSite=Strict");

// BAD - exposed cookies
StrVec_AddS(cookie, "");  // JavaScript can read, sent over HTTP
```

### 6. Structure Templates with Includes

**Why**: DRY - don't repeat header/footer code.

```
# GOOD - reusable header/footer
routes {
    / {
        header: pages/inc/header.templ
        footer: pages/inc/footer.html
    }
}

# BAD - copy header/footer to every template
```

### 7. Use Middleware Pattern for Cross-Cutting Concerns

**Why**: Session checks, logging, auth apply to multiple routes.

```c
// GOOD - session check as middleware
page {
    handlers: checkSession loadData
}

// BAD - duplicate session check in every handler
static status LoadData(Step *st, Task *tsk){
    // ... session check code duplicated ...
    // ... actual data loading ...
}
```

### 8. Handle Errors Gracefully

**Why**: User experience - don't crash on invalid input.

```c
// GOOD - check for NULL
Str *postId = Table_Get(ctx->queryIt.p, K(m, "id"));
if(postId == NULL){
    ctx->code = 404;
    // Load 404 template
    return SUCCESS;
}

// BAD - assume data exists
Str_Len(postId);  // Crashes if NULL!
```

### 9. Use ETags for Static Assets

**Why**: Performance - browser caching reduces bandwidth.

```c
// Automatic with ROUTE_ASSET flag
routes {
    /static {
        ext: css js png jpg
    }
}
// Server automatically generates ETags and handles If-None-Match
```

The `ext` list should include every asset extension you serve.

### 10. Keep Templates Simple

**Why**: Maintainability - complex logic belongs in C.

```templ
<!-- GOOD - simple iteration and display -->
; posts...
    <div>{*value#title}</div>
;

<!-- BAD - complex calculations in template -->
<!-- (Move to C handler instead) -->
```

---


## Common Pitfalls

### 1. Forgetting to Register Handlers

**Problem**: Config references `handlers: myHandler` but handler not registered.

**Symptom**: Handler never called, no data in template.

**Fix**:
```c
Table *handlers = Table_Make(m);
Single *h = Single_Make(m);
h->type.of = TYPE_WRAPPED_PTR;
h->val.ptr = MyHandler;
Table_Set(handlers, K(m, "myHandler"), h);  // Must match config name!
```

### 2. Wrong Route Extension

**Problem**: File is `page.templ` but config says `ext: html`.

**Symptom**: 404 Not Found.

**Fix**:
```
routes {
    / {
        ext: templ config
    }
}
```

### 3. Template Syntax Errors

**Problem**: Missing `;` to close iteration or conditional.

**Symptom**: Parse error or wrong rendering.

**Fix**:
```templ
; items...
    <div>{*value}</div>
;  <!-- Must have this closing semicolon! -->
```

### 4. Memory Leaks in Handlers

**Problem**: Allocating with `malloc()` instead of `MemCh`.

**Symptom**: Growing memory usage over time.

**Fix**:
```c
// GOOD
Table *data = Table_Make(m);  // Uses MemCh, auto-freed

// BAD
Table *data = malloc(sizeof(Table));  // Leaks!
```

### 5. Not Setting Content-Type

**Problem**: Forgetting to set `http->mime`.

**Symptom**: Browser doesn't render correctly (downloads instead of displays).

**Fix**:
```c
http->mime = Str_FromS(m, "text/html; charset=utf-8");
```

### 6. Incorrect Path Handling

**Problem**: Using relative paths instead of IoUtil_Annotate.

**Symptom**: Routes don't resolve.

**Fix**:
```c
// GOOD
StrVec *path = StrVec_FromS(m, "/static/style.css");
IoUtil_Annotate(m, path);  // Normalizes path

// BAD
// Using raw strings without normalization
```

### 7. Session Hijacking Vulnerability

**Problem**: Not verifying User-Agent in session validation.

**Symptom**: Session can be stolen and used from different browser.

**Fix**:
```c
Table *session = Ssid_Open(sessionCtx, ssid, userAgent);
// Ssid_Open checks User-Agent hash in session ID
```

### 8. BinSeg File Corruption

**Problem**: Writing to BinSeg file from multiple handlers simultaneously.

**Symptom**: Corrupted database file.

**Fix**: Use file locking or queue writes through single handler.

### 9. Large Response Buffering

**Problem**: Loading entire large file into memory before sending.

**Symptom**: High memory usage, slow responses.

**Fix**:
```c
// GOOD - unbuffered I/O
bf->type.state |= BUFF_UNBUFFERED;
File_Open(bf, path, O_RDONLY);  // Streams to client

// BAD - load entire file
Str *contents = File_ReadAll(m, path);  // 100MB file!
```

### 10. Not Handling POST Redirect

**Problem**: Rendering template directly after POST.

**Symptom**: Browser refresh re-submits form (duplicate entries).

**Fix**:
```c
// GOOD - POST-Redirect-GET pattern
if(ctx->method == HTTP_POST){
    ProcessForm(ctx->body);
    ctx->code = 302;  // Redirect
    Table_Set(ctx->headersOut, K(m, "Location"), K(m, "/success"));
}

// BAD - render template after POST
if(ctx->method == HTTP_POST){
    ProcessForm(ctx->body);
    // Render template - causes duplicate submission on refresh
}
```

---


## Deployment

### Production Server Setup

**1. Build Optimized Binary**:
```bash
gcc -O3 -I./dist/include -L./dist/lib main.c -lcaneka -o server
strip server  # Remove debug symbols
```

**2. Run as System Service**:

**systemd Unit** (`/etc/systemd/system/caneka-blog.service`):
```ini
[Unit]
Description=Caneka Blog Server
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/blog
ExecStart=/var/www/blog/server
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```

**Enable and Start**:
```bash
sudo systemctl enable caneka-blog
sudo systemctl start caneka-blog
sudo systemctl status caneka-blog
```

**3. Reverse Proxy with Nginx**:

**Nginx Config** (`/etc/nginx/sites-available/blog`):
```nginx
server {
    listen 80;
    server_name blog.example.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Optional: serve static files directly from Nginx
    location /static/ {
        alias /var/www/blog/pages/static/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

**Enable SSL** (with Let's Encrypt):
```bash
sudo certbot --nginx -d blog.example.com
```

**4. Logging**:

Add logging to your server:
```c
static status WebServer_logAndClose(Step *st, Task *tsk){
    TcpCtx *tcp = (TcpCtx *)as(tsk->source, TYPE_TCP_CTX);
    ProtoCtx *proto = (ProtoCtx *)as(tsk->data, TYPE_PROTO_CTX);
    HttpCtx *ctx = (HttpCtx *)as(proto->ctx, TYPE_HTTP_CTX);

    // Log format: IP - - [timestamp] "METHOD /path HTTP/1.1" status size
    fprintf(stderr, "%s - - [%s] \"%s %s HTTP/1.1\" %d %ld\n",
            IpToStr(tcp->clientIp),
            Time_ToStr(m, &tsk->created),
            HttpMethod_ToStr(ctx->method),
            StrVec_ToS(ctx->path),
            ctx->code,
            ctx->contentLength);

    return SUCCESS;
}
```

**5. Monitoring**:

Add health check endpoint:
```c
static status Health_Check(Step *st, Task *tsk){
    HttpCtx *ctx = GetHttpCtx(tsk);

    ctx->code = 200;
    ctx->mime = Str_FromS(m, "application/json");

    Buff *body = GetOutputBuffer(tsk);
    Fmt(body, "{\"status\":\"ok\",\"uptime\":$}", Time_Uptime());

    return SUCCESS;
}
```

Access at: `http://localhost:3000/health`

**6. Backup Strategy**:

BinSeg files:
```bash
# Daily backup script
#!/bin/bash
tar -czf /backup/blog-data-$(date +%Y%m%d).tar.gz /var/www/blog/data/
find /backup/ -name "blog-data-*.tar.gz" -mtime +30 -delete  # Keep 30 days
```

---


## Performance Optimization

### 1. Enable Compression

Add gzip compression in Nginx:
```nginx
gzip on;
gzip_types text/css application/javascript text/html;
gzip_min_length 1000;
```

### 2. Connection Pooling

Caneka reuses connection buffers:
```c
// Automatic - ProtoCtx buffers are recycled
// No manual pooling needed
```

### 3. Template Caching

Templates are parsed once and reused:
```c
// Templates cached in Route object
Route *route = Route_Get(pages, path);
Templ *templ = Seel_Get(route, K(m, "templ"));  // Cached
Templ_Reset(templ);  // Resets state, not structure
Templ_ToS(templ, bf, data, NULL);  // Renders without re-parsing
```

### 4. ETag Caching

Assets automatically use ETags:
- Server calculates hash on first request
- Stores in Route object
- Subsequent requests check `If-None-Match`
- Returns 304 Not Modified if match

### 5. Memory Chapter Isolation

Each connection gets its own MemCh:
- Memory allocated per-request
- Automatically freed when connection closes
- No cross-request memory leaks
- Cache-friendly allocation patterns

---



---

[← Part 1](creating-web-apps-part1) | **Part 2 of 3** | [Part 3 →](creating-web-apps-part3)
