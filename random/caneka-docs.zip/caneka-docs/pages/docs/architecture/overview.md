---
sidebar_position: 1
---

# Architecture Overview

Caneka is built on a carefully designed three-layer architecture that provides transparency, composability, and minimal dependencies. This document explains the overall system structure and design philosophy.

## The Three-Layer System

Caneka organizes its components into three primary layers, each building on the previous:

```
┌─────────────────────────────────────┐
│         Programs Layer              │
│  (webserver, tests, cli, buildeka)  │
└─────────────────────────────────────┘
              ↓ uses
┌─────────────────────────────────────┐
│          Inter Layer                │
│   (HTTP, Templates, Web Server)     │
└─────────────────────────────────────┘
              ↓ uses
┌─────────────────────────────────────┐
│           Ext Layer                 │
│  (Parser, Navigate, Seel, Serve)    │
└─────────────────────────────────────┘
              ↓ uses
┌─────────────────────────────────────┐
│           Base Layer                │
│   (Memory, Types, I/O, Sequences)   │
└─────────────────────────────────────┘
```

### Layer 1: Base
**Foundation components that require no other Caneka modules**

- Virtual memory management (MemBook, MemChapter, MemPage)
- Type system and error handling
- String and byte operations
- Sequences (arrays, lookups, hash tables)
- I/O operations (files, sockets, directories)
- Debug utilities

**Source**: `src/base/` (178 files, ~11,400 lines)

### Layer 2: Ext (Extended)
**Advanced features that build on Base**

- Roebling parser (pattern matching and DSL creation)
- Navigate (Task/Step workflow system)
- Seel (object property caching)
- Network server
- Formatting and persistence

**Source**: `src/ext/` (134 files, ~5,400 lines)

### Layer 3: Inter (Intermediate)
**Web-facing components that combine Base and Ext**

- HTTP protocol handling
- Templ template engine
- Web server utilities
- Document rendering

**Source**: `src/inter/` (62 files)

### Programs
**Executable applications using all layers**

- Web server
- Test suite
- CLI tools (clineka)
- Build system (buildeka)
- Documentation generator

**Source**: `src/programs/` (82 files)

## Design Philosophy

### Transparency

The "glass-bottom-boat" philosophy means you can see exactly what's happening at every level:

1. **No hidden abstractions**: Every component is implemented in readable C
2. **Source available**: All 456 C files can be inspected and understood
3. **Minimal magic**: Explicit over implicit wherever possible
4. **Debuggable**: Step through any operation with a debugger

### Composability

Each layer provides reusable components that combine cleanly:

1. **Clear interfaces**: Well-defined APIs between layers
2. **Minimal coupling**: Layers depend only on lower layers
3. **Reusable primitives**: Components can be used independently
4. **Extensible**: Add new features without modifying existing code

### Minimal Dependencies

The entire system requires only:

1. **POSIX OS**: Standard Unix-like environment
2. **C Compiler**: clang or gcc
3. **LibC**: Standard C library

No external libraries, no package managers, no runtime dependencies.

## Component Relationships

### Base Layer Components

```
base/
├── mem/         → Memory management (core primitive)
├── types/       → Type system (uses mem)
├── bytes/       → Strings (uses mem, types)
├── sequence/    → Arrays, lookups (uses mem, types, bytes)
├── io/          → File, socket I/O (uses mem, types, bytes)
├── encode/      → Hex encoding (uses bytes)
├── debug/       → Debugging (uses all base)
└── util/        → Utilities (standalone)
```

### Ext Layer Components

```
ext/
├── parser/      → Roebling parser (uses base)
├── navigate/    → Task/Step workflow (uses base, parser)
├── types/       → Seel object system (uses base)
├── serve/       → Network server (uses base, navigate)
├── format/      → Formatting (uses base, parser)
├── persist/     → Persistence (uses base)
└── option/      → Options (uses base)
```

### Inter Layer Components

```
inter/
├── http/        → HTTP handling (uses base, ext)
├── templ/       → Templates (uses base, parser)
├── www/         → Web server (uses base, ext, http)
└── doc/         → Documents (uses base, parser, http)
```

## Module Independence

One of Caneka's strengths is that components can often be used independently:

**Use just the memory manager**:
```c
#include "mem/mem_book.h"
MemBook *book = MemBook_Make(NULL);
```

**Use just the parser**:
```c
#include "parser/roebling.h"
Roebling *parser = Roebling_Make();
```

**Use the full stack**:
```c
#include "www/server.h"
Server *srv = Server_Make();
```

Each component has clear dependencies that are easy to track.

## Build Order

The layered architecture determines build order:

1. **Base** - Must build first (no dependencies)
2. **Ext** - Requires Base
3. **Inter** - Requires Base and Ext
4. **Programs** - Require all layers

The build system (buildeka) handles this automatically through `dependencies.txt` files in each module.

## Memory Management Throughout

All layers use the Base memory management system:

- **Consistent allocation**: Everything uses MemBook/MemChapter
- **No hidden malloc**: All allocations go through the memory manager
- **Trackable**: Can inspect and debug all memory usage
- **Efficient**: Page-based allocation with recycling

See [Memory Management](../core-concepts/memory/overview.md) for details.

## Type System Throughout

The Base type system provides runtime type information across all layers:

- **Type checking**: Runtime verification of types
- **Error handling**: Consistent error patterns
- **Introspection**: Query types at runtime
- **Safety**: Catch type mismatches early

See [Types Documentation](../api-reference/base.md#types) for details.

## Example: HTTP Request Flow

To understand how layers work together, let's trace an HTTP request:

1. **Base (I/O)**: Socket receives data
2. **Base (bytes)**: Parse bytes into strings
3. **Ext (serve)**: Network server accepts connection
4. **Inter (HTTP)**: Parse HTTP protocol
5. **Inter (templ)**: Render template with data
6. **Base (bytes)**: Format response
7. **Base (I/O)**: Send response through socket

Each layer handles its responsibility cleanly.

## Comparison to Traditional Stacks

Traditional web stack:
```
Application Code
  ↓
Web Framework (Django, Rails, Express)
  ↓
Language Runtime (Python, Ruby, Node.js)
  ↓
System Libraries
  ↓
Operating System
```

Caneka stack:
```
Application Code
  ↓
Caneka (Base → Ext → Inter)
  ↓
Operating System
```

Fewer layers means:
- More transparency
- Easier debugging
- Better performance potential
- Smaller attack surface

## Next Steps

Dive deeper into each layer:

- [Base Layer](base-layer.md) - Memory, types, I/O fundamentals
- [Ext Layer](ext-layer.md) - Parser, workflow, networking
- [Inter Layer](inter-layer.md) - HTTP, templates, web serving

Or explore specific concepts:

- [Memory Management](../core-concepts/memory/overview.md)
- [Roebling Parser](../core-concepts/parser/overview.md)
- [Navigate System](../core-concepts/navigate/overview.md)
