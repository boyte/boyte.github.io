---
sidebar_position: 2
---

# Base Layer

The Base layer is the foundation of Caneka, providing core functionality that all other components build upon. It has zero dependencies on other Caneka modules and requires only POSIX and the C standard library.

## Overview

**Location**: `src/base/` (178 files, ~11,400 lines)

**Purpose**: Provide fundamental building blocks for memory, types, I/O, and data structures

**Dependencies**: None (only POSIX + LibC)

## Core Components

### Memory Management (`mem/`)

Custom memory manager providing:
- **MemBook**: Top-level memory allocation unit
- **MemChapter**: Mid-level allocation container
- **MemPage**: Page-level memory blocks
- **Span**: Flexible array structure
- **Iter**: Iterator for traversing memory

See [Memory Management](../core-concepts/memory/overview.md) for detailed documentation.

### Type System (`types/`)

Runtime type information and error handling:
- Type definitions and checking
- Error status codes
- Type guards and validation
- Cloning and equality checking

### String and Byte Operations (`bytes/`)

String handling and formatting:
- String vectors
- Formatted output
- String cursors
- Byte manipulation

### Sequences (`sequence/`)

Data structure primitives:
- Arrays and dynamic arrays
- Hash tables
- Key-value lookups
- Shelving (storage system)

### I/O Operations (`io/`)

File and network I/O:
- File operations
- Socket handling
- Directory traversal
- Buffers
- Subprocess management

### Additional Components

- **Debug** (`debug/`): Debugging utilities, stack inspection
- **Encode** (`encode/`): Hex encoding
- **Terminal I/O** (`termio/`): CLI utilities, ANSI strings
- **Utilities** (`util/`): Integer utilities, timing, singletons

## Design Principles

### OS-Independent Memory Manager

The Base memory system doesn't rely on malloc/free:

```c
MemBook *book = MemBook_Make(NULL);
void *mem = MemCh_AllocOf(book, size, type);
// Memory is tracked and can be freed in bulk
MemBook_WipePages(book);
```

This provides:
- Consistent allocation patterns
- Bulk deallocation
- Memory tracking and statistics
- Page recycling

### Explicit Type System

Every allocated object has a type:

```c
typedef struct {
    Type type;  // Runtime type information
    // ... data fields
} MyStruct;
```

Benefits:
- Runtime type checking
- Introspection capabilities
- Debugging support

### Minimal Abstractions

Base components are intentionally low-level:
- Direct memory access when needed
- Explicit error handling
- No hidden allocations
- Predictable performance

## Key Header Files

- `src/base/include/mem/mem_book.h` - Memory management API
- `src/base/include/types/type.h` - Type system
- `src/base/include/bytes/str_vec.h` - String operations
- `src/base/include/sequence/array.h` - Arrays and sequences
- `src/base/include/io/file.h` - File I/O

## Usage Example

```c
#include "base/include/mem/mem_book.h"
#include "base/include/bytes/str_vec.h"
#include "base/include/types/type.h"

int main() {
    // Create memory book
    MemBook *book = MemBook_Make(NULL);
    
    // Allocate a string vector
    StrVec *str = StrVec_Make(book);
    StrVec_Add(str, "Hello, Caneka!");
    
    // Use the string
    printf("%s\n", StrVec_GetCStr(str));
    
    // Clean up (frees all allocations from this book)
    MemBook_WipePages(book);
    
    return 0;
}
```

## Next Steps

- Explore [Memory Management](../core-concepts/memory/overview.md) in depth
- Review [API Reference](../api-reference/base.md) for all Base functions
- See [Ext Layer](ext-layer.md) to learn what builds on Base
