---
sidebar_position: 3
---

# Ext (Extended) Layer

The Extended layer builds on Base to provide advanced features like parsing, workflow management, networking, and object systems.

## Overview

**Location**: `src/ext/` (134 files, ~5,400 lines)

**Purpose**: Advanced functionality for parsers, servers, and workflows

**Dependencies**: Base layer only

## Core Components

### Roebling Parser (`parser/`)

Pattern matching and DSL creation engine:

- Pattern-based tokenization
- Syntax-agnostic parsing
- DSL generation
- String splitting and matching

Think of it as "a regular expression engine that can generate and run data structures."

See [Roebling Parser](../core-concepts/parser/overview.md) for detailed documentation.

### Navigate System (`navigate/`)

Task/Step workflow management:

- **Task**: Work unit with steps
- **Step**: Individual operation in a task
- **Queue**: Critical section management
- **Frame**: Execution context
- **Relation**: Dependencies between tasks

Enables asynchronous, queue-managed workflows.

See [Navigate System](../core-concepts/navigate/overview.md) for details.

### Seel Type System (`types/`)

Object property caching and class system:

- Property caching for performance
- Object lifecycle management
- Interface definitions
- Type instantiation

### Network Server (`serve/`)

Low-level networking:

- Socket management
- Connection handling
- Non-blocking I/O
- Server lifecycle

## Usage Patterns

### Using the Parser

```c
#include "ext/include/parser/roebling.h"

Roebling *parser = Roebling_Make();
// Define pattern
Roebling_AddPattern(parser, "word");
// Match against input
RoeblingMatch *match = Roebling_Parse(parser, "hello");
```

### Using Navigate

```c
#include "ext/include/navigate/task.h"

Task *task = Task_Make();
Task_AddStep(task, step_function, data);
Task_Execute(task);
```

## Next Steps

- [Roebling Parser Details](../core-concepts/parser/overview.md)
- [Navigate Workflow Details](../core-concepts/navigate/overview.md)
- [Inter Layer](inter-layer.md) - What builds on Ext
