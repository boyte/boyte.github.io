---
sidebar_position: 4
---

# Inter (Intermediate) Layer

The Inter layer provides web-facing functionality, combining Base and Ext components to deliver HTTP handling, templating, and web serving capabilities.

## Overview

**Location**: `src/inter/` (62 files)

**Purpose**: HTTP, templates, and web server

**Dependencies**: Base and Ext layers

## Core Components

### HTTP Handling (`http/`)

Complete HTTP protocol implementation:

- Request parsing
- Response formatting
- Header management
- Session handling
- Cookie management
- Status codes

### Templ Template Engine (`templ/`)

HTML templating with custom syntax:

- Variable substitution: `{variable}`
- Iteration: `; collection... ; *item: ... ;`
- Nested templates
- Conditional rendering
- Static and dynamic content

See [Template Engine](../core-concepts/templ.md) for syntax details.

### Web Server (`www/`)

HTTP web server implementation:

- Request routing
- Static file serving
- Dynamic content generation
- Configuration management
- Multi-threaded serving

### Document Rendering (`doc/`)

Document format rendering:

- Pencil (.fmt) to HTML conversion
- Markdown-like syntax
- Link handling
- List generation

## Usage Example

### Simple HTTP Server

```c
#include "inter/include/www/server.h"

Server *srv = Server_Make();
Server_Listen(srv, 8080);
Server_Start(srv);
```

### Template Rendering

```templ
<h1>Welcome to {site.name}</h1>
<ul>
; users...
; *user:
  <li>{*user.name} - {*user.email}</li>
;
</ul>
```

## Next Steps

- [Template Engine Documentation](../core-concepts/templ.md)
- [Custom Formats](../formats/templ.md)
- [API Reference](../api-reference/inter.md)
