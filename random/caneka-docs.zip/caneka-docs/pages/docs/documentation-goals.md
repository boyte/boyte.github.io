---
sidebar_position: 2
---

# Documentation Goals

This documentation exists to build a shared, precise understanding of Caneka
before any DSL changes are attempted. The priority is clarity and accuracy over
new features or redesigns.

## Goals

- Capture how the language and runtime behave today, as implemented.
- Establish a single canonical reference in `documentation/docs/`.
- Distinguish "spec intent" from "implementation details."
- Identify gaps, ambiguities, and inconsistencies for follow-up.
- Provide examples that reflect real usage in `examples/` and `src/`.

## Principles

- Be explicit about what is verified vs inferred.
- Keep terminology consistent across layers and formats.
- Prefer simple, testable statements over broad claims.
- Reference code paths when describing behavior.

## Scope

In scope:
- `.cnk`, `templ`, `pencil/.fmt`, and `config` formats
- Roebling pattern matching and capture flow
- Base, Ext, Inter, and Programs layer architecture
- CLI workflows and build behavior

Out of scope (unless requested):
- DSL redesigns
- Runtime refactors for readability
- Large-scale architecture changes

## Sources of truth

- Code in `src/`
- Examples in `examples/` and `docs/`
- Runtime behavior verified by tests and CLI usage

## Contribution workflow

1. Read existing docs and the relevant code paths.
2. Cross-check docs against implementation and examples.
3. Update or add docs with concrete, verifiable details.
4. Record open questions or unknowns for later.

For repo-wide process details, see `AGENTS.md`.
