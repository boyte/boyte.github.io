#!/bin/bash
set -e

echo "Building Caneka Docs..."

if [ ! -f "../build/libcnkbase/libcnkbase.a" ]; then
    echo "Error: Caneka not built. Run ./build.sh in main directory first."
    exit 1
fi

# Find all .c files that exist (incremental)
sources=""
for file in src/*.c src/**/*.c; do
    if [ -f "$file" ]; then
        sources="$sources $file"
        echo "  Including: $file"
    fi
done

if [ -z "$sources" ]; then
    echo "Error: No source files found in src/"
    exit 1
fi

# Compile all existing sources
gcc -o caneka-docs \
    -I../build/include \
    -I../src/api/include \
    -I../src/base/include \
    -I../src/ext/include \
    -I../src/inter/include \
    -I../src/programs/webserver/include \
    $sources \
    -L../build/libcnkinter \
    -L../build/libcnkext \
    -L../build/libcnkbase \
    -lcnkinter -lcnkext -lcnkbase \
    -O2 -Wall -Wextra

echo "Build complete! Binary: ./caneka-docs"
echo "Sources compiled: $(echo $sources | wc -w)"
