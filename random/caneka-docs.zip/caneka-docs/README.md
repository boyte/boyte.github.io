# Caneka Documentation Server

A standalone documentation server built entirely in C using Caneka's runtime primitives. This project serves the Caneka documentation using a custom HTTP server and markdown parser, demonstrating Caneka's capability as a complete web development stack.

## Features

- **Custom HTTP Server**: Built from TCP sockets using Caneka primitives
- **Markdown Parser**: Custom parser handling frontmatter, block elements, and inline formatting
- **Sidebar Navigation**: Collapsible navigation with active state highlighting
- **Zero Dependencies**: No external libraries except Google Fonts (via CDN)
- **Memory Safe**: Request-scoped memory management using MemCh

## Prerequisites

### Running Pre-built Binary (macOS only)

- **macOS**: Apple Silicon (arm64) required for included binary
- **No build tools needed**: The executable is ready to run

### Building from Source

- **C Compiler**: GCC or Clang
- **Caneka Repository**: Must be built in parent directory structure
- **Caneka Libraries**: libcnkbase, libcnkext, libcnkinter (built via `../build.sh`)
- **Unix-like OS**: macOS, Linux, or WSL

**Important:** This project cannot be built standalone. It must be within the Caneka repository structure to access Caneka libraries and headers.

## Quick Start

### Build

```bash
./build.sh
```

This compiles all source files and creates the `caneka-docs` executable.

### Run

```bash
./caneka-docs --port 3000
```

Or use a custom port:

```bash
./caneka-docs --port 8080
```

Visit `http://localhost:3000/docs/intro` to view the documentation.

## Configuration

The server accepts the following options:

- `--port <number>`: Server port (default: 3000)
- `--root <path>`: Document root directory (default: ./pages)
- `--help`: Show help message

## Project Structure

```
caneka-docs/
├── src/
│   ├── main.c                  # Entry point and server configuration
│   ├── http.c                  # HTTP/1.1 server implementation
│   ├── router.c                # URL routing and request handling
│   ├── markdown/               # Markdown parser
│   │   ├── markdown.c          # Parser orchestration
│   │   ├── md_frontmatter.c    # YAML frontmatter parsing
│   │   ├── md_block.c          # Block elements (headers, lists, code)
│   │   ├── md_inline.c         # Inline elements (bold, italic, links)
│   │   └── md_html.c           # HTML generation
│   └── sidebar/                # Sidebar navigation
│       ├── sidebar.c           # Sidebar HTML rendering
│       └── sidebar_parser.c    # Config file parsing
├── pages/
│   ├── docs/                   # Markdown documentation files
│   └── sidebar.config          # Sidebar navigation structure
├── build.sh                    # Build script
├── .gitignore                  # Git ignore patterns
└── README.md                   # This file
```

## Adding Documentation

1. Place markdown files in `pages/docs/`
2. Add frontmatter with title and position:
   ```yaml
   ---
   sidebar_position: 1
   ---
   ```
3. Update `pages/sidebar.config` to include the new page
4. Restart the server

## Memory Management

All allocations use Caneka's MemCh (Memory Chapter) system:
- One MemCh per HTTP request
- Automatic cleanup after response sent
- No memory leaks between requests

## Security

Built-in protections:
- **Path Traversal**: Rejects `..` in URLs
- **XSS Prevention**: HTML entity escaping in generated output
- **Input Validation**: HTTP header size limits

## Architecture

```
User Browser
     │
     ↓ HTTP Request
HTTP Server (src/http.c)
     │
     ↓ URL Routing
Router (src/router.c)
     │
     ├─→ Markdown Handler → Parser → Templ → HTML
     │                       (src/markdown/)
     │
     └─→ Static Handler → MIME Lookup → File
                          (CSS, JS, images)
```

### Key Components

**HTTP Server** (`src/http.c`): Handles TCP connections, parses HTTP/1.1 requests, generates responses.

**Router** (`src/router.c`): URL pattern matching, request dispatching, HTML page assembly with sidebar.

**Markdown Parser** (`src/markdown/`):
- Frontmatter parsing (YAML)
- Block elements (headers, paragraphs, lists, code blocks, tables)
- Inline elements (bold, italic, code, links)
- HTML generation with proper escaping

**Sidebar** (`src/sidebar/`): Parses sidebar.config and generates collapsible navigation with active state highlighting.

## Build Process

The `build.sh` script performs incremental compilation:
1. Compiles modified source files
2. Links with Caneka base library
3. Creates `caneka-docs` executable

Build dependencies are tracked automatically - only modified files are recompiled.

## Troubleshooting

### Port Already in Use

```bash
# Find and kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Or use a different port
./caneka-docs --port 8080
```

### Build Errors

Rebuild Caneka base library first:

```bash
cd ..
./build.sh
cd caneka-docs
./build.sh
```

### Page Not Found (404)

1. Ensure file exists in `pages/docs/`
2. Check filename uses only alphanumeric, hyphens, underscores
3. Verify URL path matches file structure
4. Restart server after adding new files

## License

3-Clause BSD License (same as Caneka)

Copyright (c) Compare Basic. All rights reserved.

## Links

- **Caneka**: [github.com/comparebasic/caneka](https://github.com/comparebasic/caneka)
- **Compare Basic**: [comparebasic.com](https://comparebasic.com)
